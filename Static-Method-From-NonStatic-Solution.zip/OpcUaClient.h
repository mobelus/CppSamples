#pragma once

//#include "OpcUaEngineHeaders.h"


//#include "open62541.h"
#include <QtCore/qglobal.h>

#include "open62541.h"
//#include "opcua_global.h"

#include "objectids.h"
#include "qopcuatype.h"

//#include "testing_clock.h"


#include "ua_freeRTOS.h"


#include <cstring>
#include <string>
#include <QString>
#include <QVector>
#include <QUuid>
#include <QMap>
#include <QDateTime>
#include <QSharedPointer>

#include <QtCore/qloggingcategory.h>
#include <QtCore/qstringlist.h>
#include <QtCore/qurl.h>
#include <QtCore/quuid.h>
#include <QtCore/qdatetime.h>


#include <stdint.h>
#include <iostream>

#include <signal.h>
#include <stdlib.h>

#include <thread>
#include <chrono>
#include <atomic>
#include <functional>


UA_Boolean running = true;
UA_Logger logger = UA_Log_Stdout;


//*
std::string uaToString(UA_String uaString)
{
	std::string result;
	char *buf = new char[uaString.length + 1];
	memcpy(buf, uaString.data, uaString.length);
	buf[uaString.length] = 0;
	result = buf;

	return result;
}


QString uaToQString(UA_String uaString)
{
	QString result;
	char *buf = new char[uaString.length + 1];
	memcpy(buf, uaString.data, uaString.length);
	buf[uaString.length] = 0;
	result = buf;

	return result;
}
//*/







// https://github.com/node-opcua/node-opcua/issues/116

#if 0
static void
UA_Client_deleteMembers(UA_Client *client) {
	UA_Client_disconnect(client);
	/* Commented as UA_SecureChannel_deleteMembers already done
	 * in UA_Client_disconnect function */
	 //UA_SecureChannel_deleteMembersCleanup(&client->channel);
	if (client->connection.free)
		client->connection.free(&client->connection);
	UA_Connection_deleteMembers(&client->connection);
	UA_NodeId_deleteMembers(&client->authenticationToken);
	UA_String_deleteMembers(&client->endpointUrl);

	/* Delete the async service calls */
	UA_Client_AsyncService_removeAll(client, UA_STATUSCODE_BADSHUTDOWN);

	/* Delete the subscriptions */
#ifdef UA_ENABLE_SUBSCRIPTIONS
	UA_Client_Subscriptions_clean(client);
#endif

	/* Delete the timed work */
	UA_Timer_deleteMembers(&client->timer);

	/* Clean up the work queue */
	UA_WorkQueue_cleanup(&client->workQueue);

	UA_ClientConfig_deleteMembers(&client->config);
}



void
UA_Client_reset(UA_Client* client) {
	UA_Client_deleteMembers(client);
	UA_Client_init(client);
}

void
UA_Client_delete(UA_Client* client) {
	UA_Client_deleteMembers(client);
	UA_free(client);
}
#endif




//#include "client.h"
//UA_StatusCode UA_Client_run_iterate(UA_Client *client, UA_UInt16 timeout);


//
// from #include "testing_clock.h"
//


/* To avoid zero timestamp value in header, the testingClock
 * is assigned with non-zero timestamp to pass unit tests */
UA_DateTime testingClock = 0x5C8F735D;

/*
UA_DateTime UA_DateTime_now(void) {
	return testingClock;
}
*/
/*
UA_DateTime UA_DateTime_nowMonotonic(void) {
	return testingClock;
}
*/
/*
UA_DateTime UA_DateTime_localTimeUtcOffset(void) {
	return 0;
}
*/
void
UA_fakeSleep(UA_UInt32 duration) {
	testingClock += duration * UA_DATETIME_MSEC;
}

/* 1 millisecond = 1,000,000 Nanoseconds */
#define NANO_SECOND_MULTIPLIER 1000000

void
UA_realSleep(UA_UInt32 duration) {
#ifdef _WIN32
	Sleep(duration);
#else
	UA_UInt32 sec = duration / 1000;
	UA_UInt32 ns = (duration % 1000) * NANO_SECOND_MULTIPLIER;
	struct timespec sleepValue;
	sleepValue.tv_sec = sec;
	sleepValue.tv_nsec = ns;
	nanosleep(&sleepValue, NULL);
#endif
}

void
UA_comboSleep(unsigned long duration) {
	UA_fakeSleep((UA_UInt32)duration);
	UA_realSleep((UA_UInt32)duration);
}


//#ifdef OPCUA_LIBRARY
//#	define OPCUA_EXPORT Q_DECL_EXPORT
//#else
//#	define OPCUA_EXPORT Q_DECL_IMPORT
//#endif

UA_NodeId nodeIdFromQString(const QString &name)
{
	const int semicolonIndex = name.indexOf(';');
	if (semicolonIndex <= 0) {
		//qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "Unable to split node id string: %s", qUtf8Printable(name));
		return UA_NODEID_NULL;
	}
	QStringRef namespaceString = name.leftRef(semicolonIndex);
	if (namespaceString.length() <= 3 || !namespaceString.startsWith(QLatin1String("ns="))) {
		//qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "Not a valid index string in node id string: %s", qUtf8Printable(name));
		return UA_NODEID_NULL;
	}
	namespaceString = namespaceString.mid(3); // Remove "ns="
	QStringRef identifierString = name.midRef(semicolonIndex + 1);
	if (identifierString.length() <= 2) {
		//qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "There is no identifier in node id string: %s", qUtf8Printable(name));
		return UA_NODEID_NULL;
	}
	char identifierType;
	if (identifierString.startsWith(QLatin1String("s=")))
		identifierType = 's';
	else if (identifierString.startsWith(QLatin1String("i=")))
		identifierType = 'i';
	else if (identifierString.startsWith(QLatin1String("g=")))
		identifierType = 'g';
	else if (identifierString.startsWith(QLatin1String("b=")))
		identifierType = 'b';
	else {
		//qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "There is no valid identifier type in node id string: %s", qUtf8Printable(name));
		return UA_NODEID_NULL;
	}
	identifierString = identifierString.mid(2); // Remove identifier type
	UA_NodeId uaNodeId;
	UA_NodeId_init(&uaNodeId);
	bool ok = false;
	UA_UInt16 index = static_cast<UA_UInt16>(namespaceString.toUInt(&ok));
	if (!ok) {
		//qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "Not a valid namespace index in node id string: %s", qUtf8Printable(name));
		return UA_NODEID_NULL;
	}
	switch (identifierType) {
	case 'i': {
		bool isNumber;
		UA_UInt32 identifier = static_cast<UA_UInt32>(identifierString.toUInt(&isNumber));
		if (isNumber)
			return UA_NODEID_NUMERIC(index, identifier);
		else
			//qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "%s does not contain a valid numeric identifier", qUtf8Printable(name));
		break;
	}
	case 's': {
		if (identifierString.length() > 0)
			return UA_NODEID_STRING_ALLOC(index, identifierString.toUtf8().constData());
		else
			//qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "%s does not contain a valid string identifier", qUtf8Printable(name));
		break;
	}
	case 'g': {
		QUuid uuid(identifierString.toString());
		if (uuid.isNull()) {
			//qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "%s does not contain a valid guid identifier", qUtf8Printable(name));
		}
		UA_Guid guid;
		guid.data1 = uuid.data1;
		guid.data2 = uuid.data2;
		guid.data3 = uuid.data3;
		std::memcpy(guid.data4, uuid.data4, sizeof(uuid.data4));
		return UA_NODEID_GUID(index, guid);
	}
	case 'b': {
		const QByteArray temp = QByteArray::fromBase64(identifierString.toLocal8Bit());
		if (temp.size() > 0) {
			return UA_NODEID_BYTESTRING_ALLOC(index, temp.data());
		}
		else
			//qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "%s does not contain a valid byte string identifier", qUtf8Printable(name));
		break;
	}
	default:
		break;
		//qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "Could not parse node id: %s", qUtf8Printable(name));
	}
	return UA_NODEID_NULL;
}

QString nodeIdToQString(UA_NodeId id)
{
	QString result = QString::fromLatin1("ns=%1;").arg(id.namespaceIndex);
	switch (id.identifierType) {
	case UA_NODEIDTYPE_NUMERIC:
		result.append(QString::fromLatin1("i=%1").arg(id.identifier.numeric));
		break;
	case UA_NODEIDTYPE_STRING:
		result.append(QLatin1String("s="));
		result.append(QString::fromLocal8Bit(reinterpret_cast<char *>(id.identifier.string.data),
			id.identifier.string.length));
		break;
	case UA_NODEIDTYPE_GUID: {
		const UA_Guid &src = id.identifier.guid;
		const QUuid uuid(src.data1, src.data2, src.data3, src.data4[0], src.data4[1], src.data4[2],
			src.data4[3], src.data4[4], src.data4[5], src.data4[6], src.data4[7]);
		result.append(QStringLiteral("g=")).append(uuid.toString().midRef(1, 36)); // Remove enclosing {...}
		break;
	}
	case UA_NODEIDTYPE_BYTESTRING: {
		const QByteArray temp(reinterpret_cast<char *>(id.identifier.byteString.data), id.identifier.byteString.length);
		result.append(QStringLiteral("b=")).append(temp.toBase64());
		break;
	}
	default:
		//qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "Open62541 Utils: Could not convert UA_NodeId to QString");
		result.clear();
	}
	return result;
}





template<typename TARGETTYPE, typename UATYPE>
QVariant scalarToQVariant(UATYPE *data, QMetaType::Type type)
{
	return QVariant(type, reinterpret_cast<TARGETTYPE *>(data));
}
template<>
QVariant scalarToQVariant<QString, UA_String>(UA_String *data, QMetaType::Type type)
{
	Q_UNUSED(type)
		UA_String *uaStr = static_cast<UA_String *>(data);
	return QVariant(QString::fromUtf8(reinterpret_cast<char *>(uaStr->data), uaStr->length));
}
template<>
QVariant scalarToQVariant<QByteArray, UA_ByteString>(UA_ByteString *data, QMetaType::Type type)
{
	Q_UNUSED(type)
		UA_ByteString *uaBs = static_cast<UA_ByteString *>(data);
	return QVariant(QByteArray(reinterpret_cast<char *>(uaBs->data), uaBs->length));
}
//*
template<>
QVariant scalarToQVariant<QOpcUa::QLocalizedText, UA_LocalizedText>(UA_LocalizedText *data, QMetaType::Type type)
{
	Q_UNUSED(type)
		QOpcUa::QLocalizedText lt;
	lt.locale = scalarToQVariant<QString, UA_String>(&(data->locale), QMetaType::Type::QString).toString();
	lt.text = scalarToQVariant<QString, UA_String>(&(data->text), QMetaType::Type::QString).toString();
	return QVariant::fromValue(lt);
}
//*/
template<>
QVariant scalarToQVariant<QString, UA_NodeId>(UA_NodeId *data, QMetaType::Type type)
{
	Q_UNUSED(type)
		UA_NodeId *uan = static_cast<UA_NodeId *>(data);
	return nodeIdToQString(*uan);
}
template<>
QVariant scalarToQVariant<QDateTime, UA_DateTime>(UA_DateTime *data, QMetaType::Type type)
{
	Q_UNUSED(type)
		// OPC-UA part 3, Table C.9
		const QDateTime epochStart(QDate(1601, 1, 1), QTime(0, 0), Qt::UTC);
	return QVariant(epochStart.addMSecs(*static_cast<UA_DateTime *>(data) * UA_DATETIME_TO_MSEC).toLocalTime());
}
template<>
QVariant scalarToQVariant<QUuid, UA_Guid>(UA_Guid *data, QMetaType::Type type)
{
	Q_UNUSED(type)
		return QUuid(data->data1, data->data2, data->data3, data->data4[0], data->data4[1], data->data4[2],
			data->data4[3], data->data4[4], data->data4[5], data->data4[6], data->data4[7]);
}
template<>
QVariant scalarToQVariant<QOpcUa::QQualifiedName, UA_QualifiedName>(UA_QualifiedName *data, QMetaType::Type type)
{
	Q_UNUSED(type);
	QOpcUa::QQualifiedName temp;
	temp.namespaceIndex = data->namespaceIndex;
	temp.name = scalarToQVariant<QString, UA_String>(&(data->name), QMetaType::Type::QString).toString();
	return QVariant::fromValue(temp);
}
template <>
QVariant scalarToQVariant<QVariant, UA_ExtensionObject>(UA_ExtensionObject *data, QMetaType::Type type)
{
	bool success = false;
	QVariant result = QVariant();
	Q_UNUSED(type);
/*
	if (data->content.encoded.typeId.identifierType != UA_NODEIDTYPE_NUMERIC ||
		data->content.encoded.typeId.namespaceIndex != 0 ||
		data->encoding != UA_EXTENSIONOBJECT_ENCODED_BYTESTRING) {
		qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "Unsupported extension object type");
		return QVariant();
	}
	const char *buffer = reinterpret_cast<const char *>(data->content.encoded.body.data);
	size_t length = data->content.encoded.body.length;
	QOpcUaBinaryDataEncoding::TypeEncodingId objType = static_cast<QOpcUaBinaryDataEncoding::TypeEncodingId>(data->content.encoded.typeId.identifier.numeric);
	switch (objType) {
	case QOpcUaBinaryDataEncoding::TypeEncodingId::EUInformation:
		result = QVariant::fromValue(QOpcUaBinaryDataEncoding::decode<QOpcUa::QEUInformation>(buffer, length, success));
		break;
	case QOpcUaBinaryDataEncoding::TypeEncodingId::Range:
		result = QVariant::fromValue(QOpcUaBinaryDataEncoding::decode<QOpcUa::QRange>(buffer, length, success));
		break;
	case QOpcUaBinaryDataEncoding::TypeEncodingId::ComplexNumber:
		result = QVariant::fromValue(QOpcUaBinaryDataEncoding::decode<QOpcUa::QComplexNumber>(buffer, length, success));
		break;
	case QOpcUaBinaryDataEncoding::TypeEncodingId::DoubleComplexNumber:
		result = QVariant::fromValue(QOpcUaBinaryDataEncoding::decode<QOpcUa::QDoubleComplexNumber>(buffer, length, success));
		break;
	case QOpcUaBinaryDataEncoding::TypeEncodingId::AxisInformation:
		result = QVariant::fromValue(QOpcUaBinaryDataEncoding::decode<QOpcUa::QAxisInformation>(buffer, length, success));
		break;
	case QOpcUaBinaryDataEncoding::TypeEncodingId::XV:
		result = QVariant::fromValue(QOpcUaBinaryDataEncoding::decode<QOpcUa::QXValue>(buffer, length, success));
		break;
	default:
		qCWarning(QT_OPCUA_PLUGINS_OPEN62541, "Unknown extension object type: ns=0;i=%d", data->content.encoded.typeId.identifier.numeric);
		return QVariant();
	}
*/
	if (success)
		return result;
	else
		return QVariant();
}



template<typename TARGETTYPE, typename UATYPE>
QVariant arrayToQVariant(const UA_Variant &var, QMetaType::Type type)
{
	if (var.arrayLength > 1) {
		QVariantList list;
		for (size_t i = 0; i < var.arrayLength; ++i) {
			UATYPE *temp = static_cast<UATYPE *>(var.data);
			list.append(scalarToQVariant<TARGETTYPE, UATYPE>(&temp[i], type));
		}
		return list;
	}
	UATYPE *temp = static_cast<UATYPE *>(var.data);
	return scalarToQVariant<TARGETTYPE, UATYPE>(temp, type);
}


//*
template<typename TARGETTYPE, typename QTTYPE>
void scalarFromQVariant(const QVariant &var, TARGETTYPE *ptr)
{
	*ptr = static_cast<TARGETTYPE>(var.value<QTTYPE>());
}

template<>
void scalarFromQVariant<UA_DateTime, QDateTime>(const QVariant &var, UA_DateTime *ptr)
{
	// OPC-UA part 3, Table C.9
	const QDateTime uaEpochStart(QDate(1601, 1, 1), QTime(0, 0), Qt::UTC);
	*ptr = UA_MSEC_TO_DATETIME * (var.toDateTime().toMSecsSinceEpoch() - uaEpochStart.toMSecsSinceEpoch());
}

template<>
void scalarFromQVariant<UA_String, QString>(const QVariant &var, UA_String *ptr)
{
	UA_String tmpValue = UA_String_fromChars(var.toString().toUtf8().constData());
	UA_String_copy(&tmpValue, ptr);
	UA_String_deleteMembers(&tmpValue);
}

template<>
void scalarFromQVariant<UA_LocalizedText, QOpcUa::QLocalizedText>(const QVariant &var, UA_LocalizedText *ptr)
{
	QOpcUa::QLocalizedText lt = var.value<QOpcUa::QLocalizedText>();
	scalarFromQVariant<UA_String, QString>(lt.locale, &(ptr->locale));
	scalarFromQVariant<UA_String, QString>(lt.text, &(ptr->text));
}
template<>
void scalarFromQVariant<UA_ByteString, QByteArray>(const QVariant &var, UA_ByteString *ptr)
{
	QByteArray arr = var.toByteArray();
	UA_ByteString tmpValue;
	UA_ByteString_init(&tmpValue);
	tmpValue.length = arr.length();
	tmpValue.data = reinterpret_cast<UA_Byte *>(arr.data());
	UA_ByteString_copy(&tmpValue, ptr);
}
template<>
void scalarFromQVariant<UA_NodeId, QString>(const QVariant &var, UA_NodeId *ptr)
{
	UA_NodeId tmpValue = nodeIdFromQString(var.toString());
	UA_NodeId_copy(&tmpValue, ptr);
	UA_NodeId_deleteMembers(&tmpValue);
}

template<>
void scalarFromQVariant<UA_QualifiedName, QOpcUa::QQualifiedName>(const QVariant &var, UA_QualifiedName *ptr)
{
	QOpcUa::QQualifiedName temp = var.value<QOpcUa::QQualifiedName>();
	ptr->namespaceIndex = temp.namespaceIndex;
	scalarFromQVariant<UA_String, QString>(temp.name, &(ptr->name));
}
template<>
void scalarFromQVariant<UA_Guid, QUuid>(const QVariant &var, UA_Guid *ptr)
{
	const QUuid uuid = var.toUuid();
	ptr->data1 = uuid.data1;
	ptr->data2 = uuid.data2;
	ptr->data3 = uuid.data3;
	std::memcpy(ptr->data4, uuid.data4, sizeof(uuid.data4));
}


template<typename TARGETTYPE, typename QTTYPE>
UA_Variant arrayFromQVariant(const QVariant &var, const UA_DataType *type)
{
	UA_Variant open62541value;
	UA_Variant_init(&open62541value);
	if (var.type() == QVariant::List)
	{
		const QVariantList list = var.toList();
		if (list.isEmpty())
			return open62541value;
		TARGETTYPE *arr = static_cast<TARGETTYPE *>(UA_Array_new(list.size(), type));
		for (int i = 0; i < list.size(); ++i)
		{
			//scalarFromQVariant<TARGETTYPE, QTTYPE>(list[i], &arr[i]);
		}
		UA_Variant_setArray(&open62541value, arr, list.size(), type);
		return open62541value;
	}
	TARGETTYPE *temp = static_cast<TARGETTYPE *>(UA_new(type));
	
	//scalarFromQVariant<TARGETTYPE, QTTYPE>(var, temp);
	
	UA_Variant_setScalar(&open62541value, temp, type);
	return open62541value;
}
//*/





//////////////////////////////
// OpcUaEngineMultiPrivate
//////////////////////////////

class OpcUaEngineMultiPrivate
{
public:
	OpcUaEngineMultiPrivate(void);
	~OpcUaEngineMultiPrivate(void);

	UA_StatusCode executeMethod(const UA_NodeId *sessionId, void *sessionHandle,
		const UA_NodeId *methodId, void *methodContext,
		const UA_NodeId *objectId, void *objectContext,
		size_t inputSize, const UA_Variant *input,
		size_t outputSize, UA_Variant *output);

};

//////////////////////////////
// OpcUaEngineMulti
//////////////////////////////

class OpcUaEngineMulti
{
private:
	UA_Client *_client;

	bool _running;
	//const std::string _strConnection = "opc.tcp://D-OBROSOV:4840/"; //"opc.tcp://127.0.0.1:4840";
	const std::string _strConnection = "opc.tcp://127.0.0.1:4840";

	// QStringList 

public:


	void fullConnectionCycle();


	void connectToOpcUaServer();

	void start();
	void stop();

	// handlers

	//static void deleteSubscriptionCallback(UA_Client *client, UA_UInt32 subscriptionId, void *subscriptionContext);
	//static void subscriptionInactivityCallback(UA_Client *client, UA_UInt32 subId, void *subContext);
	void convertBrowseResult(UA_BrowseResult *src, quint32 referencesSize, QVector<UA_ReferenceDescription> &dst);

	//UA_NodeId getNodeIdFromLogicalLevel(UA_Client *client, std::string logicalLevelPointName, std::string pointPropertyName);
	UA_NodeId getNodeIdFromServerTree(
		UA_Client *client,
		int uaBrowseFolder,
		UA_BrowseResultMask uaBrowseMask,
		std::string uaBrowseFolderName
		//, std::string logicalLevelPointName
		//, std::string pointPropertyName
	);

	UA_NodeId findChildWithBrowseName(
		UA_Client *m_uaclient,
		UA_NodeId id,
		UA_NodeIdType referenceType,
		UA_BrowseResultMask nodeClassMask,
		std::string strBrowsNameToFind
	);


	// main callback

	static bool _isConnectionReady; //static std::atomic<bool> _isConnectionReady;
	static void stateCallback(UA_Client *client, UA_ClientState clientState);
	//	static void stopHandler(int sign);


	void waitForConnection();

	// 
	void ck_assert_uint_eq(int l, int r) { if (l != r) return; }
	void ck_assert_uint_eq(bool l, bool r) { if (l != r) return; }
	void ck_assert_uint_eq(UA_StatusCode l, int r) { if (l != r) return; }
	void ck_assert_uint_eq(size_t l, int r) { if (l != r) return; }

	UA_Boolean notificationReceived = false;
	UA_UInt32 countNotificationReceived = 0;
	UA_Double publishingInterval = 500.0;

	//
	// Single Part
	//

	void startSingleSubscribition();

	static void handler_AudiChanged(UA_Client *client, UA_UInt32 subId, void *subContext, UA_UInt32 monId, void *monContext, UA_DataValue *value);
	static void handler_Pt1BlockChanged(UA_Client *client, UA_UInt32 subId, void *subContext, UA_UInt32 monId, void *monContext, UA_DataValue *value);

	//
	// Multi Part
	//

	void startMultySubscribition();

	static void handler_dataChanged(UA_Client *client, UA_UInt32 subId, void *subContext, UA_UInt32 monId, void *monContext, UA_DataValue *value);

	
	void myFunc1();
	void myFunc2(int var);
	int myVar1;
	int myVar2;

	void superPuperFunction(int a);
	//void funBlock(std::string a);
	//void funPos(std::string a);

	//typedef struct { void(*ptr)(int); } Func;
	//Func vf = { &fun };

	struct VoidTypeData
	{
		enum VoidType { TYPE_STRING = 0 , TYPE_FUNCTION = 1 } voidType;

		OpcUaEngineMulti* thisPtr;
		std::string strName;
		void (OpcUaEngineMulti::*fptr)(int);
		//std::function< void (int) > fptr;
	};


	struct UUidPair
	{
		UUidPair() : _id(0), _idstr("{00000000-0000-0000-0000-000000000000}") { }
		UUidPair(QUuid id)      { _id = id; _idstr = id.toString().toStdString(); }
		UUidPair(std::string idstr) { _idstr = idstr; _id = QUuid::fromString(QString(idstr.c_str())); }
		UUidPair(QUuid id, std::string idstr) { _id = id; _idstr = idstr; }

		QUuid _id; std::string _idstr;
	};
	static QVector<UUidPair> vecUidStr;
	static QVector<UUidPair> create_vec()
	{
		QVector<UUidPair> v;
		return v;
	}


	static QMap<QUuid, VoidTypeData> mapFuncs;
	static QMap<QUuid, VoidTypeData> create_map()
	{
		QMap<QUuid, VoidTypeData> m;
		//VoidTypeData vtd;
		//m[QUuid("{00000000-0000-0000-0000-000000000000}")] = vtd;
		return m;
	}

	//QUuid* qtuuidptr;

}; // OpcUaEngineMulti



