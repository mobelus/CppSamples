

#include <string>

//namespace OpcUa
//{
enum class ObjectId : uint32_t
{
	Null = 0,
	Boolean = 1,
	SByte = 2,
	Byte = 3,
	Int16 = 4,
	UInt16 = 5,
	Int32 = 6,
	UInt32 = 7,
	Int64 = 8,
	UInt64 = 9,
	Float = 10,
	Double = 11,
	String = 12,
	DateTime = 13,
	Guid = 14,
	ByteString = 15,
	XmlElement = 16,
	NodeId = 17,
	ExpandedNodeId = 18,
	StatusCode = 19,
	QualifiedName = 20,
	LocalizedText = 21,
	Structure = 22,
	DataValue = 23,
	BaseDataType = 24,
	DiagnosticInfo = 25,
	Number = 26,
	Integer = 27,
	UInteger = 28,
	Enumeration = 29,
	Image = 30,
	References = 31,
	NonHierarchicalReferences = 32,
	HierarchicalReferences = 33,
	HasChild = 34,
	Organizes = 35,
	HasEventSource = 36,
	HasModellingRule = 37,
	HasEncoding = 38,
	HasDescription = 39,
	HasTypeDefinition = 40,
	GeneratesEvent = 41,
	Aggregates = 44,
	HasSubtype = 45,
	HasProperty = 46,
	HasComponent = 47,
	HasNotifier = 48,
	HasOrderedComponent = 49,
	FromState = 51,
	ToState = 52,
	HasCause = 53,
	HasEffect = 54,
	HasHistoricalConfiguration = 56,
	BaseObjectType = 58,
	FolderType = 61,
	BaseVariableType = 62,
	BaseDataVariableType = 63,
	PropertyType = 68,
	DataTypeDescriptionType = 69,
	DataTypeDictionaryType = 72,
	DataTypeSystemType = 75,
	DataTypeEncodingType = 76,
	ModellingRuleType = 77,
	ModellingRule_Mandatory = 78,
	ModellingRule_MandatoryShared = 79,
	ModellingRule_Optional = 80,
	ModellingRule_ExposesItsArray = 83,
	RootFolder = 84,
	ObjectsFolder = 85,
	TypesFolder = 86,
	ViewsFolder = 87,
	ObjectTypesFolder = 88,
	VariableTypesFolder = 89,
	DataTypesFolder = 90,
	ReferenceTypesFolder = 91,
	XmlSchema_TypeSystem = 92,
	OPCBinarySchema_TypeSystem = 93,
	DataTypeDescriptionType_DataTypeVersion = 104,
	DataTypeDescriptionType_DictionaryFragment = 105,
	DataTypeDictionaryType_DataTypeVersion = 106,
	DataTypeDictionaryType_NamespaceUri = 107,
	ModellingRuleType_NamingRule = 111,
	ModellingRule_Mandatory_NamingRule = 112,
	ModellingRule_Optional_NamingRule = 113,
	ModellingRule_ExposesItsArray_NamingRule = 114,
	ModellingRule_MandatoryShared_NamingRule = 116,
	HasSubStateMachine = 117,
	NamingRuleType = 120,
	IdType = 256,
	NodeClass = 257,
	Node = 258,
	Node_Encoding_DefaultXml = 259,
	Node_Encoding_DefaultBinary = 260,
	ObjectNode = 261,
	ObjectNode_Encoding_DefaultXml = 262,
	ObjectNode_Encoding_DefaultBinary = 263,
	ObjectTypeNode = 264,
	ObjectTypeNode_Encoding_DefaultXml = 265,
	ObjectTypeNode_Encoding_DefaultBinary = 266,
	VariableNode = 267,
	VariableNode_Encoding_DefaultXml = 268,
	VariableNode_Encoding_DefaultBinary = 269,
	VariableTypeNode = 270,
	VariableTypeNode_Encoding_DefaultXml = 271,
	VariableTypeNode_Encoding_DefaultBinary = 272,
	ReferenceTypeNode = 273,
	ReferenceTypeNode_Encoding_DefaultXml = 274,
	ReferenceTypeNode_Encoding_DefaultBinary = 275,
	MethodNode = 276,
	MethodNode_Encoding_DefaultXml = 277,
	MethodNode_Encoding_DefaultBinary = 278,
	ViewNode = 279,
	ViewNode_Encoding_DefaultXml = 280,
	ViewNode_Encoding_DefaultBinary = 281,
	DataTypeNode = 282,
	DataTypeNode_Encoding_DefaultXml = 283,
	DataTypeNode_Encoding_DefaultBinary = 284,
	ReferenceNode = 285,
	ReferenceNode_Encoding_DefaultXml = 286,
	ReferenceNode_Encoding_DefaultBinary = 287,
	IntegerId = 288,
	Counter = 289,
	Duration = 290,
	NumericRange = 291,
	Time = 292,
	Date = 293,
	UtcTime = 294,
	LocaleId = 295,
	Argument = 296,
	Argument_Encoding_DefaultXml = 297,
	Argument_Encoding_DefaultBinary = 298,
	StatusResult = 299,
	StatusResult_Encoding_DefaultXml = 300,
	StatusResult_Encoding_DefaultBinary = 301,
	MessageSecurityMode = 302,
	UserTokenType = 303,
	UserTokenPolicy = 304,
	UserTokenPolicy_Encoding_DefaultXml = 305,
	UserTokenPolicy_Encoding_DefaultBinary = 306,
	ApplicationType = 307,
	ApplicationDescription = 308,
	ApplicationDescription_Encoding_DefaultXml = 309,
	ApplicationDescription_Encoding_DefaultBinary = 310,
	ApplicationInstanceCertificate = 311,
	EndpointDescription = 312,
	EndpointDescription_Encoding_DefaultXml = 313,
	EndpointDescription_Encoding_DefaultBinary = 314,
	SecurityTokenRequestType = 315,
	UserIdentityToken = 316,
	UserIdentityToken_Encoding_DefaultXml = 317,
	UserIdentityToken_Encoding_DefaultBinary = 318,
	AnonymousIdentityToken = 319,
	AnonymousIdentityToken_Encoding_DefaultXml = 320,
	AnonymousIdentityToken_Encoding_DefaultBinary = 321,
	UserNameIdentityToken = 322,
	UserNameIdentityToken_Encoding_DefaultXml = 323,
	UserNameIdentityToken_Encoding_DefaultBinary = 324,
	X509IdentityToken = 325,
	X509IdentityToken_Encoding_DefaultXml = 326,
	X509IdentityToken_Encoding_DefaultBinary = 327,
	EndpointConfiguration = 331,
	EndpointConfiguration_Encoding_DefaultXml = 332,
	EndpointConfiguration_Encoding_DefaultBinary = 333,
	ComplianceLevel = 334,
	SupportedProfile = 335,
	SupportedProfile_Encoding_DefaultXml = 336,
	SupportedProfile_Encoding_DefaultBinary = 337,
	BuildInfo = 338,
	BuildInfo_Encoding_DefaultXml = 339,
	BuildInfo_Encoding_DefaultBinary = 340,
	SoftwareCertificate = 341,
	SoftwareCertificate_Encoding_DefaultXml = 342,
	SoftwareCertificate_Encoding_DefaultBinary = 343,
	SignedSoftwareCertificate = 344,
	SignedSoftwareCertificate_Encoding_DefaultXml = 345,
	SignedSoftwareCertificate_Encoding_DefaultBinary = 346,
	AttributeWriteMask = 347,
	NodeAttributesMask = 348,
	NodeAttributes = 349,
	NodeAttributes_Encoding_DefaultXml = 350,
	NodeAttributes_Encoding_DefaultBinary = 351,
	ObjectAttributes = 352,
	ObjectAttributes_Encoding_DefaultXml = 353,
	ObjectAttributes_Encoding_DefaultBinary = 354,
	VariableAttributes = 355,
	VariableAttributes_Encoding_DefaultXml = 356,
	VariableAttributes_Encoding_DefaultBinary = 357,
	MethodAttributes = 358,
	MethodAttributes_Encoding_DefaultXml = 359,
	MethodAttributes_Encoding_DefaultBinary = 360,
	ObjectTypeAttributes = 361,
	ObjectTypeAttributes_Encoding_DefaultXml = 362,
	ObjectTypeAttributes_Encoding_DefaultBinary = 363,
	VariableTypeAttributes = 364,
	VariableTypeAttributes_Encoding_DefaultXml = 365,
	VariableTypeAttributes_Encoding_DefaultBinary = 366,
	ReferenceTypeAttributes = 367,
	ReferenceTypeAttributes_Encoding_DefaultXml = 368,
	ReferenceTypeAttributes_Encoding_DefaultBinary = 369,
	DataTypeAttributes = 370,
	DataTypeAttributes_Encoding_DefaultXml = 371,
	DataTypeAttributes_Encoding_DefaultBinary = 372,
	ViewAttributes = 373,
	ViewAttributes_Encoding_DefaultXml = 374,
	ViewAttributes_Encoding_DefaultBinary = 375,
	AddNodesItem = 376,
	AddNodesItem_Encoding_DefaultXml = 377,
	AddNodesItem_Encoding_DefaultBinary = 378,
	AddReferencesItem = 379,
	AddReferencesItem_Encoding_DefaultXml = 380,
	AddReferencesItem_Encoding_DefaultBinary = 381,
	DeleteNodesItem = 382,
	DeleteNodesItem_Encoding_DefaultXml = 383,
	DeleteNodesItem_Encoding_DefaultBinary = 384,
	DeleteReferencesItem = 385,
	DeleteReferencesItem_Encoding_DefaultXml = 386,
	DeleteReferencesItem_Encoding_DefaultBinary = 387,
	SessionAuthenticationToken = 388,
	RequestHeader = 389,
	RequestHeader_Encoding_DefaultXml = 390,
	RequestHeader_Encoding_DefaultBinary = 391,
	ResponseHeader = 392,
	ResponseHeader_Encoding_DefaultXml = 393,
	ResponseHeader_Encoding_DefaultBinary = 394,
	ServiceFault = 395,
	ServiceFault_Encoding_DefaultXml = 396,
	ServiceFault_Encoding_DefaultBinary = 397,
	EnumeratedTestType = 398,
	ScalarTestType = 399,
	ScalarTestType_Encoding_DefaultXml = 400,
	ScalarTestType_Encoding_DefaultBinary = 401,
	ArrayTestType = 402,
	ArrayTestType_Encoding_DefaultXml = 403,
	ArrayTestType_Encoding_DefaultBinary = 404,
	CompositeTestType = 405,
	CompositeTestType_Encoding_DefaultXml = 406,
	CompositeTestType_Encoding_DefaultBinary = 407,
	TestStackRequest = 408,
	TestStackRequest_Encoding_DefaultXml = 409,
	TestStackRequest_Encoding_DefaultBinary = 410,
	TestStackResponse = 411,
	TestStackResponse_Encoding_DefaultXml = 412,
	TestStackResponse_Encoding_DefaultBinary = 413,
	TestStackExRequest = 414,
	TestStackExRequest_Encoding_DefaultXml = 415,
	TestStackExRequest_Encoding_DefaultBinary = 416,
	TestStackExResponse = 417,
	TestStackExResponse_Encoding_DefaultXml = 418,
	TestStackExResponse_Encoding_DefaultBinary = 419,
	FindServersRequest = 420,
	FindServersRequest_Encoding_DefaultXml = 421,
	FindServersRequest_Encoding_DefaultBinary = 422,
	FindServersResponse = 423,
	FindServersResponse_Encoding_DefaultXml = 424,
	FindServersResponse_Encoding_DefaultBinary = 425,
	GetEndpointsRequest = 426,
	GetEndpointsRequest_Encoding_DefaultXml = 427,
	GetEndpointsRequest_Encoding_DefaultBinary = 428,
	GetEndpointsResponse = 429,
	GetEndpointsResponse_Encoding_DefaultXml = 430,
	GetEndpointsResponse_Encoding_DefaultBinary = 431,
	RegisteredServer = 432,
	RegisteredServer_Encoding_DefaultXml = 433,
	RegisteredServer_Encoding_DefaultBinary = 434,
	RegisterServerRequest = 435,
	RegisterServerRequest_Encoding_DefaultXml = 436,
	RegisterServerRequest_Encoding_DefaultBinary = 437,
	RegisterServerResponse = 438,
	RegisterServerResponse_Encoding_DefaultXml = 439,
	RegisterServerResponse_Encoding_DefaultBinary = 440,
	ChannelSecurityToken = 441,
	ChannelSecurityToken_Encoding_DefaultXml = 442,
	ChannelSecurityToken_Encoding_DefaultBinary = 443,
	OpenSecureChannelRequest = 444,
	OpenSecureChannelRequest_Encoding_DefaultXml = 445,
	OpenSecureChannelRequest_Encoding_DefaultBinary = 446,
	OpenSecureChannelResponse = 447,
	OpenSecureChannelResponse_Encoding_DefaultXml = 448,
	OpenSecureChannelResponse_Encoding_DefaultBinary = 449,
	CloseSecureChannelRequest = 450,
	CloseSecureChannelRequest_Encoding_DefaultXml = 451,
	CloseSecureChannelRequest_Encoding_DefaultBinary = 452,
	CloseSecureChannelResponse = 453,
	CloseSecureChannelResponse_Encoding_DefaultXml = 454,
	CloseSecureChannelResponse_Encoding_DefaultBinary = 455,
	SignatureData = 456,
	SignatureData_Encoding_DefaultXml = 457,
	SignatureData_Encoding_DefaultBinary = 458,
	CreateSessionRequest = 459,
	CreateSessionRequest_Encoding_DefaultXml = 460,
	CreateSessionRequest_Encoding_DefaultBinary = 461,
	CreateSessionResponse = 462,
	CreateSessionResponse_Encoding_DefaultXml = 463,
	CreateSessionResponse_Encoding_DefaultBinary = 464,
	ActivateSessionRequest = 465,
	ActivateSessionRequest_Encoding_DefaultXml = 466,
	ActivateSessionRequest_Encoding_DefaultBinary = 467,
	ActivateSessionResponse = 468,
	ActivateSessionResponse_Encoding_DefaultXml = 469,
	ActivateSessionResponse_Encoding_DefaultBinary = 470,
	CloseSessionRequest = 471,
	CloseSessionRequest_Encoding_DefaultXml = 472,
	CloseSessionRequest_Encoding_DefaultBinary = 473,
	CloseSessionResponse = 474,
	CloseSessionResponse_Encoding_DefaultXml = 475,
	CloseSessionResponse_Encoding_DefaultBinary = 476,
	CancelRequest = 477,
	CancelRequest_Encoding_DefaultXml = 478,
	CancelRequest_Encoding_DefaultBinary = 479,
	CancelResponse = 480,
	CancelResponse_Encoding_DefaultXml = 481,
	CancelResponse_Encoding_DefaultBinary = 482,
	AddNodesResult = 483,
	AddNodesResult_Encoding_DefaultXml = 484,
	AddNodesResult_Encoding_DefaultBinary = 485,
	AddNodesRequest = 486,
	AddNodesRequest_Encoding_DefaultXml = 487,
	AddNodesRequest_Encoding_DefaultBinary = 488,
	AddNodesResponse = 489,
	AddNodesResponse_Encoding_DefaultXml = 490,
	AddNodesResponse_Encoding_DefaultBinary = 491,
	AddReferencesRequest = 492,
	AddReferencesRequest_Encoding_DefaultXml = 493,
	AddReferencesRequest_Encoding_DefaultBinary = 494,
	AddReferencesResponse = 495,
	AddReferencesResponse_Encoding_DefaultXml = 496,
	AddReferencesResponse_Encoding_DefaultBinary = 497,
	DeleteNodesRequest = 498,
	DeleteNodesRequest_Encoding_DefaultXml = 499,
	DeleteNodesRequest_Encoding_DefaultBinary = 500,
	DeleteNodesResponse = 501,
	DeleteNodesResponse_Encoding_DefaultXml = 502,
	DeleteNodesResponse_Encoding_DefaultBinary = 503,
	DeleteReferencesRequest = 504,
	DeleteReferencesRequest_Encoding_DefaultXml = 505,
	DeleteReferencesRequest_Encoding_DefaultBinary = 506,
	DeleteReferencesResponse = 507,
	DeleteReferencesResponse_Encoding_DefaultXml = 508,
	DeleteReferencesResponse_Encoding_DefaultBinary = 509,
	BrowseDirection = 510,
	ViewDescription = 511,
	ViewDescription_Encoding_DefaultXml = 512,
	ViewDescription_Encoding_DefaultBinary = 513,
	BrowseDescription = 514,
	BrowseDescription_Encoding_DefaultXml = 515,
	BrowseDescription_Encoding_DefaultBinary = 516,
	BrowseResultMask = 517,
	ReferenceDescription = 518,
	ReferenceDescription_Encoding_DefaultXml = 519,
	ReferenceDescription_Encoding_DefaultBinary = 520,
	ContinuationPoint = 521,
	BrowseResult = 522,
	BrowseResult_Encoding_DefaultXml = 523,
	BrowseResult_Encoding_DefaultBinary = 524,
	BrowseRequest = 525,
	BrowseRequest_Encoding_DefaultXml = 526,
	BrowseRequest_Encoding_DefaultBinary = 527,
	BrowseResponse = 528,
	BrowseResponse_Encoding_DefaultXml = 529,
	BrowseResponse_Encoding_DefaultBinary = 530,
	BrowseNextRequest = 531,
	BrowseNextRequest_Encoding_DefaultXml = 532,
	BrowseNextRequest_Encoding_DefaultBinary = 533,
	BrowseNextResponse = 534,
	BrowseNextResponse_Encoding_DefaultXml = 535,
	BrowseNextResponse_Encoding_DefaultBinary = 536,
	RelativePathElement = 537,
	RelativePathElement_Encoding_DefaultXml = 538,
	RelativePathElement_Encoding_DefaultBinary = 539,
	RelativePath = 540,
	RelativePath_Encoding_DefaultXml = 541,
	RelativePath_Encoding_DefaultBinary = 542,
	BrowsePath = 543,
	BrowsePath_Encoding_DefaultXml = 544,
	BrowsePath_Encoding_DefaultBinary = 545,
	BrowsePathTarget = 546,
	BrowsePathTarget_Encoding_DefaultXml = 547,
	BrowsePathTarget_Encoding_DefaultBinary = 548,
	BrowsePathResult = 549,
	BrowsePathResult_Encoding_DefaultXml = 550,
	BrowsePathResult_Encoding_DefaultBinary = 551,
	TranslateBrowsePathsToNodeIdsRequest = 552,
	TranslateBrowsePathsToNodeIdsRequest_Encoding_DefaultXml = 553,
	TranslateBrowsePathsToNodeIdsRequest_Encoding_DefaultBinary = 554,
	TranslateBrowsePathsToNodeIdsResponse = 555,
	TranslateBrowsePathsToNodeIdsResponse_Encoding_DefaultXml = 556,
	TranslateBrowsePathsToNodeIdsResponse_Encoding_DefaultBinary = 557,
	RegisterNodesRequest = 558,
	RegisterNodesRequest_Encoding_DefaultXml = 559,
	RegisterNodesRequest_Encoding_DefaultBinary = 560,
	RegisterNodesResponse = 561,
	RegisterNodesResponse_Encoding_DefaultXml = 562,
	RegisterNodesResponse_Encoding_DefaultBinary = 563,
	UnregisterNodesRequest = 564,
	UnregisterNodesRequest_Encoding_DefaultXml = 565,
	UnregisterNodesRequest_Encoding_DefaultBinary = 566,
	UnregisterNodesResponse = 567,
	UnregisterNodesResponse_Encoding_DefaultXml = 568,
	UnregisterNodesResponse_Encoding_DefaultBinary = 569,
	QueryDataDescription = 570,
	QueryDataDescription_Encoding_DefaultXml = 571,
	QueryDataDescription_Encoding_DefaultBinary = 572,
	NodeTypeDescription = 573,
	NodeTypeDescription_Encoding_DefaultXml = 574,
	NodeTypeDescription_Encoding_DefaultBinary = 575,
	FilterOperator = 576,
	QueryDataSet = 577,
	QueryDataSet_Encoding_DefaultXml = 578,
	QueryDataSet_Encoding_DefaultBinary = 579,
	NodeReference = 580,
	NodeReference_Encoding_DefaultXml = 581,
	NodeReference_Encoding_DefaultBinary = 582,
	ContentFilterElement = 583,
	ContentFilterElement_Encoding_DefaultXml = 584,
	ContentFilterElement_Encoding_DefaultBinary = 585,
	ContentFilter = 586,
	ContentFilter_Encoding_DefaultXml = 587,
	ContentFilter_Encoding_DefaultBinary = 588,
	FilterOperand = 589,
	FilterOperand_Encoding_DefaultXml = 590,
	FilterOperand_Encoding_DefaultBinary = 591,
	ElementOperand = 592,
	ElementOperand_Encoding_DefaultXml = 593,
	ElementOperand_Encoding_DefaultBinary = 594,
	LiteralOperand = 595,
	LiteralOperand_Encoding_DefaultXml = 596,
	LiteralOperand_Encoding_DefaultBinary = 597,
	AttributeOperand = 598,
	AttributeOperand_Encoding_DefaultXml = 599,
	AttributeOperand_Encoding_DefaultBinary = 600,
	SimpleAttributeOperand = 601,
	SimpleAttributeOperand_Encoding_DefaultXml = 602,
	SimpleAttributeOperand_Encoding_DefaultBinary = 603,
	ContentFilterElementResult = 604,
	ContentFilterElementResult_Encoding_DefaultXml = 605,
	ContentFilterElementResult_Encoding_DefaultBinary = 606,
	ContentFilterResult = 607,
	ContentFilterResult_Encoding_DefaultXml = 608,
	ContentFilterResult_Encoding_DefaultBinary = 609,
	ParsingResult = 610,
	ParsingResult_Encoding_DefaultXml = 611,
	ParsingResult_Encoding_DefaultBinary = 612,
	QueryFirstRequest = 613,
	QueryFirstRequest_Encoding_DefaultXml = 614,
	QueryFirstRequest_Encoding_DefaultBinary = 615,
	QueryFirstResponse = 616,
	QueryFirstResponse_Encoding_DefaultXml = 617,
	QueryFirstResponse_Encoding_DefaultBinary = 618,
	QueryNextRequest = 619,
	QueryNextRequest_Encoding_DefaultXml = 620,
	QueryNextRequest_Encoding_DefaultBinary = 621,
	QueryNextResponse = 622,
	QueryNextResponse_Encoding_DefaultXml = 623,
	QueryNextResponse_Encoding_DefaultBinary = 624,
	TimestampsToReturn = 625,
	ReadValueId = 626,
	ReadValueId_Encoding_DefaultXml = 627,
	ReadValueId_Encoding_DefaultBinary = 628,
	ReadRequest = 629,
	ReadRequest_Encoding_DefaultXml = 630,
	ReadRequest_Encoding_DefaultBinary = 631,
	ReadResponse = 632,
	ReadResponse_Encoding_DefaultXml = 633,
	ReadResponse_Encoding_DefaultBinary = 634,
	HistoryReadValueId = 635,
	HistoryReadValueId_Encoding_DefaultXml = 636,
	HistoryReadValueId_Encoding_DefaultBinary = 637,
	HistoryReadResult = 638,
	HistoryReadResult_Encoding_DefaultXml = 639,
	HistoryReadResult_Encoding_DefaultBinary = 640,
	HistoryReadDetails = 641,
	HistoryReadDetails_Encoding_DefaultXml = 642,
	HistoryReadDetails_Encoding_DefaultBinary = 643,
	ReadEventDetails = 644,
	ReadEventDetails_Encoding_DefaultXml = 645,
	ReadEventDetails_Encoding_DefaultBinary = 646,
	ReadRawModifiedDetails = 647,
	ReadRawModifiedDetails_Encoding_DefaultXml = 648,
	ReadRawModifiedDetails_Encoding_DefaultBinary = 649,
	ReadProcessedDetails = 650,
	ReadProcessedDetails_Encoding_DefaultXml = 651,
	ReadProcessedDetails_Encoding_DefaultBinary = 652,
	ReadAtTimeDetails = 653,
	ReadAtTimeDetails_Encoding_DefaultXml = 654,
	ReadAtTimeDetails_Encoding_DefaultBinary = 655,
	HistoryData = 656,
	HistoryData_Encoding_DefaultXml = 657,
	HistoryData_Encoding_DefaultBinary = 658,
	HistoryEvent = 659,
	HistoryEvent_Encoding_DefaultXml = 660,
	HistoryEvent_Encoding_DefaultBinary = 661,
	HistoryReadRequest = 662,
	HistoryReadRequest_Encoding_DefaultXml = 663,
	HistoryReadRequest_Encoding_DefaultBinary = 664,
	HistoryReadResponse = 665,
	HistoryReadResponse_Encoding_DefaultXml = 666,
	HistoryReadResponse_Encoding_DefaultBinary = 667,
	WriteValue = 668,
	WriteValue_Encoding_DefaultXml = 669,
	WriteValue_Encoding_DefaultBinary = 670,
	WriteRequest = 671,
	WriteRequest_Encoding_DefaultXml = 672,
	WriteRequest_Encoding_DefaultBinary = 673,
	WriteResponse = 674,
	WriteResponse_Encoding_DefaultXml = 675,
	WriteResponse_Encoding_DefaultBinary = 676,
	HistoryUpdateDetails = 677,
	HistoryUpdateDetails_Encoding_DefaultXml = 678,
	HistoryUpdateDetails_Encoding_DefaultBinary = 679,
	UpdateDataDetails = 680,
	UpdateDataDetails_Encoding_DefaultXml = 681,
	UpdateDataDetails_Encoding_DefaultBinary = 682,
	UpdateEventDetails = 683,
	UpdateEventDetails_Encoding_DefaultXml = 684,
	UpdateEventDetails_Encoding_DefaultBinary = 685,
	DeleteRawModifiedDetails = 686,
	DeleteRawModifiedDetails_Encoding_DefaultXml = 687,
	DeleteRawModifiedDetails_Encoding_DefaultBinary = 688,
	DeleteAtTimeDetails = 689,
	DeleteAtTimeDetails_Encoding_DefaultXml = 690,
	DeleteAtTimeDetails_Encoding_DefaultBinary = 691,
	DeleteEventDetails = 692,
	DeleteEventDetails_Encoding_DefaultXml = 693,
	DeleteEventDetails_Encoding_DefaultBinary = 694,
	HistoryUpdateResult = 695,
	HistoryUpdateResult_Encoding_DefaultXml = 696,
	HistoryUpdateResult_Encoding_DefaultBinary = 697,
	HistoryUpdateRequest = 698,
	HistoryUpdateRequest_Encoding_DefaultXml = 699,
	HistoryUpdateRequest_Encoding_DefaultBinary = 700,
	HistoryUpdateResponse = 701,
	HistoryUpdateResponse_Encoding_DefaultXml = 702,
	HistoryUpdateResponse_Encoding_DefaultBinary = 703,
	CallMethodRequest = 704,
	CallMethodRequest_Encoding_DefaultXml = 705,
	CallMethodRequest_Encoding_DefaultBinary = 706,
	CallMethodResult = 707,
	CallMethodResult_Encoding_DefaultXml = 708,
	CallMethodResult_Encoding_DefaultBinary = 709,
	CallRequest = 710,
	CallRequest_Encoding_DefaultXml = 711,
	CallRequest_Encoding_DefaultBinary = 712,
	CallResponse = 713,
	CallResponse_Encoding_DefaultXml = 714,
	CallResponse_Encoding_DefaultBinary = 715,
	MonitoringMode = 716,
	DataChangeTrigger = 717,
	DeadbandType = 718,
	MonitoringFilter = 719,
	MonitoringFilter_Encoding_DefaultXml = 720,
	MonitoringFilter_Encoding_DefaultBinary = 721,
	DataChangeFilter = 722,
	DataChangeFilter_Encoding_DefaultXml = 723,
	DataChangeFilter_Encoding_DefaultBinary = 724,
	EventFilter = 725,
	EventFilter_Encoding_DefaultXml = 726,
	EventFilter_Encoding_DefaultBinary = 727,
	AggregateFilter = 728,
	AggregateFilter_Encoding_DefaultXml = 729,
	AggregateFilter_Encoding_DefaultBinary = 730,
	MonitoringFilterResult = 731,
	MonitoringFilterResult_Encoding_DefaultXml = 732,
	MonitoringFilterResult_Encoding_DefaultBinary = 733,
	EventFilterResult = 734,
	EventFilterResult_Encoding_DefaultXml = 735,
	EventFilterResult_Encoding_DefaultBinary = 736,
	AggregateFilterResult = 737,
	AggregateFilterResult_Encoding_DefaultXml = 738,
	AggregateFilterResult_Encoding_DefaultBinary = 739,
	MonitoringParameters = 740,
	MonitoringParameters_Encoding_DefaultXml = 741,
	MonitoringParameters_Encoding_DefaultBinary = 742,
	MonitoredItemCreateRequest = 743,
	MonitoredItemCreateRequest_Encoding_DefaultXml = 744,
	MonitoredItemCreateRequest_Encoding_DefaultBinary = 745,
	MonitoredItemCreateResult = 746,
	MonitoredItemCreateResult_Encoding_DefaultXml = 747,
	MonitoredItemCreateResult_Encoding_DefaultBinary = 748,
	CreateMonitoredItemsRequest = 749,
	CreateMonitoredItemsRequest_Encoding_DefaultXml = 750,
	CreateMonitoredItemsRequest_Encoding_DefaultBinary = 751,
	CreateMonitoredItemsResponse = 752,
	CreateMonitoredItemsResponse_Encoding_DefaultXml = 753,
	CreateMonitoredItemsResponse_Encoding_DefaultBinary = 754,
	MonitoredItemModifyRequest = 755,
	MonitoredItemModifyRequest_Encoding_DefaultXml = 756,
	MonitoredItemModifyRequest_Encoding_DefaultBinary = 757,
	MonitoredItemModifyResult = 758,
	MonitoredItemModifyResult_Encoding_DefaultXml = 759,
	MonitoredItemModifyResult_Encoding_DefaultBinary = 760,
	ModifyMonitoredItemsRequest = 761,
	ModifyMonitoredItemsRequest_Encoding_DefaultXml = 762,
	ModifyMonitoredItemsRequest_Encoding_DefaultBinary = 763,
	ModifyMonitoredItemsResponse = 764,
	ModifyMonitoredItemsResponse_Encoding_DefaultXml = 765,
	ModifyMonitoredItemsResponse_Encoding_DefaultBinary = 766,
	SetMonitoringModeRequest = 767,
	SetMonitoringModeRequest_Encoding_DefaultXml = 768,
	SetMonitoringModeRequest_Encoding_DefaultBinary = 769,
	SetMonitoringModeResponse = 770,
	SetMonitoringModeResponse_Encoding_DefaultXml = 771,
	SetMonitoringModeResponse_Encoding_DefaultBinary = 772,
	SetTriggeringRequest = 773,
	SetTriggeringRequest_Encoding_DefaultXml = 774,
	SetTriggeringRequest_Encoding_DefaultBinary = 775,
	SetTriggeringResponse = 776,
	SetTriggeringResponse_Encoding_DefaultXml = 777,
	SetTriggeringResponse_Encoding_DefaultBinary = 778,
	DeleteMonitoredItemsRequest = 779,
	DeleteMonitoredItemsRequest_Encoding_DefaultXml = 780,
	DeleteMonitoredItemsRequest_Encoding_DefaultBinary = 781,
	DeleteMonitoredItemsResponse = 782,
	DeleteMonitoredItemsResponse_Encoding_DefaultXml = 783,
	DeleteMonitoredItemsResponse_Encoding_DefaultBinary = 784,
	CreateSubscriptionRequest = 785,
	CreateSubscriptionRequest_Encoding_DefaultXml = 786,
	CreateSubscriptionRequest_Encoding_DefaultBinary = 787,
	CreateSubscriptionResponse = 788,
	CreateSubscriptionResponse_Encoding_DefaultXml = 789,
	CreateSubscriptionResponse_Encoding_DefaultBinary = 790,
	ModifySubscriptionRequest = 791,
	ModifySubscriptionRequest_Encoding_DefaultXml = 792,
	ModifySubscriptionRequest_Encoding_DefaultBinary = 793,
	ModifySubscriptionResponse = 794,
	ModifySubscriptionResponse_Encoding_DefaultXml = 795,
	ModifySubscriptionResponse_Encoding_DefaultBinary = 796,
	SetPublishingModeRequest = 797,
	SetPublishingModeRequest_Encoding_DefaultXml = 798,
	SetPublishingModeRequest_Encoding_DefaultBinary = 799,
	SetPublishingModeResponse = 800,
	SetPublishingModeResponse_Encoding_DefaultXml = 801,
	SetPublishingModeResponse_Encoding_DefaultBinary = 802,
	NotificationMessage = 803,
	NotificationMessage_Encoding_DefaultXml = 804,
	NotificationMessage_Encoding_DefaultBinary = 805,
	MonitoredItemNotification = 806,
	MonitoredItemNotification_Encoding_DefaultXml = 807,
	MonitoredItemNotification_Encoding_DefaultBinary = 808,
	DataChangeNotification = 809,
	DataChangeNotification_Encoding_DefaultXml = 810,
	DataChangeNotification_Encoding_DefaultBinary = 811,
	StatusChangeNotification = 818,
	StatusChangeNotification_Encoding_DefaultXml = 819,
	StatusChangeNotification_Encoding_DefaultBinary = 820,
	SubscriptionAcknowledgement = 821,
	SubscriptionAcknowledgement_Encoding_DefaultXml = 822,
	SubscriptionAcknowledgement_Encoding_DefaultBinary = 823,
	PublishRequest = 824,
	PublishRequest_Encoding_DefaultXml = 825,
	PublishRequest_Encoding_DefaultBinary = 826,
	PublishResponse = 827,
	PublishResponse_Encoding_DefaultXml = 828,
	PublishResponse_Encoding_DefaultBinary = 829,
	RepublishRequest = 830,
	RepublishRequest_Encoding_DefaultXml = 831,
	RepublishRequest_Encoding_DefaultBinary = 832,
	RepublishResponse = 833,
	RepublishResponse_Encoding_DefaultXml = 834,
	RepublishResponse_Encoding_DefaultBinary = 835,
	TransferResult = 836,
	TransferResult_Encoding_DefaultXml = 837,
	TransferResult_Encoding_DefaultBinary = 838,
	TransferSubscriptionsRequest = 839,
	TransferSubscriptionsRequest_Encoding_DefaultXml = 840,
	TransferSubscriptionsRequest_Encoding_DefaultBinary = 841,
	TransferSubscriptionsResponse = 842,
	TransferSubscriptionsResponse_Encoding_DefaultXml = 843,
	TransferSubscriptionsResponse_Encoding_DefaultBinary = 844,
	DeleteSubscriptionsRequest = 845,
	DeleteSubscriptionsRequest_Encoding_DefaultXml = 846,
	DeleteSubscriptionsRequest_Encoding_DefaultBinary = 847,
	DeleteSubscriptionsResponse = 848,
	DeleteSubscriptionsResponse_Encoding_DefaultXml = 849,
	DeleteSubscriptionsResponse_Encoding_DefaultBinary = 850,
	RedundancySupport = 851,
	ServerState = 852,
	RedundantServerDataType = 853,
	RedundantServerDataType_Encoding_DefaultXml = 854,
	RedundantServerDataType_Encoding_DefaultBinary = 855,
	SamplingIntervalDiagnosticsDataType = 856,
	SamplingIntervalDiagnosticsDataType_Encoding_DefaultXml = 857,
	SamplingIntervalDiagnosticsDataType_Encoding_DefaultBinary = 858,
	ServerDiagnosticsSummaryDataType = 859,
	ServerDiagnosticsSummaryDataType_Encoding_DefaultXml = 860,
	ServerDiagnosticsSummaryDataType_Encoding_DefaultBinary = 861,
	ServerStatusDataType = 862,
	ServerStatusDataType_Encoding_DefaultXml = 863,
	ServerStatusDataType_Encoding_DefaultBinary = 864,
	SessionDiagnosticsDataType = 865,
	SessionDiagnosticsDataType_Encoding_DefaultXml = 866,
	SessionDiagnosticsDataType_Encoding_DefaultBinary = 867,
	SessionSecurityDiagnosticsDataType = 868,
	SessionSecurityDiagnosticsDataType_Encoding_DefaultXml = 869,
	SessionSecurityDiagnosticsDataType_Encoding_DefaultBinary = 870,
	ServiceCounterDataType = 871,
	ServiceCounterDataType_Encoding_DefaultXml = 872,
	ServiceCounterDataType_Encoding_DefaultBinary = 873,
	SubscriptionDiagnosticsDataType = 874,
	SubscriptionDiagnosticsDataType_Encoding_DefaultXml = 875,
	SubscriptionDiagnosticsDataType_Encoding_DefaultBinary = 876,
	ModelChangeStructureDataType = 877,
	ModelChangeStructureDataType_Encoding_DefaultXml = 878,
	ModelChangeStructureDataType_Encoding_DefaultBinary = 879,
	Range = 884,
	Range_Encoding_DefaultXml = 885,
	Range_Encoding_DefaultBinary = 886,
	EUInformation = 887,
	EUInformation_Encoding_DefaultXml = 888,
	EUInformation_Encoding_DefaultBinary = 889,
	ExceptionDeviationFormat = 890,
	Annotation = 891,
	Annotation_Encoding_DefaultXml = 892,
	Annotation_Encoding_DefaultBinary = 893,
	ProgramDiagnosticDataType = 894,
	ProgramDiagnosticDataType_Encoding_DefaultXml = 895,
	ProgramDiagnosticDataType_Encoding_DefaultBinary = 896,
	SemanticChangeStructureDataType = 897,
	SemanticChangeStructureDataType_Encoding_DefaultXml = 898,
	SemanticChangeStructureDataType_Encoding_DefaultBinary = 899,
	EventNotificationList = 914,
	EventNotificationList_Encoding_DefaultXml = 915,
	EventNotificationList_Encoding_DefaultBinary = 916,
	EventFieldList = 917,
	EventFieldList_Encoding_DefaultXml = 918,
	EventFieldList_Encoding_DefaultBinary = 919,
	HistoryEventFieldList = 920,
	HistoryEventFieldList_Encoding_DefaultXml = 921,
	HistoryEventFieldList_Encoding_DefaultBinary = 922,
	HistoryUpdateEventResult = 929,
	HistoryUpdateEventResult_Encoding_DefaultXml = 930,
	HistoryUpdateEventResult_Encoding_DefaultBinary = 931,
	IssuedIdentityToken = 938,
	IssuedIdentityToken_Encoding_DefaultXml = 939,
	IssuedIdentityToken_Encoding_DefaultBinary = 940,
	NotificationData = 945,
	NotificationData_Encoding_DefaultXml = 946,
	NotificationData_Encoding_DefaultBinary = 947,
	AggregateConfiguration = 948,
	AggregateConfiguration_Encoding_DefaultXml = 949,
	AggregateConfiguration_Encoding_DefaultBinary = 950,
	ImageBMP = 2000,
	ImageGIF = 2001,
	ImageJPG = 2002,
	ImagePNG = 2003,
	ServerType = 2004,
	ServerType_ServerArray = 2005,
	ServerType_NamespaceArray = 2006,
	ServerType_ServerStatus = 2007,
	ServerType_ServiceLevel = 2008,
	ServerType_ServerCapabilities = 2009,
	ServerType_ServerDiagnostics = 2010,
	ServerType_VendorServerInfo = 2011,
	ServerType_ServerRedundancy = 2012,
	ServerCapabilitiesType = 2013,
	ServerCapabilitiesType_ServerProfileArray = 2014,
	ServerCapabilitiesType_LocaleIdArray = 2016,
	ServerCapabilitiesType_MinSupportedSampleRate = 2017,
	ServerCapabilitiesType_ModellingRules = 2019,
	ServerDiagnosticsType = 2020,
	ServerDiagnosticsType_ServerDiagnosticsSummary = 2021,
	ServerDiagnosticsType_SamplingIntervalDiagnosticsArray = 2022,
	ServerDiagnosticsType_SubscriptionDiagnosticsArray = 2023,
	ServerDiagnosticsType_EnabledFlag = 2025,
	SessionsDiagnosticsSummaryType = 2026,
	SessionsDiagnosticsSummaryType_SessionDiagnosticsArray = 2027,
	SessionsDiagnosticsSummaryType_SessionSecurityDiagnosticsArray = 2028,
	SessionDiagnosticsObjectType = 2029,
	SessionDiagnosticsObjectType_SessionDiagnostics = 2030,
	SessionDiagnosticsObjectType_SessionSecurityDiagnostics = 2031,
	SessionDiagnosticsObjectType_SubscriptionDiagnosticsArray = 2032,
	VendorServerInfoType = 2033,
	ServerRedundancyType = 2034,
	ServerRedundancyType_RedundancySupport = 2035,
	TransparentRedundancyType = 2036,
	TransparentRedundancyType_CurrentServerId = 2037,
	TransparentRedundancyType_RedundantServerArray = 2038,
	NonTransparentRedundancyType = 2039,
	NonTransparentRedundancyType_ServerUriArray = 2040,
	BaseEventType = 2041,
	BaseEventType_EventId = 2042,
	BaseEventType_EventType = 2043,
	BaseEventType_SourceNode = 2044,
	BaseEventType_SourceName = 2045,
	BaseEventType_Time = 2046,
	BaseEventType_ReceiveTime = 2047,
	BaseEventType_Message = 2050,
	BaseEventType_Severity = 2051,
	AuditEventType = 2052,
	AuditEventType_ActionTimeStamp = 2053,
	AuditEventType_Status = 2054,
	AuditEventType_ServerId = 2055,
	AuditEventType_ClientAuditEntryId = 2056,
	AuditEventType_ClientUserId = 2057,
	AuditSecurityEventType = 2058,
	AuditChannelEventType = 2059,
	AuditOpenSecureChannelEventType = 2060,
	AuditOpenSecureChannelEventType_ClientCertificate = 2061,
	AuditOpenSecureChannelEventType_RequestType = 2062,
	AuditOpenSecureChannelEventType_SecurityPolicyUri = 2063,
	AuditOpenSecureChannelEventType_SecurityMode = 2065,
	AuditOpenSecureChannelEventType_RequestedLifetime = 2066,
	AuditSessionEventType = 2069,
	AuditSessionEventType_SessionId = 2070,
	AuditCreateSessionEventType = 2071,
	AuditCreateSessionEventType_SecureChannelId = 2072,
	AuditCreateSessionEventType_ClientCertificate = 2073,
	AuditCreateSessionEventType_RevisedSessionTimeout = 2074,
	AuditActivateSessionEventType = 2075,
	AuditActivateSessionEventType_ClientSoftwareCertificates = 2076,
	AuditActivateSessionEventType_UserIdentityToken = 2077,
	AuditCancelEventType = 2078,
	AuditCancelEventType_RequestHandle = 2079,
	AuditCertificateEventType = 2080,
	AuditCertificateEventType_Certificate = 2081,
	AuditCertificateDataMismatchEventType = 2082,
	AuditCertificateDataMismatchEventType_InvalidHostname = 2083,
	AuditCertificateDataMismatchEventType_InvalidUri = 2084,
	AuditCertificateExpiredEventType = 2085,
	AuditCertificateInvalidEventType = 2086,
	AuditCertificateUntrustedEventType = 2087,
	AuditCertificateRevokedEventType = 2088,
	AuditCertificateMismatchEventType = 2089,
	AuditNodeManagementEventType = 2090,
	AuditAddNodesEventType = 2091,
	AuditAddNodesEventType_NodesToAdd = 2092,
	AuditDeleteNodesEventType = 2093,
	AuditDeleteNodesEventType_NodesToDelete = 2094,
	AuditAddReferencesEventType = 2095,
	AuditAddReferencesEventType_ReferencesToAdd = 2096,
	AuditDeleteReferencesEventType = 2097,
	AuditDeleteReferencesEventType_ReferencesToDelete = 2098,
	AuditUpdateEventType = 2099,
	AuditWriteUpdateEventType = 2100,
	AuditWriteUpdateEventType_IndexRange = 2101,
	AuditWriteUpdateEventType_OldValue = 2102,
	AuditWriteUpdateEventType_NewValue = 2103,
	AuditHistoryUpdateEventType = 2104,
	AuditUpdateMethodEventType = 2127,
	AuditUpdateMethodEventType_MethodId = 2128,
	AuditUpdateMethodEventType_InputArguments = 2129,
	SystemEventType = 2130,
	DeviceFailureEventType = 2131,
	BaseModelChangeEventType = 2132,
	GeneralModelChangeEventType = 2133,
	GeneralModelChangeEventType_Changes = 2134,
	ServerVendorCapabilityType = 2137,
	ServerStatusType = 2138,
	ServerStatusType_StartTime = 2139,
	ServerStatusType_CurrentTime = 2140,
	ServerStatusType_State = 2141,
	ServerStatusType_BuildInfo = 2142,
	ServerDiagnosticsSummaryType = 2150,
	ServerDiagnosticsSummaryType_ServerViewCount = 2151,
	ServerDiagnosticsSummaryType_CurrentSessionCount = 2152,
	ServerDiagnosticsSummaryType_CumulatedSessionCount = 2153,
	ServerDiagnosticsSummaryType_SecurityRejectedSessionCount = 2154,
	ServerDiagnosticsSummaryType_RejectedSessionCount = 2155,
	ServerDiagnosticsSummaryType_SessionTimeoutCount = 2156,
	ServerDiagnosticsSummaryType_SessionAbortCount = 2157,
	ServerDiagnosticsSummaryType_PublishingIntervalCount = 2159,
	ServerDiagnosticsSummaryType_CurrentSubscriptionCount = 2160,
	ServerDiagnosticsSummaryType_CumulatedSubscriptionCount = 2161,
	ServerDiagnosticsSummaryType_SecurityRejectedRequestsCount = 2162,
	ServerDiagnosticsSummaryType_RejectedRequestsCount = 2163,
	SamplingIntervalDiagnosticsArrayType = 2164,
	SamplingIntervalDiagnosticsType = 2165,
	SamplingIntervalDiagnosticsType_SamplingInterval = 2166,
	SubscriptionDiagnosticsArrayType = 2171,
	SubscriptionDiagnosticsType = 2172,
	SubscriptionDiagnosticsType_SessionId = 2173,
	SubscriptionDiagnosticsType_SubscriptionId = 2174,
	SubscriptionDiagnosticsType_Priority = 2175,
	SubscriptionDiagnosticsType_PublishingInterval = 2176,
	SubscriptionDiagnosticsType_MaxKeepAliveCount = 2177,
	SubscriptionDiagnosticsType_MaxNotificationsPerPublish = 2179,
	SubscriptionDiagnosticsType_PublishingEnabled = 2180,
	SubscriptionDiagnosticsType_ModifyCount = 2181,
	SubscriptionDiagnosticsType_EnableCount = 2182,
	SubscriptionDiagnosticsType_DisableCount = 2183,
	SubscriptionDiagnosticsType_RepublishRequestCount = 2184,
	SubscriptionDiagnosticsType_RepublishMessageRequestCount = 2185,
	SubscriptionDiagnosticsType_RepublishMessageCount = 2186,
	SubscriptionDiagnosticsType_TransferRequestCount = 2187,
	SubscriptionDiagnosticsType_TransferredToAltClientCount = 2188,
	SubscriptionDiagnosticsType_TransferredToSameClientCount = 2189,
	SubscriptionDiagnosticsType_PublishRequestCount = 2190,
	SubscriptionDiagnosticsType_DataChangeNotificationsCount = 2191,
	SubscriptionDiagnosticsType_NotificationsCount = 2193,
	SessionDiagnosticsArrayType = 2196,
	SessionDiagnosticsVariableType = 2197,
	SessionDiagnosticsVariableType_SessionId = 2198,
	SessionDiagnosticsVariableType_SessionName = 2199,
	SessionDiagnosticsVariableType_ClientDescription = 2200,
	SessionDiagnosticsVariableType_ServerUri = 2201,
	SessionDiagnosticsVariableType_EndpointUrl = 2202,
	SessionDiagnosticsVariableType_LocaleIds = 2203,
	SessionDiagnosticsVariableType_ActualSessionTimeout = 2204,
	SessionDiagnosticsVariableType_ClientConnectionTime = 2205,
	SessionDiagnosticsVariableType_ClientLastContactTime = 2206,
	SessionDiagnosticsVariableType_CurrentSubscriptionsCount = 2207,
	SessionDiagnosticsVariableType_CurrentMonitoredItemsCount = 2208,
	SessionDiagnosticsVariableType_CurrentPublishRequestsInQueue = 2209,
	SessionDiagnosticsVariableType_ReadCount = 2217,
	SessionDiagnosticsVariableType_HistoryReadCount = 2218,
	SessionDiagnosticsVariableType_WriteCount = 2219,
	SessionDiagnosticsVariableType_HistoryUpdateCount = 2220,
	SessionDiagnosticsVariableType_CallCount = 2221,
	SessionDiagnosticsVariableType_CreateMonitoredItemsCount = 2222,
	SessionDiagnosticsVariableType_ModifyMonitoredItemsCount = 2223,
	SessionDiagnosticsVariableType_SetMonitoringModeCount = 2224,
	SessionDiagnosticsVariableType_SetTriggeringCount = 2225,
	SessionDiagnosticsVariableType_DeleteMonitoredItemsCount = 2226,
	SessionDiagnosticsVariableType_CreateSubscriptionCount = 2227,
	SessionDiagnosticsVariableType_ModifySubscriptionCount = 2228,
	SessionDiagnosticsVariableType_SetPublishingModeCount = 2229,
	SessionDiagnosticsVariableType_PublishCount = 2230,
	SessionDiagnosticsVariableType_RepublishCount = 2231,
	SessionDiagnosticsVariableType_TransferSubscriptionsCount = 2232,
	SessionDiagnosticsVariableType_DeleteSubscriptionsCount = 2233,
	SessionDiagnosticsVariableType_AddNodesCount = 2234,
	SessionDiagnosticsVariableType_AddReferencesCount = 2235,
	SessionDiagnosticsVariableType_DeleteNodesCount = 2236,
	SessionDiagnosticsVariableType_DeleteReferencesCount = 2237,
	SessionDiagnosticsVariableType_BrowseCount = 2238,
	SessionDiagnosticsVariableType_BrowseNextCount = 2239,
	SessionDiagnosticsVariableType_TranslateBrowsePathsToNodeIdsCount = 2240,
	SessionDiagnosticsVariableType_QueryFirstCount = 2241,
	SessionDiagnosticsVariableType_QueryNextCount = 2242,
	SessionSecurityDiagnosticsArrayType = 2243,
	SessionSecurityDiagnosticsType = 2244,
	SessionSecurityDiagnosticsType_SessionId = 2245,
	SessionSecurityDiagnosticsType_ClientUserIdOfSession = 2246,
	SessionSecurityDiagnosticsType_ClientUserIdHistory = 2247,
	SessionSecurityDiagnosticsType_AuthenticationMechanism = 2248,
	SessionSecurityDiagnosticsType_Encoding = 2249,
	SessionSecurityDiagnosticsType_TransportProtocol = 2250,
	SessionSecurityDiagnosticsType_SecurityMode = 2251,
	SessionSecurityDiagnosticsType_SecurityPolicyUri = 2252,
	Server = 2253,
	Server_ServerArray = 2254,
	Server_NamespaceArray = 2255,
	Server_ServerStatus = 2256,
	Server_ServerStatus_StartTime = 2257,
	Server_ServerStatus_CurrentTime = 2258,
	Server_ServerStatus_State = 2259,
	Server_ServerStatus_BuildInfo = 2260,
	Server_ServerStatus_BuildInfo_ProductName = 2261,
	Server_ServerStatus_BuildInfo_ProductUri = 2262,
	Server_ServerStatus_BuildInfo_ManufacturerName = 2263,
	Server_ServerStatus_BuildInfo_SoftwareVersion = 2264,
	Server_ServerStatus_BuildInfo_BuildNumber = 2265,
	Server_ServerStatus_BuildInfo_BuildDate = 2266,
	Server_ServiceLevel = 2267,
	Server_ServerCapabilities = 2268,
	Server_ServerCapabilities_ServerProfileArray = 2269,
	Server_ServerCapabilities_LocaleIdArray = 2271,
	Server_ServerCapabilities_MinSupportedSampleRate = 2272,
	Server_ServerDiagnostics = 2274,
	Server_ServerDiagnostics_ServerDiagnosticsSummary = 2275,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_ServerViewCount = 2276,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSessionCount = 2277,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSessionCount = 2278,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedSessionCount = 2279,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_SessionTimeoutCount = 2281,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_SessionAbortCount = 2282,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_PublishingIntervalCount = 2284,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSubscriptionCount = 2285,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSubscriptionCount = 2286,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedRequestsCount = 2287,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_RejectedRequestsCount = 2288,
	Server_ServerDiagnostics_SamplingIntervalDiagnosticsArray = 2289,
	Server_ServerDiagnostics_SubscriptionDiagnosticsArray = 2290,
	Server_ServerDiagnostics_EnabledFlag = 2294,
	Server_VendorServerInfo = 2295,
	Server_ServerRedundancy = 2296,
	StateMachineType = 2299,
	StateType = 2307,
	StateType_StateNumber = 2308,
	InitialStateType = 2309,
	TransitionType = 2310,
	TransitionEventType = 2311,
	TransitionType_TransitionNumber = 2312,
	AuditUpdateStateEventType = 2315,
	HistoricalDataConfigurationType = 2318,
	HistoricalDataConfigurationType_Stepped = 2323,
	HistoricalDataConfigurationType_Definition = 2324,
	HistoricalDataConfigurationType_MaxTimeInterval = 2325,
	HistoricalDataConfigurationType_MinTimeInterval = 2326,
	HistoricalDataConfigurationType_ExceptionDeviation = 2327,
	HistoricalDataConfigurationType_ExceptionDeviationFormat = 2328,
	HistoryServerCapabilitiesType = 2330,
	HistoryServerCapabilitiesType_AccessHistoryDataCapability = 2331,
	HistoryServerCapabilitiesType_AccessHistoryEventsCapability = 2332,
	HistoryServerCapabilitiesType_InsertDataCapability = 2334,
	HistoryServerCapabilitiesType_ReplaceDataCapability = 2335,
	HistoryServerCapabilitiesType_UpdateDataCapability = 2336,
	HistoryServerCapabilitiesType_DeleteRawCapability = 2337,
	HistoryServerCapabilitiesType_DeleteAtTimeCapability = 2338,
	AggregateFunctionType = 2340,
	AggregateFunction_Interpolative = 2341,
	AggregateFunction_Average = 2342,
	AggregateFunction_TimeAverage = 2343,
	AggregateFunction_Total = 2344,
	AggregateFunction_Minimum = 2346,
	AggregateFunction_Maximum = 2347,
	AggregateFunction_MinimumActualTime = 2348,
	AggregateFunction_MaximumActualTime = 2349,
	AggregateFunction_Range = 2350,
	AggregateFunction_AnnotationCount = 2351,
	AggregateFunction_Count = 2352,
	AggregateFunction_NumberOfTransitions = 2355,
	AggregateFunction_Start = 2357,
	AggregateFunction_End = 2358,
	AggregateFunction_Delta = 2359,
	AggregateFunction_DurationGood = 2360,
	AggregateFunction_DurationBad = 2361,
	AggregateFunction_PercentGood = 2362,
	AggregateFunction_PercentBad = 2363,
	AggregateFunction_WorstQuality = 2364,
	DataItemType = 2365,
	DataItemType_Definition = 2366,
	DataItemType_ValuePrecision = 2367,
	AnalogItemType = 2368,
	AnalogItemType_EURange = 2369,
	AnalogItemType_InstrumentRange = 2370,
	AnalogItemType_EngineeringUnits = 2371,
	DiscreteItemType = 2372,
	TwoStateDiscreteType = 2373,
	TwoStateDiscreteType_FalseState = 2374,
	TwoStateDiscreteType_TrueState = 2375,
	MultiStateDiscreteType = 2376,
	MultiStateDiscreteType_EnumStrings = 2377,
	ProgramTransitionEventType = 2378,
	ProgramTransitionEventType_IntermediateResult = 2379,
	ProgramDiagnosticType = 2380,
	ProgramDiagnosticType_CreateSessionId = 2381,
	ProgramDiagnosticType_CreateClientName = 2382,
	ProgramDiagnosticType_InvocationCreationTime = 2383,
	ProgramDiagnosticType_LastTransitionTime = 2384,
	ProgramDiagnosticType_LastMethodCall = 2385,
	ProgramDiagnosticType_LastMethodSessionId = 2386,
	ProgramDiagnosticType_LastMethodInputArguments = 2387,
	ProgramDiagnosticType_LastMethodOutputArguments = 2388,
	ProgramDiagnosticType_LastMethodCallTime = 2389,
	ProgramDiagnosticType_LastMethodReturnStatus = 2390,
	ProgramStateMachineType = 2391,
	ProgramStateMachineType_Creatable = 2392,
	ProgramStateMachineType_Deletable = 2393,
	ProgramStateMachineType_AutoDelete = 2394,
	ProgramStateMachineType_RecycleCount = 2395,
	ProgramStateMachineType_InstanceCount = 2396,
	ProgramStateMachineType_MaxInstanceCount = 2397,
	ProgramStateMachineType_MaxRecycleCount = 2398,
	ProgramStateMachineType_ProgramDiagnostics = 2399,
	ProgramStateMachineType_Ready = 2400,
	ProgramStateMachineType_Ready_StateNumber = 2401,
	ProgramStateMachineType_Running = 2402,
	ProgramStateMachineType_Running_StateNumber = 2403,
	ProgramStateMachineType_Suspended = 2404,
	ProgramStateMachineType_Suspended_StateNumber = 2405,
	ProgramStateMachineType_Halted = 2406,
	ProgramStateMachineType_Halted_StateNumber = 2407,
	ProgramStateMachineType_HaltedToReady = 2408,
	ProgramStateMachineType_HaltedToReady_TransitionNumber = 2409,
	ProgramStateMachineType_ReadyToRunning = 2410,
	ProgramStateMachineType_ReadyToRunning_TransitionNumber = 2411,
	ProgramStateMachineType_RunningToHalted = 2412,
	ProgramStateMachineType_RunningToHalted_TransitionNumber = 2413,
	ProgramStateMachineType_RunningToReady = 2414,
	ProgramStateMachineType_RunningToReady_TransitionNumber = 2415,
	ProgramStateMachineType_RunningToSuspended = 2416,
	ProgramStateMachineType_RunningToSuspended_TransitionNumber = 2417,
	ProgramStateMachineType_SuspendedToRunning = 2418,
	ProgramStateMachineType_SuspendedToRunning_TransitionNumber = 2419,
	ProgramStateMachineType_SuspendedToHalted = 2420,
	ProgramStateMachineType_SuspendedToHalted_TransitionNumber = 2421,
	ProgramStateMachineType_SuspendedToReady = 2422,
	ProgramStateMachineType_SuspendedToReady_TransitionNumber = 2423,
	ProgramStateMachineType_ReadyToHalted = 2424,
	ProgramStateMachineType_ReadyToHalted_TransitionNumber = 2425,
	ProgramStateMachineType_Start = 2426,
	ProgramStateMachineType_Suspend = 2427,
	ProgramStateMachineType_Resume = 2428,
	ProgramStateMachineType_Halt = 2429,
	ProgramStateMachineType_Reset = 2430,
	SessionDiagnosticsVariableType_RegisterNodesCount = 2730,
	SessionDiagnosticsVariableType_UnregisterNodesCount = 2731,
	ServerCapabilitiesType_MaxBrowseContinuationPoints = 2732,
	ServerCapabilitiesType_MaxQueryContinuationPoints = 2733,
	ServerCapabilitiesType_MaxHistoryContinuationPoints = 2734,
	Server_ServerCapabilities_MaxBrowseContinuationPoints = 2735,
	Server_ServerCapabilities_MaxQueryContinuationPoints = 2736,
	Server_ServerCapabilities_MaxHistoryContinuationPoints = 2737,
	SemanticChangeEventType = 2738,
	SemanticChangeEventType_Changes = 2739,
	ServerType_Auditing = 2742,
	ServerDiagnosticsType_SessionsDiagnosticsSummary = 2744,
	AuditChannelEventType_SecureChannelId = 2745,
	AuditOpenSecureChannelEventType_ClientCertificateThumbprint = 2746,
	AuditCreateSessionEventType_ClientCertificateThumbprint = 2747,
	AuditUrlMismatchEventType = 2748,
	AuditUrlMismatchEventType_EndpointUrl = 2749,
	AuditWriteUpdateEventType_AttributeId = 2750,
	AuditHistoryUpdateEventType_ParameterDataTypeId = 2751,
	ServerStatusType_SecondsTillShutdown = 2752,
	ServerStatusType_ShutdownReason = 2753,
	ServerCapabilitiesType_AggregateFunctions = 2754,
	StateVariableType = 2755,
	StateVariableType_Id = 2756,
	StateVariableType_Name = 2757,
	StateVariableType_Number = 2758,
	StateVariableType_EffectiveDisplayName = 2759,
	FiniteStateVariableType = 2760,
	FiniteStateVariableType_Id = 2761,
	TransitionVariableType = 2762,
	TransitionVariableType_Id = 2763,
	TransitionVariableType_Name = 2764,
	TransitionVariableType_Number = 2765,
	TransitionVariableType_TransitionTime = 2766,
	FiniteTransitionVariableType = 2767,
	FiniteTransitionVariableType_Id = 2768,
	StateMachineType_CurrentState = 2769,
	StateMachineType_LastTransition = 2770,
	FiniteStateMachineType = 2771,
	FiniteStateMachineType_CurrentState = 2772,
	FiniteStateMachineType_LastTransition = 2773,
	TransitionEventType_Transition = 2774,
	TransitionEventType_FromState = 2775,
	TransitionEventType_ToState = 2776,
	AuditUpdateStateEventType_OldStateId = 2777,
	AuditUpdateStateEventType_NewStateId = 2778,
	ConditionType = 2782,
	RefreshStartEventType = 2787,
	RefreshEndEventType = 2788,
	RefreshRequiredEventType = 2789,
	AuditConditionEventType = 2790,
	AuditConditionEnableEventType = 2803,
	AuditConditionCommentEventType = 2829,
	DialogConditionType = 2830,
	DialogConditionType_Prompt = 2831,
	AcknowledgeableConditionType = 2881,
	AlarmConditionType = 2915,
	ShelvedStateMachineType = 2929,
	ShelvedStateMachineType_Unshelved = 2930,
	ShelvedStateMachineType_TimedShelved = 2932,
	ShelvedStateMachineType_OneShotShelved = 2933,
	ShelvedStateMachineType_UnshelvedToTimedShelved = 2935,
	ShelvedStateMachineType_UnshelvedToOneShotShelved = 2936,
	ShelvedStateMachineType_TimedShelvedToUnshelved = 2940,
	ShelvedStateMachineType_TimedShelvedToOneShotShelved = 2942,
	ShelvedStateMachineType_OneShotShelvedToUnshelved = 2943,
	ShelvedStateMachineType_OneShotShelvedToTimedShelved = 2945,
	ShelvedStateMachineType_Unshelve = 2947,
	ShelvedStateMachineType_OneShotShelve = 2948,
	ShelvedStateMachineType_TimedShelve = 2949,
	LimitAlarmType = 2955,
	ShelvedStateMachineType_TimedShelve_InputArguments = 2991,
	Server_ServerStatus_SecondsTillShutdown = 2992,
	Server_ServerStatus_ShutdownReason = 2993,
	Server_Auditing = 2994,
	Server_ServerCapabilities_ModellingRules = 2996,
	Server_ServerCapabilities_AggregateFunctions = 2997,
	SubscriptionDiagnosticsType_EventNotificationsCount = 2998,
	AuditHistoryEventUpdateEventType = 2999,
	AuditHistoryEventUpdateEventType_Filter = 3003,
	AuditHistoryValueUpdateEventType = 3006,
	AuditHistoryDeleteEventType = 3012,
	AuditHistoryRawModifyDeleteEventType = 3014,
	AuditHistoryRawModifyDeleteEventType_IsDeleteModified = 3015,
	AuditHistoryRawModifyDeleteEventType_StartTime = 3016,
	AuditHistoryRawModifyDeleteEventType_EndTime = 3017,
	AuditHistoryAtTimeDeleteEventType = 3019,
	AuditHistoryAtTimeDeleteEventType_ReqTimes = 3020,
	AuditHistoryAtTimeDeleteEventType_OldValues = 3021,
	AuditHistoryEventDeleteEventType = 3022,
	AuditHistoryEventDeleteEventType_EventIds = 3023,
	AuditHistoryEventDeleteEventType_OldValues = 3024,
	AuditHistoryEventUpdateEventType_UpdatedNode = 3025,
	AuditHistoryValueUpdateEventType_UpdatedNode = 3026,
	AuditHistoryDeleteEventType_UpdatedNode = 3027,
	AuditHistoryEventUpdateEventType_PerformInsertReplace = 3028,
	AuditHistoryEventUpdateEventType_NewValues = 3029,
	AuditHistoryEventUpdateEventType_OldValues = 3030,
	AuditHistoryValueUpdateEventType_PerformInsertReplace = 3031,
	AuditHistoryValueUpdateEventType_NewValues = 3032,
	AuditHistoryValueUpdateEventType_OldValues = 3033,
	AuditHistoryRawModifyDeleteEventType_OldValues = 3034,
	EventQueueOverflowEventType = 3035,
	EventTypesFolder = 3048,
	ServerCapabilitiesType_SoftwareCertificates = 3049,
	SessionDiagnosticsVariableType_MaxResponseMessageSize = 3050,
	BuildInfoType = 3051,
	BuildInfoType_ProductUri = 3052,
	BuildInfoType_ManufacturerName = 3053,
	BuildInfoType_ProductName = 3054,
	BuildInfoType_SoftwareVersion = 3055,
	BuildInfoType_BuildNumber = 3056,
	BuildInfoType_BuildDate = 3057,
	SessionSecurityDiagnosticsType_ClientCertificate = 3058,
	HistoricalDataConfigurationType_AggregateConfiguration = 3059,
	DefaultBinary = 3062,
	DefaultXml = 3063,
	AlwaysGeneratesEvent = 3065,
	Icon = 3067,
	NodeVersion = 3068,
	LocalTime = 3069,
	AllowNulls = 3070,
	EnumValues = 3071,
	InputArguments = 3072,
	OutputArguments = 3073,
	ServerType_ServerStatus_StartTime = 3074,
	ServerType_ServerStatus_CurrentTime = 3075,
	ServerType_ServerStatus_State = 3076,
	ServerType_ServerStatus_BuildInfo = 3077,
	ServerType_ServerStatus_BuildInfo_ProductUri = 3078,
	ServerType_ServerStatus_BuildInfo_ManufacturerName = 3079,
	ServerType_ServerStatus_BuildInfo_ProductName = 3080,
	ServerType_ServerStatus_BuildInfo_SoftwareVersion = 3081,
	ServerType_ServerStatus_BuildInfo_BuildNumber = 3082,
	ServerType_ServerStatus_BuildInfo_BuildDate = 3083,
	ServerType_ServerStatus_SecondsTillShutdown = 3084,
	ServerType_ServerStatus_ShutdownReason = 3085,
	ServerType_ServerCapabilities_ServerProfileArray = 3086,
	ServerType_ServerCapabilities_LocaleIdArray = 3087,
	ServerType_ServerCapabilities_MinSupportedSampleRate = 3088,
	ServerType_ServerCapabilities_MaxBrowseContinuationPoints = 3089,
	ServerType_ServerCapabilities_MaxQueryContinuationPoints = 3090,
	ServerType_ServerCapabilities_MaxHistoryContinuationPoints = 3091,
	ServerType_ServerCapabilities_SoftwareCertificates = 3092,
	ServerType_ServerCapabilities_ModellingRules = 3093,
	ServerType_ServerCapabilities_AggregateFunctions = 3094,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary = 3095,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_ServerViewCount = 3096,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSessionCount = 3097,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSessionCount = 3098,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedSessionCount = 3099,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_RejectedSessionCount = 3100,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SessionTimeoutCount = 3101,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SessionAbortCount = 3102,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_PublishingIntervalCount = 3104,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSubscriptionCount = 3105,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSubscriptionCount = 3106,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedRequestsCount = 3107,
	ServerType_ServerDiagnostics_ServerDiagnosticsSummary_RejectedRequestsCount = 3108,
	ServerType_ServerDiagnostics_SamplingIntervalDiagnosticsArray = 3109,
	ServerType_ServerDiagnostics_SubscriptionDiagnosticsArray = 3110,
	ServerType_ServerDiagnostics_SessionsDiagnosticsSummary = 3111,
	ServerType_ServerDiagnostics_SessionsDiagnosticsSummary_SessionDiagnosticsArray = 3112,
	ServerType_ServerDiagnostics_SessionsDiagnosticsSummary_SessionSecurityDiagnosticsArray = 3113,
	ServerType_ServerDiagnostics_EnabledFlag = 3114,
	ServerType_ServerRedundancy_RedundancySupport = 3115,
	ServerDiagnosticsType_ServerDiagnosticsSummary_ServerViewCount = 3116,
	ServerDiagnosticsType_ServerDiagnosticsSummary_CurrentSessionCount = 3117,
	ServerDiagnosticsType_ServerDiagnosticsSummary_CumulatedSessionCount = 3118,
	ServerDiagnosticsType_ServerDiagnosticsSummary_SecurityRejectedSessionCount = 3119,
	ServerDiagnosticsType_ServerDiagnosticsSummary_RejectedSessionCount = 3120,
	ServerDiagnosticsType_ServerDiagnosticsSummary_SessionTimeoutCount = 3121,
	ServerDiagnosticsType_ServerDiagnosticsSummary_SessionAbortCount = 3122,
	ServerDiagnosticsType_ServerDiagnosticsSummary_PublishingIntervalCount = 3124,
	ServerDiagnosticsType_ServerDiagnosticsSummary_CurrentSubscriptionCount = 3125,
	ServerDiagnosticsType_ServerDiagnosticsSummary_CumulatedSubscriptionCount = 3126,
	ServerDiagnosticsType_ServerDiagnosticsSummary_SecurityRejectedRequestsCount = 3127,
	ServerDiagnosticsType_ServerDiagnosticsSummary_RejectedRequestsCount = 3128,
	ServerDiagnosticsType_SessionsDiagnosticsSummary_SessionDiagnosticsArray = 3129,
	ServerDiagnosticsType_SessionsDiagnosticsSummary_SessionSecurityDiagnosticsArray = 3130,
	SessionDiagnosticsObjectType_SessionDiagnostics_SessionId = 3131,
	SessionDiagnosticsObjectType_SessionDiagnostics_SessionName = 3132,
	SessionDiagnosticsObjectType_SessionDiagnostics_ClientDescription = 3133,
	SessionDiagnosticsObjectType_SessionDiagnostics_ServerUri = 3134,
	SessionDiagnosticsObjectType_SessionDiagnostics_EndpointUrl = 3135,
	SessionDiagnosticsObjectType_SessionDiagnostics_LocaleIds = 3136,
	SessionDiagnosticsObjectType_SessionDiagnostics_ActualSessionTimeout = 3137,
	SessionDiagnosticsObjectType_SessionDiagnostics_MaxResponseMessageSize = 3138,
	SessionDiagnosticsObjectType_SessionDiagnostics_ClientConnectionTime = 3139,
	SessionDiagnosticsObjectType_SessionDiagnostics_ClientLastContactTime = 3140,
	SessionDiagnosticsObjectType_SessionDiagnostics_CurrentSubscriptionsCount = 3141,
	SessionDiagnosticsObjectType_SessionDiagnostics_CurrentMonitoredItemsCount = 3142,
	SessionDiagnosticsObjectType_SessionDiagnostics_CurrentPublishRequestsInQueue = 3143,
	SessionDiagnosticsObjectType_SessionDiagnostics_ReadCount = 3151,
	SessionDiagnosticsObjectType_SessionDiagnostics_HistoryReadCount = 3152,
	SessionDiagnosticsObjectType_SessionDiagnostics_WriteCount = 3153,
	SessionDiagnosticsObjectType_SessionDiagnostics_HistoryUpdateCount = 3154,
	SessionDiagnosticsObjectType_SessionDiagnostics_CallCount = 3155,
	SessionDiagnosticsObjectType_SessionDiagnostics_CreateMonitoredItemsCount = 3156,
	SessionDiagnosticsObjectType_SessionDiagnostics_ModifyMonitoredItemsCount = 3157,
	SessionDiagnosticsObjectType_SessionDiagnostics_SetMonitoringModeCount = 3158,
	SessionDiagnosticsObjectType_SessionDiagnostics_SetTriggeringCount = 3159,
	SessionDiagnosticsObjectType_SessionDiagnostics_DeleteMonitoredItemsCount = 3160,
	SessionDiagnosticsObjectType_SessionDiagnostics_CreateSubscriptionCount = 3161,
	SessionDiagnosticsObjectType_SessionDiagnostics_ModifySubscriptionCount = 3162,
	SessionDiagnosticsObjectType_SessionDiagnostics_SetPublishingModeCount = 3163,
	SessionDiagnosticsObjectType_SessionDiagnostics_PublishCount = 3164,
	SessionDiagnosticsObjectType_SessionDiagnostics_RepublishCount = 3165,
	SessionDiagnosticsObjectType_SessionDiagnostics_TransferSubscriptionsCount = 3166,
	SessionDiagnosticsObjectType_SessionDiagnostics_DeleteSubscriptionsCount = 3167,
	SessionDiagnosticsObjectType_SessionDiagnostics_AddNodesCount = 3168,
	SessionDiagnosticsObjectType_SessionDiagnostics_AddReferencesCount = 3169,
	SessionDiagnosticsObjectType_SessionDiagnostics_DeleteNodesCount = 3170,
	SessionDiagnosticsObjectType_SessionDiagnostics_DeleteReferencesCount = 3171,
	SessionDiagnosticsObjectType_SessionDiagnostics_BrowseCount = 3172,
	SessionDiagnosticsObjectType_SessionDiagnostics_BrowseNextCount = 3173,
	SessionDiagnosticsObjectType_SessionDiagnostics_TranslateBrowsePathsToNodeIdsCount = 3174,
	SessionDiagnosticsObjectType_SessionDiagnostics_QueryFirstCount = 3175,
	SessionDiagnosticsObjectType_SessionDiagnostics_QueryNextCount = 3176,
	SessionDiagnosticsObjectType_SessionDiagnostics_RegisterNodesCount = 3177,
	SessionDiagnosticsObjectType_SessionDiagnostics_UnregisterNodesCount = 3178,
	SessionDiagnosticsObjectType_SessionSecurityDiagnostics_SessionId = 3179,
	SessionDiagnosticsObjectType_SessionSecurityDiagnostics_ClientUserIdOfSession = 3180,
	SessionDiagnosticsObjectType_SessionSecurityDiagnostics_ClientUserIdHistory = 3181,
	SessionDiagnosticsObjectType_SessionSecurityDiagnostics_AuthenticationMechanism = 3182,
	SessionDiagnosticsObjectType_SessionSecurityDiagnostics_Encoding = 3183,
	SessionDiagnosticsObjectType_SessionSecurityDiagnostics_TransportProtocol = 3184,
	SessionDiagnosticsObjectType_SessionSecurityDiagnostics_SecurityMode = 3185,
	SessionDiagnosticsObjectType_SessionSecurityDiagnostics_SecurityPolicyUri = 3186,
	SessionDiagnosticsObjectType_SessionSecurityDiagnostics_ClientCertificate = 3187,
	TransparentRedundancyType_RedundancySupport = 3188,
	NonTransparentRedundancyType_RedundancySupport = 3189,
	BaseEventType_LocalTime = 3190,
	EventQueueOverflowEventType_EventId = 3191,
	EventQueueOverflowEventType_EventType = 3192,
	EventQueueOverflowEventType_SourceNode = 3193,
	EventQueueOverflowEventType_SourceName = 3194,
	EventQueueOverflowEventType_Time = 3195,
	EventQueueOverflowEventType_ReceiveTime = 3196,
	EventQueueOverflowEventType_LocalTime = 3197,
	EventQueueOverflowEventType_Message = 3198,
	EventQueueOverflowEventType_Severity = 3199,
	AuditEventType_EventId = 3200,
	AuditEventType_EventType = 3201,
	AuditEventType_SourceNode = 3202,
	AuditEventType_SourceName = 3203,
	AuditEventType_Time = 3204,
	AuditEventType_ReceiveTime = 3205,
	AuditEventType_LocalTime = 3206,
	AuditEventType_Message = 3207,
	AuditEventType_Severity = 3208,
	AuditSecurityEventType_EventId = 3209,
	AuditSecurityEventType_EventType = 3210,
	AuditSecurityEventType_SourceNode = 3211,
	AuditSecurityEventType_SourceName = 3212,
	AuditSecurityEventType_Time = 3213,
	AuditSecurityEventType_ReceiveTime = 3214,
	AuditSecurityEventType_LocalTime = 3215,
	AuditSecurityEventType_Message = 3216,
	AuditSecurityEventType_Severity = 3217,
	AuditSecurityEventType_ActionTimeStamp = 3218,
	AuditSecurityEventType_Status = 3219,
	AuditSecurityEventType_ServerId = 3220,
	AuditSecurityEventType_ClientAuditEntryId = 3221,
	AuditSecurityEventType_ClientUserId = 3222,
	AuditChannelEventType_EventId = 3223,
	AuditChannelEventType_EventType = 3224,
	AuditChannelEventType_SourceNode = 3225,
	AuditChannelEventType_SourceName = 3226,
	AuditChannelEventType_Time = 3227,
	AuditChannelEventType_ReceiveTime = 3228,
	AuditChannelEventType_LocalTime = 3229,
	AuditChannelEventType_Message = 3230,
	AuditChannelEventType_Severity = 3231,
	AuditChannelEventType_ActionTimeStamp = 3232,
	AuditChannelEventType_Status = 3233,
	AuditChannelEventType_ServerId = 3234,
	AuditChannelEventType_ClientAuditEntryId = 3235,
	AuditChannelEventType_ClientUserId = 3236,
	AuditOpenSecureChannelEventType_EventId = 3237,
	AuditOpenSecureChannelEventType_EventType = 3238,
	AuditOpenSecureChannelEventType_SourceNode = 3239,
	AuditOpenSecureChannelEventType_SourceName = 3240,
	AuditOpenSecureChannelEventType_Time = 3241,
	AuditOpenSecureChannelEventType_ReceiveTime = 3242,
	AuditOpenSecureChannelEventType_LocalTime = 3243,
	AuditOpenSecureChannelEventType_Message = 3244,
	AuditOpenSecureChannelEventType_Severity = 3245,
	AuditOpenSecureChannelEventType_ActionTimeStamp = 3246,
	AuditOpenSecureChannelEventType_Status = 3247,
	AuditOpenSecureChannelEventType_ServerId = 3248,
	AuditOpenSecureChannelEventType_ClientAuditEntryId = 3249,
	AuditOpenSecureChannelEventType_ClientUserId = 3250,
	AuditOpenSecureChannelEventType_SecureChannelId = 3251,
	AuditSessionEventType_EventId = 3252,
	AuditSessionEventType_EventType = 3253,
	AuditSessionEventType_SourceNode = 3254,
	AuditSessionEventType_SourceName = 3255,
	AuditSessionEventType_Time = 3256,
	AuditSessionEventType_ReceiveTime = 3257,
	AuditSessionEventType_LocalTime = 3258,
	AuditSessionEventType_Message = 3259,
	AuditSessionEventType_Severity = 3260,
	AuditSessionEventType_ActionTimeStamp = 3261,
	AuditSessionEventType_Status = 3262,
	AuditSessionEventType_ServerId = 3263,
	AuditSessionEventType_ClientAuditEntryId = 3264,
	AuditSessionEventType_ClientUserId = 3265,
	AuditCreateSessionEventType_EventId = 3266,
	AuditCreateSessionEventType_EventType = 3267,
	AuditCreateSessionEventType_SourceNode = 3268,
	AuditCreateSessionEventType_SourceName = 3269,
	AuditCreateSessionEventType_Time = 3270,
	AuditCreateSessionEventType_ReceiveTime = 3271,
	AuditCreateSessionEventType_LocalTime = 3272,
	AuditCreateSessionEventType_Message = 3273,
	AuditCreateSessionEventType_Severity = 3274,
	AuditCreateSessionEventType_ActionTimeStamp = 3275,
	AuditCreateSessionEventType_Status = 3276,
	AuditCreateSessionEventType_ServerId = 3277,
	AuditCreateSessionEventType_ClientAuditEntryId = 3278,
	AuditCreateSessionEventType_ClientUserId = 3279,
	AuditCreateSessionEventType_SessionId = 3280,
	AuditUrlMismatchEventType_EventId = 3281,
	AuditUrlMismatchEventType_EventType = 3282,
	AuditUrlMismatchEventType_SourceNode = 3283,
	AuditUrlMismatchEventType_SourceName = 3284,
	AuditUrlMismatchEventType_Time = 3285,
	AuditUrlMismatchEventType_ReceiveTime = 3286,
	AuditUrlMismatchEventType_LocalTime = 3287,
	AuditUrlMismatchEventType_Message = 3288,
	AuditUrlMismatchEventType_Severity = 3289,
	AuditUrlMismatchEventType_ActionTimeStamp = 3290,
	AuditUrlMismatchEventType_Status = 3291,
	AuditUrlMismatchEventType_ServerId = 3292,
	AuditUrlMismatchEventType_ClientAuditEntryId = 3293,
	AuditUrlMismatchEventType_ClientUserId = 3294,
	AuditUrlMismatchEventType_SessionId = 3295,
	AuditUrlMismatchEventType_SecureChannelId = 3296,
	AuditUrlMismatchEventType_ClientCertificate = 3297,
	AuditUrlMismatchEventType_ClientCertificateThumbprint = 3298,
	AuditUrlMismatchEventType_RevisedSessionTimeout = 3299,
	AuditActivateSessionEventType_EventId = 3300,
	AuditActivateSessionEventType_EventType = 3301,
	AuditActivateSessionEventType_SourceNode = 3302,
	AuditActivateSessionEventType_SourceName = 3303,
	AuditActivateSessionEventType_Time = 3304,
	AuditActivateSessionEventType_ReceiveTime = 3305,
	AuditActivateSessionEventType_LocalTime = 3306,
	AuditActivateSessionEventType_Message = 3307,
	AuditActivateSessionEventType_Severity = 3308,
	AuditActivateSessionEventType_ActionTimeStamp = 3309,
	AuditActivateSessionEventType_Status = 3310,
	AuditActivateSessionEventType_ServerId = 3311,
	AuditActivateSessionEventType_ClientAuditEntryId = 3312,
	AuditActivateSessionEventType_ClientUserId = 3313,
	AuditActivateSessionEventType_SessionId = 3314,
	AuditCancelEventType_EventId = 3315,
	AuditCancelEventType_EventType = 3316,
	AuditCancelEventType_SourceNode = 3317,
	AuditCancelEventType_SourceName = 3318,
	AuditCancelEventType_Time = 3319,
	AuditCancelEventType_ReceiveTime = 3320,
	AuditCancelEventType_LocalTime = 3321,
	AuditCancelEventType_Message = 3322,
	AuditCancelEventType_Severity = 3323,
	AuditCancelEventType_ActionTimeStamp = 3324,
	AuditCancelEventType_Status = 3325,
	AuditCancelEventType_ServerId = 3326,
	AuditCancelEventType_ClientAuditEntryId = 3327,
	AuditCancelEventType_ClientUserId = 3328,
	AuditCancelEventType_SessionId = 3329,
	AuditCertificateEventType_EventId = 3330,
	AuditCertificateEventType_EventType = 3331,
	AuditCertificateEventType_SourceNode = 3332,
	AuditCertificateEventType_SourceName = 3333,
	AuditCertificateEventType_Time = 3334,
	AuditCertificateEventType_ReceiveTime = 3335,
	AuditCertificateEventType_LocalTime = 3336,
	AuditCertificateEventType_Message = 3337,
	AuditCertificateEventType_Severity = 3338,
	AuditCertificateEventType_ActionTimeStamp = 3339,
	AuditCertificateEventType_Status = 3340,
	AuditCertificateEventType_ServerId = 3341,
	AuditCertificateEventType_ClientAuditEntryId = 3342,
	AuditCertificateEventType_ClientUserId = 3343,
	AuditCertificateDataMismatchEventType_EventId = 3344,
	AuditCertificateDataMismatchEventType_EventType = 3345,
	AuditCertificateDataMismatchEventType_SourceNode = 3346,
	AuditCertificateDataMismatchEventType_SourceName = 3347,
	AuditCertificateDataMismatchEventType_Time = 3348,
	AuditCertificateDataMismatchEventType_ReceiveTime = 3349,
	AuditCertificateDataMismatchEventType_LocalTime = 3350,
	AuditCertificateDataMismatchEventType_Message = 3351,
	AuditCertificateDataMismatchEventType_Severity = 3352,
	AuditCertificateDataMismatchEventType_ActionTimeStamp = 3353,
	AuditCertificateDataMismatchEventType_Status = 3354,
	AuditCertificateDataMismatchEventType_ServerId = 3355,
	AuditCertificateDataMismatchEventType_ClientAuditEntryId = 3356,
	AuditCertificateDataMismatchEventType_ClientUserId = 3357,
	AuditCertificateDataMismatchEventType_Certificate = 3358,
	AuditCertificateExpiredEventType_EventId = 3359,
	AuditCertificateExpiredEventType_EventType = 3360,
	AuditCertificateExpiredEventType_SourceNode = 3361,
	AuditCertificateExpiredEventType_SourceName = 3362,
	AuditCertificateExpiredEventType_Time = 3363,
	AuditCertificateExpiredEventType_ReceiveTime = 3364,
	AuditCertificateExpiredEventType_LocalTime = 3365,
	AuditCertificateExpiredEventType_Message = 3366,
	AuditCertificateExpiredEventType_Severity = 3367,
	AuditCertificateExpiredEventType_ActionTimeStamp = 3368,
	AuditCertificateExpiredEventType_Status = 3369,
	AuditCertificateExpiredEventType_ServerId = 3370,
	AuditCertificateExpiredEventType_ClientAuditEntryId = 3371,
	AuditCertificateExpiredEventType_ClientUserId = 3372,
	AuditCertificateExpiredEventType_Certificate = 3373,
	AuditCertificateInvalidEventType_EventId = 3374,
	AuditCertificateInvalidEventType_EventType = 3375,
	AuditCertificateInvalidEventType_SourceNode = 3376,
	AuditCertificateInvalidEventType_SourceName = 3377,
	AuditCertificateInvalidEventType_Time = 3378,
	AuditCertificateInvalidEventType_ReceiveTime = 3379,
	AuditCertificateInvalidEventType_LocalTime = 3380,
	AuditCertificateInvalidEventType_Message = 3381,
	AuditCertificateInvalidEventType_Severity = 3382,
	AuditCertificateInvalidEventType_ActionTimeStamp = 3383,
	AuditCertificateInvalidEventType_Status = 3384,
	AuditCertificateInvalidEventType_ServerId = 3385,
	AuditCertificateInvalidEventType_ClientAuditEntryId = 3386,
	AuditCertificateInvalidEventType_ClientUserId = 3387,
	AuditCertificateInvalidEventType_Certificate = 3388,
	AuditCertificateUntrustedEventType_EventId = 3389,
	AuditCertificateUntrustedEventType_EventType = 3390,
	AuditCertificateUntrustedEventType_SourceNode = 3391,
	AuditCertificateUntrustedEventType_SourceName = 3392,
	AuditCertificateUntrustedEventType_Time = 3393,
	AuditCertificateUntrustedEventType_ReceiveTime = 3394,
	AuditCertificateUntrustedEventType_LocalTime = 3395,
	AuditCertificateUntrustedEventType_Message = 3396,
	AuditCertificateUntrustedEventType_Severity = 3397,
	AuditCertificateUntrustedEventType_ActionTimeStamp = 3398,
	AuditCertificateUntrustedEventType_Status = 3399,
	AuditCertificateUntrustedEventType_ServerId = 3400,
	AuditCertificateUntrustedEventType_ClientAuditEntryId = 3401,
	AuditCertificateUntrustedEventType_ClientUserId = 3402,
	AuditCertificateUntrustedEventType_Certificate = 3403,
	AuditCertificateRevokedEventType_EventId = 3404,
	AuditCertificateRevokedEventType_EventType = 3405,
	AuditCertificateRevokedEventType_SourceNode = 3406,
	AuditCertificateRevokedEventType_SourceName = 3407,
	AuditCertificateRevokedEventType_Time = 3408,
	AuditCertificateRevokedEventType_ReceiveTime = 3409,
	AuditCertificateRevokedEventType_LocalTime = 3410,
	AuditCertificateRevokedEventType_Message = 3411,
	AuditCertificateRevokedEventType_Severity = 3412,
	AuditCertificateRevokedEventType_ActionTimeStamp = 3413,
	AuditCertificateRevokedEventType_Status = 3414,
	AuditCertificateRevokedEventType_ServerId = 3415,
	AuditCertificateRevokedEventType_ClientAuditEntryId = 3416,
	AuditCertificateRevokedEventType_ClientUserId = 3417,
	AuditCertificateRevokedEventType_Certificate = 3418,
	AuditCertificateMismatchEventType_EventId = 3419,
	AuditCertificateMismatchEventType_EventType = 3420,
	AuditCertificateMismatchEventType_SourceNode = 3421,
	AuditCertificateMismatchEventType_SourceName = 3422,
	AuditCertificateMismatchEventType_Time = 3423,
	AuditCertificateMismatchEventType_ReceiveTime = 3424,
	AuditCertificateMismatchEventType_LocalTime = 3425,
	AuditCertificateMismatchEventType_Message = 3426,
	AuditCertificateMismatchEventType_Severity = 3427,
	AuditCertificateMismatchEventType_ActionTimeStamp = 3428,
	AuditCertificateMismatchEventType_Status = 3429,
	AuditCertificateMismatchEventType_ServerId = 3430,
	AuditCertificateMismatchEventType_ClientAuditEntryId = 3431,
	AuditCertificateMismatchEventType_ClientUserId = 3432,
	AuditCertificateMismatchEventType_Certificate = 3433,
	AuditNodeManagementEventType_EventId = 3434,
	AuditNodeManagementEventType_EventType = 3435,
	AuditNodeManagementEventType_SourceNode = 3436,
	AuditNodeManagementEventType_SourceName = 3437,
	AuditNodeManagementEventType_Time = 3438,
	AuditNodeManagementEventType_ReceiveTime = 3439,
	AuditNodeManagementEventType_LocalTime = 3440,
	AuditNodeManagementEventType_Message = 3441,
	AuditNodeManagementEventType_Severity = 3442,
	AuditNodeManagementEventType_ActionTimeStamp = 3443,
	AuditNodeManagementEventType_Status = 3444,
	AuditNodeManagementEventType_ServerId = 3445,
	AuditNodeManagementEventType_ClientAuditEntryId = 3446,
	AuditNodeManagementEventType_ClientUserId = 3447,
	AuditAddNodesEventType_EventId = 3448,
	AuditAddNodesEventType_EventType = 3449,
	AuditAddNodesEventType_SourceNode = 3450,
	AuditAddNodesEventType_SourceName = 3451,
	AuditAddNodesEventType_Time = 3452,
	AuditAddNodesEventType_ReceiveTime = 3453,
	AuditAddNodesEventType_LocalTime = 3454,
	AuditAddNodesEventType_Message = 3455,
	AuditAddNodesEventType_Severity = 3456,
	AuditAddNodesEventType_ActionTimeStamp = 3457,
	AuditAddNodesEventType_Status = 3458,
	AuditAddNodesEventType_ServerId = 3459,
	AuditAddNodesEventType_ClientAuditEntryId = 3460,
	AuditAddNodesEventType_ClientUserId = 3461,
	AuditDeleteNodesEventType_EventId = 3462,
	AuditDeleteNodesEventType_EventType = 3463,
	AuditDeleteNodesEventType_SourceNode = 3464,
	AuditDeleteNodesEventType_SourceName = 3465,
	AuditDeleteNodesEventType_Time = 3466,
	AuditDeleteNodesEventType_ReceiveTime = 3467,
	AuditDeleteNodesEventType_LocalTime = 3468,
	AuditDeleteNodesEventType_Message = 3469,
	AuditDeleteNodesEventType_Severity = 3470,
	AuditDeleteNodesEventType_ActionTimeStamp = 3471,
	AuditDeleteNodesEventType_Status = 3472,
	AuditDeleteNodesEventType_ServerId = 3473,
	AuditDeleteNodesEventType_ClientAuditEntryId = 3474,
	AuditDeleteNodesEventType_ClientUserId = 3475,
	AuditAddReferencesEventType_EventId = 3476,
	AuditAddReferencesEventType_EventType = 3477,
	AuditAddReferencesEventType_SourceNode = 3478,
	AuditAddReferencesEventType_SourceName = 3479,
	AuditAddReferencesEventType_Time = 3480,
	AuditAddReferencesEventType_ReceiveTime = 3481,
	AuditAddReferencesEventType_LocalTime = 3482,
	AuditAddReferencesEventType_Message = 3483,
	AuditAddReferencesEventType_Severity = 3484,
	AuditAddReferencesEventType_ActionTimeStamp = 3485,
	AuditAddReferencesEventType_Status = 3486,
	AuditAddReferencesEventType_ServerId = 3487,
	AuditAddReferencesEventType_ClientAuditEntryId = 3488,
	AuditAddReferencesEventType_ClientUserId = 3489,
	AuditDeleteReferencesEventType_EventId = 3490,
	AuditDeleteReferencesEventType_EventType = 3491,
	AuditDeleteReferencesEventType_SourceNode = 3492,
	AuditDeleteReferencesEventType_SourceName = 3493,
	AuditDeleteReferencesEventType_Time = 3494,
	AuditDeleteReferencesEventType_ReceiveTime = 3495,
	AuditDeleteReferencesEventType_LocalTime = 3496,
	AuditDeleteReferencesEventType_Message = 3497,
	AuditDeleteReferencesEventType_Severity = 3498,
	AuditDeleteReferencesEventType_ActionTimeStamp = 3499,
	AuditDeleteReferencesEventType_Status = 3500,
	AuditDeleteReferencesEventType_ServerId = 3501,
	AuditDeleteReferencesEventType_ClientAuditEntryId = 3502,
	AuditDeleteReferencesEventType_ClientUserId = 3503,
	AuditUpdateEventType_EventId = 3504,
	AuditUpdateEventType_EventType = 3505,
	AuditUpdateEventType_SourceNode = 3506,
	AuditUpdateEventType_SourceName = 3507,
	AuditUpdateEventType_Time = 3508,
	AuditUpdateEventType_ReceiveTime = 3509,
	AuditUpdateEventType_LocalTime = 3510,
	AuditUpdateEventType_Message = 3511,
	AuditUpdateEventType_Severity = 3512,
	AuditUpdateEventType_ActionTimeStamp = 3513,
	AuditUpdateEventType_Status = 3514,
	AuditUpdateEventType_ServerId = 3515,
	AuditUpdateEventType_ClientAuditEntryId = 3516,
	AuditUpdateEventType_ClientUserId = 3517,
	AuditWriteUpdateEventType_EventId = 3518,
	AuditWriteUpdateEventType_EventType = 3519,
	AuditWriteUpdateEventType_SourceNode = 3520,
	AuditWriteUpdateEventType_SourceName = 3521,
	AuditWriteUpdateEventType_Time = 3522,
	AuditWriteUpdateEventType_ReceiveTime = 3523,
	AuditWriteUpdateEventType_LocalTime = 3524,
	AuditWriteUpdateEventType_Message = 3525,
	AuditWriteUpdateEventType_Severity = 3526,
	AuditWriteUpdateEventType_ActionTimeStamp = 3527,
	AuditWriteUpdateEventType_Status = 3528,
	AuditWriteUpdateEventType_ServerId = 3529,
	AuditWriteUpdateEventType_ClientAuditEntryId = 3530,
	AuditWriteUpdateEventType_ClientUserId = 3531,
	AuditHistoryUpdateEventType_EventId = 3532,
	AuditHistoryUpdateEventType_EventType = 3533,
	AuditHistoryUpdateEventType_SourceNode = 3534,
	AuditHistoryUpdateEventType_SourceName = 3535,
	AuditHistoryUpdateEventType_Time = 3536,
	AuditHistoryUpdateEventType_ReceiveTime = 3537,
	AuditHistoryUpdateEventType_LocalTime = 3538,
	AuditHistoryUpdateEventType_Message = 3539,
	AuditHistoryUpdateEventType_Severity = 3540,
	AuditHistoryUpdateEventType_ActionTimeStamp = 3541,
	AuditHistoryUpdateEventType_Status = 3542,
	AuditHistoryUpdateEventType_ServerId = 3543,
	AuditHistoryUpdateEventType_ClientAuditEntryId = 3544,
	AuditHistoryUpdateEventType_ClientUserId = 3545,
	AuditHistoryEventUpdateEventType_EventId = 3546,
	AuditHistoryEventUpdateEventType_EventType = 3547,
	AuditHistoryEventUpdateEventType_SourceNode = 3548,
	AuditHistoryEventUpdateEventType_SourceName = 3549,
	AuditHistoryEventUpdateEventType_Time = 3550,
	AuditHistoryEventUpdateEventType_ReceiveTime = 3551,
	AuditHistoryEventUpdateEventType_LocalTime = 3552,
	AuditHistoryEventUpdateEventType_Message = 3553,
	AuditHistoryEventUpdateEventType_Severity = 3554,
	AuditHistoryEventUpdateEventType_ActionTimeStamp = 3555,
	AuditHistoryEventUpdateEventType_Status = 3556,
	AuditHistoryEventUpdateEventType_ServerId = 3557,
	AuditHistoryEventUpdateEventType_ClientAuditEntryId = 3558,
	AuditHistoryEventUpdateEventType_ClientUserId = 3559,
	AuditHistoryEventUpdateEventType_ParameterDataTypeId = 3560,
	AuditHistoryValueUpdateEventType_EventId = 3561,
	AuditHistoryValueUpdateEventType_EventType = 3562,
	AuditHistoryValueUpdateEventType_SourceNode = 3563,
	AuditHistoryValueUpdateEventType_SourceName = 3564,
	AuditHistoryValueUpdateEventType_Time = 3565,
	AuditHistoryValueUpdateEventType_ReceiveTime = 3566,
	AuditHistoryValueUpdateEventType_LocalTime = 3567,
	AuditHistoryValueUpdateEventType_Message = 3568,
	AuditHistoryValueUpdateEventType_Severity = 3569,
	AuditHistoryValueUpdateEventType_ActionTimeStamp = 3570,
	AuditHistoryValueUpdateEventType_Status = 3571,
	AuditHistoryValueUpdateEventType_ServerId = 3572,
	AuditHistoryValueUpdateEventType_ClientAuditEntryId = 3573,
	AuditHistoryValueUpdateEventType_ClientUserId = 3574,
	AuditHistoryValueUpdateEventType_ParameterDataTypeId = 3575,
	AuditHistoryDeleteEventType_EventId = 3576,
	AuditHistoryDeleteEventType_EventType = 3577,
	AuditHistoryDeleteEventType_SourceNode = 3578,
	AuditHistoryDeleteEventType_SourceName = 3579,
	AuditHistoryDeleteEventType_Time = 3580,
	AuditHistoryDeleteEventType_ReceiveTime = 3581,
	AuditHistoryDeleteEventType_LocalTime = 3582,
	AuditHistoryDeleteEventType_Message = 3583,
	AuditHistoryDeleteEventType_Severity = 3584,
	AuditHistoryDeleteEventType_ActionTimeStamp = 3585,
	AuditHistoryDeleteEventType_Status = 3586,
	AuditHistoryDeleteEventType_ServerId = 3587,
	AuditHistoryDeleteEventType_ClientAuditEntryId = 3588,
	AuditHistoryDeleteEventType_ClientUserId = 3589,
	AuditHistoryDeleteEventType_ParameterDataTypeId = 3590,
	AuditHistoryRawModifyDeleteEventType_EventId = 3591,
	AuditHistoryRawModifyDeleteEventType_EventType = 3592,
	AuditHistoryRawModifyDeleteEventType_SourceNode = 3593,
	AuditHistoryRawModifyDeleteEventType_SourceName = 3594,
	AuditHistoryRawModifyDeleteEventType_Time = 3595,
	AuditHistoryRawModifyDeleteEventType_ReceiveTime = 3596,
	AuditHistoryRawModifyDeleteEventType_LocalTime = 3597,
	AuditHistoryRawModifyDeleteEventType_Message = 3598,
	AuditHistoryRawModifyDeleteEventType_Severity = 3599,
	AuditHistoryRawModifyDeleteEventType_ActionTimeStamp = 3600,
	AuditHistoryRawModifyDeleteEventType_Status = 3601,
	AuditHistoryRawModifyDeleteEventType_ServerId = 3602,
	AuditHistoryRawModifyDeleteEventType_ClientAuditEntryId = 3603,
	AuditHistoryRawModifyDeleteEventType_ClientUserId = 3604,
	AuditHistoryRawModifyDeleteEventType_ParameterDataTypeId = 3605,
	AuditHistoryRawModifyDeleteEventType_UpdatedNode = 3606,
	AuditHistoryAtTimeDeleteEventType_EventId = 3607,
	AuditHistoryAtTimeDeleteEventType_EventType = 3608,
	AuditHistoryAtTimeDeleteEventType_SourceNode = 3609,
	AuditHistoryAtTimeDeleteEventType_SourceName = 3610,
	AuditHistoryAtTimeDeleteEventType_Time = 3611,
	AuditHistoryAtTimeDeleteEventType_ReceiveTime = 3612,
	AuditHistoryAtTimeDeleteEventType_LocalTime = 3613,
	AuditHistoryAtTimeDeleteEventType_Message = 3614,
	AuditHistoryAtTimeDeleteEventType_Severity = 3615,
	AuditHistoryAtTimeDeleteEventType_ActionTimeStamp = 3616,
	AuditHistoryAtTimeDeleteEventType_Status = 3617,
	AuditHistoryAtTimeDeleteEventType_ServerId = 3618,
	AuditHistoryAtTimeDeleteEventType_ClientAuditEntryId = 3619,
	AuditHistoryAtTimeDeleteEventType_ClientUserId = 3620,
	AuditHistoryAtTimeDeleteEventType_ParameterDataTypeId = 3621,
	AuditHistoryAtTimeDeleteEventType_UpdatedNode = 3622,
	AuditHistoryEventDeleteEventType_EventId = 3623,
	AuditHistoryEventDeleteEventType_EventType = 3624,
	AuditHistoryEventDeleteEventType_SourceNode = 3625,
	AuditHistoryEventDeleteEventType_SourceName = 3626,
	AuditHistoryEventDeleteEventType_Time = 3627,
	AuditHistoryEventDeleteEventType_ReceiveTime = 3628,
	AuditHistoryEventDeleteEventType_LocalTime = 3629,
	AuditHistoryEventDeleteEventType_Message = 3630,
	AuditHistoryEventDeleteEventType_Severity = 3631,
	AuditHistoryEventDeleteEventType_ActionTimeStamp = 3632,
	AuditHistoryEventDeleteEventType_Status = 3633,
	AuditHistoryEventDeleteEventType_ServerId = 3634,
	AuditHistoryEventDeleteEventType_ClientAuditEntryId = 3635,
	AuditHistoryEventDeleteEventType_ClientUserId = 3636,
	AuditHistoryEventDeleteEventType_ParameterDataTypeId = 3637,
	AuditHistoryEventDeleteEventType_UpdatedNode = 3638,
	AuditUpdateMethodEventType_EventId = 3639,
	AuditUpdateMethodEventType_EventType = 3640,
	AuditUpdateMethodEventType_SourceNode = 3641,
	AuditUpdateMethodEventType_SourceName = 3642,
	AuditUpdateMethodEventType_Time = 3643,
	AuditUpdateMethodEventType_ReceiveTime = 3644,
	AuditUpdateMethodEventType_LocalTime = 3645,
	AuditUpdateMethodEventType_Message = 3646,
	AuditUpdateMethodEventType_Severity = 3647,
	AuditUpdateMethodEventType_ActionTimeStamp = 3648,
	AuditUpdateMethodEventType_Status = 3649,
	AuditUpdateMethodEventType_ServerId = 3650,
	AuditUpdateMethodEventType_ClientAuditEntryId = 3651,
	AuditUpdateMethodEventType_ClientUserId = 3652,
	SystemEventType_EventId = 3653,
	SystemEventType_EventType = 3654,
	SystemEventType_SourceNode = 3655,
	SystemEventType_SourceName = 3656,
	SystemEventType_Time = 3657,
	SystemEventType_ReceiveTime = 3658,
	SystemEventType_LocalTime = 3659,
	SystemEventType_Message = 3660,
	SystemEventType_Severity = 3661,
	DeviceFailureEventType_EventId = 3662,
	DeviceFailureEventType_EventType = 3663,
	DeviceFailureEventType_SourceNode = 3664,
	DeviceFailureEventType_SourceName = 3665,
	DeviceFailureEventType_Time = 3666,
	DeviceFailureEventType_ReceiveTime = 3667,
	DeviceFailureEventType_LocalTime = 3668,
	DeviceFailureEventType_Message = 3669,
	DeviceFailureEventType_Severity = 3670,
	BaseModelChangeEventType_EventId = 3671,
	BaseModelChangeEventType_EventType = 3672,
	BaseModelChangeEventType_SourceNode = 3673,
	BaseModelChangeEventType_SourceName = 3674,
	BaseModelChangeEventType_Time = 3675,
	BaseModelChangeEventType_ReceiveTime = 3676,
	BaseModelChangeEventType_LocalTime = 3677,
	BaseModelChangeEventType_Message = 3678,
	BaseModelChangeEventType_Severity = 3679,
	GeneralModelChangeEventType_EventId = 3680,
	GeneralModelChangeEventType_EventType = 3681,
	GeneralModelChangeEventType_SourceNode = 3682,
	GeneralModelChangeEventType_SourceName = 3683,
	GeneralModelChangeEventType_Time = 3684,
	GeneralModelChangeEventType_ReceiveTime = 3685,
	GeneralModelChangeEventType_LocalTime = 3686,
	GeneralModelChangeEventType_Message = 3687,
	GeneralModelChangeEventType_Severity = 3688,
	SemanticChangeEventType_EventId = 3689,
	SemanticChangeEventType_EventType = 3690,
	SemanticChangeEventType_SourceNode = 3691,
	SemanticChangeEventType_SourceName = 3692,
	SemanticChangeEventType_Time = 3693,
	SemanticChangeEventType_ReceiveTime = 3694,
	SemanticChangeEventType_LocalTime = 3695,
	SemanticChangeEventType_Message = 3696,
	SemanticChangeEventType_Severity = 3697,
	ServerStatusType_BuildInfo_ProductUri = 3698,
	ServerStatusType_BuildInfo_ManufacturerName = 3699,
	ServerStatusType_BuildInfo_ProductName = 3700,
	ServerStatusType_BuildInfo_SoftwareVersion = 3701,
	ServerStatusType_BuildInfo_BuildNumber = 3702,
	ServerStatusType_BuildInfo_BuildDate = 3703,
	Server_ServerCapabilities_SoftwareCertificates = 3704,
	Server_ServerDiagnostics_ServerDiagnosticsSummary_RejectedSessionCount = 3705,
	Server_ServerDiagnostics_SessionsDiagnosticsSummary = 3706,
	Server_ServerDiagnostics_SessionsDiagnosticsSummary_SessionDiagnosticsArray = 3707,
	Server_ServerDiagnostics_SessionsDiagnosticsSummary_SessionSecurityDiagnosticsArray = 3708,
	Server_ServerRedundancy_RedundancySupport = 3709,
	FiniteStateVariableType_Name = 3714,
	FiniteStateVariableType_Number = 3715,
	FiniteStateVariableType_EffectiveDisplayName = 3716,
	FiniteTransitionVariableType_Name = 3717,
	FiniteTransitionVariableType_Number = 3718,
	FiniteTransitionVariableType_TransitionTime = 3719,
	StateMachineType_CurrentState_Id = 3720,
	StateMachineType_CurrentState_Name = 3721,
	StateMachineType_CurrentState_Number = 3722,
	StateMachineType_CurrentState_EffectiveDisplayName = 3723,
	StateMachineType_LastTransition_Id = 3724,
	StateMachineType_LastTransition_Name = 3725,
	StateMachineType_LastTransition_Number = 3726,
	StateMachineType_LastTransition_TransitionTime = 3727,
	FiniteStateMachineType_CurrentState_Id = 3728,
	FiniteStateMachineType_CurrentState_Name = 3729,
	FiniteStateMachineType_CurrentState_Number = 3730,
	FiniteStateMachineType_CurrentState_EffectiveDisplayName = 3731,
	FiniteStateMachineType_LastTransition_Id = 3732,
	FiniteStateMachineType_LastTransition_Name = 3733,
	FiniteStateMachineType_LastTransition_Number = 3734,
	FiniteStateMachineType_LastTransition_TransitionTime = 3735,
	InitialStateType_StateNumber = 3736,
	TransitionEventType_EventId = 3737,
	TransitionEventType_EventType = 3738,
	TransitionEventType_SourceNode = 3739,
	TransitionEventType_SourceName = 3740,
	TransitionEventType_Time = 3741,
	TransitionEventType_ReceiveTime = 3742,
	TransitionEventType_LocalTime = 3743,
	TransitionEventType_Message = 3744,
	TransitionEventType_Severity = 3745,
	TransitionEventType_FromState_Id = 3746,
	TransitionEventType_FromState_Name = 3747,
	TransitionEventType_FromState_Number = 3748,
	TransitionEventType_FromState_EffectiveDisplayName = 3749,
	TransitionEventType_ToState_Id = 3750,
	TransitionEventType_ToState_Name = 3751,
	TransitionEventType_ToState_Number = 3752,
	TransitionEventType_ToState_EffectiveDisplayName = 3753,
	TransitionEventType_Transition_Id = 3754,
	TransitionEventType_Transition_Name = 3755,
	TransitionEventType_Transition_Number = 3756,
	TransitionEventType_Transition_TransitionTime = 3757,
	AuditUpdateStateEventType_EventId = 3758,
	AuditUpdateStateEventType_EventType = 3759,
	AuditUpdateStateEventType_SourceNode = 3760,
	AuditUpdateStateEventType_SourceName = 3761,
	AuditUpdateStateEventType_Time = 3762,
	AuditUpdateStateEventType_ReceiveTime = 3763,
	AuditUpdateStateEventType_LocalTime = 3764,
	AuditUpdateStateEventType_Message = 3765,
	AuditUpdateStateEventType_Severity = 3766,
	AuditUpdateStateEventType_ActionTimeStamp = 3767,
	AuditUpdateStateEventType_Status = 3768,
	AuditUpdateStateEventType_ServerId = 3769,
	AuditUpdateStateEventType_ClientAuditEntryId = 3770,
	AuditUpdateStateEventType_ClientUserId = 3771,
	AuditUpdateStateEventType_MethodId = 3772,
	AuditUpdateStateEventType_InputArguments = 3773,
	AnalogItemType_Definition = 3774,
	AnalogItemType_ValuePrecision = 3775,
	DiscreteItemType_Definition = 3776,
	DiscreteItemType_ValuePrecision = 3777,
	TwoStateDiscreteType_Definition = 3778,
	TwoStateDiscreteType_ValuePrecision = 3779,
	MultiStateDiscreteType_Definition = 3780,
	MultiStateDiscreteType_ValuePrecision = 3781,
	ProgramTransitionEventType_EventId = 3782,
	ProgramTransitionEventType_EventType = 3783,
	ProgramTransitionEventType_SourceNode = 3784,
	ProgramTransitionEventType_SourceName = 3785,
	ProgramTransitionEventType_Time = 3786,
	ProgramTransitionEventType_ReceiveTime = 3787,
	ProgramTransitionEventType_LocalTime = 3788,
	ProgramTransitionEventType_Message = 3789,
	ProgramTransitionEventType_Severity = 3790,
	ProgramTransitionEventType_FromState = 3791,
	ProgramTransitionEventType_FromState_Id = 3792,
	ProgramTransitionEventType_FromState_Name = 3793,
	ProgramTransitionEventType_FromState_Number = 3794,
	ProgramTransitionEventType_FromState_EffectiveDisplayName = 3795,
	ProgramTransitionEventType_ToState = 3796,
	ProgramTransitionEventType_ToState_Id = 3797,
	ProgramTransitionEventType_ToState_Name = 3798,
	ProgramTransitionEventType_ToState_Number = 3799,
	ProgramTransitionEventType_ToState_EffectiveDisplayName = 3800,
	ProgramTransitionEventType_Transition = 3801,
	ProgramTransitionEventType_Transition_Id = 3802,
	ProgramTransitionEventType_Transition_Name = 3803,
	ProgramTransitionEventType_Transition_Number = 3804,
	ProgramTransitionEventType_Transition_TransitionTime = 3805,
	ProgramTransitionAuditEventType = 3806,
	ProgramTransitionAuditEventType_EventId = 3807,
	ProgramTransitionAuditEventType_EventType = 3808,
	ProgramTransitionAuditEventType_SourceNode = 3809,
	ProgramTransitionAuditEventType_SourceName = 3810,
	ProgramTransitionAuditEventType_Time = 3811,
	ProgramTransitionAuditEventType_ReceiveTime = 3812,
	ProgramTransitionAuditEventType_LocalTime = 3813,
	ProgramTransitionAuditEventType_Message = 3814,
	ProgramTransitionAuditEventType_Severity = 3815,
	ProgramTransitionAuditEventType_ActionTimeStamp = 3816,
	ProgramTransitionAuditEventType_Status = 3817,
	ProgramTransitionAuditEventType_ServerId = 3818,
	ProgramTransitionAuditEventType_ClientAuditEntryId = 3819,
	ProgramTransitionAuditEventType_ClientUserId = 3820,
	ProgramTransitionAuditEventType_MethodId = 3821,
	ProgramTransitionAuditEventType_InputArguments = 3822,
	ProgramTransitionAuditEventType_OldStateId = 3823,
	ProgramTransitionAuditEventType_NewStateId = 3824,
	ProgramTransitionAuditEventType_Transition = 3825,
	ProgramTransitionAuditEventType_Transition_Id = 3826,
	ProgramTransitionAuditEventType_Transition_Name = 3827,
	ProgramTransitionAuditEventType_Transition_Number = 3828,
	ProgramTransitionAuditEventType_Transition_TransitionTime = 3829,
	ProgramStateMachineType_CurrentState = 3830,
	ProgramStateMachineType_CurrentState_Id = 3831,
	ProgramStateMachineType_CurrentState_Name = 3832,
	ProgramStateMachineType_CurrentState_Number = 3833,
	ProgramStateMachineType_CurrentState_EffectiveDisplayName = 3834,
	ProgramStateMachineType_LastTransition = 3835,
	ProgramStateMachineType_LastTransition_Id = 3836,
	ProgramStateMachineType_LastTransition_Name = 3837,
	ProgramStateMachineType_LastTransition_Number = 3838,
	ProgramStateMachineType_LastTransition_TransitionTime = 3839,
	ProgramStateMachineType_ProgramDiagnostics_CreateSessionId = 3840,
	ProgramStateMachineType_ProgramDiagnostics_CreateClientName = 3841,
	ProgramStateMachineType_ProgramDiagnostics_InvocationCreationTime = 3842,
	ProgramStateMachineType_ProgramDiagnostics_LastTransitionTime = 3843,
	ProgramStateMachineType_ProgramDiagnostics_LastMethodCall = 3844,
	ProgramStateMachineType_ProgramDiagnostics_LastMethodSessionId = 3845,
	ProgramStateMachineType_ProgramDiagnostics_LastMethodInputArguments = 3846,
	ProgramStateMachineType_ProgramDiagnostics_LastMethodOutputArguments = 3847,
	ProgramStateMachineType_ProgramDiagnostics_LastMethodCallTime = 3848,
	ProgramStateMachineType_ProgramDiagnostics_LastMethodReturnStatus = 3849,
	ProgramStateMachineType_FinalResultData = 3850,
	AddCommentMethodType = 3863,
	AddCommentMethodType_InputArguments = 3864,
	ConditionType_EventId = 3865,
	ConditionType_EventType = 3866,
	ConditionType_SourceNode = 3867,
	ConditionType_SourceName = 3868,
	ConditionType_Time = 3869,
	ConditionType_ReceiveTime = 3870,
	ConditionType_LocalTime = 3871,
	ConditionType_Message = 3872,
	ConditionType_Severity = 3873,
	ConditionType_Retain = 3874,
	ConditionType_ConditionRefresh = 3875,
	ConditionType_ConditionRefresh_InputArguments = 3876,
	RefreshStartEventType_EventId = 3969,
	RefreshStartEventType_EventType = 3970,
	RefreshStartEventType_SourceNode = 3971,
	RefreshStartEventType_SourceName = 3972,
	RefreshStartEventType_Time = 3973,
	RefreshStartEventType_ReceiveTime = 3974,
	RefreshStartEventType_LocalTime = 3975,
	RefreshStartEventType_Message = 3976,
	RefreshStartEventType_Severity = 3977,
	RefreshEndEventType_EventId = 3978,
	RefreshEndEventType_EventType = 3979,
	RefreshEndEventType_SourceNode = 3980,
	RefreshEndEventType_SourceName = 3981,
	RefreshEndEventType_Time = 3982,
	RefreshEndEventType_ReceiveTime = 3983,
	RefreshEndEventType_LocalTime = 3984,
	RefreshEndEventType_Message = 3985,
	RefreshEndEventType_Severity = 3986,
	RefreshRequiredEventType_EventId = 3987,
	RefreshRequiredEventType_EventType = 3988,
	RefreshRequiredEventType_SourceNode = 3989,
	RefreshRequiredEventType_SourceName = 3990,
	RefreshRequiredEventType_Time = 3991,
	RefreshRequiredEventType_ReceiveTime = 3992,
	RefreshRequiredEventType_LocalTime = 3993,
	RefreshRequiredEventType_Message = 3994,
	RefreshRequiredEventType_Severity = 3995,
	AuditConditionEventType_EventId = 3996,
	AuditConditionEventType_EventType = 3997,
	AuditConditionEventType_SourceNode = 3998,
	AuditConditionEventType_SourceName = 3999,
	AuditConditionEventType_Time = 4000,
	AuditConditionEventType_ReceiveTime = 4001,
	AuditConditionEventType_LocalTime = 4002,
	AuditConditionEventType_Message = 4003,
	AuditConditionEventType_Severity = 4004,
	AuditConditionEventType_ActionTimeStamp = 4005,
	AuditConditionEventType_Status = 4006,
	AuditConditionEventType_ServerId = 4007,
	AuditConditionEventType_ClientAuditEntryId = 4008,
	AuditConditionEventType_ClientUserId = 4009,
	AuditConditionEventType_MethodId = 4010,
	AuditConditionEventType_InputArguments = 4011,
	AuditConditionEnableEventType_EventId = 4106,
	AuditConditionEnableEventType_EventType = 4107,
	AuditConditionEnableEventType_SourceNode = 4108,
	AuditConditionEnableEventType_SourceName = 4109,
	AuditConditionEnableEventType_Time = 4110,
	AuditConditionEnableEventType_ReceiveTime = 4111,
	AuditConditionEnableEventType_LocalTime = 4112,
	AuditConditionEnableEventType_Message = 4113,
	AuditConditionEnableEventType_Severity = 4114,
	AuditConditionEnableEventType_ActionTimeStamp = 4115,
	AuditConditionEnableEventType_Status = 4116,
	AuditConditionEnableEventType_ServerId = 4117,
	AuditConditionEnableEventType_ClientAuditEntryId = 4118,
	AuditConditionEnableEventType_ClientUserId = 4119,
	AuditConditionEnableEventType_MethodId = 4120,
	AuditConditionEnableEventType_InputArguments = 4121,
	AuditConditionCommentEventType_EventId = 4170,
	AuditConditionCommentEventType_EventType = 4171,
	AuditConditionCommentEventType_SourceNode = 4172,
	AuditConditionCommentEventType_SourceName = 4173,
	AuditConditionCommentEventType_Time = 4174,
	AuditConditionCommentEventType_ReceiveTime = 4175,
	AuditConditionCommentEventType_LocalTime = 4176,
	AuditConditionCommentEventType_Message = 4177,
	AuditConditionCommentEventType_Severity = 4178,
	AuditConditionCommentEventType_ActionTimeStamp = 4179,
	AuditConditionCommentEventType_Status = 4180,
	AuditConditionCommentEventType_ServerId = 4181,
	AuditConditionCommentEventType_ClientAuditEntryId = 4182,
	AuditConditionCommentEventType_ClientUserId = 4183,
	AuditConditionCommentEventType_MethodId = 4184,
	AuditConditionCommentEventType_InputArguments = 4185,
	DialogConditionType_EventId = 4188,
	DialogConditionType_EventType = 4189,
	DialogConditionType_SourceNode = 4190,
	DialogConditionType_SourceName = 4191,
	DialogConditionType_Time = 4192,
	DialogConditionType_ReceiveTime = 4193,
	DialogConditionType_LocalTime = 4194,
	DialogConditionType_Message = 4195,
	DialogConditionType_Severity = 4196,
	DialogConditionType_Retain = 4197,
	DialogConditionType_ConditionRefresh = 4198,
	DialogConditionType_ConditionRefresh_InputArguments = 4199,
	AcknowledgeableConditionType_EventId = 5113,
	AcknowledgeableConditionType_EventType = 5114,
	AcknowledgeableConditionType_SourceNode = 5115,
	AcknowledgeableConditionType_SourceName = 5116,
	AcknowledgeableConditionType_Time = 5117,
	AcknowledgeableConditionType_ReceiveTime = 5118,
	AcknowledgeableConditionType_LocalTime = 5119,
	AcknowledgeableConditionType_Message = 5120,
	AcknowledgeableConditionType_Severity = 5121,
	AcknowledgeableConditionType_Retain = 5122,
	AcknowledgeableConditionType_ConditionRefresh = 5123,
	AcknowledgeableConditionType_ConditionRefresh_InputArguments = 5124,
	AlarmConditionType_EventId = 5540,
	AlarmConditionType_EventType = 5541,
	AlarmConditionType_SourceNode = 5542,
	AlarmConditionType_SourceName = 5543,
	AlarmConditionType_Time = 5544,
	AlarmConditionType_ReceiveTime = 5545,
	AlarmConditionType_LocalTime = 5546,
	AlarmConditionType_Message = 5547,
	AlarmConditionType_Severity = 5548,
	AlarmConditionType_Retain = 5549,
	AlarmConditionType_ConditionRefresh = 5550,
	AlarmConditionType_ConditionRefresh_InputArguments = 5551,
	ShelvedStateMachineType_CurrentState = 6088,
	ShelvedStateMachineType_CurrentState_Id = 6089,
	ShelvedStateMachineType_CurrentState_Name = 6090,
	ShelvedStateMachineType_CurrentState_Number = 6091,
	ShelvedStateMachineType_CurrentState_EffectiveDisplayName = 6092,
	ShelvedStateMachineType_LastTransition = 6093,
	ShelvedStateMachineType_LastTransition_Id = 6094,
	ShelvedStateMachineType_LastTransition_Name = 6095,
	ShelvedStateMachineType_LastTransition_Number = 6096,
	ShelvedStateMachineType_LastTransition_TransitionTime = 6097,
	ShelvedStateMachineType_Unshelved_StateNumber = 6098,
	ShelvedStateMachineType_TimedShelved_StateNumber = 6100,
	ShelvedStateMachineType_OneShotShelved_StateNumber = 6101,
	TimedShelveMethodType = 6102,
	TimedShelveMethodType_InputArguments = 6103,
	LimitAlarmType_EventId = 6116,
	LimitAlarmType_EventType = 6117,
	LimitAlarmType_SourceNode = 6118,
	LimitAlarmType_SourceName = 6119,
	LimitAlarmType_Time = 6120,
	LimitAlarmType_ReceiveTime = 6121,
	LimitAlarmType_LocalTime = 6122,
	LimitAlarmType_Message = 6123,
	LimitAlarmType_Severity = 6124,
	LimitAlarmType_Retain = 6125,
	LimitAlarmType_ConditionRefresh = 6126,
	LimitAlarmType_ConditionRefresh_InputArguments = 6127,
	IdType_EnumStrings = 7591,
	EnumValueType = 7594,
	MessageSecurityMode_EnumStrings = 7595,
	UserTokenType_EnumStrings = 7596,
	ApplicationType_EnumStrings = 7597,
	SecurityTokenRequestType_EnumStrings = 7598,
	ComplianceLevel_EnumStrings = 7599,
	BrowseDirection_EnumStrings = 7603,
	FilterOperator_EnumStrings = 7605,
	TimestampsToReturn_EnumStrings = 7606,
	MonitoringMode_EnumStrings = 7608,
	DataChangeTrigger_EnumStrings = 7609,
	DeadbandType_EnumStrings = 7610,
	RedundancySupport_EnumStrings = 7611,
	ServerState_EnumStrings = 7612,
	ExceptionDeviationFormat_EnumStrings = 7614,
	EnumValueType_Encoding_DefaultXml = 7616,
	OpcUa_BinarySchema = 7617,
	OpcUa_BinarySchema_DataTypeVersion = 7618,
	OpcUa_BinarySchema_NamespaceUri = 7619,
	OpcUa_BinarySchema_Argument = 7650,
	OpcUa_BinarySchema_Argument_DataTypeVersion = 7651,
	OpcUa_BinarySchema_Argument_DictionaryFragment = 7652,
	OpcUa_BinarySchema_EnumValueType = 7656,
	OpcUa_BinarySchema_EnumValueType_DataTypeVersion = 7657,
	OpcUa_BinarySchema_EnumValueType_DictionaryFragment = 7658,
	OpcUa_BinarySchema_StatusResult = 7659,
	OpcUa_BinarySchema_StatusResult_DataTypeVersion = 7660,
	OpcUa_BinarySchema_StatusResult_DictionaryFragment = 7661,
	OpcUa_BinarySchema_UserTokenPolicy = 7662,
	OpcUa_BinarySchema_UserTokenPolicy_DataTypeVersion = 7663,
	OpcUa_BinarySchema_UserTokenPolicy_DictionaryFragment = 7664,
	OpcUa_BinarySchema_ApplicationDescription = 7665,
	OpcUa_BinarySchema_ApplicationDescription_DataTypeVersion = 7666,
	OpcUa_BinarySchema_ApplicationDescription_DictionaryFragment = 7667,
	OpcUa_BinarySchema_EndpointDescription = 7668,
	OpcUa_BinarySchema_EndpointDescription_DataTypeVersion = 7669,
	OpcUa_BinarySchema_EndpointDescription_DictionaryFragment = 7670,
	OpcUa_BinarySchema_UserIdentityToken = 7671,
	OpcUa_BinarySchema_UserIdentityToken_DataTypeVersion = 7672,
	OpcUa_BinarySchema_UserIdentityToken_DictionaryFragment = 7673,
	OpcUa_BinarySchema_AnonymousIdentityToken = 7674,
	OpcUa_BinarySchema_AnonymousIdentityToken_DataTypeVersion = 7675,
	OpcUa_BinarySchema_AnonymousIdentityToken_DictionaryFragment = 7676,
	OpcUa_BinarySchema_UserNameIdentityToken = 7677,
	OpcUa_BinarySchema_UserNameIdentityToken_DataTypeVersion = 7678,
	OpcUa_BinarySchema_UserNameIdentityToken_DictionaryFragment = 7679,
	OpcUa_BinarySchema_X509IdentityToken = 7680,
	OpcUa_BinarySchema_X509IdentityToken_DataTypeVersion = 7681,
	OpcUa_BinarySchema_X509IdentityToken_DictionaryFragment = 7682,
	OpcUa_BinarySchema_IssuedIdentityToken = 7683,
	OpcUa_BinarySchema_IssuedIdentityToken_DataTypeVersion = 7684,
	OpcUa_BinarySchema_IssuedIdentityToken_DictionaryFragment = 7685,
	OpcUa_BinarySchema_EndpointConfiguration = 7686,
	OpcUa_BinarySchema_EndpointConfiguration_DataTypeVersion = 7687,
	OpcUa_BinarySchema_EndpointConfiguration_DictionaryFragment = 7688,
	OpcUa_BinarySchema_SupportedProfile = 7689,
	OpcUa_BinarySchema_SupportedProfile_DataTypeVersion = 7690,
	OpcUa_BinarySchema_SupportedProfile_DictionaryFragment = 7691,
	OpcUa_BinarySchema_BuildInfo = 7692,
	OpcUa_BinarySchema_BuildInfo_DataTypeVersion = 7693,
	OpcUa_BinarySchema_BuildInfo_DictionaryFragment = 7694,
	OpcUa_BinarySchema_SoftwareCertificate = 7695,
	OpcUa_BinarySchema_SoftwareCertificate_DataTypeVersion = 7696,
	OpcUa_BinarySchema_SoftwareCertificate_DictionaryFragment = 7697,
	OpcUa_BinarySchema_SignedSoftwareCertificate = 7698,
	OpcUa_BinarySchema_SignedSoftwareCertificate_DataTypeVersion = 7699,
	OpcUa_BinarySchema_SignedSoftwareCertificate_DictionaryFragment = 7700,
	OpcUa_BinarySchema_AddNodesItem = 7728,
	OpcUa_BinarySchema_AddNodesItem_DataTypeVersion = 7729,
	OpcUa_BinarySchema_AddNodesItem_DictionaryFragment = 7730,
	OpcUa_BinarySchema_AddReferencesItem = 7731,
	OpcUa_BinarySchema_AddReferencesItem_DataTypeVersion = 7732,
	OpcUa_BinarySchema_AddReferencesItem_DictionaryFragment = 7733,
	OpcUa_BinarySchema_DeleteNodesItem = 7734,
	OpcUa_BinarySchema_DeleteNodesItem_DataTypeVersion = 7735,
	OpcUa_BinarySchema_DeleteNodesItem_DictionaryFragment = 7736,
	OpcUa_BinarySchema_DeleteReferencesItem = 7737,
	OpcUa_BinarySchema_DeleteReferencesItem_DataTypeVersion = 7738,
	OpcUa_BinarySchema_DeleteReferencesItem_DictionaryFragment = 7739,
	OpcUa_BinarySchema_ScalarTestType = 7749,
	OpcUa_BinarySchema_ScalarTestType_DataTypeVersion = 7750,
	OpcUa_BinarySchema_ScalarTestType_DictionaryFragment = 7751,
	OpcUa_BinarySchema_ArrayTestType = 7752,
	OpcUa_BinarySchema_ArrayTestType_DataTypeVersion = 7753,
	OpcUa_BinarySchema_ArrayTestType_DictionaryFragment = 7754,
	OpcUa_BinarySchema_CompositeTestType = 7755,
	OpcUa_BinarySchema_CompositeTestType_DataTypeVersion = 7756,
	OpcUa_BinarySchema_CompositeTestType_DictionaryFragment = 7757,
	OpcUa_BinarySchema_RegisteredServer = 7782,
	OpcUa_BinarySchema_RegisteredServer_DataTypeVersion = 7783,
	OpcUa_BinarySchema_RegisteredServer_DictionaryFragment = 7784,
	OpcUa_BinarySchema_ContentFilterElement = 7929,
	OpcUa_BinarySchema_ContentFilterElement_DataTypeVersion = 7930,
	OpcUa_BinarySchema_ContentFilterElement_DictionaryFragment = 7931,
	OpcUa_BinarySchema_ContentFilter = 7932,
	OpcUa_BinarySchema_ContentFilter_DataTypeVersion = 7933,
	OpcUa_BinarySchema_ContentFilter_DictionaryFragment = 7934,
	OpcUa_BinarySchema_FilterOperand = 7935,
	OpcUa_BinarySchema_FilterOperand_DataTypeVersion = 7936,
	OpcUa_BinarySchema_FilterOperand_DictionaryFragment = 7937,
	OpcUa_BinarySchema_ElementOperand = 7938,
	OpcUa_BinarySchema_ElementOperand_DataTypeVersion = 7939,
	OpcUa_BinarySchema_ElementOperand_DictionaryFragment = 7940,
	OpcUa_BinarySchema_LiteralOperand = 7941,
	OpcUa_BinarySchema_LiteralOperand_DataTypeVersion = 7942,
	OpcUa_BinarySchema_LiteralOperand_DictionaryFragment = 7943,
	OpcUa_BinarySchema_AttributeOperand = 7944,
	OpcUa_BinarySchema_AttributeOperand_DataTypeVersion = 7945,
	OpcUa_BinarySchema_AttributeOperand_DictionaryFragment = 7946,
	OpcUa_BinarySchema_SimpleAttributeOperand = 7947,
	OpcUa_BinarySchema_SimpleAttributeOperand_DataTypeVersion = 7948,
	OpcUa_BinarySchema_SimpleAttributeOperand_DictionaryFragment = 7949,
	OpcUa_BinarySchema_HistoryEvent = 8004,
	OpcUa_BinarySchema_HistoryEvent_DataTypeVersion = 8005,
	OpcUa_BinarySchema_HistoryEvent_DictionaryFragment = 8006,
	OpcUa_BinarySchema_MonitoringFilter = 8067,
	OpcUa_BinarySchema_MonitoringFilter_DataTypeVersion = 8068,
	OpcUa_BinarySchema_MonitoringFilter_DictionaryFragment = 8069,
	OpcUa_BinarySchema_EventFilter = 8073,
	OpcUa_BinarySchema_EventFilter_DataTypeVersion = 8074,
	OpcUa_BinarySchema_EventFilter_DictionaryFragment = 8075,
	OpcUa_BinarySchema_AggregateConfiguration = 8076,
	OpcUa_BinarySchema_AggregateConfiguration_DataTypeVersion = 8077,
	OpcUa_BinarySchema_AggregateConfiguration_DictionaryFragment = 8078,
	OpcUa_BinarySchema_HistoryEventFieldList = 8172,
	OpcUa_BinarySchema_HistoryEventFieldList_DataTypeVersion = 8173,
	OpcUa_BinarySchema_HistoryEventFieldList_DictionaryFragment = 8174,
	OpcUa_BinarySchema_RedundantServerDataType = 8208,
	OpcUa_BinarySchema_RedundantServerDataType_DataTypeVersion = 8209,
	OpcUa_BinarySchema_RedundantServerDataType_DictionaryFragment = 8210,
	OpcUa_BinarySchema_SamplingIntervalDiagnosticsDataType = 8211,
	OpcUa_BinarySchema_SamplingIntervalDiagnosticsDataType_DataTypeVersion = 8212,
	OpcUa_BinarySchema_SamplingIntervalDiagnosticsDataType_DictionaryFragment = 8213,
	OpcUa_BinarySchema_ServerDiagnosticsSummaryDataType = 8214,
	OpcUa_BinarySchema_ServerDiagnosticsSummaryDataType_DataTypeVersion = 8215,
	OpcUa_BinarySchema_ServerDiagnosticsSummaryDataType_DictionaryFragment = 8216,
	OpcUa_BinarySchema_ServerStatusDataType = 8217,
	OpcUa_BinarySchema_ServerStatusDataType_DataTypeVersion = 8218,
	OpcUa_BinarySchema_ServerStatusDataType_DictionaryFragment = 8219,
	OpcUa_BinarySchema_SessionDiagnosticsDataType = 8220,
	OpcUa_BinarySchema_SessionDiagnosticsDataType_DataTypeVersion = 8221,
	OpcUa_BinarySchema_SessionDiagnosticsDataType_DictionaryFragment = 8222,
	OpcUa_BinarySchema_SessionSecurityDiagnosticsDataType = 8223,
	OpcUa_BinarySchema_SessionSecurityDiagnosticsDataType_DataTypeVersion = 8224,
	OpcUa_BinarySchema_SessionSecurityDiagnosticsDataType_DictionaryFragment = 8225,
	OpcUa_BinarySchema_ServiceCounterDataType = 8226,
	OpcUa_BinarySchema_ServiceCounterDataType_DataTypeVersion = 8227,
	OpcUa_BinarySchema_ServiceCounterDataType_DictionaryFragment = 8228,
	OpcUa_BinarySchema_SubscriptionDiagnosticsDataType = 8229,
	OpcUa_BinarySchema_SubscriptionDiagnosticsDataType_DataTypeVersion = 8230,
	OpcUa_BinarySchema_SubscriptionDiagnosticsDataType_DictionaryFragment = 8231,
	OpcUa_BinarySchema_ModelChangeStructureDataType = 8232,
	OpcUa_BinarySchema_ModelChangeStructureDataType_DataTypeVersion = 8233,
	OpcUa_BinarySchema_ModelChangeStructureDataType_DictionaryFragment = 8234,
	OpcUa_BinarySchema_SemanticChangeStructureDataType = 8235,
	OpcUa_BinarySchema_SemanticChangeStructureDataType_DataTypeVersion = 8236,
	OpcUa_BinarySchema_SemanticChangeStructureDataType_DictionaryFragment = 8237,
	OpcUa_BinarySchema_Range = 8238,
	OpcUa_BinarySchema_Range_DataTypeVersion = 8239,
	OpcUa_BinarySchema_Range_DictionaryFragment = 8240,
	OpcUa_BinarySchema_EUInformation = 8241,
	OpcUa_BinarySchema_EUInformation_DataTypeVersion = 8242,
	OpcUa_BinarySchema_EUInformation_DictionaryFragment = 8243,
	OpcUa_BinarySchema_Annotation = 8244,
	OpcUa_BinarySchema_Annotation_DataTypeVersion = 8245,
	OpcUa_BinarySchema_Annotation_DictionaryFragment = 8246,
	OpcUa_BinarySchema_ProgramDiagnosticDataType = 8247,
	OpcUa_BinarySchema_ProgramDiagnosticDataType_DataTypeVersion = 8248,
	OpcUa_BinarySchema_ProgramDiagnosticDataType_DictionaryFragment = 8249,
	EnumValueType_Encoding_DefaultBinary = 8251,
	OpcUa_XmlSchema = 8252,
	OpcUa_XmlSchema_DataTypeVersion = 8253,
	OpcUa_XmlSchema_NamespaceUri = 8254,
	OpcUa_XmlSchema_Argument = 8285,
	OpcUa_XmlSchema_Argument_DataTypeVersion = 8286,
	OpcUa_XmlSchema_Argument_DictionaryFragment = 8287,
	OpcUa_XmlSchema_EnumValueType = 8291,
	OpcUa_XmlSchema_EnumValueType_DataTypeVersion = 8292,
	OpcUa_XmlSchema_EnumValueType_DictionaryFragment = 8293,
	OpcUa_XmlSchema_StatusResult = 8294,
	OpcUa_XmlSchema_StatusResult_DataTypeVersion = 8295,
	OpcUa_XmlSchema_StatusResult_DictionaryFragment = 8296,
	OpcUa_XmlSchema_UserTokenPolicy = 8297,
	OpcUa_XmlSchema_UserTokenPolicy_DataTypeVersion = 8298,
	OpcUa_XmlSchema_UserTokenPolicy_DictionaryFragment = 8299,
	OpcUa_XmlSchema_ApplicationDescription = 8300,
	OpcUa_XmlSchema_ApplicationDescription_DataTypeVersion = 8301,
	OpcUa_XmlSchema_ApplicationDescription_DictionaryFragment = 8302,
	OpcUa_XmlSchema_EndpointDescription = 8303,
	OpcUa_XmlSchema_EndpointDescription_DataTypeVersion = 8304,
	OpcUa_XmlSchema_EndpointDescription_DictionaryFragment = 8305,
	OpcUa_XmlSchema_UserIdentityToken = 8306,
	OpcUa_XmlSchema_UserIdentityToken_DataTypeVersion = 8307,
	OpcUa_XmlSchema_UserIdentityToken_DictionaryFragment = 8308,
	OpcUa_XmlSchema_AnonymousIdentityToken = 8309,
	OpcUa_XmlSchema_AnonymousIdentityToken_DataTypeVersion = 8310,
	OpcUa_XmlSchema_AnonymousIdentityToken_DictionaryFragment = 8311,
	OpcUa_XmlSchema_UserNameIdentityToken = 8312,
	OpcUa_XmlSchema_UserNameIdentityToken_DataTypeVersion = 8313,
	OpcUa_XmlSchema_UserNameIdentityToken_DictionaryFragment = 8314,
	OpcUa_XmlSchema_X509IdentityToken = 8315,
	OpcUa_XmlSchema_X509IdentityToken_DataTypeVersion = 8316,
	OpcUa_XmlSchema_X509IdentityToken_DictionaryFragment = 8317,
	OpcUa_XmlSchema_IssuedIdentityToken = 8318,
	OpcUa_XmlSchema_IssuedIdentityToken_DataTypeVersion = 8319,
	OpcUa_XmlSchema_IssuedIdentityToken_DictionaryFragment = 8320,
	OpcUa_XmlSchema_EndpointConfiguration = 8321,
	OpcUa_XmlSchema_EndpointConfiguration_DataTypeVersion = 8322,
	OpcUa_XmlSchema_EndpointConfiguration_DictionaryFragment = 8323,
	OpcUa_XmlSchema_SupportedProfile = 8324,
	OpcUa_XmlSchema_SupportedProfile_DataTypeVersion = 8325,
	OpcUa_XmlSchema_SupportedProfile_DictionaryFragment = 8326,
	OpcUa_XmlSchema_BuildInfo = 8327,
	OpcUa_XmlSchema_BuildInfo_DataTypeVersion = 8328,
	OpcUa_XmlSchema_BuildInfo_DictionaryFragment = 8329,
	OpcUa_XmlSchema_SoftwareCertificate = 8330,
	OpcUa_XmlSchema_SoftwareCertificate_DataTypeVersion = 8331,
	OpcUa_XmlSchema_SoftwareCertificate_DictionaryFragment = 8332,
	OpcUa_XmlSchema_SignedSoftwareCertificate = 8333,
	OpcUa_XmlSchema_SignedSoftwareCertificate_DataTypeVersion = 8334,
	OpcUa_XmlSchema_SignedSoftwareCertificate_DictionaryFragment = 8335,
	OpcUa_XmlSchema_AddNodesItem = 8363,
	OpcUa_XmlSchema_AddNodesItem_DataTypeVersion = 8364,
	OpcUa_XmlSchema_AddNodesItem_DictionaryFragment = 8365,
	OpcUa_XmlSchema_AddReferencesItem = 8366,
	OpcUa_XmlSchema_AddReferencesItem_DataTypeVersion = 8367,
	OpcUa_XmlSchema_AddReferencesItem_DictionaryFragment = 8368,
	OpcUa_XmlSchema_DeleteNodesItem = 8369,
	OpcUa_XmlSchema_DeleteNodesItem_DataTypeVersion = 8370,
	OpcUa_XmlSchema_DeleteNodesItem_DictionaryFragment = 8371,
	OpcUa_XmlSchema_DeleteReferencesItem = 8372,
	OpcUa_XmlSchema_DeleteReferencesItem_DataTypeVersion = 8373,
	OpcUa_XmlSchema_DeleteReferencesItem_DictionaryFragment = 8374,
	OpcUa_XmlSchema_ScalarTestType = 8384,
	OpcUa_XmlSchema_ScalarTestType_DataTypeVersion = 8385,
	OpcUa_XmlSchema_ScalarTestType_DictionaryFragment = 8386,
	OpcUa_XmlSchema_ArrayTestType = 8387,
	OpcUa_XmlSchema_ArrayTestType_DataTypeVersion = 8388,
	OpcUa_XmlSchema_ArrayTestType_DictionaryFragment = 8389,
	OpcUa_XmlSchema_CompositeTestType = 8390,
	OpcUa_XmlSchema_CompositeTestType_DataTypeVersion = 8391,
	OpcUa_XmlSchema_CompositeTestType_DictionaryFragment = 8392,
	OpcUa_XmlSchema_RegisteredServer = 8417,
	OpcUa_XmlSchema_RegisteredServer_DataTypeVersion = 8418,
	OpcUa_XmlSchema_RegisteredServer_DictionaryFragment = 8419,
	OpcUa_XmlSchema_ContentFilterElement = 8564,
	OpcUa_XmlSchema_ContentFilterElement_DataTypeVersion = 8565,
	OpcUa_XmlSchema_ContentFilterElement_DictionaryFragment = 8566,
	OpcUa_XmlSchema_ContentFilter = 8567,
	OpcUa_XmlSchema_ContentFilter_DataTypeVersion = 8568,
	OpcUa_XmlSchema_ContentFilter_DictionaryFragment = 8569,
	OpcUa_XmlSchema_FilterOperand = 8570,
	OpcUa_XmlSchema_FilterOperand_DataTypeVersion = 8571,
	OpcUa_XmlSchema_FilterOperand_DictionaryFragment = 8572,
	OpcUa_XmlSchema_ElementOperand = 8573,
	OpcUa_XmlSchema_ElementOperand_DataTypeVersion = 8574,
	OpcUa_XmlSchema_ElementOperand_DictionaryFragment = 8575,
	OpcUa_XmlSchema_LiteralOperand = 8576,
	OpcUa_XmlSchema_LiteralOperand_DataTypeVersion = 8577,
	OpcUa_XmlSchema_LiteralOperand_DictionaryFragment = 8578,
	OpcUa_XmlSchema_AttributeOperand = 8579,
	OpcUa_XmlSchema_AttributeOperand_DataTypeVersion = 8580,
	OpcUa_XmlSchema_AttributeOperand_DictionaryFragment = 8581,
	OpcUa_XmlSchema_SimpleAttributeOperand = 8582,
	OpcUa_XmlSchema_SimpleAttributeOperand_DataTypeVersion = 8583,
	OpcUa_XmlSchema_SimpleAttributeOperand_DictionaryFragment = 8584,
	OpcUa_XmlSchema_HistoryEvent = 8639,
	OpcUa_XmlSchema_HistoryEvent_DataTypeVersion = 8640,
	OpcUa_XmlSchema_HistoryEvent_DictionaryFragment = 8641,
	OpcUa_XmlSchema_MonitoringFilter = 8702,
	OpcUa_XmlSchema_MonitoringFilter_DataTypeVersion = 8703,
	OpcUa_XmlSchema_MonitoringFilter_DictionaryFragment = 8704,
	OpcUa_XmlSchema_EventFilter = 8708,
	OpcUa_XmlSchema_EventFilter_DataTypeVersion = 8709,
	OpcUa_XmlSchema_EventFilter_DictionaryFragment = 8710,
	OpcUa_XmlSchema_AggregateConfiguration = 8711,
	OpcUa_XmlSchema_AggregateConfiguration_DataTypeVersion = 8712,
	OpcUa_XmlSchema_AggregateConfiguration_DictionaryFragment = 8713,
	OpcUa_XmlSchema_HistoryEventFieldList = 8807,
	OpcUa_XmlSchema_HistoryEventFieldList_DataTypeVersion = 8808,
	OpcUa_XmlSchema_HistoryEventFieldList_DictionaryFragment = 8809,
	OpcUa_XmlSchema_RedundantServerDataType = 8843,
	OpcUa_XmlSchema_RedundantServerDataType_DataTypeVersion = 8844,
	OpcUa_XmlSchema_RedundantServerDataType_DictionaryFragment = 8845,
	OpcUa_XmlSchema_SamplingIntervalDiagnosticsDataType = 8846,
	OpcUa_XmlSchema_SamplingIntervalDiagnosticsDataType_DataTypeVersion = 8847,
	OpcUa_XmlSchema_SamplingIntervalDiagnosticsDataType_DictionaryFragment = 8848,
	OpcUa_XmlSchema_ServerDiagnosticsSummaryDataType = 8849,
	OpcUa_XmlSchema_ServerDiagnosticsSummaryDataType_DataTypeVersion = 8850,
	OpcUa_XmlSchema_ServerDiagnosticsSummaryDataType_DictionaryFragment = 8851,
	OpcUa_XmlSchema_ServerStatusDataType = 8852,
	OpcUa_XmlSchema_ServerStatusDataType_DataTypeVersion = 8853,
	OpcUa_XmlSchema_ServerStatusDataType_DictionaryFragment = 8854,
	OpcUa_XmlSchema_SessionDiagnosticsDataType = 8855,
	OpcUa_XmlSchema_SessionDiagnosticsDataType_DataTypeVersion = 8856,
	OpcUa_XmlSchema_SessionDiagnosticsDataType_DictionaryFragment = 8857,
	OpcUa_XmlSchema_SessionSecurityDiagnosticsDataType = 8858,
	OpcUa_XmlSchema_SessionSecurityDiagnosticsDataType_DataTypeVersion = 8859,
	OpcUa_XmlSchema_SessionSecurityDiagnosticsDataType_DictionaryFragment = 8860,
	OpcUa_XmlSchema_ServiceCounterDataType = 8861,
	OpcUa_XmlSchema_ServiceCounterDataType_DataTypeVersion = 8862,
	OpcUa_XmlSchema_ServiceCounterDataType_DictionaryFragment = 8863,
	OpcUa_XmlSchema_SubscriptionDiagnosticsDataType = 8864,
	OpcUa_XmlSchema_SubscriptionDiagnosticsDataType_DataTypeVersion = 8865,
	OpcUa_XmlSchema_SubscriptionDiagnosticsDataType_DictionaryFragment = 8866,
	OpcUa_XmlSchema_ModelChangeStructureDataType = 8867,
	OpcUa_XmlSchema_ModelChangeStructureDataType_DataTypeVersion = 8868,
	OpcUa_XmlSchema_ModelChangeStructureDataType_DictionaryFragment = 8869,
	OpcUa_XmlSchema_SemanticChangeStructureDataType = 8870,
	OpcUa_XmlSchema_SemanticChangeStructureDataType_DataTypeVersion = 8871,
	OpcUa_XmlSchema_SemanticChangeStructureDataType_DictionaryFragment = 8872,
	OpcUa_XmlSchema_Range = 8873,
	OpcUa_XmlSchema_Range_DataTypeVersion = 8874,
	OpcUa_XmlSchema_Range_DictionaryFragment = 8875,
	OpcUa_XmlSchema_EUInformation = 8876,
	OpcUa_XmlSchema_EUInformation_DataTypeVersion = 8877,
	OpcUa_XmlSchema_EUInformation_DictionaryFragment = 8878,
	OpcUa_XmlSchema_Annotation = 8879,
	OpcUa_XmlSchema_Annotation_DataTypeVersion = 8880,
	OpcUa_XmlSchema_Annotation_DictionaryFragment = 8881,
	OpcUa_XmlSchema_ProgramDiagnosticDataType = 8882,
	OpcUa_XmlSchema_ProgramDiagnosticDataType_DataTypeVersion = 8883,
	OpcUa_XmlSchema_ProgramDiagnosticDataType_DictionaryFragment = 8884,
	SubscriptionDiagnosticsType_MaxLifetimeCount = 8888,
	SubscriptionDiagnosticsType_LatePublishRequestCount = 8889,
	SubscriptionDiagnosticsType_CurrentKeepAliveCount = 8890,
	SubscriptionDiagnosticsType_CurrentLifetimeCount = 8891,
	SubscriptionDiagnosticsType_UnacknowledgedMessageCount = 8892,
	SubscriptionDiagnosticsType_DiscardedMessageCount = 8893,
	SubscriptionDiagnosticsType_MonitoredItemCount = 8894,
	SubscriptionDiagnosticsType_DisabledMonitoredItemCount = 8895,
	SubscriptionDiagnosticsType_MonitoringQueueOverflowCount = 8896,
	SubscriptionDiagnosticsType_NextSequenceNumber = 8897,
	SessionDiagnosticsObjectType_SessionDiagnostics_TotalRequestCount = 8898,
	SessionDiagnosticsVariableType_TotalRequestCount = 8900,
	SubscriptionDiagnosticsType_EventQueueOverFlowCount = 8902,
	TimeZoneDataType = 8912,
	TimeZoneDataType_Encoding_DefaultXml = 8913,
	OpcUa_BinarySchema_TimeZoneDataType = 8914,
	OpcUa_BinarySchema_TimeZoneDataType_DataTypeVersion = 8915,
	OpcUa_BinarySchema_TimeZoneDataType_DictionaryFragment = 8916,
	TimeZoneDataType_Encoding_DefaultBinary = 8917,
	OpcUa_XmlSchema_TimeZoneDataType = 8918,
	OpcUa_XmlSchema_TimeZoneDataType_DataTypeVersion = 8919,
	OpcUa_XmlSchema_TimeZoneDataType_DictionaryFragment = 8920,
	LockType = 8921,
	LockType_Lock = 8922,
	LockType_Unlock = 8923,
	ServerLock = 8924,
	ServerLock_Lock = 8925,
	ServerLock_Unlock = 8926,
	AuditConditionRespondEventType = 8927,
	AuditConditionRespondEventType_EventId = 8928,
	AuditConditionRespondEventType_EventType = 8929,
	AuditConditionRespondEventType_SourceNode = 8930,
	AuditConditionRespondEventType_SourceName = 8931,
	AuditConditionRespondEventType_Time = 8932,
	AuditConditionRespondEventType_ReceiveTime = 8933,
	AuditConditionRespondEventType_LocalTime = 8934,
	AuditConditionRespondEventType_Message = 8935,
	AuditConditionRespondEventType_Severity = 8936,
	AuditConditionRespondEventType_ActionTimeStamp = 8937,
	AuditConditionRespondEventType_Status = 8938,
	AuditConditionRespondEventType_ServerId = 8939,
	AuditConditionRespondEventType_ClientAuditEntryId = 8940,
	AuditConditionRespondEventType_ClientUserId = 8941,
	AuditConditionRespondEventType_MethodId = 8942,
	AuditConditionRespondEventType_InputArguments = 8943,
	AuditConditionAcknowledgeEventType = 8944,
	AuditConditionAcknowledgeEventType_EventId = 8945,
	AuditConditionAcknowledgeEventType_EventType = 8946,
	AuditConditionAcknowledgeEventType_SourceNode = 8947,
	AuditConditionAcknowledgeEventType_SourceName = 8948,
	AuditConditionAcknowledgeEventType_Time = 8949,
	AuditConditionAcknowledgeEventType_ReceiveTime = 8950,
	AuditConditionAcknowledgeEventType_LocalTime = 8951,
	AuditConditionAcknowledgeEventType_Message = 8952,
	AuditConditionAcknowledgeEventType_Severity = 8953,
	AuditConditionAcknowledgeEventType_ActionTimeStamp = 8954,
	AuditConditionAcknowledgeEventType_Status = 8955,
	AuditConditionAcknowledgeEventType_ServerId = 8956,
	AuditConditionAcknowledgeEventType_ClientAuditEntryId = 8957,
	AuditConditionAcknowledgeEventType_ClientUserId = 8958,
	AuditConditionAcknowledgeEventType_MethodId = 8959,
	AuditConditionAcknowledgeEventType_InputArguments = 8960,
	AuditConditionConfirmEventType = 8961,
	AuditConditionConfirmEventType_EventId = 8962,
	AuditConditionConfirmEventType_EventType = 8963,
	AuditConditionConfirmEventType_SourceNode = 8964,
	AuditConditionConfirmEventType_SourceName = 8965,
	AuditConditionConfirmEventType_Time = 8966,
	AuditConditionConfirmEventType_ReceiveTime = 8967,
	AuditConditionConfirmEventType_LocalTime = 8968,
	AuditConditionConfirmEventType_Message = 8969,
	AuditConditionConfirmEventType_Severity = 8970,
	AuditConditionConfirmEventType_ActionTimeStamp = 8971,
	AuditConditionConfirmEventType_Status = 8972,
	AuditConditionConfirmEventType_ServerId = 8973,
	AuditConditionConfirmEventType_ClientAuditEntryId = 8974,
	AuditConditionConfirmEventType_ClientUserId = 8975,
	AuditConditionConfirmEventType_MethodId = 8976,
	AuditConditionConfirmEventType_InputArguments = 8977,
	TwoStateVariableType = 8995,
	TwoStateVariableType_Id = 8996,
	TwoStateVariableType_Name = 8997,
	TwoStateVariableType_Number = 8998,
	TwoStateVariableType_EffectiveDisplayName = 8999,
	TwoStateVariableType_TransitionTime = 9000,
	TwoStateVariableType_EffectiveTransitionTime = 9001,
	ConditionVariableType = 9002,
	ConditionVariableType_SourceTimestamp = 9003,
	HasTrueSubState = 9004,
	HasFalseSubState = 9005,
	HasCondition = 9006,
	ConditionRefreshMethodType = 9007,
	ConditionRefreshMethodType_InputArguments = 9008,
	ConditionType_ConditionName = 9009,
	ConditionType_BranchId = 9010,
	ConditionType_EnabledState = 9011,
	ConditionType_EnabledState_Id = 9012,
	ConditionType_EnabledState_Name = 9013,
	ConditionType_EnabledState_Number = 9014,
	ConditionType_EnabledState_EffectiveDisplayName = 9015,
	ConditionType_EnabledState_TransitionTime = 9016,
	ConditionType_EnabledState_EffectiveTransitionTime = 9017,
	ConditionType_EnabledState_TrueState = 9018,
	ConditionType_EnabledState_FalseState = 9019,
	ConditionType_Quality = 9020,
	ConditionType_Quality_SourceTimestamp = 9021,
	ConditionType_LastSeverity = 9022,
	ConditionType_LastSeverity_SourceTimestamp = 9023,
	ConditionType_Comment = 9024,
	ConditionType_Comment_SourceTimestamp = 9025,
	ConditionType_ClientUserId = 9026,
	ConditionType_Enable = 9027,
	ConditionType_Disable = 9028,
	ConditionType_AddComment = 9029,
	ConditionType_AddComment_InputArguments = 9030,
	DialogResponseMethodType = 9031,
	DialogResponseMethodType_InputArguments = 9032,
	DialogConditionType_ConditionName = 9033,
	DialogConditionType_BranchId = 9034,
	DialogConditionType_EnabledState = 9035,
	DialogConditionType_EnabledState_Id = 9036,
	DialogConditionType_EnabledState_Name = 9037,
	DialogConditionType_EnabledState_Number = 9038,
	DialogConditionType_EnabledState_EffectiveDisplayName = 9039,
	DialogConditionType_EnabledState_TransitionTime = 9040,
	DialogConditionType_EnabledState_EffectiveTransitionTime = 9041,
	DialogConditionType_EnabledState_TrueState = 9042,
	DialogConditionType_EnabledState_FalseState = 9043,
	DialogConditionType_Quality = 9044,
	DialogConditionType_Quality_SourceTimestamp = 9045,
	DialogConditionType_LastSeverity = 9046,
	DialogConditionType_LastSeverity_SourceTimestamp = 9047,
	DialogConditionType_Comment = 9048,
	DialogConditionType_Comment_SourceTimestamp = 9049,
	DialogConditionType_ClientUserId = 9050,
	DialogConditionType_Enable = 9051,
	DialogConditionType_Disable = 9052,
	DialogConditionType_AddComment = 9053,
	DialogConditionType_AddComment_InputArguments = 9054,
	DialogConditionType_DialogState = 9055,
	DialogConditionType_DialogState_Id = 9056,
	DialogConditionType_DialogState_Name = 9057,
	DialogConditionType_DialogState_Number = 9058,
	DialogConditionType_DialogState_EffectiveDisplayName = 9059,
	DialogConditionType_DialogState_TransitionTime = 9060,
	DialogConditionType_DialogState_EffectiveTransitionTime = 9061,
	DialogConditionType_DialogState_TrueState = 9062,
	DialogConditionType_DialogState_FalseState = 9063,
	DialogConditionType_ResponseOptionSet = 9064,
	DialogConditionType_DefaultResponse = 9065,
	DialogConditionType_OkResponse = 9066,
	DialogConditionType_CancelResponse = 9067,
	DialogConditionType_LastResponse = 9068,
	DialogConditionType_Respond = 9069,
	DialogConditionType_Respond_InputArguments = 9070,
	AcknowledgeableConditionType_ConditionName = 9071,
	AcknowledgeableConditionType_BranchId = 9072,
	AcknowledgeableConditionType_EnabledState = 9073,
	AcknowledgeableConditionType_EnabledState_Id = 9074,
	AcknowledgeableConditionType_EnabledState_Name = 9075,
	AcknowledgeableConditionType_EnabledState_Number = 9076,
	AcknowledgeableConditionType_EnabledState_EffectiveDisplayName = 9077,
	AcknowledgeableConditionType_EnabledState_TransitionTime = 9078,
	AcknowledgeableConditionType_EnabledState_EffectiveTransitionTime = 9079,
	AcknowledgeableConditionType_EnabledState_TrueState = 9080,
	AcknowledgeableConditionType_EnabledState_FalseState = 9081,
	AcknowledgeableConditionType_Quality = 9082,
	AcknowledgeableConditionType_Quality_SourceTimestamp = 9083,
	AcknowledgeableConditionType_LastSeverity = 9084,
	AcknowledgeableConditionType_LastSeverity_SourceTimestamp = 9085,
	AcknowledgeableConditionType_Comment = 9086,
	AcknowledgeableConditionType_Comment_SourceTimestamp = 9087,
	AcknowledgeableConditionType_ClientUserId = 9088,
	AcknowledgeableConditionType_Enable = 9089,
	AcknowledgeableConditionType_Disable = 9090,
	AcknowledgeableConditionType_AddComment = 9091,
	AcknowledgeableConditionType_AddComment_InputArguments = 9092,
	AcknowledgeableConditionType_AckedState = 9093,
	AcknowledgeableConditionType_AckedState_Id = 9094,
	AcknowledgeableConditionType_AckedState_Name = 9095,
	AcknowledgeableConditionType_AckedState_Number = 9096,
	AcknowledgeableConditionType_AckedState_EffectiveDisplayName = 9097,
	AcknowledgeableConditionType_AckedState_TransitionTime = 9098,
	AcknowledgeableConditionType_AckedState_EffectiveTransitionTime = 9099,
	AcknowledgeableConditionType_AckedState_TrueState = 9100,
	AcknowledgeableConditionType_AckedState_FalseState = 9101,
	AcknowledgeableConditionType_ConfirmedState = 9102,
	AcknowledgeableConditionType_ConfirmedState_Id = 9103,
	AcknowledgeableConditionType_ConfirmedState_Name = 9104,
	AcknowledgeableConditionType_ConfirmedState_Number = 9105,
	AcknowledgeableConditionType_ConfirmedState_EffectiveDisplayName = 9106,
	AcknowledgeableConditionType_ConfirmedState_TransitionTime = 9107,
	AcknowledgeableConditionType_ConfirmedState_EffectiveTransitionTime = 9108,
	AcknowledgeableConditionType_ConfirmedState_TrueState = 9109,
	AcknowledgeableConditionType_ConfirmedState_FalseState = 9110,
	AcknowledgeableConditionType_Acknowledge = 9111,
	AcknowledgeableConditionType_Acknowledge_InputArguments = 9112,
	AcknowledgeableConditionType_Confirm = 9113,
	AcknowledgeableConditionType_Confirm_InputArguments = 9114,
	ShelvedStateMachineType_UnshelveTime = 9115,
	AlarmConditionType_ConditionName = 9116,
	AlarmConditionType_BranchId = 9117,
	AlarmConditionType_EnabledState = 9118,
	AlarmConditionType_EnabledState_Id = 9119,
	AlarmConditionType_EnabledState_Name = 9120,
	AlarmConditionType_EnabledState_Number = 9121,
	AlarmConditionType_EnabledState_EffectiveDisplayName = 9122,
	AlarmConditionType_EnabledState_TransitionTime = 9123,
	AlarmConditionType_EnabledState_EffectiveTransitionTime = 9124,
	AlarmConditionType_EnabledState_TrueState = 9125,
	AlarmConditionType_EnabledState_FalseState = 9126,
	AlarmConditionType_Quality = 9127,
	AlarmConditionType_Quality_SourceTimestamp = 9128,
	AlarmConditionType_LastSeverity = 9129,
	AlarmConditionType_LastSeverity_SourceTimestamp = 9130,
	AlarmConditionType_Comment = 9131,
	AlarmConditionType_Comment_SourceTimestamp = 9132,
	AlarmConditionType_ClientUserId = 9133,
	AlarmConditionType_Enable = 9134,
	AlarmConditionType_Disable = 9135,
	AlarmConditionType_AddComment = 9136,
	AlarmConditionType_AddComment_InputArguments = 9137,
	AlarmConditionType_AckedState = 9138,
	AlarmConditionType_AckedState_Id = 9139,
	AlarmConditionType_AckedState_Name = 9140,
	AlarmConditionType_AckedState_Number = 9141,
	AlarmConditionType_AckedState_EffectiveDisplayName = 9142,
	AlarmConditionType_AckedState_TransitionTime = 9143,
	AlarmConditionType_AckedState_EffectiveTransitionTime = 9144,
	AlarmConditionType_AckedState_TrueState = 9145,
	AlarmConditionType_AckedState_FalseState = 9146,
	AlarmConditionType_ConfirmedState = 9147,
	AlarmConditionType_ConfirmedState_Id = 9148,
	AlarmConditionType_ConfirmedState_Name = 9149,
	AlarmConditionType_ConfirmedState_Number = 9150,
	AlarmConditionType_ConfirmedState_EffectiveDisplayName = 9151,
	AlarmConditionType_ConfirmedState_TransitionTime = 9152,
	AlarmConditionType_ConfirmedState_EffectiveTransitionTime = 9153,
	AlarmConditionType_ConfirmedState_TrueState = 9154,
	AlarmConditionType_ConfirmedState_FalseState = 9155,
	AlarmConditionType_Acknowledge = 9156,
	AlarmConditionType_Acknowledge_InputArguments = 9157,
	AlarmConditionType_Confirm = 9158,
	AlarmConditionType_Confirm_InputArguments = 9159,
	AlarmConditionType_ActiveState = 9160,
	AlarmConditionType_ActiveState_Id = 9161,
	AlarmConditionType_ActiveState_Name = 9162,
	AlarmConditionType_ActiveState_Number = 9163,
	AlarmConditionType_ActiveState_EffectiveDisplayName = 9164,
	AlarmConditionType_ActiveState_TransitionTime = 9165,
	AlarmConditionType_ActiveState_EffectiveTransitionTime = 9166,
	AlarmConditionType_ActiveState_TrueState = 9167,
	AlarmConditionType_ActiveState_FalseState = 9168,
	AlarmConditionType_SuppressedState = 9169,
	AlarmConditionType_SuppressedState_Id = 9170,
	AlarmConditionType_SuppressedState_Name = 9171,
	AlarmConditionType_SuppressedState_Number = 9172,
	AlarmConditionType_SuppressedState_EffectiveDisplayName = 9173,
	AlarmConditionType_SuppressedState_TransitionTime = 9174,
	AlarmConditionType_SuppressedState_EffectiveTransitionTime = 9175,
	AlarmConditionType_SuppressedState_TrueState = 9176,
	AlarmConditionType_SuppressedState_FalseState = 9177,
	AlarmConditionType_ShelvingState = 9178,
	AlarmConditionType_ShelvingState_CurrentState = 9179,
	AlarmConditionType_ShelvingState_CurrentState_Id = 9180,
	AlarmConditionType_ShelvingState_CurrentState_Name = 9181,
	AlarmConditionType_ShelvingState_CurrentState_Number = 9182,
	AlarmConditionType_ShelvingState_CurrentState_EffectiveDisplayName = 9183,
	AlarmConditionType_ShelvingState_LastTransition = 9184,
	AlarmConditionType_ShelvingState_LastTransition_Id = 9185,
	AlarmConditionType_ShelvingState_LastTransition_Name = 9186,
	AlarmConditionType_ShelvingState_LastTransition_Number = 9187,
	AlarmConditionType_ShelvingState_LastTransition_TransitionTime = 9188,
	AlarmConditionType_ShelvingState_UnshelveTime = 9189,
	AlarmConditionType_ShelvingState_Unshelve = 9211,
	AlarmConditionType_ShelvingState_OneShotShelve = 9212,
	AlarmConditionType_ShelvingState_TimedShelve = 9213,
	AlarmConditionType_ShelvingState_TimedShelve_InputArguments = 9214,
	AlarmConditionType_SuppressedOrShelved = 9215,
	AlarmConditionType_MaxTimeShelved = 9216,
	LimitAlarmType_ConditionName = 9217,
	LimitAlarmType_BranchId = 9218,
	LimitAlarmType_EnabledState = 9219,
	LimitAlarmType_EnabledState_Id = 9220,
	LimitAlarmType_EnabledState_Name = 9221,
	LimitAlarmType_EnabledState_Number = 9222,
	LimitAlarmType_EnabledState_EffectiveDisplayName = 9223,
	LimitAlarmType_EnabledState_TransitionTime = 9224,
	LimitAlarmType_EnabledState_EffectiveTransitionTime = 9225,
	LimitAlarmType_EnabledState_TrueState = 9226,
	LimitAlarmType_EnabledState_FalseState = 9227,
	LimitAlarmType_Quality = 9228,
	LimitAlarmType_Quality_SourceTimestamp = 9229,
	LimitAlarmType_LastSeverity = 9230,
	LimitAlarmType_LastSeverity_SourceTimestamp = 9231,
	LimitAlarmType_Comment = 9232,
	LimitAlarmType_Comment_SourceTimestamp = 9233,
	LimitAlarmType_ClientUserId = 9234,
	LimitAlarmType_Enable = 9235,
	LimitAlarmType_Disable = 9236,
	LimitAlarmType_AddComment = 9237,
	LimitAlarmType_AddComment_InputArguments = 9238,
	LimitAlarmType_AckedState = 9239,
	LimitAlarmType_AckedState_Id = 9240,
	LimitAlarmType_AckedState_Name = 9241,
	LimitAlarmType_AckedState_Number = 9242,
	LimitAlarmType_AckedState_EffectiveDisplayName = 9243,
	LimitAlarmType_AckedState_TransitionTime = 9244,
	LimitAlarmType_AckedState_EffectiveTransitionTime = 9245,
	LimitAlarmType_AckedState_TrueState = 9246,
	LimitAlarmType_AckedState_FalseState = 9247,
	LimitAlarmType_ConfirmedState = 9248,
	LimitAlarmType_ConfirmedState_Id = 9249,
	LimitAlarmType_ConfirmedState_Name = 9250,
	LimitAlarmType_ConfirmedState_Number = 9251,
	LimitAlarmType_ConfirmedState_EffectiveDisplayName = 9252,
	LimitAlarmType_ConfirmedState_TransitionTime = 9253,
	LimitAlarmType_ConfirmedState_EffectiveTransitionTime = 9254,
	LimitAlarmType_ConfirmedState_TrueState = 9255,
	LimitAlarmType_ConfirmedState_FalseState = 9256,
	LimitAlarmType_Acknowledge = 9257,
	LimitAlarmType_Acknowledge_InputArguments = 9258,
	LimitAlarmType_Confirm = 9259,
	LimitAlarmType_Confirm_InputArguments = 9260,
	LimitAlarmType_ActiveState = 9261,
	LimitAlarmType_ActiveState_Id = 9262,
	LimitAlarmType_ActiveState_Name = 9263,
	LimitAlarmType_ActiveState_Number = 9264,
	LimitAlarmType_ActiveState_EffectiveDisplayName = 9265,
	LimitAlarmType_ActiveState_TransitionTime = 9266,
	LimitAlarmType_ActiveState_EffectiveTransitionTime = 9267,
	LimitAlarmType_ActiveState_TrueState = 9268,
	LimitAlarmType_ActiveState_FalseState = 9269,
	LimitAlarmType_SuppressedState = 9270,
	LimitAlarmType_SuppressedState_Id = 9271,
	LimitAlarmType_SuppressedState_Name = 9272,
	LimitAlarmType_SuppressedState_Number = 9273,
	LimitAlarmType_SuppressedState_EffectiveDisplayName = 9274,
	LimitAlarmType_SuppressedState_TransitionTime = 9275,
	LimitAlarmType_SuppressedState_EffectiveTransitionTime = 9276,
	LimitAlarmType_SuppressedState_TrueState = 9277,
	LimitAlarmType_SuppressedState_FalseState = 9278,
	LimitAlarmType_ShelvingState = 9279,
	LimitAlarmType_ShelvingState_CurrentState = 9280,
	LimitAlarmType_ShelvingState_CurrentState_Id = 9281,
	LimitAlarmType_ShelvingState_CurrentState_Name = 9282,
	LimitAlarmType_ShelvingState_CurrentState_Number = 9283,
	LimitAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 9284,
	LimitAlarmType_ShelvingState_LastTransition = 9285,
	LimitAlarmType_ShelvingState_LastTransition_Id = 9286,
	LimitAlarmType_ShelvingState_LastTransition_Name = 9287,
	LimitAlarmType_ShelvingState_LastTransition_Number = 9288,
	LimitAlarmType_ShelvingState_LastTransition_TransitionTime = 9289,
	LimitAlarmType_ShelvingState_UnshelveTime = 9290,
	LimitAlarmType_ShelvingState_Unshelve = 9312,
	LimitAlarmType_ShelvingState_OneShotShelve = 9313,
	LimitAlarmType_ShelvingState_TimedShelve = 9314,
	LimitAlarmType_ShelvingState_TimedShelve_InputArguments = 9315,
	LimitAlarmType_SuppressedOrShelved = 9316,
	LimitAlarmType_MaxTimeShelved = 9317,
	ExclusiveLimitStateMachineType = 9318,
	ExclusiveLimitStateMachineType_CurrentState = 9319,
	ExclusiveLimitStateMachineType_CurrentState_Id = 9320,
	ExclusiveLimitStateMachineType_CurrentState_Name = 9321,
	ExclusiveLimitStateMachineType_CurrentState_Number = 9322,
	ExclusiveLimitStateMachineType_CurrentState_EffectiveDisplayName = 9323,
	ExclusiveLimitStateMachineType_LastTransition = 9324,
	ExclusiveLimitStateMachineType_LastTransition_Id = 9325,
	ExclusiveLimitStateMachineType_LastTransition_Name = 9326,
	ExclusiveLimitStateMachineType_LastTransition_Number = 9327,
	ExclusiveLimitStateMachineType_LastTransition_TransitionTime = 9328,
	ExclusiveLimitStateMachineType_HighHigh = 9329,
	ExclusiveLimitStateMachineType_HighHigh_StateNumber = 9330,
	ExclusiveLimitStateMachineType_High = 9331,
	ExclusiveLimitStateMachineType_High_StateNumber = 9332,
	ExclusiveLimitStateMachineType_Low = 9333,
	ExclusiveLimitStateMachineType_Low_StateNumber = 9334,
	ExclusiveLimitStateMachineType_LowLow = 9335,
	ExclusiveLimitStateMachineType_LowLow_StateNumber = 9336,
	ExclusiveLimitStateMachineType_LowLowToLow = 9337,
	ExclusiveLimitStateMachineType_LowToLowLow = 9338,
	ExclusiveLimitStateMachineType_HighHighToHigh = 9339,
	ExclusiveLimitStateMachineType_HighToHighHigh = 9340,
	ExclusiveLimitAlarmType = 9341,
	ExclusiveLimitAlarmType_EventId = 9342,
	ExclusiveLimitAlarmType_EventType = 9343,
	ExclusiveLimitAlarmType_SourceNode = 9344,
	ExclusiveLimitAlarmType_SourceName = 9345,
	ExclusiveLimitAlarmType_Time = 9346,
	ExclusiveLimitAlarmType_ReceiveTime = 9347,
	ExclusiveLimitAlarmType_LocalTime = 9348,
	ExclusiveLimitAlarmType_Message = 9349,
	ExclusiveLimitAlarmType_Severity = 9350,
	ExclusiveLimitAlarmType_ConditionName = 9351,
	ExclusiveLimitAlarmType_BranchId = 9352,
	ExclusiveLimitAlarmType_Retain = 9353,
	ExclusiveLimitAlarmType_EnabledState = 9354,
	ExclusiveLimitAlarmType_EnabledState_Id = 9355,
	ExclusiveLimitAlarmType_EnabledState_Name = 9356,
	ExclusiveLimitAlarmType_EnabledState_Number = 9357,
	ExclusiveLimitAlarmType_EnabledState_EffectiveDisplayName = 9358,
	ExclusiveLimitAlarmType_EnabledState_TransitionTime = 9359,
	ExclusiveLimitAlarmType_EnabledState_EffectiveTransitionTime = 9360,
	ExclusiveLimitAlarmType_EnabledState_TrueState = 9361,
	ExclusiveLimitAlarmType_EnabledState_FalseState = 9362,
	ExclusiveLimitAlarmType_Quality = 9363,
	ExclusiveLimitAlarmType_Quality_SourceTimestamp = 9364,
	ExclusiveLimitAlarmType_LastSeverity = 9365,
	ExclusiveLimitAlarmType_LastSeverity_SourceTimestamp = 9366,
	ExclusiveLimitAlarmType_Comment = 9367,
	ExclusiveLimitAlarmType_Comment_SourceTimestamp = 9368,
	ExclusiveLimitAlarmType_ClientUserId = 9369,
	ExclusiveLimitAlarmType_Enable = 9370,
	ExclusiveLimitAlarmType_Disable = 9371,
	ExclusiveLimitAlarmType_AddComment = 9372,
	ExclusiveLimitAlarmType_AddComment_InputArguments = 9373,
	ExclusiveLimitAlarmType_ConditionRefresh = 9374,
	ExclusiveLimitAlarmType_ConditionRefresh_InputArguments = 9375,
	ExclusiveLimitAlarmType_AckedState = 9376,
	ExclusiveLimitAlarmType_AckedState_Id = 9377,
	ExclusiveLimitAlarmType_AckedState_Name = 9378,
	ExclusiveLimitAlarmType_AckedState_Number = 9379,
	ExclusiveLimitAlarmType_AckedState_EffectiveDisplayName = 9380,
	ExclusiveLimitAlarmType_AckedState_TransitionTime = 9381,
	ExclusiveLimitAlarmType_AckedState_EffectiveTransitionTime = 9382,
	ExclusiveLimitAlarmType_AckedState_TrueState = 9383,
	ExclusiveLimitAlarmType_AckedState_FalseState = 9384,
	ExclusiveLimitAlarmType_ConfirmedState = 9385,
	ExclusiveLimitAlarmType_ConfirmedState_Id = 9386,
	ExclusiveLimitAlarmType_ConfirmedState_Name = 9387,
	ExclusiveLimitAlarmType_ConfirmedState_Number = 9388,
	ExclusiveLimitAlarmType_ConfirmedState_EffectiveDisplayName = 9389,
	ExclusiveLimitAlarmType_ConfirmedState_TransitionTime = 9390,
	ExclusiveLimitAlarmType_ConfirmedState_EffectiveTransitionTime = 9391,
	ExclusiveLimitAlarmType_ConfirmedState_TrueState = 9392,
	ExclusiveLimitAlarmType_ConfirmedState_FalseState = 9393,
	ExclusiveLimitAlarmType_Acknowledge = 9394,
	ExclusiveLimitAlarmType_Acknowledge_InputArguments = 9395,
	ExclusiveLimitAlarmType_Confirm = 9396,
	ExclusiveLimitAlarmType_Confirm_InputArguments = 9397,
	ExclusiveLimitAlarmType_ActiveState = 9398,
	ExclusiveLimitAlarmType_ActiveState_Id = 9399,
	ExclusiveLimitAlarmType_ActiveState_Name = 9400,
	ExclusiveLimitAlarmType_ActiveState_Number = 9401,
	ExclusiveLimitAlarmType_ActiveState_EffectiveDisplayName = 9402,
	ExclusiveLimitAlarmType_ActiveState_TransitionTime = 9403,
	ExclusiveLimitAlarmType_ActiveState_EffectiveTransitionTime = 9404,
	ExclusiveLimitAlarmType_ActiveState_TrueState = 9405,
	ExclusiveLimitAlarmType_ActiveState_FalseState = 9406,
	ExclusiveLimitAlarmType_SuppressedState = 9407,
	ExclusiveLimitAlarmType_SuppressedState_Id = 9408,
	ExclusiveLimitAlarmType_SuppressedState_Name = 9409,
	ExclusiveLimitAlarmType_SuppressedState_Number = 9410,
	ExclusiveLimitAlarmType_SuppressedState_EffectiveDisplayName = 9411,
	ExclusiveLimitAlarmType_SuppressedState_TransitionTime = 9412,
	ExclusiveLimitAlarmType_SuppressedState_EffectiveTransitionTime = 9413,
	ExclusiveLimitAlarmType_SuppressedState_TrueState = 9414,
	ExclusiveLimitAlarmType_SuppressedState_FalseState = 9415,
	ExclusiveLimitAlarmType_ShelvingState = 9416,
	ExclusiveLimitAlarmType_ShelvingState_CurrentState = 9417,
	ExclusiveLimitAlarmType_ShelvingState_CurrentState_Id = 9418,
	ExclusiveLimitAlarmType_ShelvingState_CurrentState_Name = 9419,
	ExclusiveLimitAlarmType_ShelvingState_CurrentState_Number = 9420,
	ExclusiveLimitAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 9421,
	ExclusiveLimitAlarmType_ShelvingState_LastTransition = 9422,
	ExclusiveLimitAlarmType_ShelvingState_LastTransition_Id = 9423,
	ExclusiveLimitAlarmType_ShelvingState_LastTransition_Name = 9424,
	ExclusiveLimitAlarmType_ShelvingState_LastTransition_Number = 9425,
	ExclusiveLimitAlarmType_ShelvingState_LastTransition_TransitionTime = 9426,
	ExclusiveLimitAlarmType_ShelvingState_UnshelveTime = 9427,
	ExclusiveLimitAlarmType_ShelvingState_Unshelve = 9449,
	ExclusiveLimitAlarmType_ShelvingState_OneShotShelve = 9450,
	ExclusiveLimitAlarmType_ShelvingState_TimedShelve = 9451,
	ExclusiveLimitAlarmType_ShelvingState_TimedShelve_InputArguments = 9452,
	ExclusiveLimitAlarmType_SuppressedOrShelved = 9453,
	ExclusiveLimitAlarmType_MaxTimeShelved = 9454,
	ExclusiveLimitAlarmType_LimitState = 9455,
	ExclusiveLimitAlarmType_LimitState_CurrentState = 9456,
	ExclusiveLimitAlarmType_LimitState_CurrentState_Id = 9457,
	ExclusiveLimitAlarmType_LimitState_CurrentState_Name = 9458,
	ExclusiveLimitAlarmType_LimitState_CurrentState_Number = 9459,
	ExclusiveLimitAlarmType_LimitState_CurrentState_EffectiveDisplayName = 9460,
	ExclusiveLimitAlarmType_LimitState_LastTransition = 9461,
	ExclusiveLimitAlarmType_LimitState_LastTransition_Id = 9462,
	ExclusiveLimitAlarmType_LimitState_LastTransition_Name = 9463,
	ExclusiveLimitAlarmType_LimitState_LastTransition_Number = 9464,
	ExclusiveLimitAlarmType_LimitState_LastTransition_TransitionTime = 9465,
	ExclusiveLimitAlarmType_HighHighLimit = 9478,
	ExclusiveLimitAlarmType_HighLimit = 9479,
	ExclusiveLimitAlarmType_LowLimit = 9480,
	ExclusiveLimitAlarmType_LowLowLimit = 9481,
	ExclusiveLevelAlarmType = 9482,
	ExclusiveLevelAlarmType_EventId = 9483,
	ExclusiveLevelAlarmType_EventType = 9484,
	ExclusiveLevelAlarmType_SourceNode = 9485,
	ExclusiveLevelAlarmType_SourceName = 9486,
	ExclusiveLevelAlarmType_Time = 9487,
	ExclusiveLevelAlarmType_ReceiveTime = 9488,
	ExclusiveLevelAlarmType_LocalTime = 9489,
	ExclusiveLevelAlarmType_Message = 9490,
	ExclusiveLevelAlarmType_Severity = 9491,
	ExclusiveLevelAlarmType_ConditionName = 9492,
	ExclusiveLevelAlarmType_BranchId = 9493,
	ExclusiveLevelAlarmType_Retain = 9494,
	ExclusiveLevelAlarmType_EnabledState = 9495,
	ExclusiveLevelAlarmType_EnabledState_Id = 9496,
	ExclusiveLevelAlarmType_EnabledState_Name = 9497,
	ExclusiveLevelAlarmType_EnabledState_Number = 9498,
	ExclusiveLevelAlarmType_EnabledState_EffectiveDisplayName = 9499,
	ExclusiveLevelAlarmType_EnabledState_TransitionTime = 9500,
	ExclusiveLevelAlarmType_EnabledState_EffectiveTransitionTime = 9501,
	ExclusiveLevelAlarmType_EnabledState_TrueState = 9502,
	ExclusiveLevelAlarmType_EnabledState_FalseState = 9503,
	ExclusiveLevelAlarmType_Quality = 9504,
	ExclusiveLevelAlarmType_Quality_SourceTimestamp = 9505,
	ExclusiveLevelAlarmType_LastSeverity = 9506,
	ExclusiveLevelAlarmType_LastSeverity_SourceTimestamp = 9507,
	ExclusiveLevelAlarmType_Comment = 9508,
	ExclusiveLevelAlarmType_Comment_SourceTimestamp = 9509,
	ExclusiveLevelAlarmType_ClientUserId = 9510,
	ExclusiveLevelAlarmType_Enable = 9511,
	ExclusiveLevelAlarmType_Disable = 9512,
	ExclusiveLevelAlarmType_AddComment = 9513,
	ExclusiveLevelAlarmType_AddComment_InputArguments = 9514,
	ExclusiveLevelAlarmType_ConditionRefresh = 9515,
	ExclusiveLevelAlarmType_ConditionRefresh_InputArguments = 9516,
	ExclusiveLevelAlarmType_AckedState = 9517,
	ExclusiveLevelAlarmType_AckedState_Id = 9518,
	ExclusiveLevelAlarmType_AckedState_Name = 9519,
	ExclusiveLevelAlarmType_AckedState_Number = 9520,
	ExclusiveLevelAlarmType_AckedState_EffectiveDisplayName = 9521,
	ExclusiveLevelAlarmType_AckedState_TransitionTime = 9522,
	ExclusiveLevelAlarmType_AckedState_EffectiveTransitionTime = 9523,
	ExclusiveLevelAlarmType_AckedState_TrueState = 9524,
	ExclusiveLevelAlarmType_AckedState_FalseState = 9525,
	ExclusiveLevelAlarmType_ConfirmedState = 9526,
	ExclusiveLevelAlarmType_ConfirmedState_Id = 9527,
	ExclusiveLevelAlarmType_ConfirmedState_Name = 9528,
	ExclusiveLevelAlarmType_ConfirmedState_Number = 9529,
	ExclusiveLevelAlarmType_ConfirmedState_EffectiveDisplayName = 9530,
	ExclusiveLevelAlarmType_ConfirmedState_TransitionTime = 9531,
	ExclusiveLevelAlarmType_ConfirmedState_EffectiveTransitionTime = 9532,
	ExclusiveLevelAlarmType_ConfirmedState_TrueState = 9533,
	ExclusiveLevelAlarmType_ConfirmedState_FalseState = 9534,
	ExclusiveLevelAlarmType_Acknowledge = 9535,
	ExclusiveLevelAlarmType_Acknowledge_InputArguments = 9536,
	ExclusiveLevelAlarmType_Confirm = 9537,
	ExclusiveLevelAlarmType_Confirm_InputArguments = 9538,
	ExclusiveLevelAlarmType_ActiveState = 9539,
	ExclusiveLevelAlarmType_ActiveState_Id = 9540,
	ExclusiveLevelAlarmType_ActiveState_Name = 9541,
	ExclusiveLevelAlarmType_ActiveState_Number = 9542,
	ExclusiveLevelAlarmType_ActiveState_EffectiveDisplayName = 9543,
	ExclusiveLevelAlarmType_ActiveState_TransitionTime = 9544,
	ExclusiveLevelAlarmType_ActiveState_EffectiveTransitionTime = 9545,
	ExclusiveLevelAlarmType_ActiveState_TrueState = 9546,
	ExclusiveLevelAlarmType_ActiveState_FalseState = 9547,
	ExclusiveLevelAlarmType_SuppressedState = 9548,
	ExclusiveLevelAlarmType_SuppressedState_Id = 9549,
	ExclusiveLevelAlarmType_SuppressedState_Name = 9550,
	ExclusiveLevelAlarmType_SuppressedState_Number = 9551,
	ExclusiveLevelAlarmType_SuppressedState_EffectiveDisplayName = 9552,
	ExclusiveLevelAlarmType_SuppressedState_TransitionTime = 9553,
	ExclusiveLevelAlarmType_SuppressedState_EffectiveTransitionTime = 9554,
	ExclusiveLevelAlarmType_SuppressedState_TrueState = 9555,
	ExclusiveLevelAlarmType_SuppressedState_FalseState = 9556,
	ExclusiveLevelAlarmType_ShelvingState = 9557,
	ExclusiveLevelAlarmType_ShelvingState_CurrentState = 9558,
	ExclusiveLevelAlarmType_ShelvingState_CurrentState_Id = 9559,
	ExclusiveLevelAlarmType_ShelvingState_CurrentState_Name = 9560,
	ExclusiveLevelAlarmType_ShelvingState_CurrentState_Number = 9561,
	ExclusiveLevelAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 9562,
	ExclusiveLevelAlarmType_ShelvingState_LastTransition = 9563,
	ExclusiveLevelAlarmType_ShelvingState_LastTransition_Id = 9564,
	ExclusiveLevelAlarmType_ShelvingState_LastTransition_Name = 9565,
	ExclusiveLevelAlarmType_ShelvingState_LastTransition_Number = 9566,
	ExclusiveLevelAlarmType_ShelvingState_LastTransition_TransitionTime = 9567,
	ExclusiveLevelAlarmType_ShelvingState_UnshelveTime = 9568,
	ExclusiveLevelAlarmType_ShelvingState_Unshelve = 9590,
	ExclusiveLevelAlarmType_ShelvingState_OneShotShelve = 9591,
	ExclusiveLevelAlarmType_ShelvingState_TimedShelve = 9592,
	ExclusiveLevelAlarmType_ShelvingState_TimedShelve_InputArguments = 9593,
	ExclusiveLevelAlarmType_SuppressedOrShelved = 9594,
	ExclusiveLevelAlarmType_MaxTimeShelved = 9595,
	ExclusiveLevelAlarmType_LimitState = 9596,
	ExclusiveLevelAlarmType_LimitState_CurrentState = 9597,
	ExclusiveLevelAlarmType_LimitState_CurrentState_Id = 9598,
	ExclusiveLevelAlarmType_LimitState_CurrentState_Name = 9599,
	ExclusiveLevelAlarmType_LimitState_CurrentState_Number = 9600,
	ExclusiveLevelAlarmType_LimitState_CurrentState_EffectiveDisplayName = 9601,
	ExclusiveLevelAlarmType_LimitState_LastTransition = 9602,
	ExclusiveLevelAlarmType_LimitState_LastTransition_Id = 9603,
	ExclusiveLevelAlarmType_LimitState_LastTransition_Name = 9604,
	ExclusiveLevelAlarmType_LimitState_LastTransition_Number = 9605,
	ExclusiveLevelAlarmType_LimitState_LastTransition_TransitionTime = 9606,
	ExclusiveLevelAlarmType_HighHighLimit = 9619,
	ExclusiveLevelAlarmType_HighLimit = 9620,
	ExclusiveLevelAlarmType_LowLimit = 9621,
	ExclusiveLevelAlarmType_LowLowLimit = 9622,
	ExclusiveRateOfChangeAlarmType = 9623,
	ExclusiveRateOfChangeAlarmType_EventId = 9624,
	ExclusiveRateOfChangeAlarmType_EventType = 9625,
	ExclusiveRateOfChangeAlarmType_SourceNode = 9626,
	ExclusiveRateOfChangeAlarmType_SourceName = 9627,
	ExclusiveRateOfChangeAlarmType_Time = 9628,
	ExclusiveRateOfChangeAlarmType_ReceiveTime = 9629,
	ExclusiveRateOfChangeAlarmType_LocalTime = 9630,
	ExclusiveRateOfChangeAlarmType_Message = 9631,
	ExclusiveRateOfChangeAlarmType_Severity = 9632,
	ExclusiveRateOfChangeAlarmType_ConditionName = 9633,
	ExclusiveRateOfChangeAlarmType_BranchId = 9634,
	ExclusiveRateOfChangeAlarmType_Retain = 9635,
	ExclusiveRateOfChangeAlarmType_EnabledState = 9636,
	ExclusiveRateOfChangeAlarmType_EnabledState_Id = 9637,
	ExclusiveRateOfChangeAlarmType_EnabledState_Name = 9638,
	ExclusiveRateOfChangeAlarmType_EnabledState_Number = 9639,
	ExclusiveRateOfChangeAlarmType_EnabledState_EffectiveDisplayName = 9640,
	ExclusiveRateOfChangeAlarmType_EnabledState_TransitionTime = 9641,
	ExclusiveRateOfChangeAlarmType_EnabledState_EffectiveTransitionTime = 9642,
	ExclusiveRateOfChangeAlarmType_EnabledState_TrueState = 9643,
	ExclusiveRateOfChangeAlarmType_EnabledState_FalseState = 9644,
	ExclusiveRateOfChangeAlarmType_Quality = 9645,
	ExclusiveRateOfChangeAlarmType_Quality_SourceTimestamp = 9646,
	ExclusiveRateOfChangeAlarmType_LastSeverity = 9647,
	ExclusiveRateOfChangeAlarmType_LastSeverity_SourceTimestamp = 9648,
	ExclusiveRateOfChangeAlarmType_Comment = 9649,
	ExclusiveRateOfChangeAlarmType_Comment_SourceTimestamp = 9650,
	ExclusiveRateOfChangeAlarmType_ClientUserId = 9651,
	ExclusiveRateOfChangeAlarmType_Enable = 9652,
	ExclusiveRateOfChangeAlarmType_Disable = 9653,
	ExclusiveRateOfChangeAlarmType_AddComment = 9654,
	ExclusiveRateOfChangeAlarmType_AddComment_InputArguments = 9655,
	ExclusiveRateOfChangeAlarmType_ConditionRefresh = 9656,
	ExclusiveRateOfChangeAlarmType_ConditionRefresh_InputArguments = 9657,
	ExclusiveRateOfChangeAlarmType_AckedState = 9658,
	ExclusiveRateOfChangeAlarmType_AckedState_Id = 9659,
	ExclusiveRateOfChangeAlarmType_AckedState_Name = 9660,
	ExclusiveRateOfChangeAlarmType_AckedState_Number = 9661,
	ExclusiveRateOfChangeAlarmType_AckedState_EffectiveDisplayName = 9662,
	ExclusiveRateOfChangeAlarmType_AckedState_TransitionTime = 9663,
	ExclusiveRateOfChangeAlarmType_AckedState_EffectiveTransitionTime = 9664,
	ExclusiveRateOfChangeAlarmType_AckedState_TrueState = 9665,
	ExclusiveRateOfChangeAlarmType_AckedState_FalseState = 9666,
	ExclusiveRateOfChangeAlarmType_ConfirmedState = 9667,
	ExclusiveRateOfChangeAlarmType_ConfirmedState_Id = 9668,
	ExclusiveRateOfChangeAlarmType_ConfirmedState_Name = 9669,
	ExclusiveRateOfChangeAlarmType_ConfirmedState_Number = 9670,
	ExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveDisplayName = 9671,
	ExclusiveRateOfChangeAlarmType_ConfirmedState_TransitionTime = 9672,
	ExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveTransitionTime = 9673,
	ExclusiveRateOfChangeAlarmType_ConfirmedState_TrueState = 9674,
	ExclusiveRateOfChangeAlarmType_ConfirmedState_FalseState = 9675,
	ExclusiveRateOfChangeAlarmType_Acknowledge = 9676,
	ExclusiveRateOfChangeAlarmType_Acknowledge_InputArguments = 9677,
	ExclusiveRateOfChangeAlarmType_Confirm = 9678,
	ExclusiveRateOfChangeAlarmType_Confirm_InputArguments = 9679,
	ExclusiveRateOfChangeAlarmType_ActiveState = 9680,
	ExclusiveRateOfChangeAlarmType_ActiveState_Id = 9681,
	ExclusiveRateOfChangeAlarmType_ActiveState_Name = 9682,
	ExclusiveRateOfChangeAlarmType_ActiveState_Number = 9683,
	ExclusiveRateOfChangeAlarmType_ActiveState_EffectiveDisplayName = 9684,
	ExclusiveRateOfChangeAlarmType_ActiveState_TransitionTime = 9685,
	ExclusiveRateOfChangeAlarmType_ActiveState_EffectiveTransitionTime = 9686,
	ExclusiveRateOfChangeAlarmType_ActiveState_TrueState = 9687,
	ExclusiveRateOfChangeAlarmType_ActiveState_FalseState = 9688,
	ExclusiveRateOfChangeAlarmType_SuppressedState = 9689,
	ExclusiveRateOfChangeAlarmType_SuppressedState_Id = 9690,
	ExclusiveRateOfChangeAlarmType_SuppressedState_Name = 9691,
	ExclusiveRateOfChangeAlarmType_SuppressedState_Number = 9692,
	ExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveDisplayName = 9693,
	ExclusiveRateOfChangeAlarmType_SuppressedState_TransitionTime = 9694,
	ExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveTransitionTime = 9695,
	ExclusiveRateOfChangeAlarmType_SuppressedState_TrueState = 9696,
	ExclusiveRateOfChangeAlarmType_SuppressedState_FalseState = 9697,
	ExclusiveRateOfChangeAlarmType_ShelvingState = 9698,
	ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState = 9699,
	ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Id = 9700,
	ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Name = 9701,
	ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Number = 9702,
	ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 9703,
	ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition = 9704,
	ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Id = 9705,
	ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Name = 9706,
	ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Number = 9707,
	ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_TransitionTime = 9708,
	ExclusiveRateOfChangeAlarmType_ShelvingState_UnshelveTime = 9709,
	ExclusiveRateOfChangeAlarmType_ShelvingState_Unshelve = 9731,
	ExclusiveRateOfChangeAlarmType_ShelvingState_OneShotShelve = 9732,
	ExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve = 9733,
	ExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve_InputArguments = 9734,
	ExclusiveRateOfChangeAlarmType_SuppressedOrShelved = 9735,
	ExclusiveRateOfChangeAlarmType_MaxTimeShelved = 9736,
	ExclusiveRateOfChangeAlarmType_LimitState = 9737,
	ExclusiveRateOfChangeAlarmType_LimitState_CurrentState = 9738,
	ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_Id = 9739,
	ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_Name = 9740,
	ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_Number = 9741,
	ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_EffectiveDisplayName = 9742,
	ExclusiveRateOfChangeAlarmType_LimitState_LastTransition = 9743,
	ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_Id = 9744,
	ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_Name = 9745,
	ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_Number = 9746,
	ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_TransitionTime = 9747,
	ExclusiveRateOfChangeAlarmType_HighHighLimit = 9760,
	ExclusiveRateOfChangeAlarmType_HighLimit = 9761,
	ExclusiveRateOfChangeAlarmType_LowLimit = 9762,
	ExclusiveRateOfChangeAlarmType_LowLowLimit = 9763,
	ExclusiveDeviationAlarmType = 9764,
	ExclusiveDeviationAlarmType_EventId = 9765,
	ExclusiveDeviationAlarmType_EventType = 9766,
	ExclusiveDeviationAlarmType_SourceNode = 9767,
	ExclusiveDeviationAlarmType_SourceName = 9768,
	ExclusiveDeviationAlarmType_Time = 9769,
	ExclusiveDeviationAlarmType_ReceiveTime = 9770,
	ExclusiveDeviationAlarmType_LocalTime = 9771,
	ExclusiveDeviationAlarmType_Message = 9772,
	ExclusiveDeviationAlarmType_Severity = 9773,
	ExclusiveDeviationAlarmType_ConditionName = 9774,
	ExclusiveDeviationAlarmType_BranchId = 9775,
	ExclusiveDeviationAlarmType_Retain = 9776,
	ExclusiveDeviationAlarmType_EnabledState = 9777,
	ExclusiveDeviationAlarmType_EnabledState_Id = 9778,
	ExclusiveDeviationAlarmType_EnabledState_Name = 9779,
	ExclusiveDeviationAlarmType_EnabledState_Number = 9780,
	ExclusiveDeviationAlarmType_EnabledState_EffectiveDisplayName = 9781,
	ExclusiveDeviationAlarmType_EnabledState_TransitionTime = 9782,
	ExclusiveDeviationAlarmType_EnabledState_EffectiveTransitionTime = 9783,
	ExclusiveDeviationAlarmType_EnabledState_TrueState = 9784,
	ExclusiveDeviationAlarmType_EnabledState_FalseState = 9785,
	ExclusiveDeviationAlarmType_Quality = 9786,
	ExclusiveDeviationAlarmType_Quality_SourceTimestamp = 9787,
	ExclusiveDeviationAlarmType_LastSeverity = 9788,
	ExclusiveDeviationAlarmType_LastSeverity_SourceTimestamp = 9789,
	ExclusiveDeviationAlarmType_Comment = 9790,
	ExclusiveDeviationAlarmType_Comment_SourceTimestamp = 9791,
	ExclusiveDeviationAlarmType_ClientUserId = 9792,
	ExclusiveDeviationAlarmType_Enable = 9793,
	ExclusiveDeviationAlarmType_Disable = 9794,
	ExclusiveDeviationAlarmType_AddComment = 9795,
	ExclusiveDeviationAlarmType_AddComment_InputArguments = 9796,
	ExclusiveDeviationAlarmType_ConditionRefresh = 9797,
	ExclusiveDeviationAlarmType_ConditionRefresh_InputArguments = 9798,
	ExclusiveDeviationAlarmType_AckedState = 9799,
	ExclusiveDeviationAlarmType_AckedState_Id = 9800,
	ExclusiveDeviationAlarmType_AckedState_Name = 9801,
	ExclusiveDeviationAlarmType_AckedState_Number = 9802,
	ExclusiveDeviationAlarmType_AckedState_EffectiveDisplayName = 9803,
	ExclusiveDeviationAlarmType_AckedState_TransitionTime = 9804,
	ExclusiveDeviationAlarmType_AckedState_EffectiveTransitionTime = 9805,
	ExclusiveDeviationAlarmType_AckedState_TrueState = 9806,
	ExclusiveDeviationAlarmType_AckedState_FalseState = 9807,
	ExclusiveDeviationAlarmType_ConfirmedState = 9808,
	ExclusiveDeviationAlarmType_ConfirmedState_Id = 9809,
	ExclusiveDeviationAlarmType_ConfirmedState_Name = 9810,
	ExclusiveDeviationAlarmType_ConfirmedState_Number = 9811,
	ExclusiveDeviationAlarmType_ConfirmedState_EffectiveDisplayName = 9812,
	ExclusiveDeviationAlarmType_ConfirmedState_TransitionTime = 9813,
	ExclusiveDeviationAlarmType_ConfirmedState_EffectiveTransitionTime = 9814,
	ExclusiveDeviationAlarmType_ConfirmedState_TrueState = 9815,
	ExclusiveDeviationAlarmType_ConfirmedState_FalseState = 9816,
	ExclusiveDeviationAlarmType_Acknowledge = 9817,
	ExclusiveDeviationAlarmType_Acknowledge_InputArguments = 9818,
	ExclusiveDeviationAlarmType_Confirm = 9819,
	ExclusiveDeviationAlarmType_Confirm_InputArguments = 9820,
	ExclusiveDeviationAlarmType_ActiveState = 9821,
	ExclusiveDeviationAlarmType_ActiveState_Id = 9822,
	ExclusiveDeviationAlarmType_ActiveState_Name = 9823,
	ExclusiveDeviationAlarmType_ActiveState_Number = 9824,
	ExclusiveDeviationAlarmType_ActiveState_EffectiveDisplayName = 9825,
	ExclusiveDeviationAlarmType_ActiveState_TransitionTime = 9826,
	ExclusiveDeviationAlarmType_ActiveState_EffectiveTransitionTime = 9827,
	ExclusiveDeviationAlarmType_ActiveState_TrueState = 9828,
	ExclusiveDeviationAlarmType_ActiveState_FalseState = 9829,
	ExclusiveDeviationAlarmType_SuppressedState = 9830,
	ExclusiveDeviationAlarmType_SuppressedState_Id = 9831,
	ExclusiveDeviationAlarmType_SuppressedState_Name = 9832,
	ExclusiveDeviationAlarmType_SuppressedState_Number = 9833,
	ExclusiveDeviationAlarmType_SuppressedState_EffectiveDisplayName = 9834,
	ExclusiveDeviationAlarmType_SuppressedState_TransitionTime = 9835,
	ExclusiveDeviationAlarmType_SuppressedState_EffectiveTransitionTime = 9836,
	ExclusiveDeviationAlarmType_SuppressedState_TrueState = 9837,
	ExclusiveDeviationAlarmType_SuppressedState_FalseState = 9838,
	ExclusiveDeviationAlarmType_ShelvingState = 9839,
	ExclusiveDeviationAlarmType_ShelvingState_CurrentState = 9840,
	ExclusiveDeviationAlarmType_ShelvingState_CurrentState_Id = 9841,
	ExclusiveDeviationAlarmType_ShelvingState_CurrentState_Name = 9842,
	ExclusiveDeviationAlarmType_ShelvingState_CurrentState_Number = 9843,
	ExclusiveDeviationAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 9844,
	ExclusiveDeviationAlarmType_ShelvingState_LastTransition = 9845,
	ExclusiveDeviationAlarmType_ShelvingState_LastTransition_Id = 9846,
	ExclusiveDeviationAlarmType_ShelvingState_LastTransition_Name = 9847,
	ExclusiveDeviationAlarmType_ShelvingState_LastTransition_Number = 9848,
	ExclusiveDeviationAlarmType_ShelvingState_LastTransition_TransitionTime = 9849,
	ExclusiveDeviationAlarmType_ShelvingState_UnshelveTime = 9850,
	ExclusiveDeviationAlarmType_ShelvingState_Unshelve = 9872,
	ExclusiveDeviationAlarmType_ShelvingState_OneShotShelve = 9873,
	ExclusiveDeviationAlarmType_ShelvingState_TimedShelve = 9874,
	ExclusiveDeviationAlarmType_ShelvingState_TimedShelve_InputArguments = 9875,
	ExclusiveDeviationAlarmType_SuppressedOrShelved = 9876,
	ExclusiveDeviationAlarmType_MaxTimeShelved = 9877,
	ExclusiveDeviationAlarmType_LimitState = 9878,
	ExclusiveDeviationAlarmType_LimitState_CurrentState = 9879,
	ExclusiveDeviationAlarmType_LimitState_CurrentState_Id = 9880,
	ExclusiveDeviationAlarmType_LimitState_CurrentState_Name = 9881,
	ExclusiveDeviationAlarmType_LimitState_CurrentState_Number = 9882,
	ExclusiveDeviationAlarmType_LimitState_CurrentState_EffectiveDisplayName = 9883,
	ExclusiveDeviationAlarmType_LimitState_LastTransition = 9884,
	ExclusiveDeviationAlarmType_LimitState_LastTransition_Id = 9885,
	ExclusiveDeviationAlarmType_LimitState_LastTransition_Name = 9886,
	ExclusiveDeviationAlarmType_LimitState_LastTransition_Number = 9887,
	ExclusiveDeviationAlarmType_LimitState_LastTransition_TransitionTime = 9888,
	ExclusiveDeviationAlarmType_HighHighLimit = 9901,
	ExclusiveDeviationAlarmType_HighLimit = 9902,
	ExclusiveDeviationAlarmType_LowLimit = 9903,
	ExclusiveDeviationAlarmType_LowLowLimit = 9904,
	ExclusiveDeviationAlarmType_SetpointNode = 9905,
	NonExclusiveLimitAlarmType = 9906,
	NonExclusiveLimitAlarmType_EventId = 9907,
	NonExclusiveLimitAlarmType_EventType = 9908,
	NonExclusiveLimitAlarmType_SourceNode = 9909,
	NonExclusiveLimitAlarmType_SourceName = 9910,
	NonExclusiveLimitAlarmType_Time = 9911,
	NonExclusiveLimitAlarmType_ReceiveTime = 9912,
	NonExclusiveLimitAlarmType_LocalTime = 9913,
	NonExclusiveLimitAlarmType_Message = 9914,
	NonExclusiveLimitAlarmType_Severity = 9915,
	NonExclusiveLimitAlarmType_ConditionName = 9916,
	NonExclusiveLimitAlarmType_BranchId = 9917,
	NonExclusiveLimitAlarmType_Retain = 9918,
	NonExclusiveLimitAlarmType_EnabledState = 9919,
	NonExclusiveLimitAlarmType_EnabledState_Id = 9920,
	NonExclusiveLimitAlarmType_EnabledState_Name = 9921,
	NonExclusiveLimitAlarmType_EnabledState_Number = 9922,
	NonExclusiveLimitAlarmType_EnabledState_EffectiveDisplayName = 9923,
	NonExclusiveLimitAlarmType_EnabledState_TransitionTime = 9924,
	NonExclusiveLimitAlarmType_EnabledState_EffectiveTransitionTime = 9925,
	NonExclusiveLimitAlarmType_EnabledState_TrueState = 9926,
	NonExclusiveLimitAlarmType_EnabledState_FalseState = 9927,
	NonExclusiveLimitAlarmType_Quality = 9928,
	NonExclusiveLimitAlarmType_Quality_SourceTimestamp = 9929,
	NonExclusiveLimitAlarmType_LastSeverity = 9930,
	NonExclusiveLimitAlarmType_LastSeverity_SourceTimestamp = 9931,
	NonExclusiveLimitAlarmType_Comment = 9932,
	NonExclusiveLimitAlarmType_Comment_SourceTimestamp = 9933,
	NonExclusiveLimitAlarmType_ClientUserId = 9934,
	NonExclusiveLimitAlarmType_Enable = 9935,
	NonExclusiveLimitAlarmType_Disable = 9936,
	NonExclusiveLimitAlarmType_AddComment = 9937,
	NonExclusiveLimitAlarmType_AddComment_InputArguments = 9938,
	NonExclusiveLimitAlarmType_ConditionRefresh = 9939,
	NonExclusiveLimitAlarmType_ConditionRefresh_InputArguments = 9940,
	NonExclusiveLimitAlarmType_AckedState = 9941,
	NonExclusiveLimitAlarmType_AckedState_Id = 9942,
	NonExclusiveLimitAlarmType_AckedState_Name = 9943,
	NonExclusiveLimitAlarmType_AckedState_Number = 9944,
	NonExclusiveLimitAlarmType_AckedState_EffectiveDisplayName = 9945,
	NonExclusiveLimitAlarmType_AckedState_TransitionTime = 9946,
	NonExclusiveLimitAlarmType_AckedState_EffectiveTransitionTime = 9947,
	NonExclusiveLimitAlarmType_AckedState_TrueState = 9948,
	NonExclusiveLimitAlarmType_AckedState_FalseState = 9949,
	NonExclusiveLimitAlarmType_ConfirmedState = 9950,
	NonExclusiveLimitAlarmType_ConfirmedState_Id = 9951,
	NonExclusiveLimitAlarmType_ConfirmedState_Name = 9952,
	NonExclusiveLimitAlarmType_ConfirmedState_Number = 9953,
	NonExclusiveLimitAlarmType_ConfirmedState_EffectiveDisplayName = 9954,
	NonExclusiveLimitAlarmType_ConfirmedState_TransitionTime = 9955,
	NonExclusiveLimitAlarmType_ConfirmedState_EffectiveTransitionTime = 9956,
	NonExclusiveLimitAlarmType_ConfirmedState_TrueState = 9957,
	NonExclusiveLimitAlarmType_ConfirmedState_FalseState = 9958,
	NonExclusiveLimitAlarmType_Acknowledge = 9959,
	NonExclusiveLimitAlarmType_Acknowledge_InputArguments = 9960,
	NonExclusiveLimitAlarmType_Confirm = 9961,
	NonExclusiveLimitAlarmType_Confirm_InputArguments = 9962,
	NonExclusiveLimitAlarmType_ActiveState = 9963,
	NonExclusiveLimitAlarmType_ActiveState_Id = 9964,
	NonExclusiveLimitAlarmType_ActiveState_Name = 9965,
	NonExclusiveLimitAlarmType_ActiveState_Number = 9966,
	NonExclusiveLimitAlarmType_ActiveState_EffectiveDisplayName = 9967,
	NonExclusiveLimitAlarmType_ActiveState_TransitionTime = 9968,
	NonExclusiveLimitAlarmType_ActiveState_EffectiveTransitionTime = 9969,
	NonExclusiveLimitAlarmType_ActiveState_TrueState = 9970,
	NonExclusiveLimitAlarmType_ActiveState_FalseState = 9971,
	NonExclusiveLimitAlarmType_SuppressedState = 9972,
	NonExclusiveLimitAlarmType_SuppressedState_Id = 9973,
	NonExclusiveLimitAlarmType_SuppressedState_Name = 9974,
	NonExclusiveLimitAlarmType_SuppressedState_Number = 9975,
	NonExclusiveLimitAlarmType_SuppressedState_EffectiveDisplayName = 9976,
	NonExclusiveLimitAlarmType_SuppressedState_TransitionTime = 9977,
	NonExclusiveLimitAlarmType_SuppressedState_EffectiveTransitionTime = 9978,
	NonExclusiveLimitAlarmType_SuppressedState_TrueState = 9979,
	NonExclusiveLimitAlarmType_SuppressedState_FalseState = 9980,
	NonExclusiveLimitAlarmType_ShelvingState = 9981,
	NonExclusiveLimitAlarmType_ShelvingState_CurrentState = 9982,
	NonExclusiveLimitAlarmType_ShelvingState_CurrentState_Id = 9983,
	NonExclusiveLimitAlarmType_ShelvingState_CurrentState_Name = 9984,
	NonExclusiveLimitAlarmType_ShelvingState_CurrentState_Number = 9985,
	NonExclusiveLimitAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 9986,
	NonExclusiveLimitAlarmType_ShelvingState_LastTransition = 9987,
	NonExclusiveLimitAlarmType_ShelvingState_LastTransition_Id = 9988,
	NonExclusiveLimitAlarmType_ShelvingState_LastTransition_Name = 9989,
	NonExclusiveLimitAlarmType_ShelvingState_LastTransition_Number = 9990,
	NonExclusiveLimitAlarmType_ShelvingState_LastTransition_TransitionTime = 9991,
	NonExclusiveLimitAlarmType_ShelvingState_UnshelveTime = 9992,
	NonExclusiveLimitAlarmType_ShelvingState_Unshelve = 10014,
	NonExclusiveLimitAlarmType_ShelvingState_OneShotShelve = 10015,
	NonExclusiveLimitAlarmType_ShelvingState_TimedShelve = 10016,
	NonExclusiveLimitAlarmType_ShelvingState_TimedShelve_InputArguments = 10017,
	NonExclusiveLimitAlarmType_SuppressedOrShelved = 10018,
	NonExclusiveLimitAlarmType_MaxTimeShelved = 10019,
	NonExclusiveLimitAlarmType_HighHighState = 10020,
	NonExclusiveLimitAlarmType_HighHighState_Id = 10021,
	NonExclusiveLimitAlarmType_HighHighState_Name = 10022,
	NonExclusiveLimitAlarmType_HighHighState_Number = 10023,
	NonExclusiveLimitAlarmType_HighHighState_EffectiveDisplayName = 10024,
	NonExclusiveLimitAlarmType_HighHighState_TransitionTime = 10025,
	NonExclusiveLimitAlarmType_HighHighState_EffectiveTransitionTime = 10026,
	NonExclusiveLimitAlarmType_HighHighState_TrueState = 10027,
	NonExclusiveLimitAlarmType_HighHighState_FalseState = 10028,
	NonExclusiveLimitAlarmType_HighState = 10029,
	NonExclusiveLimitAlarmType_HighState_Id = 10030,
	NonExclusiveLimitAlarmType_HighState_Name = 10031,
	NonExclusiveLimitAlarmType_HighState_Number = 10032,
	NonExclusiveLimitAlarmType_HighState_EffectiveDisplayName = 10033,
	NonExclusiveLimitAlarmType_HighState_TransitionTime = 10034,
	NonExclusiveLimitAlarmType_HighState_EffectiveTransitionTime = 10035,
	NonExclusiveLimitAlarmType_HighState_TrueState = 10036,
	NonExclusiveLimitAlarmType_HighState_FalseState = 10037,
	NonExclusiveLimitAlarmType_LowState = 10038,
	NonExclusiveLimitAlarmType_LowState_Id = 10039,
	NonExclusiveLimitAlarmType_LowState_Name = 10040,
	NonExclusiveLimitAlarmType_LowState_Number = 10041,
	NonExclusiveLimitAlarmType_LowState_EffectiveDisplayName = 10042,
	NonExclusiveLimitAlarmType_LowState_TransitionTime = 10043,
	NonExclusiveLimitAlarmType_LowState_EffectiveTransitionTime = 10044,
	NonExclusiveLimitAlarmType_LowState_TrueState = 10045,
	NonExclusiveLimitAlarmType_LowState_FalseState = 10046,
	NonExclusiveLimitAlarmType_LowLowState = 10047,
	NonExclusiveLimitAlarmType_LowLowState_Id = 10048,
	NonExclusiveLimitAlarmType_LowLowState_Name = 10049,
	NonExclusiveLimitAlarmType_LowLowState_Number = 10050,
	NonExclusiveLimitAlarmType_LowLowState_EffectiveDisplayName = 10051,
	NonExclusiveLimitAlarmType_LowLowState_TransitionTime = 10052,
	NonExclusiveLimitAlarmType_LowLowState_EffectiveTransitionTime = 10053,
	NonExclusiveLimitAlarmType_LowLowState_TrueState = 10054,
	NonExclusiveLimitAlarmType_LowLowState_FalseState = 10055,
	NonExclusiveLimitAlarmType_HighHighLimit = 10056,
	NonExclusiveLimitAlarmType_HighLimit = 10057,
	NonExclusiveLimitAlarmType_LowLimit = 10058,
	NonExclusiveLimitAlarmType_LowLowLimit = 10059,
	NonExclusiveLevelAlarmType = 10060,
	NonExclusiveLevelAlarmType_EventId = 10061,
	NonExclusiveLevelAlarmType_EventType = 10062,
	NonExclusiveLevelAlarmType_SourceNode = 10063,
	NonExclusiveLevelAlarmType_SourceName = 10064,
	NonExclusiveLevelAlarmType_Time = 10065,
	NonExclusiveLevelAlarmType_ReceiveTime = 10066,
	NonExclusiveLevelAlarmType_LocalTime = 10067,
	NonExclusiveLevelAlarmType_Message = 10068,
	NonExclusiveLevelAlarmType_Severity = 10069,
	NonExclusiveLevelAlarmType_ConditionName = 10070,
	NonExclusiveLevelAlarmType_BranchId = 10071,
	NonExclusiveLevelAlarmType_Retain = 10072,
	NonExclusiveLevelAlarmType_EnabledState = 10073,
	NonExclusiveLevelAlarmType_EnabledState_Id = 10074,
	NonExclusiveLevelAlarmType_EnabledState_Name = 10075,
	NonExclusiveLevelAlarmType_EnabledState_Number = 10076,
	NonExclusiveLevelAlarmType_EnabledState_EffectiveDisplayName = 10077,
	NonExclusiveLevelAlarmType_EnabledState_TransitionTime = 10078,
	NonExclusiveLevelAlarmType_EnabledState_EffectiveTransitionTime = 10079,
	NonExclusiveLevelAlarmType_EnabledState_TrueState = 10080,
	NonExclusiveLevelAlarmType_EnabledState_FalseState = 10081,
	NonExclusiveLevelAlarmType_Quality = 10082,
	NonExclusiveLevelAlarmType_Quality_SourceTimestamp = 10083,
	NonExclusiveLevelAlarmType_LastSeverity = 10084,
	NonExclusiveLevelAlarmType_LastSeverity_SourceTimestamp = 10085,
	NonExclusiveLevelAlarmType_Comment = 10086,
	NonExclusiveLevelAlarmType_Comment_SourceTimestamp = 10087,
	NonExclusiveLevelAlarmType_ClientUserId = 10088,
	NonExclusiveLevelAlarmType_Enable = 10089,
	NonExclusiveLevelAlarmType_Disable = 10090,
	NonExclusiveLevelAlarmType_AddComment = 10091,
	NonExclusiveLevelAlarmType_AddComment_InputArguments = 10092,
	NonExclusiveLevelAlarmType_ConditionRefresh = 10093,
	NonExclusiveLevelAlarmType_ConditionRefresh_InputArguments = 10094,
	NonExclusiveLevelAlarmType_AckedState = 10095,
	NonExclusiveLevelAlarmType_AckedState_Id = 10096,
	NonExclusiveLevelAlarmType_AckedState_Name = 10097,
	NonExclusiveLevelAlarmType_AckedState_Number = 10098,
	NonExclusiveLevelAlarmType_AckedState_EffectiveDisplayName = 10099,
	NonExclusiveLevelAlarmType_AckedState_TransitionTime = 10100,
	NonExclusiveLevelAlarmType_AckedState_EffectiveTransitionTime = 10101,
	NonExclusiveLevelAlarmType_AckedState_TrueState = 10102,
	NonExclusiveLevelAlarmType_AckedState_FalseState = 10103,
	NonExclusiveLevelAlarmType_ConfirmedState = 10104,
	NonExclusiveLevelAlarmType_ConfirmedState_Id = 10105,
	NonExclusiveLevelAlarmType_ConfirmedState_Name = 10106,
	NonExclusiveLevelAlarmType_ConfirmedState_Number = 10107,
	NonExclusiveLevelAlarmType_ConfirmedState_EffectiveDisplayName = 10108,
	NonExclusiveLevelAlarmType_ConfirmedState_TransitionTime = 10109,
	NonExclusiveLevelAlarmType_ConfirmedState_EffectiveTransitionTime = 10110,
	NonExclusiveLevelAlarmType_ConfirmedState_TrueState = 10111,
	NonExclusiveLevelAlarmType_ConfirmedState_FalseState = 10112,
	NonExclusiveLevelAlarmType_Acknowledge = 10113,
	NonExclusiveLevelAlarmType_Acknowledge_InputArguments = 10114,
	NonExclusiveLevelAlarmType_Confirm = 10115,
	NonExclusiveLevelAlarmType_Confirm_InputArguments = 10116,
	NonExclusiveLevelAlarmType_ActiveState = 10117,
	NonExclusiveLevelAlarmType_ActiveState_Id = 10118,
	NonExclusiveLevelAlarmType_ActiveState_Name = 10119,
	NonExclusiveLevelAlarmType_ActiveState_Number = 10120,
	NonExclusiveLevelAlarmType_ActiveState_EffectiveDisplayName = 10121,
	NonExclusiveLevelAlarmType_ActiveState_TransitionTime = 10122,
	NonExclusiveLevelAlarmType_ActiveState_EffectiveTransitionTime = 10123,
	NonExclusiveLevelAlarmType_ActiveState_TrueState = 10124,
	NonExclusiveLevelAlarmType_ActiveState_FalseState = 10125,
	NonExclusiveLevelAlarmType_SuppressedState = 10126,
	NonExclusiveLevelAlarmType_SuppressedState_Id = 10127,
	NonExclusiveLevelAlarmType_SuppressedState_Name = 10128,
	NonExclusiveLevelAlarmType_SuppressedState_Number = 10129,
	NonExclusiveLevelAlarmType_SuppressedState_EffectiveDisplayName = 10130,
	NonExclusiveLevelAlarmType_SuppressedState_TransitionTime = 10131,
	NonExclusiveLevelAlarmType_SuppressedState_EffectiveTransitionTime = 10132,
	NonExclusiveLevelAlarmType_SuppressedState_TrueState = 10133,
	NonExclusiveLevelAlarmType_SuppressedState_FalseState = 10134,
	NonExclusiveLevelAlarmType_ShelvingState = 10135,
	NonExclusiveLevelAlarmType_ShelvingState_CurrentState = 10136,
	NonExclusiveLevelAlarmType_ShelvingState_CurrentState_Id = 10137,
	NonExclusiveLevelAlarmType_ShelvingState_CurrentState_Name = 10138,
	NonExclusiveLevelAlarmType_ShelvingState_CurrentState_Number = 10139,
	NonExclusiveLevelAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 10140,
	NonExclusiveLevelAlarmType_ShelvingState_LastTransition = 10141,
	NonExclusiveLevelAlarmType_ShelvingState_LastTransition_Id = 10142,
	NonExclusiveLevelAlarmType_ShelvingState_LastTransition_Name = 10143,
	NonExclusiveLevelAlarmType_ShelvingState_LastTransition_Number = 10144,
	NonExclusiveLevelAlarmType_ShelvingState_LastTransition_TransitionTime = 10145,
	NonExclusiveLevelAlarmType_ShelvingState_UnshelveTime = 10146,
	NonExclusiveLevelAlarmType_ShelvingState_Unshelve = 10168,
	NonExclusiveLevelAlarmType_ShelvingState_OneShotShelve = 10169,
	NonExclusiveLevelAlarmType_ShelvingState_TimedShelve = 10170,
	NonExclusiveLevelAlarmType_ShelvingState_TimedShelve_InputArguments = 10171,
	NonExclusiveLevelAlarmType_SuppressedOrShelved = 10172,
	NonExclusiveLevelAlarmType_MaxTimeShelved = 10173,
	NonExclusiveLevelAlarmType_HighHighState = 10174,
	NonExclusiveLevelAlarmType_HighHighState_Id = 10175,
	NonExclusiveLevelAlarmType_HighHighState_Name = 10176,
	NonExclusiveLevelAlarmType_HighHighState_Number = 10177,
	NonExclusiveLevelAlarmType_HighHighState_EffectiveDisplayName = 10178,
	NonExclusiveLevelAlarmType_HighHighState_TransitionTime = 10179,
	NonExclusiveLevelAlarmType_HighHighState_EffectiveTransitionTime = 10180,
	NonExclusiveLevelAlarmType_HighHighState_TrueState = 10181,
	NonExclusiveLevelAlarmType_HighHighState_FalseState = 10182,
	NonExclusiveLevelAlarmType_HighState = 10183,
	NonExclusiveLevelAlarmType_HighState_Id = 10184,
	NonExclusiveLevelAlarmType_HighState_Name = 10185,
	NonExclusiveLevelAlarmType_HighState_Number = 10186,
	NonExclusiveLevelAlarmType_HighState_EffectiveDisplayName = 10187,
	NonExclusiveLevelAlarmType_HighState_TransitionTime = 10188,
	NonExclusiveLevelAlarmType_HighState_EffectiveTransitionTime = 10189,
	NonExclusiveLevelAlarmType_HighState_TrueState = 10190,
	NonExclusiveLevelAlarmType_HighState_FalseState = 10191,
	NonExclusiveLevelAlarmType_LowState = 10192,
	NonExclusiveLevelAlarmType_LowState_Id = 10193,
	NonExclusiveLevelAlarmType_LowState_Name = 10194,
	NonExclusiveLevelAlarmType_LowState_Number = 10195,
	NonExclusiveLevelAlarmType_LowState_EffectiveDisplayName = 10196,
	NonExclusiveLevelAlarmType_LowState_TransitionTime = 10197,
	NonExclusiveLevelAlarmType_LowState_EffectiveTransitionTime = 10198,
	NonExclusiveLevelAlarmType_LowState_TrueState = 10199,
	NonExclusiveLevelAlarmType_LowState_FalseState = 10200,
	NonExclusiveLevelAlarmType_LowLowState = 10201,
	NonExclusiveLevelAlarmType_LowLowState_Id = 10202,
	NonExclusiveLevelAlarmType_LowLowState_Name = 10203,
	NonExclusiveLevelAlarmType_LowLowState_Number = 10204,
	NonExclusiveLevelAlarmType_LowLowState_EffectiveDisplayName = 10205,
	NonExclusiveLevelAlarmType_LowLowState_TransitionTime = 10206,
	NonExclusiveLevelAlarmType_LowLowState_EffectiveTransitionTime = 10207,
	NonExclusiveLevelAlarmType_LowLowState_TrueState = 10208,
	NonExclusiveLevelAlarmType_LowLowState_FalseState = 10209,
	NonExclusiveLevelAlarmType_HighHighLimit = 10210,
	NonExclusiveLevelAlarmType_HighLimit = 10211,
	NonExclusiveLevelAlarmType_LowLimit = 10212,
	NonExclusiveLevelAlarmType_LowLowLimit = 10213,
	NonExclusiveRateOfChangeAlarmType = 10214,
	NonExclusiveRateOfChangeAlarmType_EventId = 10215,
	NonExclusiveRateOfChangeAlarmType_EventType = 10216,
	NonExclusiveRateOfChangeAlarmType_SourceNode = 10217,
	NonExclusiveRateOfChangeAlarmType_SourceName = 10218,
	NonExclusiveRateOfChangeAlarmType_Time = 10219,
	NonExclusiveRateOfChangeAlarmType_ReceiveTime = 10220,
	NonExclusiveRateOfChangeAlarmType_LocalTime = 10221,
	NonExclusiveRateOfChangeAlarmType_Message = 10222,
	NonExclusiveRateOfChangeAlarmType_Severity = 10223,
	NonExclusiveRateOfChangeAlarmType_ConditionName = 10224,
	NonExclusiveRateOfChangeAlarmType_BranchId = 10225,
	NonExclusiveRateOfChangeAlarmType_Retain = 10226,
	NonExclusiveRateOfChangeAlarmType_EnabledState = 10227,
	NonExclusiveRateOfChangeAlarmType_EnabledState_Id = 10228,
	NonExclusiveRateOfChangeAlarmType_EnabledState_Name = 10229,
	NonExclusiveRateOfChangeAlarmType_EnabledState_Number = 10230,
	NonExclusiveRateOfChangeAlarmType_EnabledState_EffectiveDisplayName = 10231,
	NonExclusiveRateOfChangeAlarmType_EnabledState_TransitionTime = 10232,
	NonExclusiveRateOfChangeAlarmType_EnabledState_EffectiveTransitionTime = 10233,
	NonExclusiveRateOfChangeAlarmType_EnabledState_TrueState = 10234,
	NonExclusiveRateOfChangeAlarmType_EnabledState_FalseState = 10235,
	NonExclusiveRateOfChangeAlarmType_Quality = 10236,
	NonExclusiveRateOfChangeAlarmType_Quality_SourceTimestamp = 10237,
	NonExclusiveRateOfChangeAlarmType_LastSeverity = 10238,
	NonExclusiveRateOfChangeAlarmType_LastSeverity_SourceTimestamp = 10239,
	NonExclusiveRateOfChangeAlarmType_Comment = 10240,
	NonExclusiveRateOfChangeAlarmType_Comment_SourceTimestamp = 10241,
	NonExclusiveRateOfChangeAlarmType_ClientUserId = 10242,
	NonExclusiveRateOfChangeAlarmType_Enable = 10243,
	NonExclusiveRateOfChangeAlarmType_Disable = 10244,
	NonExclusiveRateOfChangeAlarmType_AddComment = 10245,
	NonExclusiveRateOfChangeAlarmType_AddComment_InputArguments = 10246,
	NonExclusiveRateOfChangeAlarmType_ConditionRefresh = 10247,
	NonExclusiveRateOfChangeAlarmType_ConditionRefresh_InputArguments = 10248,
	NonExclusiveRateOfChangeAlarmType_AckedState = 10249,
	NonExclusiveRateOfChangeAlarmType_AckedState_Id = 10250,
	NonExclusiveRateOfChangeAlarmType_AckedState_Name = 10251,
	NonExclusiveRateOfChangeAlarmType_AckedState_Number = 10252,
	NonExclusiveRateOfChangeAlarmType_AckedState_EffectiveDisplayName = 10253,
	NonExclusiveRateOfChangeAlarmType_AckedState_TransitionTime = 10254,
	NonExclusiveRateOfChangeAlarmType_AckedState_EffectiveTransitionTime = 10255,
	NonExclusiveRateOfChangeAlarmType_AckedState_TrueState = 10256,
	NonExclusiveRateOfChangeAlarmType_AckedState_FalseState = 10257,
	NonExclusiveRateOfChangeAlarmType_ConfirmedState = 10258,
	NonExclusiveRateOfChangeAlarmType_ConfirmedState_Id = 10259,
	NonExclusiveRateOfChangeAlarmType_ConfirmedState_Name = 10260,
	NonExclusiveRateOfChangeAlarmType_ConfirmedState_Number = 10261,
	NonExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveDisplayName = 10262,
	NonExclusiveRateOfChangeAlarmType_ConfirmedState_TransitionTime = 10263,
	NonExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveTransitionTime = 10264,
	NonExclusiveRateOfChangeAlarmType_ConfirmedState_TrueState = 10265,
	NonExclusiveRateOfChangeAlarmType_ConfirmedState_FalseState = 10266,
	NonExclusiveRateOfChangeAlarmType_Acknowledge = 10267,
	NonExclusiveRateOfChangeAlarmType_Acknowledge_InputArguments = 10268,
	NonExclusiveRateOfChangeAlarmType_Confirm = 10269,
	NonExclusiveRateOfChangeAlarmType_Confirm_InputArguments = 10270,
	NonExclusiveRateOfChangeAlarmType_ActiveState = 10271,
	NonExclusiveRateOfChangeAlarmType_ActiveState_Id = 10272,
	NonExclusiveRateOfChangeAlarmType_ActiveState_Name = 10273,
	NonExclusiveRateOfChangeAlarmType_ActiveState_Number = 10274,
	NonExclusiveRateOfChangeAlarmType_ActiveState_EffectiveDisplayName = 10275,
	NonExclusiveRateOfChangeAlarmType_ActiveState_TransitionTime = 10276,
	NonExclusiveRateOfChangeAlarmType_ActiveState_EffectiveTransitionTime = 10277,
	NonExclusiveRateOfChangeAlarmType_ActiveState_TrueState = 10278,
	NonExclusiveRateOfChangeAlarmType_ActiveState_FalseState = 10279,
	NonExclusiveRateOfChangeAlarmType_SuppressedState = 10280,
	NonExclusiveRateOfChangeAlarmType_SuppressedState_Id = 10281,
	NonExclusiveRateOfChangeAlarmType_SuppressedState_Name = 10282,
	NonExclusiveRateOfChangeAlarmType_SuppressedState_Number = 10283,
	NonExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveDisplayName = 10284,
	NonExclusiveRateOfChangeAlarmType_SuppressedState_TransitionTime = 10285,
	NonExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveTransitionTime = 10286,
	NonExclusiveRateOfChangeAlarmType_SuppressedState_TrueState = 10287,
	NonExclusiveRateOfChangeAlarmType_SuppressedState_FalseState = 10288,
	NonExclusiveRateOfChangeAlarmType_ShelvingState = 10289,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState = 10290,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Id = 10291,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Name = 10292,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Number = 10293,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 10294,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition = 10295,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Id = 10296,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Name = 10297,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Number = 10298,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_TransitionTime = 10299,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_UnshelveTime = 10300,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_Unshelve = 10322,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_OneShotShelve = 10323,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve = 10324,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve_InputArguments = 10325,
	NonExclusiveRateOfChangeAlarmType_SuppressedOrShelved = 10326,
	NonExclusiveRateOfChangeAlarmType_MaxTimeShelved = 10327,
	NonExclusiveRateOfChangeAlarmType_HighHighState = 10328,
	NonExclusiveRateOfChangeAlarmType_HighHighState_Id = 10329,
	NonExclusiveRateOfChangeAlarmType_HighHighState_Name = 10330,
	NonExclusiveRateOfChangeAlarmType_HighHighState_Number = 10331,
	NonExclusiveRateOfChangeAlarmType_HighHighState_EffectiveDisplayName = 10332,
	NonExclusiveRateOfChangeAlarmType_HighHighState_TransitionTime = 10333,
	NonExclusiveRateOfChangeAlarmType_HighHighState_EffectiveTransitionTime = 10334,
	NonExclusiveRateOfChangeAlarmType_HighHighState_TrueState = 10335,
	NonExclusiveRateOfChangeAlarmType_HighHighState_FalseState = 10336,
	NonExclusiveRateOfChangeAlarmType_HighState = 10337,
	NonExclusiveRateOfChangeAlarmType_HighState_Id = 10338,
	NonExclusiveRateOfChangeAlarmType_HighState_Name = 10339,
	NonExclusiveRateOfChangeAlarmType_HighState_Number = 10340,
	NonExclusiveRateOfChangeAlarmType_HighState_EffectiveDisplayName = 10341,
	NonExclusiveRateOfChangeAlarmType_HighState_TransitionTime = 10342,
	NonExclusiveRateOfChangeAlarmType_HighState_EffectiveTransitionTime = 10343,
	NonExclusiveRateOfChangeAlarmType_HighState_TrueState = 10344,
	NonExclusiveRateOfChangeAlarmType_HighState_FalseState = 10345,
	NonExclusiveRateOfChangeAlarmType_LowState = 10346,
	NonExclusiveRateOfChangeAlarmType_LowState_Id = 10347,
	NonExclusiveRateOfChangeAlarmType_LowState_Name = 10348,
	NonExclusiveRateOfChangeAlarmType_LowState_Number = 10349,
	NonExclusiveRateOfChangeAlarmType_LowState_EffectiveDisplayName = 10350,
	NonExclusiveRateOfChangeAlarmType_LowState_TransitionTime = 10351,
	NonExclusiveRateOfChangeAlarmType_LowState_EffectiveTransitionTime = 10352,
	NonExclusiveRateOfChangeAlarmType_LowState_TrueState = 10353,
	NonExclusiveRateOfChangeAlarmType_LowState_FalseState = 10354,
	NonExclusiveRateOfChangeAlarmType_LowLowState = 10355,
	NonExclusiveRateOfChangeAlarmType_LowLowState_Id = 10356,
	NonExclusiveRateOfChangeAlarmType_LowLowState_Name = 10357,
	NonExclusiveRateOfChangeAlarmType_LowLowState_Number = 10358,
	NonExclusiveRateOfChangeAlarmType_LowLowState_EffectiveDisplayName = 10359,
	NonExclusiveRateOfChangeAlarmType_LowLowState_TransitionTime = 10360,
	NonExclusiveRateOfChangeAlarmType_LowLowState_EffectiveTransitionTime = 10361,
	NonExclusiveRateOfChangeAlarmType_LowLowState_TrueState = 10362,
	NonExclusiveRateOfChangeAlarmType_LowLowState_FalseState = 10363,
	NonExclusiveRateOfChangeAlarmType_HighHighLimit = 10364,
	NonExclusiveRateOfChangeAlarmType_HighLimit = 10365,
	NonExclusiveRateOfChangeAlarmType_LowLimit = 10366,
	NonExclusiveRateOfChangeAlarmType_LowLowLimit = 10367,
	NonExclusiveDeviationAlarmType = 10368,
	NonExclusiveDeviationAlarmType_EventId = 10369,
	NonExclusiveDeviationAlarmType_EventType = 10370,
	NonExclusiveDeviationAlarmType_SourceNode = 10371,
	NonExclusiveDeviationAlarmType_SourceName = 10372,
	NonExclusiveDeviationAlarmType_Time = 10373,
	NonExclusiveDeviationAlarmType_ReceiveTime = 10374,
	NonExclusiveDeviationAlarmType_LocalTime = 10375,
	NonExclusiveDeviationAlarmType_Message = 10376,
	NonExclusiveDeviationAlarmType_Severity = 10377,
	NonExclusiveDeviationAlarmType_ConditionName = 10378,
	NonExclusiveDeviationAlarmType_BranchId = 10379,
	NonExclusiveDeviationAlarmType_Retain = 10380,
	NonExclusiveDeviationAlarmType_EnabledState = 10381,
	NonExclusiveDeviationAlarmType_EnabledState_Id = 10382,
	NonExclusiveDeviationAlarmType_EnabledState_Name = 10383,
	NonExclusiveDeviationAlarmType_EnabledState_Number = 10384,
	NonExclusiveDeviationAlarmType_EnabledState_EffectiveDisplayName = 10385,
	NonExclusiveDeviationAlarmType_EnabledState_TransitionTime = 10386,
	NonExclusiveDeviationAlarmType_EnabledState_EffectiveTransitionTime = 10387,
	NonExclusiveDeviationAlarmType_EnabledState_TrueState = 10388,
	NonExclusiveDeviationAlarmType_EnabledState_FalseState = 10389,
	NonExclusiveDeviationAlarmType_Quality = 10390,
	NonExclusiveDeviationAlarmType_Quality_SourceTimestamp = 10391,
	NonExclusiveDeviationAlarmType_LastSeverity = 10392,
	NonExclusiveDeviationAlarmType_LastSeverity_SourceTimestamp = 10393,
	NonExclusiveDeviationAlarmType_Comment = 10394,
	NonExclusiveDeviationAlarmType_Comment_SourceTimestamp = 10395,
	NonExclusiveDeviationAlarmType_ClientUserId = 10396,
	NonExclusiveDeviationAlarmType_Enable = 10397,
	NonExclusiveDeviationAlarmType_Disable = 10398,
	NonExclusiveDeviationAlarmType_AddComment = 10399,
	NonExclusiveDeviationAlarmType_AddComment_InputArguments = 10400,
	NonExclusiveDeviationAlarmType_ConditionRefresh = 10401,
	NonExclusiveDeviationAlarmType_ConditionRefresh_InputArguments = 10402,
	NonExclusiveDeviationAlarmType_AckedState = 10403,
	NonExclusiveDeviationAlarmType_AckedState_Id = 10404,
	NonExclusiveDeviationAlarmType_AckedState_Name = 10405,
	NonExclusiveDeviationAlarmType_AckedState_Number = 10406,
	NonExclusiveDeviationAlarmType_AckedState_EffectiveDisplayName = 10407,
	NonExclusiveDeviationAlarmType_AckedState_TransitionTime = 10408,
	NonExclusiveDeviationAlarmType_AckedState_EffectiveTransitionTime = 10409,
	NonExclusiveDeviationAlarmType_AckedState_TrueState = 10410,
	NonExclusiveDeviationAlarmType_AckedState_FalseState = 10411,
	NonExclusiveDeviationAlarmType_ConfirmedState = 10412,
	NonExclusiveDeviationAlarmType_ConfirmedState_Id = 10413,
	NonExclusiveDeviationAlarmType_ConfirmedState_Name = 10414,
	NonExclusiveDeviationAlarmType_ConfirmedState_Number = 10415,
	NonExclusiveDeviationAlarmType_ConfirmedState_EffectiveDisplayName = 10416,
	NonExclusiveDeviationAlarmType_ConfirmedState_TransitionTime = 10417,
	NonExclusiveDeviationAlarmType_ConfirmedState_EffectiveTransitionTime = 10418,
	NonExclusiveDeviationAlarmType_ConfirmedState_TrueState = 10419,
	NonExclusiveDeviationAlarmType_ConfirmedState_FalseState = 10420,
	NonExclusiveDeviationAlarmType_Acknowledge = 10421,
	NonExclusiveDeviationAlarmType_Acknowledge_InputArguments = 10422,
	NonExclusiveDeviationAlarmType_Confirm = 10423,
	NonExclusiveDeviationAlarmType_Confirm_InputArguments = 10424,
	NonExclusiveDeviationAlarmType_ActiveState = 10425,
	NonExclusiveDeviationAlarmType_ActiveState_Id = 10426,
	NonExclusiveDeviationAlarmType_ActiveState_Name = 10427,
	NonExclusiveDeviationAlarmType_ActiveState_Number = 10428,
	NonExclusiveDeviationAlarmType_ActiveState_EffectiveDisplayName = 10429,
	NonExclusiveDeviationAlarmType_ActiveState_TransitionTime = 10430,
	NonExclusiveDeviationAlarmType_ActiveState_EffectiveTransitionTime = 10431,
	NonExclusiveDeviationAlarmType_ActiveState_TrueState = 10432,
	NonExclusiveDeviationAlarmType_ActiveState_FalseState = 10433,
	NonExclusiveDeviationAlarmType_SuppressedState = 10434,
	NonExclusiveDeviationAlarmType_SuppressedState_Id = 10435,
	NonExclusiveDeviationAlarmType_SuppressedState_Name = 10436,
	NonExclusiveDeviationAlarmType_SuppressedState_Number = 10437,
	NonExclusiveDeviationAlarmType_SuppressedState_EffectiveDisplayName = 10438,
	NonExclusiveDeviationAlarmType_SuppressedState_TransitionTime = 10439,
	NonExclusiveDeviationAlarmType_SuppressedState_EffectiveTransitionTime = 10440,
	NonExclusiveDeviationAlarmType_SuppressedState_TrueState = 10441,
	NonExclusiveDeviationAlarmType_SuppressedState_FalseState = 10442,
	NonExclusiveDeviationAlarmType_ShelvingState = 10443,
	NonExclusiveDeviationAlarmType_ShelvingState_CurrentState = 10444,
	NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_Id = 10445,
	NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_Name = 10446,
	NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_Number = 10447,
	NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 10448,
	NonExclusiveDeviationAlarmType_ShelvingState_LastTransition = 10449,
	NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_Id = 10450,
	NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_Name = 10451,
	NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_Number = 10452,
	NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_TransitionTime = 10453,
	NonExclusiveDeviationAlarmType_ShelvingState_UnshelveTime = 10454,
	NonExclusiveDeviationAlarmType_ShelvingState_Unshelve = 10476,
	NonExclusiveDeviationAlarmType_ShelvingState_OneShotShelve = 10477,
	NonExclusiveDeviationAlarmType_ShelvingState_TimedShelve = 10478,
	NonExclusiveDeviationAlarmType_ShelvingState_TimedShelve_InputArguments = 10479,
	NonExclusiveDeviationAlarmType_SuppressedOrShelved = 10480,
	NonExclusiveDeviationAlarmType_MaxTimeShelved = 10481,
	NonExclusiveDeviationAlarmType_HighHighState = 10482,
	NonExclusiveDeviationAlarmType_HighHighState_Id = 10483,
	NonExclusiveDeviationAlarmType_HighHighState_Name = 10484,
	NonExclusiveDeviationAlarmType_HighHighState_Number = 10485,
	NonExclusiveDeviationAlarmType_HighHighState_EffectiveDisplayName = 10486,
	NonExclusiveDeviationAlarmType_HighHighState_TransitionTime = 10487,
	NonExclusiveDeviationAlarmType_HighHighState_EffectiveTransitionTime = 10488,
	NonExclusiveDeviationAlarmType_HighHighState_TrueState = 10489,
	NonExclusiveDeviationAlarmType_HighHighState_FalseState = 10490,
	NonExclusiveDeviationAlarmType_HighState = 10491,
	NonExclusiveDeviationAlarmType_HighState_Id = 10492,
	NonExclusiveDeviationAlarmType_HighState_Name = 10493,
	NonExclusiveDeviationAlarmType_HighState_Number = 10494,
	NonExclusiveDeviationAlarmType_HighState_EffectiveDisplayName = 10495,
	NonExclusiveDeviationAlarmType_HighState_TransitionTime = 10496,
	NonExclusiveDeviationAlarmType_HighState_EffectiveTransitionTime = 10497,
	NonExclusiveDeviationAlarmType_HighState_TrueState = 10498,
	NonExclusiveDeviationAlarmType_HighState_FalseState = 10499,
	NonExclusiveDeviationAlarmType_LowState = 10500,
	NonExclusiveDeviationAlarmType_LowState_Id = 10501,
	NonExclusiveDeviationAlarmType_LowState_Name = 10502,
	NonExclusiveDeviationAlarmType_LowState_Number = 10503,
	NonExclusiveDeviationAlarmType_LowState_EffectiveDisplayName = 10504,
	NonExclusiveDeviationAlarmType_LowState_TransitionTime = 10505,
	NonExclusiveDeviationAlarmType_LowState_EffectiveTransitionTime = 10506,
	NonExclusiveDeviationAlarmType_LowState_TrueState = 10507,
	NonExclusiveDeviationAlarmType_LowState_FalseState = 10508,
	NonExclusiveDeviationAlarmType_LowLowState = 10509,
	NonExclusiveDeviationAlarmType_LowLowState_Id = 10510,
	NonExclusiveDeviationAlarmType_LowLowState_Name = 10511,
	NonExclusiveDeviationAlarmType_LowLowState_Number = 10512,
	NonExclusiveDeviationAlarmType_LowLowState_EffectiveDisplayName = 10513,
	NonExclusiveDeviationAlarmType_LowLowState_TransitionTime = 10514,
	NonExclusiveDeviationAlarmType_LowLowState_EffectiveTransitionTime = 10515,
	NonExclusiveDeviationAlarmType_LowLowState_TrueState = 10516,
	NonExclusiveDeviationAlarmType_LowLowState_FalseState = 10517,
	NonExclusiveDeviationAlarmType_HighHighLimit = 10518,
	NonExclusiveDeviationAlarmType_HighLimit = 10519,
	NonExclusiveDeviationAlarmType_LowLimit = 10520,
	NonExclusiveDeviationAlarmType_LowLowLimit = 10521,
	NonExclusiveDeviationAlarmType_SetpointNode = 10522,
	DiscreteAlarmType = 10523,
	DiscreteAlarmType_EventId = 10524,
	DiscreteAlarmType_EventType = 10525,
	DiscreteAlarmType_SourceNode = 10526,
	DiscreteAlarmType_SourceName = 10527,
	DiscreteAlarmType_Time = 10528,
	DiscreteAlarmType_ReceiveTime = 10529,
	DiscreteAlarmType_LocalTime = 10530,
	DiscreteAlarmType_Message = 10531,
	DiscreteAlarmType_Severity = 10532,
	DiscreteAlarmType_ConditionName = 10533,
	DiscreteAlarmType_BranchId = 10534,
	DiscreteAlarmType_Retain = 10535,
	DiscreteAlarmType_EnabledState = 10536,
	DiscreteAlarmType_EnabledState_Id = 10537,
	DiscreteAlarmType_EnabledState_Name = 10538,
	DiscreteAlarmType_EnabledState_Number = 10539,
	DiscreteAlarmType_EnabledState_EffectiveDisplayName = 10540,
	DiscreteAlarmType_EnabledState_TransitionTime = 10541,
	DiscreteAlarmType_EnabledState_EffectiveTransitionTime = 10542,
	DiscreteAlarmType_EnabledState_TrueState = 10543,
	DiscreteAlarmType_EnabledState_FalseState = 10544,
	DiscreteAlarmType_Quality = 10545,
	DiscreteAlarmType_Quality_SourceTimestamp = 10546,
	DiscreteAlarmType_LastSeverity = 10547,
	DiscreteAlarmType_LastSeverity_SourceTimestamp = 10548,
	DiscreteAlarmType_Comment = 10549,
	DiscreteAlarmType_Comment_SourceTimestamp = 10550,
	DiscreteAlarmType_ClientUserId = 10551,
	DiscreteAlarmType_Enable = 10552,
	DiscreteAlarmType_Disable = 10553,
	DiscreteAlarmType_AddComment = 10554,
	DiscreteAlarmType_AddComment_InputArguments = 10555,
	DiscreteAlarmType_ConditionRefresh = 10556,
	DiscreteAlarmType_ConditionRefresh_InputArguments = 10557,
	DiscreteAlarmType_AckedState = 10558,
	DiscreteAlarmType_AckedState_Id = 10559,
	DiscreteAlarmType_AckedState_Name = 10560,
	DiscreteAlarmType_AckedState_Number = 10561,
	DiscreteAlarmType_AckedState_EffectiveDisplayName = 10562,
	DiscreteAlarmType_AckedState_TransitionTime = 10563,
	DiscreteAlarmType_AckedState_EffectiveTransitionTime = 10564,
	DiscreteAlarmType_AckedState_TrueState = 10565,
	DiscreteAlarmType_AckedState_FalseState = 10566,
	DiscreteAlarmType_ConfirmedState = 10567,
	DiscreteAlarmType_ConfirmedState_Id = 10568,
	DiscreteAlarmType_ConfirmedState_Name = 10569,
	DiscreteAlarmType_ConfirmedState_Number = 10570,
	DiscreteAlarmType_ConfirmedState_EffectiveDisplayName = 10571,
	DiscreteAlarmType_ConfirmedState_TransitionTime = 10572,
	DiscreteAlarmType_ConfirmedState_EffectiveTransitionTime = 10573,
	DiscreteAlarmType_ConfirmedState_TrueState = 10574,
	DiscreteAlarmType_ConfirmedState_FalseState = 10575,
	DiscreteAlarmType_Acknowledge = 10576,
	DiscreteAlarmType_Acknowledge_InputArguments = 10577,
	DiscreteAlarmType_Confirm = 10578,
	DiscreteAlarmType_Confirm_InputArguments = 10579,
	DiscreteAlarmType_ActiveState = 10580,
	DiscreteAlarmType_ActiveState_Id = 10581,
	DiscreteAlarmType_ActiveState_Name = 10582,
	DiscreteAlarmType_ActiveState_Number = 10583,
	DiscreteAlarmType_ActiveState_EffectiveDisplayName = 10584,
	DiscreteAlarmType_ActiveState_TransitionTime = 10585,
	DiscreteAlarmType_ActiveState_EffectiveTransitionTime = 10586,
	DiscreteAlarmType_ActiveState_TrueState = 10587,
	DiscreteAlarmType_ActiveState_FalseState = 10588,
	DiscreteAlarmType_SuppressedState = 10589,
	DiscreteAlarmType_SuppressedState_Id = 10590,
	DiscreteAlarmType_SuppressedState_Name = 10591,
	DiscreteAlarmType_SuppressedState_Number = 10592,
	DiscreteAlarmType_SuppressedState_EffectiveDisplayName = 10593,
	DiscreteAlarmType_SuppressedState_TransitionTime = 10594,
	DiscreteAlarmType_SuppressedState_EffectiveTransitionTime = 10595,
	DiscreteAlarmType_SuppressedState_TrueState = 10596,
	DiscreteAlarmType_SuppressedState_FalseState = 10597,
	DiscreteAlarmType_ShelvingState = 10598,
	DiscreteAlarmType_ShelvingState_CurrentState = 10599,
	DiscreteAlarmType_ShelvingState_CurrentState_Id = 10600,
	DiscreteAlarmType_ShelvingState_CurrentState_Name = 10601,
	DiscreteAlarmType_ShelvingState_CurrentState_Number = 10602,
	DiscreteAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 10603,
	DiscreteAlarmType_ShelvingState_LastTransition = 10604,
	DiscreteAlarmType_ShelvingState_LastTransition_Id = 10605,
	DiscreteAlarmType_ShelvingState_LastTransition_Name = 10606,
	DiscreteAlarmType_ShelvingState_LastTransition_Number = 10607,
	DiscreteAlarmType_ShelvingState_LastTransition_TransitionTime = 10608,
	DiscreteAlarmType_ShelvingState_UnshelveTime = 10609,
	DiscreteAlarmType_ShelvingState_Unshelve = 10631,
	DiscreteAlarmType_ShelvingState_OneShotShelve = 10632,
	DiscreteAlarmType_ShelvingState_TimedShelve = 10633,
	DiscreteAlarmType_ShelvingState_TimedShelve_InputArguments = 10634,
	DiscreteAlarmType_SuppressedOrShelved = 10635,
	DiscreteAlarmType_MaxTimeShelved = 10636,
	OffNormalAlarmType = 10637,
	OffNormalAlarmType_EventId = 10638,
	OffNormalAlarmType_EventType = 10639,
	OffNormalAlarmType_SourceNode = 10640,
	OffNormalAlarmType_SourceName = 10641,
	OffNormalAlarmType_Time = 10642,
	OffNormalAlarmType_ReceiveTime = 10643,
	OffNormalAlarmType_LocalTime = 10644,
	OffNormalAlarmType_Message = 10645,
	OffNormalAlarmType_Severity = 10646,
	OffNormalAlarmType_ConditionName = 10647,
	OffNormalAlarmType_BranchId = 10648,
	OffNormalAlarmType_Retain = 10649,
	OffNormalAlarmType_EnabledState = 10650,
	OffNormalAlarmType_EnabledState_Id = 10651,
	OffNormalAlarmType_EnabledState_Name = 10652,
	OffNormalAlarmType_EnabledState_Number = 10653,
	OffNormalAlarmType_EnabledState_EffectiveDisplayName = 10654,
	OffNormalAlarmType_EnabledState_TransitionTime = 10655,
	OffNormalAlarmType_EnabledState_EffectiveTransitionTime = 10656,
	OffNormalAlarmType_EnabledState_TrueState = 10657,
	OffNormalAlarmType_EnabledState_FalseState = 10658,
	OffNormalAlarmType_Quality = 10659,
	OffNormalAlarmType_Quality_SourceTimestamp = 10660,
	OffNormalAlarmType_LastSeverity = 10661,
	OffNormalAlarmType_LastSeverity_SourceTimestamp = 10662,
	OffNormalAlarmType_Comment = 10663,
	OffNormalAlarmType_Comment_SourceTimestamp = 10664,
	OffNormalAlarmType_ClientUserId = 10665,
	OffNormalAlarmType_Enable = 10666,
	OffNormalAlarmType_Disable = 10667,
	OffNormalAlarmType_AddComment = 10668,
	OffNormalAlarmType_AddComment_InputArguments = 10669,
	OffNormalAlarmType_ConditionRefresh = 10670,
	OffNormalAlarmType_ConditionRefresh_InputArguments = 10671,
	OffNormalAlarmType_AckedState = 10672,
	OffNormalAlarmType_AckedState_Id = 10673,
	OffNormalAlarmType_AckedState_Name = 10674,
	OffNormalAlarmType_AckedState_Number = 10675,
	OffNormalAlarmType_AckedState_EffectiveDisplayName = 10676,
	OffNormalAlarmType_AckedState_TransitionTime = 10677,
	OffNormalAlarmType_AckedState_EffectiveTransitionTime = 10678,
	OffNormalAlarmType_AckedState_TrueState = 10679,
	OffNormalAlarmType_AckedState_FalseState = 10680,
	OffNormalAlarmType_ConfirmedState = 10681,
	OffNormalAlarmType_ConfirmedState_Id = 10682,
	OffNormalAlarmType_ConfirmedState_Name = 10683,
	OffNormalAlarmType_ConfirmedState_Number = 10684,
	OffNormalAlarmType_ConfirmedState_EffectiveDisplayName = 10685,
	OffNormalAlarmType_ConfirmedState_TransitionTime = 10686,
	OffNormalAlarmType_ConfirmedState_EffectiveTransitionTime = 10687,
	OffNormalAlarmType_ConfirmedState_TrueState = 10688,
	OffNormalAlarmType_ConfirmedState_FalseState = 10689,
	OffNormalAlarmType_Acknowledge = 10690,
	OffNormalAlarmType_Acknowledge_InputArguments = 10691,
	OffNormalAlarmType_Confirm = 10692,
	OffNormalAlarmType_Confirm_InputArguments = 10693,
	OffNormalAlarmType_ActiveState = 10694,
	OffNormalAlarmType_ActiveState_Id = 10695,
	OffNormalAlarmType_ActiveState_Name = 10696,
	OffNormalAlarmType_ActiveState_Number = 10697,
	OffNormalAlarmType_ActiveState_EffectiveDisplayName = 10698,
	OffNormalAlarmType_ActiveState_TransitionTime = 10699,
	OffNormalAlarmType_ActiveState_EffectiveTransitionTime = 10700,
	OffNormalAlarmType_ActiveState_TrueState = 10701,
	OffNormalAlarmType_ActiveState_FalseState = 10702,
	OffNormalAlarmType_SuppressedState = 10703,
	OffNormalAlarmType_SuppressedState_Id = 10704,
	OffNormalAlarmType_SuppressedState_Name = 10705,
	OffNormalAlarmType_SuppressedState_Number = 10706,
	OffNormalAlarmType_SuppressedState_EffectiveDisplayName = 10707,
	OffNormalAlarmType_SuppressedState_TransitionTime = 10708,
	OffNormalAlarmType_SuppressedState_EffectiveTransitionTime = 10709,
	OffNormalAlarmType_SuppressedState_TrueState = 10710,
	OffNormalAlarmType_SuppressedState_FalseState = 10711,
	OffNormalAlarmType_ShelvingState = 10712,
	OffNormalAlarmType_ShelvingState_CurrentState = 10713,
	OffNormalAlarmType_ShelvingState_CurrentState_Id = 10714,
	OffNormalAlarmType_ShelvingState_CurrentState_Name = 10715,
	OffNormalAlarmType_ShelvingState_CurrentState_Number = 10716,
	OffNormalAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 10717,
	OffNormalAlarmType_ShelvingState_LastTransition = 10718,
	OffNormalAlarmType_ShelvingState_LastTransition_Id = 10719,
	OffNormalAlarmType_ShelvingState_LastTransition_Name = 10720,
	OffNormalAlarmType_ShelvingState_LastTransition_Number = 10721,
	OffNormalAlarmType_ShelvingState_LastTransition_TransitionTime = 10722,
	OffNormalAlarmType_ShelvingState_UnshelveTime = 10723,
	OffNormalAlarmType_ShelvingState_Unshelve = 10745,
	OffNormalAlarmType_ShelvingState_OneShotShelve = 10746,
	OffNormalAlarmType_ShelvingState_TimedShelve = 10747,
	OffNormalAlarmType_ShelvingState_TimedShelve_InputArguments = 10748,
	OffNormalAlarmType_SuppressedOrShelved = 10749,
	OffNormalAlarmType_MaxTimeShelved = 10750,
	TripAlarmType = 10751,
	TripAlarmType_EventId = 10752,
	TripAlarmType_EventType = 10753,
	TripAlarmType_SourceNode = 10754,
	TripAlarmType_SourceName = 10755,
	TripAlarmType_Time = 10756,
	TripAlarmType_ReceiveTime = 10757,
	TripAlarmType_LocalTime = 10758,
	TripAlarmType_Message = 10759,
	TripAlarmType_Severity = 10760,
	TripAlarmType_ConditionName = 10761,
	TripAlarmType_BranchId = 10762,
	TripAlarmType_Retain = 10763,
	TripAlarmType_EnabledState = 10764,
	TripAlarmType_EnabledState_Id = 10765,
	TripAlarmType_EnabledState_Name = 10766,
	TripAlarmType_EnabledState_Number = 10767,
	TripAlarmType_EnabledState_EffectiveDisplayName = 10768,
	TripAlarmType_EnabledState_TransitionTime = 10769,
	TripAlarmType_EnabledState_EffectiveTransitionTime = 10770,
	TripAlarmType_EnabledState_TrueState = 10771,
	TripAlarmType_EnabledState_FalseState = 10772,
	TripAlarmType_Quality = 10773,
	TripAlarmType_Quality_SourceTimestamp = 10774,
	TripAlarmType_LastSeverity = 10775,
	TripAlarmType_LastSeverity_SourceTimestamp = 10776,
	TripAlarmType_Comment = 10777,
	TripAlarmType_Comment_SourceTimestamp = 10778,
	TripAlarmType_ClientUserId = 10779,
	TripAlarmType_Enable = 10780,
	TripAlarmType_Disable = 10781,
	TripAlarmType_AddComment = 10782,
	TripAlarmType_AddComment_InputArguments = 10783,
	TripAlarmType_ConditionRefresh = 10784,
	TripAlarmType_ConditionRefresh_InputArguments = 10785,
	TripAlarmType_AckedState = 10786,
	TripAlarmType_AckedState_Id = 10787,
	TripAlarmType_AckedState_Name = 10788,
	TripAlarmType_AckedState_Number = 10789,
	TripAlarmType_AckedState_EffectiveDisplayName = 10790,
	TripAlarmType_AckedState_TransitionTime = 10791,
	TripAlarmType_AckedState_EffectiveTransitionTime = 10792,
	TripAlarmType_AckedState_TrueState = 10793,
	TripAlarmType_AckedState_FalseState = 10794,
	TripAlarmType_ConfirmedState = 10795,
	TripAlarmType_ConfirmedState_Id = 10796,
	TripAlarmType_ConfirmedState_Name = 10797,
	TripAlarmType_ConfirmedState_Number = 10798,
	TripAlarmType_ConfirmedState_EffectiveDisplayName = 10799,
	TripAlarmType_ConfirmedState_TransitionTime = 10800,
	TripAlarmType_ConfirmedState_EffectiveTransitionTime = 10801,
	TripAlarmType_ConfirmedState_TrueState = 10802,
	TripAlarmType_ConfirmedState_FalseState = 10803,
	TripAlarmType_Acknowledge = 10804,
	TripAlarmType_Acknowledge_InputArguments = 10805,
	TripAlarmType_Confirm = 10806,
	TripAlarmType_Confirm_InputArguments = 10807,
	TripAlarmType_ActiveState = 10808,
	TripAlarmType_ActiveState_Id = 10809,
	TripAlarmType_ActiveState_Name = 10810,
	TripAlarmType_ActiveState_Number = 10811,
	TripAlarmType_ActiveState_EffectiveDisplayName = 10812,
	TripAlarmType_ActiveState_TransitionTime = 10813,
	TripAlarmType_ActiveState_EffectiveTransitionTime = 10814,
	TripAlarmType_ActiveState_TrueState = 10815,
	TripAlarmType_ActiveState_FalseState = 10816,
	TripAlarmType_SuppressedState = 10817,
	TripAlarmType_SuppressedState_Id = 10818,
	TripAlarmType_SuppressedState_Name = 10819,
	TripAlarmType_SuppressedState_Number = 10820,
	TripAlarmType_SuppressedState_EffectiveDisplayName = 10821,
	TripAlarmType_SuppressedState_TransitionTime = 10822,
	TripAlarmType_SuppressedState_EffectiveTransitionTime = 10823,
	TripAlarmType_SuppressedState_TrueState = 10824,
	TripAlarmType_SuppressedState_FalseState = 10825,
	TripAlarmType_ShelvingState = 10826,
	TripAlarmType_ShelvingState_CurrentState = 10827,
	TripAlarmType_ShelvingState_CurrentState_Id = 10828,
	TripAlarmType_ShelvingState_CurrentState_Name = 10829,
	TripAlarmType_ShelvingState_CurrentState_Number = 10830,
	TripAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 10831,
	TripAlarmType_ShelvingState_LastTransition = 10832,
	TripAlarmType_ShelvingState_LastTransition_Id = 10833,
	TripAlarmType_ShelvingState_LastTransition_Name = 10834,
	TripAlarmType_ShelvingState_LastTransition_Number = 10835,
	TripAlarmType_ShelvingState_LastTransition_TransitionTime = 10836,
	TripAlarmType_ShelvingState_UnshelveTime = 10837,
	TripAlarmType_ShelvingState_Unshelve = 10859,
	TripAlarmType_ShelvingState_OneShotShelve = 10860,
	TripAlarmType_ShelvingState_TimedShelve = 10861,
	TripAlarmType_ShelvingState_TimedShelve_InputArguments = 10862,
	TripAlarmType_SuppressedOrShelved = 10863,
	TripAlarmType_MaxTimeShelved = 10864,
	AuditConditionShelvingEventType = 11093,
	AuditConditionShelvingEventType_EventId = 11094,
	AuditConditionShelvingEventType_EventType = 11095,
	AuditConditionShelvingEventType_SourceNode = 11096,
	AuditConditionShelvingEventType_SourceName = 11097,
	AuditConditionShelvingEventType_Time = 11098,
	AuditConditionShelvingEventType_ReceiveTime = 11099,
	AuditConditionShelvingEventType_LocalTime = 11100,
	AuditConditionShelvingEventType_Message = 11101,
	AuditConditionShelvingEventType_Severity = 11102,
	AuditConditionShelvingEventType_ActionTimeStamp = 11103,
	AuditConditionShelvingEventType_Status = 11104,
	AuditConditionShelvingEventType_ServerId = 11105,
	AuditConditionShelvingEventType_ClientAuditEntryId = 11106,
	AuditConditionShelvingEventType_ClientUserId = 11107,
	AuditConditionShelvingEventType_MethodId = 11108,
	AuditConditionShelvingEventType_InputArguments = 11109,
	TwoStateVariableType_TrueState = 11110,
	TwoStateVariableType_FalseState = 11111,
	ConditionType_ConditionClassId = 11112,
	ConditionType_ConditionClassName = 11113,
	DialogConditionType_ConditionClassId = 11114,
	DialogConditionType_ConditionClassName = 11115,
	AcknowledgeableConditionType_ConditionClassId = 11116,
	AcknowledgeableConditionType_ConditionClassName = 11117,
	AlarmConditionType_ConditionClassId = 11118,
	AlarmConditionType_ConditionClassName = 11119,
	AlarmConditionType_InputNode = 11120,
	LimitAlarmType_ConditionClassId = 11121,
	LimitAlarmType_ConditionClassName = 11122,
	LimitAlarmType_InputNode = 11123,
	LimitAlarmType_HighHighLimit = 11124,
	LimitAlarmType_HighLimit = 11125,
	LimitAlarmType_LowLimit = 11126,
	LimitAlarmType_LowLowLimit = 11127,
	ExclusiveLimitAlarmType_ConditionClassId = 11128,
	ExclusiveLimitAlarmType_ConditionClassName = 11129,
	ExclusiveLimitAlarmType_InputNode = 11130,
	ExclusiveLevelAlarmType_ConditionClassId = 11131,
	ExclusiveLevelAlarmType_ConditionClassName = 11132,
	ExclusiveLevelAlarmType_InputNode = 11133,
	ExclusiveRateOfChangeAlarmType_ConditionClassId = 11134,
	ExclusiveRateOfChangeAlarmType_ConditionClassName = 11135,
	ExclusiveRateOfChangeAlarmType_InputNode = 11136,
	ExclusiveDeviationAlarmType_ConditionClassId = 11137,
	ExclusiveDeviationAlarmType_ConditionClassName = 11138,
	ExclusiveDeviationAlarmType_InputNode = 11139,
	NonExclusiveLimitAlarmType_ConditionClassId = 11140,
	NonExclusiveLimitAlarmType_ConditionClassName = 11141,
	NonExclusiveLimitAlarmType_InputNode = 11142,
	NonExclusiveLevelAlarmType_ConditionClassId = 11143,
	NonExclusiveLevelAlarmType_ConditionClassName = 11144,
	NonExclusiveLevelAlarmType_InputNode = 11145,
	NonExclusiveRateOfChangeAlarmType_ConditionClassId = 11146,
	NonExclusiveRateOfChangeAlarmType_ConditionClassName = 11147,
	NonExclusiveRateOfChangeAlarmType_InputNode = 11148,
	NonExclusiveDeviationAlarmType_ConditionClassId = 11149,
	NonExclusiveDeviationAlarmType_ConditionClassName = 11150,
	NonExclusiveDeviationAlarmType_InputNode = 11151,
	DiscreteAlarmType_ConditionClassId = 11152,
	DiscreteAlarmType_ConditionClassName = 11153,
	DiscreteAlarmType_InputNode = 11154,
	OffNormalAlarmType_ConditionClassId = 11155,
	OffNormalAlarmType_ConditionClassName = 11156,
	OffNormalAlarmType_InputNode = 11157,
	OffNormalAlarmType_NormalState = 11158,
	TripAlarmType_ConditionClassId = 11159,
	TripAlarmType_ConditionClassName = 11160,
	TripAlarmType_InputNode = 11161,
	TripAlarmType_NormalState = 11162,
	BaseConditionClassType = 11163,
	ProcessConditionClassType = 11164,
	MaintenanceConditionClassType = 11165,
	SystemConditionClassType = 11166,
	HistoricalDataConfigurationType_AggregateConfiguration_TreatUncertainAsBad = 11168,
	HistoricalDataConfigurationType_AggregateConfiguration_PercentDataBad = 11169,
	HistoricalDataConfigurationType_AggregateConfiguration_PercentDataGood = 11170,
	HistoricalDataConfigurationType_AggregateConfiguration_UseSlopedExtrapolation = 11171,
	HistoryServerCapabilitiesType_AggregateFunctions = 11172,
	AggregateConfigurationType = 11187,
	AggregateConfigurationType_TreatUncertainAsBad = 11188,
	AggregateConfigurationType_PercentDataBad = 11189,
	AggregateConfigurationType_PercentDataGood = 11190,
	AggregateConfigurationType_UseSlopedExtrapolation = 11191,
	HistoryServerCapabilities = 11192,
	HistoryServerCapabilities_AccessHistoryDataCapability = 11193,
	HistoryServerCapabilities_InsertDataCapability = 11196,
	HistoryServerCapabilities_ReplaceDataCapability = 11197,
	HistoryServerCapabilities_UpdateDataCapability = 11198,
	HistoryServerCapabilities_DeleteRawCapability = 11199,
	HistoryServerCapabilities_DeleteAtTimeCapability = 11200,
	HistoryServerCapabilities_AggregateFunctions = 11201,
	HAConfiguration = 11202,
	HAConfiguration_AggregateConfiguration = 11203,
	HAConfiguration_AggregateConfiguration_TreatUncertainAsBad = 11204,
	HAConfiguration_AggregateConfiguration_PercentDataBad = 11205,
	HAConfiguration_AggregateConfiguration_PercentDataGood = 11206,
	HAConfiguration_AggregateConfiguration_UseSlopedExtrapolation = 11207,
	HAConfiguration_Stepped = 11208,
	HAConfiguration_Definition = 11209,
	HAConfiguration_MaxTimeInterval = 11210,
	HAConfiguration_MinTimeInterval = 11211,
	HAConfiguration_ExceptionDeviation = 11212,
	HAConfiguration_ExceptionDeviationFormat = 11213,
	Annotations = 11214,
	HistoricalEventFilter = 11215,
	ModificationInfo = 11216,
	HistoryModifiedData = 11217,
	ModificationInfo_Encoding_DefaultXml = 11218,
	HistoryModifiedData_Encoding_DefaultXml = 11219,
	ModificationInfo_Encoding_DefaultBinary = 11226,
	HistoryModifiedData_Encoding_DefaultBinary = 11227,
	HistoryUpdateType = 11234,
	MultiStateValueDiscreteType = 11238,
	MultiStateValueDiscreteType_Definition = 11239,
	MultiStateValueDiscreteType_ValuePrecision = 11240,
	MultiStateValueDiscreteType_EnumValues = 11241,
	HistoryServerCapabilities_AccessHistoryEventsCapability = 11242,
	HistoryServerCapabilitiesType_MaxReturnDataValues = 11268,
	HistoryServerCapabilitiesType_MaxReturnEventValues = 11269,
	HistoryServerCapabilitiesType_InsertAnnotationCapability = 11270,
	HistoryServerCapabilities_MaxReturnDataValues = 11273,
	HistoryServerCapabilities_MaxReturnEventValues = 11274,
	HistoryServerCapabilities_InsertAnnotationCapability = 11275,
	HistoryServerCapabilitiesType_InsertEventCapability = 11278,
	HistoryServerCapabilitiesType_ReplaceEventCapability = 11279,
	HistoryServerCapabilitiesType_UpdateEventCapability = 11280,
	HistoryServerCapabilities_InsertEventCapability = 11281,
	HistoryServerCapabilities_ReplaceEventCapability = 11282,
	HistoryServerCapabilities_UpdateEventCapability = 11283,
	AggregateFunction_TimeAverage2 = 11285,
	AggregateFunction_Minimum2 = 11286,
	AggregateFunction_Maximum2 = 11287,
	AggregateFunction_Range2 = 11288,
	AggregateFunction_WorstQuality2 = 11292,
	PerformUpdateType = 11293,
	UpdateStructureDataDetails = 11295,
	UpdateStructureDataDetails_Encoding_DefaultXml = 11296,
	UpdateStructureDataDetails_Encoding_DefaultBinary = 11300,
	AggregateFunction_Total2 = 11304,
	AggregateFunction_MinimumActualTime2 = 11305,
	AggregateFunction_MaximumActualTime2 = 11306,
	AggregateFunction_DurationInStateZero = 11307,
	AggregateFunction_DurationInStateNonZero = 11308,
	Server_ServerRedundancy_CurrentServerId = 11312,
	Server_ServerRedundancy_RedundantServerArray = 11313,
	Server_ServerRedundancy_ServerUriArray = 11314,
	ShelvedStateMachineType_UnshelvedToTimedShelved_TransitionNumber = 11322,
	ShelvedStateMachineType_UnshelvedToOneShotShelved_TransitionNumber = 11323,
	ShelvedStateMachineType_TimedShelvedToUnshelved_TransitionNumber = 11324,
	ShelvedStateMachineType_TimedShelvedToOneShotShelved_TransitionNumber = 11325,
	ShelvedStateMachineType_OneShotShelvedToUnshelved_TransitionNumber = 11326,
	ShelvedStateMachineType_OneShotShelvedToTimedShelved_TransitionNumber = 11327,
	ExclusiveLimitStateMachineType_LowLowToLow_TransitionNumber = 11340,
	ExclusiveLimitStateMachineType_LowToLowLow_TransitionNumber = 11341,
	ExclusiveLimitStateMachineType_HighHighToHigh_TransitionNumber = 11342,
	ExclusiveLimitStateMachineType_HighToHighHigh_TransitionNumber = 11343,
	AggregateFunction_StandardDeviationSample = 11426,
	AggregateFunction_StandardDeviationPopulation = 11427,
	AggregateFunction_VarianceSample = 11428,
	AggregateFunction_VariancePopulation = 11429,
	EnumStrings = 11432,
	ValueAsText = 11433,
	ProgressEventType = 11436,
	ProgressEventType_EventId = 11437,
	ProgressEventType_EventType = 11438,
	ProgressEventType_SourceNode = 11439,
	ProgressEventType_SourceName = 11440,
	ProgressEventType_Time = 11441,
	ProgressEventType_ReceiveTime = 11442,
	ProgressEventType_LocalTime = 11443,
	ProgressEventType_Message = 11444,
	ProgressEventType_Severity = 11445,
	SystemStatusChangeEventType = 11446,
	SystemStatusChangeEventType_EventId = 11447,
	SystemStatusChangeEventType_EventType = 11448,
	SystemStatusChangeEventType_SourceNode = 11449,
	SystemStatusChangeEventType_SourceName = 11450,
	SystemStatusChangeEventType_Time = 11451,
	SystemStatusChangeEventType_ReceiveTime = 11452,
	SystemStatusChangeEventType_LocalTime = 11453,
	SystemStatusChangeEventType_Message = 11454,
	SystemStatusChangeEventType_Severity = 11455,
	TransitionVariableType_EffectiveTransitionTime = 11456,
	FiniteTransitionVariableType_EffectiveTransitionTime = 11457,
	StateMachineType_LastTransition_EffectiveTransitionTime = 11458,
	FiniteStateMachineType_LastTransition_EffectiveTransitionTime = 11459,
	TransitionEventType_Transition_EffectiveTransitionTime = 11460,
	MultiStateValueDiscreteType_ValueAsText = 11461,
	ProgramTransitionEventType_Transition_EffectiveTransitionTime = 11462,
	ProgramTransitionAuditEventType_Transition_EffectiveTransitionTime = 11463,
	ProgramStateMachineType_LastTransition_EffectiveTransitionTime = 11464,
	ShelvedStateMachineType_LastTransition_EffectiveTransitionTime = 11465,
	AlarmConditionType_ShelvingState_LastTransition_EffectiveTransitionTime = 11466,
	LimitAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11467,
	ExclusiveLimitStateMachineType_LastTransition_EffectiveTransitionTime = 11468,
	ExclusiveLimitAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11469,
	ExclusiveLimitAlarmType_LimitState_LastTransition_EffectiveTransitionTime = 11470,
	ExclusiveLevelAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11471,
	ExclusiveLevelAlarmType_LimitState_LastTransition_EffectiveTransitionTime = 11472,
	ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11473,
	ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_EffectiveTransitionTime = 11474,
	ExclusiveDeviationAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11475,
	ExclusiveDeviationAlarmType_LimitState_LastTransition_EffectiveTransitionTime = 11476,
	NonExclusiveLimitAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11477,
	NonExclusiveLevelAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11478,
	NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11479,
	NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11480,
	DiscreteAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11481,
	OffNormalAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11482,
	TripAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11483,
	AuditActivateSessionEventType_SecureChannelId = 11485,
	OptionSetType = 11487,
	OptionSetType_OptionSetValues = 11488,
	ServerType_GetMonitoredItems = 11489,
	ServerType_GetMonitoredItems_InputArguments = 11490,
	ServerType_GetMonitoredItems_OutputArguments = 11491,
	Server_GetMonitoredItems = 11492,
	Server_GetMonitoredItems_InputArguments = 11493,
	Server_GetMonitoredItems_OutputArguments = 11494,
	GetMonitoredItemsMethodType = 11495,
	GetMonitoredItemsMethodType_InputArguments = 11496,
	GetMonitoredItemsMethodType_OutputArguments = 11497,
	MaxStringLength = 11498,
	HistoricalDataConfigurationType_StartOfArchive = 11499,
	HistoricalDataConfigurationType_StartOfOnlineArchive = 11500,
	HistoryServerCapabilitiesType_DeleteEventCapability = 11501,
	HistoryServerCapabilities_DeleteEventCapability = 11502,
	HAConfiguration_StartOfArchive = 11503,
	HAConfiguration_StartOfOnlineArchive = 11504,
	AggregateFunction_StartBound = 11505,
	AggregateFunction_EndBound = 11506,
	AggregateFunction_DeltaBounds = 11507,
	ModellingRule_OptionalPlaceholder = 11508,
	ModellingRule_OptionalPlaceholder_NamingRule = 11509,
	ModellingRule_MandatoryPlaceholder = 11510,
	ModellingRule_MandatoryPlaceholder_NamingRule = 11511,
	MaxArrayLength = 11512,
	EngineeringUnits = 11513,
	ServerType_ServerCapabilities_MaxArrayLength = 11514,
	ServerType_ServerCapabilities_MaxStringLength = 11515,
	ServerType_ServerCapabilities_OperationLimits = 11516,
	ServerType_ServerCapabilities_OperationLimits_MaxNodesPerRead = 11517,
	ServerType_ServerCapabilities_OperationLimits_MaxNodesPerWrite = 11519,
	ServerType_ServerCapabilities_OperationLimits_MaxNodesPerMethodCall = 11521,
	ServerType_ServerCapabilities_OperationLimits_MaxNodesPerBrowse = 11522,
	ServerType_ServerCapabilities_OperationLimits_MaxNodesPerRegisterNodes = 11523,
	ServerType_ServerCapabilities_OperationLimits_MaxNodesPerTranslateBrowsePathsToNodeIds = 11524,
	ServerType_ServerCapabilities_OperationLimits_MaxNodesPerNodeManagement = 11525,
	ServerType_ServerCapabilities_OperationLimits_MaxMonitoredItemsPerCall = 11526,
	ServerType_Namespaces = 11527,
	ServerType_Namespaces_AddressSpaceFile = 11528,
	ServerType_Namespaces_AddressSpaceFile_Size = 11529,
	ServerType_Namespaces_AddressSpaceFile_Writeable = 11530,
	ServerType_Namespaces_AddressSpaceFile_UserWriteable = 11531,
	ServerType_Namespaces_AddressSpaceFile_OpenCount = 11532,
	ServerType_Namespaces_AddressSpaceFile_Open = 11533,
	ServerType_Namespaces_AddressSpaceFile_Open_InputArguments = 11534,
	ServerType_Namespaces_AddressSpaceFile_Open_OutputArguments = 11535,
	ServerType_Namespaces_AddressSpaceFile_Close = 11536,
	ServerType_Namespaces_AddressSpaceFile_Close_InputArguments = 11537,
	ServerType_Namespaces_AddressSpaceFile_Read = 11538,
	ServerType_Namespaces_AddressSpaceFile_Read_InputArguments = 11539,
	ServerType_Namespaces_AddressSpaceFile_Read_OutputArguments = 11540,
	ServerType_Namespaces_AddressSpaceFile_Write = 11541,
	ServerType_Namespaces_AddressSpaceFile_Write_InputArguments = 11542,
	ServerType_Namespaces_AddressSpaceFile_GetPosition = 11543,
	ServerType_Namespaces_AddressSpaceFile_GetPosition_InputArguments = 11544,
	ServerType_Namespaces_AddressSpaceFile_GetPosition_OutputArguments = 11545,
	ServerType_Namespaces_AddressSpaceFile_SetPosition = 11546,
	ServerType_Namespaces_AddressSpaceFile_SetPosition_InputArguments = 11547,
	ServerType_Namespaces_AddressSpaceFile_ExportNamespace = 11548,
	ServerCapabilitiesType_MaxArrayLength = 11549,
	ServerCapabilitiesType_MaxStringLength = 11550,
	ServerCapabilitiesType_OperationLimits = 11551,
	ServerCapabilitiesType_OperationLimits_MaxNodesPerRead = 11552,
	ServerCapabilitiesType_OperationLimits_MaxNodesPerWrite = 11554,
	ServerCapabilitiesType_OperationLimits_MaxNodesPerMethodCall = 11556,
	ServerCapabilitiesType_OperationLimits_MaxNodesPerBrowse = 11557,
	ServerCapabilitiesType_OperationLimits_MaxNodesPerRegisterNodes = 11558,
	ServerCapabilitiesType_OperationLimits_MaxNodesPerTranslateBrowsePathsToNodeIds = 11559,
	ServerCapabilitiesType_OperationLimits_MaxNodesPerNodeManagement = 11560,
	ServerCapabilitiesType_OperationLimits_MaxMonitoredItemsPerCall = 11561,
	ServerCapabilitiesType_VendorCapability = 11562,
	OperationLimitsType = 11564,
	OperationLimitsType_MaxNodesPerRead = 11565,
	OperationLimitsType_MaxNodesPerWrite = 11567,
	OperationLimitsType_MaxNodesPerMethodCall = 11569,
	OperationLimitsType_MaxNodesPerBrowse = 11570,
	OperationLimitsType_MaxNodesPerRegisterNodes = 11571,
	OperationLimitsType_MaxNodesPerTranslateBrowsePathsToNodeIds = 11572,
	OperationLimitsType_MaxNodesPerNodeManagement = 11573,
	OperationLimitsType_MaxMonitoredItemsPerCall = 11574,
	FileType = 11575,
	FileType_Size = 11576,
	FileType_Writeable = 11577,
	FileType_UserWriteable = 11578,
	FileType_OpenCount = 11579,
	FileType_Open = 11580,
	FileType_Open_InputArguments = 11581,
	FileType_Open_OutputArguments = 11582,
	FileType_Close = 11583,
	FileType_Close_InputArguments = 11584,
	FileType_Read = 11585,
	FileType_Read_InputArguments = 11586,
	FileType_Read_OutputArguments = 11587,
	FileType_Write = 11588,
	FileType_Write_InputArguments = 11589,
	FileType_GetPosition = 11590,
	FileType_GetPosition_InputArguments = 11591,
	FileType_GetPosition_OutputArguments = 11592,
	FileType_SetPosition = 11593,
	FileType_SetPosition_InputArguments = 11594,
	AddressSpaceFileType = 11595,
	AddressSpaceFileType_Size = 11596,
	AddressSpaceFileType_Writeable = 11597,
	AddressSpaceFileType_UserWriteable = 11598,
	AddressSpaceFileType_OpenCount = 11599,
	AddressSpaceFileType_Open = 11600,
	AddressSpaceFileType_Open_InputArguments = 11601,
	AddressSpaceFileType_Open_OutputArguments = 11602,
	AddressSpaceFileType_Close = 11603,
	AddressSpaceFileType_Close_InputArguments = 11604,
	AddressSpaceFileType_Read = 11605,
	AddressSpaceFileType_Read_InputArguments = 11606,
	AddressSpaceFileType_Read_OutputArguments = 11607,
	AddressSpaceFileType_Write = 11608,
	AddressSpaceFileType_Write_InputArguments = 11609,
	AddressSpaceFileType_GetPosition = 11610,
	AddressSpaceFileType_GetPosition_InputArguments = 11611,
	AddressSpaceFileType_GetPosition_OutputArguments = 11612,
	AddressSpaceFileType_SetPosition = 11613,
	AddressSpaceFileType_SetPosition_InputArguments = 11614,
	AddressSpaceFileType_ExportNamespace = 11615,
	NamespaceMetadataType = 11616,
	NamespaceMetadataType_NamespaceUri = 11617,
	NamespaceMetadataType_NamespaceVersion = 11618,
	NamespaceMetadataType_NamespacePublicationDate = 11619,
	NamespaceMetadataType_IsNamespaceSubset = 11620,
	NamespaceMetadataType_StaticNodeIdIdentifierTypes = 11621,
	NamespaceMetadataType_StaticNumericNodeIdRange = 11622,
	NamespaceMetadataType_StaticStringNodeIdPattern = 11623,
	NamespaceMetadataType_NamespaceFile = 11624,
	NamespaceMetadataType_NamespaceFile_Size = 11625,
	NamespaceMetadataType_NamespaceFile_Writeable = 11626,
	NamespaceMetadataType_NamespaceFile_UserWriteable = 11627,
	NamespaceMetadataType_NamespaceFile_OpenCount = 11628,
	NamespaceMetadataType_NamespaceFile_Open = 11629,
	NamespaceMetadataType_NamespaceFile_Open_InputArguments = 11630,
	NamespaceMetadataType_NamespaceFile_Open_OutputArguments = 11631,
	NamespaceMetadataType_NamespaceFile_Close = 11632,
	NamespaceMetadataType_NamespaceFile_Close_InputArguments = 11633,
	NamespaceMetadataType_NamespaceFile_Read = 11634,
	NamespaceMetadataType_NamespaceFile_Read_InputArguments = 11635,
	NamespaceMetadataType_NamespaceFile_Read_OutputArguments = 11636,
	NamespaceMetadataType_NamespaceFile_Write = 11637,
	NamespaceMetadataType_NamespaceFile_Write_InputArguments = 11638,
	NamespaceMetadataType_NamespaceFile_GetPosition = 11639,
	NamespaceMetadataType_NamespaceFile_GetPosition_InputArguments = 11640,
	NamespaceMetadataType_NamespaceFile_GetPosition_OutputArguments = 11641,
	NamespaceMetadataType_NamespaceFile_SetPosition = 11642,
	NamespaceMetadataType_NamespaceFile_SetPosition_InputArguments = 11643,
	NamespaceMetadataType_NamespaceFile_ExportNamespace = 11644,
	NamespacesType = 11645,
	NamespacesType_NamespaceIdentifier = 11646,
	NamespacesType_NamespaceIdentifier_NamespaceUri = 11647,
	NamespacesType_NamespaceIdentifier_NamespaceVersion = 11648,
	NamespacesType_NamespaceIdentifier_NamespacePublicationDate = 11649,
	NamespacesType_NamespaceIdentifier_IsNamespaceSubset = 11650,
	NamespacesType_NamespaceIdentifier_StaticNodeIdIdentifierTypes = 11651,
	NamespacesType_NamespaceIdentifier_StaticNumericNodeIdRange = 11652,
	NamespacesType_NamespaceIdentifier_StaticStringNodeIdPattern = 11653,
	NamespacesType_NamespaceIdentifier_NamespaceFile = 11654,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Size = 11655,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Writeable = 11656,
	NamespacesType_NamespaceIdentifier_NamespaceFile_UserWriteable = 11657,
	NamespacesType_NamespaceIdentifier_NamespaceFile_OpenCount = 11658,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Open = 11659,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Open_InputArguments = 11660,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Open_OutputArguments = 11661,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Close = 11662,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Close_InputArguments = 11663,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Read = 11664,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Read_InputArguments = 11665,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Read_OutputArguments = 11666,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Write = 11667,
	NamespacesType_NamespaceIdentifier_NamespaceFile_Write_InputArguments = 11668,
	NamespacesType_NamespaceIdentifier_NamespaceFile_GetPosition = 11669,
	NamespacesType_NamespaceIdentifier_NamespaceFile_GetPosition_InputArguments = 11670,
	NamespacesType_NamespaceIdentifier_NamespaceFile_GetPosition_OutputArguments = 11671,
	NamespacesType_NamespaceIdentifier_NamespaceFile_SetPosition = 11672,
	NamespacesType_NamespaceIdentifier_NamespaceFile_SetPosition_InputArguments = 11673,
	NamespacesType_NamespaceIdentifier_NamespaceFile_ExportNamespace = 11674,
	NamespacesType_AddressSpaceFile = 11675,
	NamespacesType_AddressSpaceFile_Size = 11676,
	NamespacesType_AddressSpaceFile_Writeable = 11677,
	NamespacesType_AddressSpaceFile_UserWriteable = 11678,
	NamespacesType_AddressSpaceFile_OpenCount = 11679,
	NamespacesType_AddressSpaceFile_Open = 11680,
	NamespacesType_AddressSpaceFile_Open_InputArguments = 11681,
	NamespacesType_AddressSpaceFile_Open_OutputArguments = 11682,
	NamespacesType_AddressSpaceFile_Close = 11683,
	NamespacesType_AddressSpaceFile_Close_InputArguments = 11684,
	NamespacesType_AddressSpaceFile_Read = 11685,
	NamespacesType_AddressSpaceFile_Read_InputArguments = 11686,
	NamespacesType_AddressSpaceFile_Read_OutputArguments = 11687,
	NamespacesType_AddressSpaceFile_Write = 11688,
	NamespacesType_AddressSpaceFile_Write_InputArguments = 11689,
	NamespacesType_AddressSpaceFile_GetPosition = 11690,
	NamespacesType_AddressSpaceFile_GetPosition_InputArguments = 11691,
	NamespacesType_AddressSpaceFile_GetPosition_OutputArguments = 11692,
	NamespacesType_AddressSpaceFile_SetPosition = 11693,
	NamespacesType_AddressSpaceFile_SetPosition_InputArguments = 11694,
	NamespacesType_AddressSpaceFile_ExportNamespace = 11695,
	SystemStatusChangeEventType_SystemState = 11696,
	SamplingIntervalDiagnosticsType_SampledMonitoredItemsCount = 11697,
	SamplingIntervalDiagnosticsType_MaxSampledMonitoredItemsCount = 11698,
	SamplingIntervalDiagnosticsType_DisabledMonitoredItemsSamplingCount = 11699,
	OptionSetType_BitMask = 11701,
	Server_ServerCapabilities_MaxArrayLength = 11702,
	Server_ServerCapabilities_MaxStringLength = 11703,
	Server_ServerCapabilities_OperationLimits = 11704,
	Server_ServerCapabilities_OperationLimits_MaxNodesPerRead = 11705,
	Server_ServerCapabilities_OperationLimits_MaxNodesPerWrite = 11707,
	Server_ServerCapabilities_OperationLimits_MaxNodesPerMethodCall = 11709,
	Server_ServerCapabilities_OperationLimits_MaxNodesPerBrowse = 11710,
	Server_ServerCapabilities_OperationLimits_MaxNodesPerRegisterNodes = 11711,
	Server_ServerCapabilities_OperationLimits_MaxNodesPerTranslateBrowsePathsToNodeIds = 11712,
	Server_ServerCapabilities_OperationLimits_MaxNodesPerNodeManagement = 11713,
	Server_ServerCapabilities_OperationLimits_MaxMonitoredItemsPerCall = 11714,
	Server_Namespaces = 11715,
	Server_Namespaces_AddressSpaceFile = 11716,
	Server_Namespaces_AddressSpaceFile_Size = 11717,
	Server_Namespaces_AddressSpaceFile_Writeable = 11718,
	Server_Namespaces_AddressSpaceFile_UserWriteable = 11719,
	Server_Namespaces_AddressSpaceFile_OpenCount = 11720,
	Server_Namespaces_AddressSpaceFile_Open = 11721,
	Server_Namespaces_AddressSpaceFile_Open_InputArguments = 11722,
	Server_Namespaces_AddressSpaceFile_Open_OutputArguments = 11723,
	Server_Namespaces_AddressSpaceFile_Close = 11724,
	Server_Namespaces_AddressSpaceFile_Close_InputArguments = 11725,
	Server_Namespaces_AddressSpaceFile_Read = 11726,
	Server_Namespaces_AddressSpaceFile_Read_InputArguments = 11727,
	Server_Namespaces_AddressSpaceFile_Read_OutputArguments = 11728,
	Server_Namespaces_AddressSpaceFile_Write = 11729,
	Server_Namespaces_AddressSpaceFile_Write_InputArguments = 11730,
	Server_Namespaces_AddressSpaceFile_GetPosition = 11731,
	Server_Namespaces_AddressSpaceFile_GetPosition_InputArguments = 11732,
	Server_Namespaces_AddressSpaceFile_GetPosition_OutputArguments = 11733,
	Server_Namespaces_AddressSpaceFile_SetPosition = 11734,
	Server_Namespaces_AddressSpaceFile_SetPosition_InputArguments = 11735,
	Server_Namespaces_AddressSpaceFile_ExportNamespace = 11736,
	BitFieldMaskDataType = 11737,
	OpenMethodType = 11738,
	OpenMethodType_InputArguments = 11739,
	OpenMethodType_OutputArguments = 11740,
	CloseMethodType = 11741,
	CloseMethodType_InputArguments = 11742,
	ReadMethodType = 11743,
	ReadMethodType_InputArguments = 11744,
	ReadMethodType_OutputArguments = 11745,
	WriteMethodType = 11746,
	WriteMethodType_InputArguments = 11747,
	GetPositionMethodType = 11748,
	GetPositionMethodType_InputArguments = 11749,
	GetPositionMethodType_OutputArguments = 11750,
	SetPositionMethodType = 11751,
	SetPositionMethodType_InputArguments = 11752,
	SystemOffNormalAlarmType = 11753,
	SystemOffNormalAlarmType_EventId = 11754,
	SystemOffNormalAlarmType_EventType = 11755,
	SystemOffNormalAlarmType_SourceNode = 11756,
	SystemOffNormalAlarmType_SourceName = 11757,
	SystemOffNormalAlarmType_Time = 11758,
	SystemOffNormalAlarmType_ReceiveTime = 11759,
	SystemOffNormalAlarmType_LocalTime = 11760,
	SystemOffNormalAlarmType_Message = 11761,
	SystemOffNormalAlarmType_Severity = 11762,
	SystemOffNormalAlarmType_ConditionClassId = 11763,
	SystemOffNormalAlarmType_ConditionClassName = 11764,
	SystemOffNormalAlarmType_ConditionName = 11765,
	SystemOffNormalAlarmType_BranchId = 11766,
	SystemOffNormalAlarmType_Retain = 11767,
	SystemOffNormalAlarmType_EnabledState = 11768,
	SystemOffNormalAlarmType_EnabledState_Id = 11769,
	SystemOffNormalAlarmType_EnabledState_Name = 11770,
	SystemOffNormalAlarmType_EnabledState_Number = 11771,
	SystemOffNormalAlarmType_EnabledState_EffectiveDisplayName = 11772,
	SystemOffNormalAlarmType_EnabledState_TransitionTime = 11773,
	SystemOffNormalAlarmType_EnabledState_EffectiveTransitionTime = 11774,
	SystemOffNormalAlarmType_EnabledState_TrueState = 11775,
	SystemOffNormalAlarmType_EnabledState_FalseState = 11776,
	SystemOffNormalAlarmType_Quality = 11777,
	SystemOffNormalAlarmType_Quality_SourceTimestamp = 11778,
	SystemOffNormalAlarmType_LastSeverity = 11779,
	SystemOffNormalAlarmType_LastSeverity_SourceTimestamp = 11780,
	SystemOffNormalAlarmType_Comment = 11781,
	SystemOffNormalAlarmType_Comment_SourceTimestamp = 11782,
	SystemOffNormalAlarmType_ClientUserId = 11783,
	SystemOffNormalAlarmType_Disable = 11784,
	SystemOffNormalAlarmType_Enable = 11785,
	SystemOffNormalAlarmType_AddComment = 11786,
	SystemOffNormalAlarmType_AddComment_InputArguments = 11787,
	SystemOffNormalAlarmType_ConditionRefresh = 11788,
	SystemOffNormalAlarmType_ConditionRefresh_InputArguments = 11789,
	SystemOffNormalAlarmType_AckedState = 11790,
	SystemOffNormalAlarmType_AckedState_Id = 11791,
	SystemOffNormalAlarmType_AckedState_Name = 11792,
	SystemOffNormalAlarmType_AckedState_Number = 11793,
	SystemOffNormalAlarmType_AckedState_EffectiveDisplayName = 11794,
	SystemOffNormalAlarmType_AckedState_TransitionTime = 11795,
	SystemOffNormalAlarmType_AckedState_EffectiveTransitionTime = 11796,
	SystemOffNormalAlarmType_AckedState_TrueState = 11797,
	SystemOffNormalAlarmType_AckedState_FalseState = 11798,
	SystemOffNormalAlarmType_ConfirmedState = 11799,
	SystemOffNormalAlarmType_ConfirmedState_Id = 11800,
	SystemOffNormalAlarmType_ConfirmedState_Name = 11801,
	SystemOffNormalAlarmType_ConfirmedState_Number = 11802,
	SystemOffNormalAlarmType_ConfirmedState_EffectiveDisplayName = 11803,
	SystemOffNormalAlarmType_ConfirmedState_TransitionTime = 11804,
	SystemOffNormalAlarmType_ConfirmedState_EffectiveTransitionTime = 11805,
	SystemOffNormalAlarmType_ConfirmedState_TrueState = 11806,
	SystemOffNormalAlarmType_ConfirmedState_FalseState = 11807,
	SystemOffNormalAlarmType_Acknowledge = 11808,
	SystemOffNormalAlarmType_Acknowledge_InputArguments = 11809,
	SystemOffNormalAlarmType_Confirm = 11810,
	SystemOffNormalAlarmType_Confirm_InputArguments = 11811,
	SystemOffNormalAlarmType_ActiveState = 11812,
	SystemOffNormalAlarmType_ActiveState_Id = 11813,
	SystemOffNormalAlarmType_ActiveState_Name = 11814,
	SystemOffNormalAlarmType_ActiveState_Number = 11815,
	SystemOffNormalAlarmType_ActiveState_EffectiveDisplayName = 11816,
	SystemOffNormalAlarmType_ActiveState_TransitionTime = 11817,
	SystemOffNormalAlarmType_ActiveState_EffectiveTransitionTime = 11818,
	SystemOffNormalAlarmType_ActiveState_TrueState = 11819,
	SystemOffNormalAlarmType_ActiveState_FalseState = 11820,
	SystemOffNormalAlarmType_InputNode = 11821,
	SystemOffNormalAlarmType_SuppressedState = 11822,
	SystemOffNormalAlarmType_SuppressedState_Id = 11823,
	SystemOffNormalAlarmType_SuppressedState_Name = 11824,
	SystemOffNormalAlarmType_SuppressedState_Number = 11825,
	SystemOffNormalAlarmType_SuppressedState_EffectiveDisplayName = 11826,
	SystemOffNormalAlarmType_SuppressedState_TransitionTime = 11827,
	SystemOffNormalAlarmType_SuppressedState_EffectiveTransitionTime = 11828,
	SystemOffNormalAlarmType_SuppressedState_TrueState = 11829,
	SystemOffNormalAlarmType_SuppressedState_FalseState = 11830,
	SystemOffNormalAlarmType_ShelvingState = 11831,
	SystemOffNormalAlarmType_ShelvingState_CurrentState = 11832,
	SystemOffNormalAlarmType_ShelvingState_CurrentState_Id = 11833,
	SystemOffNormalAlarmType_ShelvingState_CurrentState_Name = 11834,
	SystemOffNormalAlarmType_ShelvingState_CurrentState_Number = 11835,
	SystemOffNormalAlarmType_ShelvingState_CurrentState_EffectiveDisplayName = 11836,
	SystemOffNormalAlarmType_ShelvingState_LastTransition = 11837,
	SystemOffNormalAlarmType_ShelvingState_LastTransition_Id = 11838,
	SystemOffNormalAlarmType_ShelvingState_LastTransition_Name = 11839,
	SystemOffNormalAlarmType_ShelvingState_LastTransition_Number = 11840,
	SystemOffNormalAlarmType_ShelvingState_LastTransition_TransitionTime = 11841,
	SystemOffNormalAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime = 11842,
	SystemOffNormalAlarmType_ShelvingState_UnshelveTime = 11843,
	SystemOffNormalAlarmType_ShelvingState_Unshelve = 11844,
	SystemOffNormalAlarmType_ShelvingState_OneShotShelve = 11845,
	SystemOffNormalAlarmType_ShelvingState_TimedShelve = 11846,
	SystemOffNormalAlarmType_ShelvingState_TimedShelve_InputArguments = 11847,
	SystemOffNormalAlarmType_SuppressedOrShelved = 11848,
	SystemOffNormalAlarmType_MaxTimeShelved = 11849,
	SystemOffNormalAlarmType_NormalState = 11850,
	AuditConditionCommentEventType_Comment = 11851,
	AuditConditionRespondEventType_SelectedResponse = 11852,
	AuditConditionAcknowledgeEventType_Comment = 11853,
	AuditConditionConfirmEventType_Comment = 11854,
	AuditConditionShelvingEventType_ShelvingTime = 11855,
	AuditProgramTransitionEventType = 11856,
	AuditProgramTransitionEventType_EventId = 11857,
	AuditProgramTransitionEventType_EventType = 11858,
	AuditProgramTransitionEventType_SourceNode = 11859,
	AuditProgramTransitionEventType_SourceName = 11860,
	AuditProgramTransitionEventType_Time = 11861,
	AuditProgramTransitionEventType_ReceiveTime = 11862,
	AuditProgramTransitionEventType_LocalTime = 11863,
	AuditProgramTransitionEventType_Message = 11864,
	AuditProgramTransitionEventType_Severity = 11865,
	AuditProgramTransitionEventType_ActionTimeStamp = 11866,
	AuditProgramTransitionEventType_Status = 11867,
	AuditProgramTransitionEventType_ServerId = 11868,
	AuditProgramTransitionEventType_ClientAuditEntryId = 11869,
	AuditProgramTransitionEventType_ClientUserId = 11870,
	AuditProgramTransitionEventType_MethodId = 11871,
	AuditProgramTransitionEventType_InputArguments = 11872,
	AuditProgramTransitionEventType_OldStateId = 11873,
	AuditProgramTransitionEventType_NewStateId = 11874,
	AuditProgramTransitionEventType_TransitionNumber = 11875,
	HistoricalDataConfigurationType_AggregateFunctions = 11876,
	HAConfiguration_AggregateFunctions = 11877,
	NodeClass_EnumValues = 11878,
	InstanceNode = 11879,
	TypeNode = 11880,
	NodeAttributesMask_EnumValues = 11881,
	AttributeWriteMask_EnumValues = 11882,
	BrowseResultMask_EnumValues = 11883,
	HistoryUpdateType_EnumValues = 11884,
	PerformUpdateType_EnumValues = 11885,
	EnumeratedTestType_EnumValues = 11886,
	InstanceNode_Encoding_DefaultXml = 11887,
	TypeNode_Encoding_DefaultXml = 11888,
	InstanceNode_Encoding_DefaultBinary = 11889,
	TypeNode_Encoding_DefaultBinary = 11890,
	SessionDiagnosticsObjectType_SessionDiagnostics_UnauthorizedRequestCount = 11891,
	SessionDiagnosticsVariableType_UnauthorizedRequestCount = 11892,
	OpenFileMode = 11939,
	OpenFileMode_EnumValues = 11940,
	ModelChangeStructureVerbMask = 11941,
	ModelChangeStructureVerbMask_EnumValues = 11942,
	EndpointUrlListDataType = 11943,
	NetworkGroupDataType = 11944,
	NonTransparentNetworkRedundancyType = 11945,
	NonTransparentNetworkRedundancyType_RedundancySupport = 11946,
	NonTransparentNetworkRedundancyType_ServerUriArray = 11947,
	NonTransparentNetworkRedundancyType_ServerNetworkGroups = 11948,
	EndpointUrlListDataType_Encoding_DefaultXml = 11949,
	NetworkGroupDataType_Encoding_DefaultXml = 11950,
	OpcUa_XmlSchema_EndpointUrlListDataType = 11951,
	OpcUa_XmlSchema_EndpointUrlListDataType_DataTypeVersion = 11952,
	OpcUa_XmlSchema_EndpointUrlListDataType_DictionaryFragment = 11953,
	OpcUa_XmlSchema_NetworkGroupDataType = 11954,
	OpcUa_XmlSchema_NetworkGroupDataType_DataTypeVersion = 11955,
	OpcUa_XmlSchema_NetworkGroupDataType_DictionaryFragment = 11956,
	EndpointUrlListDataType_Encoding_DefaultBinary = 11957,
	NetworkGroupDataType_Encoding_DefaultBinary = 11958,
	OpcUa_BinarySchema_EndpointUrlListDataType = 11959,
	OpcUa_BinarySchema_EndpointUrlListDataType_DataTypeVersion = 11960,
	OpcUa_BinarySchema_EndpointUrlListDataType_DictionaryFragment = 11961,
	OpcUa_BinarySchema_NetworkGroupDataType = 11962,
	OpcUa_BinarySchema_NetworkGroupDataType_DataTypeVersion = 11963,
	OpcUa_BinarySchema_NetworkGroupDataType_DictionaryFragment = 11964,
	ArrayItemType = 12021,
	ArrayItemType_Definition = 12022,
	ArrayItemType_ValuePrecision = 12023,
	ArrayItemType_InstrumentRange = 12024,
	ArrayItemType_EURange = 12025,
	ArrayItemType_EngineeringUnits = 12026,
	ArrayItemType_Title = 12027,
	ArrayItemType_AxisScaleType = 12028,
	YArrayItemType = 12029,
	YArrayItemType_Definition = 12030,
	YArrayItemType_ValuePrecision = 12031,
	YArrayItemType_InstrumentRange = 12032,
	YArrayItemType_EURange = 12033,
	YArrayItemType_EngineeringUnits = 12034,
	YArrayItemType_Title = 12035,
	YArrayItemType_AxisScaleType = 12036,
	YArrayItemType_XAxisDefinition = 12037,
	XYArrayItemType = 12038,
	XYArrayItemType_Definition = 12039,
	XYArrayItemType_ValuePrecision = 12040,
	XYArrayItemType_InstrumentRange = 12041,
	XYArrayItemType_EURange = 12042,
	XYArrayItemType_EngineeringUnits = 12043,
	XYArrayItemType_Title = 12044,
	XYArrayItemType_AxisScaleType = 12045,
	XYArrayItemType_XAxisDefinition = 12046,
	ImageItemType = 12047,
	ImageItemType_Definition = 12048,
	ImageItemType_ValuePrecision = 12049,
	ImageItemType_InstrumentRange = 12050,
	ImageItemType_EURange = 12051,
	ImageItemType_EngineeringUnits = 12052,
	ImageItemType_Title = 12053,
	ImageItemType_AxisScaleType = 12054,
	ImageItemType_XAxisDefinition = 12055,
	ImageItemType_YAxisDefinition = 12056,
	CubeItemType = 12057,
	CubeItemType_Definition = 12058,
	CubeItemType_ValuePrecision = 12059,
	CubeItemType_InstrumentRange = 12060,
	CubeItemType_EURange = 12061,
	CubeItemType_EngineeringUnits = 12062,
	CubeItemType_Title = 12063,
	CubeItemType_AxisScaleType = 12064,
	CubeItemType_XAxisDefinition = 12065,
	CubeItemType_YAxisDefinition = 12066,
	CubeItemType_ZAxisDefinition = 12067,
	NDimensionArrayItemType = 12068,
	NDimensionArrayItemType_Definition = 12069,
	NDimensionArrayItemType_ValuePrecision = 12070,
	NDimensionArrayItemType_InstrumentRange = 12071,
	NDimensionArrayItemType_EURange = 12072,
	NDimensionArrayItemType_EngineeringUnits = 12073,
	NDimensionArrayItemType_Title = 12074,
	NDimensionArrayItemType_AxisScaleType = 12075,
	NDimensionArrayItemType_AxisDefinition = 12076,
	AxisScaleEnumeration = 12077,
	AxisScaleEnumeration_EnumStrings = 12078,
	AxisInformation = 12079,
	XVType = 12080,
	AxisInformation_Encoding_DefaultXml = 12081,
	XVType_Encoding_DefaultXml = 12082,
	OpcUa_XmlSchema_AxisInformation = 12083,
	OpcUa_XmlSchema_AxisInformation_DataTypeVersion = 12084,
	OpcUa_XmlSchema_AxisInformation_DictionaryFragment = 12085,
	OpcUa_XmlSchema_XVType = 12086,
	OpcUa_XmlSchema_XVType_DataTypeVersion = 12087,
	OpcUa_XmlSchema_XVType_DictionaryFragment = 12088,
	AxisInformation_Encoding_DefaultBinary = 12089,
	XVType_Encoding_DefaultBinary = 12090,
	OpcUa_BinarySchema_AxisInformation = 12091,
	OpcUa_BinarySchema_AxisInformation_DataTypeVersion = 12092,
	OpcUa_BinarySchema_AxisInformation_DictionaryFragment = 12093,
	OpcUa_BinarySchema_XVType = 12094,
	OpcUa_BinarySchema_XVType_DataTypeVersion = 12095,
	OpcUa_BinarySchema_XVType_DictionaryFragment = 12096,
	SessionsDiagnosticsSummaryType_SessionPlaceholder = 12097,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics = 12098,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SessionId = 12099,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SessionName = 12100,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ClientDescription = 12101,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ServerUri = 12102,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_EndpointUrl = 12103,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_LocaleIds = 12104,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ActualSessionTimeout = 12105,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_MaxResponseMessageSize = 12106,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ClientConnectionTime = 12107,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ClientLastContactTime = 12108,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CurrentSubscriptionsCount = 12109,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CurrentMonitoredItemsCount = 12110,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CurrentPublishRequestsInQueue = 12111,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_TotalRequestCount = 12112,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_UnauthorizedRequestCount = 12113,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ReadCount = 12114,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_HistoryReadCount = 12115,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_WriteCount = 12116,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_HistoryUpdateCount = 12117,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CallCount = 12118,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CreateMonitoredItemsCount = 12119,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ModifyMonitoredItemsCount = 12120,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SetMonitoringModeCount = 12121,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SetTriggeringCount = 12122,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteMonitoredItemsCount = 12123,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CreateSubscriptionCount = 12124,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ModifySubscriptionCount = 12125,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SetPublishingModeCount = 12126,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_PublishCount = 12127,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_RepublishCount = 12128,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_TransferSubscriptionsCount = 12129,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteSubscriptionsCount = 12130,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_AddNodesCount = 12131,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_AddReferencesCount = 12132,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteNodesCount = 12133,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteReferencesCount = 12134,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_BrowseCount = 12135,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_BrowseNextCount = 12136,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_TranslateBrowsePathsToNodeIdsCount = 12137,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_QueryFirstCount = 12138,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_QueryNextCount = 12139,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_RegisterNodesCount = 12140,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_UnregisterNodesCount = 12141,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics = 12142,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_SessionId = 12143,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_ClientUserIdOfSession = 12144,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_ClientUserIdHistory = 12145,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_AuthenticationMechanism = 12146,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_Encoding = 12147,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_TransportProtocol = 12148,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_SecurityMode = 12149,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_SecurityPolicyUri = 12150,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_ClientCertificate = 12151,
	SessionsDiagnosticsSummaryType_SessionPlaceholder_SubscriptionDiagnosticsArray = 12152,
	ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadData = 12153,
	ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadEvents = 12154,
	ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateData = 12155,
	ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateEvents = 12156,
	ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryReadData = 12157,
	ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryReadEvents = 12158,
	ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryUpdateData = 12159,
	ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryUpdateEvents = 12160,
	OperationLimitsType_MaxNodesPerHistoryReadData = 12161,
	OperationLimitsType_MaxNodesPerHistoryReadEvents = 12162,
	OperationLimitsType_MaxNodesPerHistoryUpdateData = 12163,
	OperationLimitsType_MaxNodesPerHistoryUpdateEvents = 12164,
	Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadData = 12165,
	Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadEvents = 12166,
	Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateData = 12167,
	Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateEvents = 12168,
	NamingRuleType_EnumValues = 12169,
	ViewVersion = 12170,
	ComplexNumberType = 12171,
	DoubleComplexNumberType = 12172,
	ComplexNumberType_Encoding_DefaultXml = 12173,
	DoubleComplexNumberType_Encoding_DefaultXml = 12174,
	OpcUa_XmlSchema_ComplexNumberType = 12175,
	OpcUa_XmlSchema_ComplexNumberType_DataTypeVersion = 12176,
	OpcUa_XmlSchema_ComplexNumberType_DictionaryFragment = 12177,
	OpcUa_XmlSchema_DoubleComplexNumberType = 12178,
	OpcUa_XmlSchema_DoubleComplexNumberType_DataTypeVersion = 12179,
	OpcUa_XmlSchema_DoubleComplexNumberType_DictionaryFragment = 12180,
	ComplexNumberType_Encoding_DefaultBinary = 12181,
	DoubleComplexNumberType_Encoding_DefaultBinary = 12182,
	OpcUa_BinarySchema_ComplexNumberType = 12183,
	OpcUa_BinarySchema_ComplexNumberType_DataTypeVersion = 12184,
	OpcUa_BinarySchema_ComplexNumberType_DictionaryFragment = 12185,
	OpcUa_BinarySchema_DoubleComplexNumberType = 12186,
	OpcUa_BinarySchema_DoubleComplexNumberType_DataTypeVersion = 12187,
	OpcUa_BinarySchema_DoubleComplexNumberType_DictionaryFragment = 12188,
};
//}



std::string ToString(const ObjectId & value)
{
	switch (value)
	{
	case ObjectId::Boolean:
		return "Boolean";
	case ObjectId::SByte:
		return "SByte";
	case ObjectId::Byte:
		return "Byte";
	case ObjectId::Int16:
		return "Int16";
	case ObjectId::UInt16:
		return "UInt16";
	case ObjectId::Int32:
		return "Int32";
	case ObjectId::UInt32:
		return "UInt32";
	case ObjectId::Int64:
		return "Int64";
	case ObjectId::UInt64:
		return "UInt64";
	case ObjectId::Float:
		return "Float";
	case ObjectId::Double:
		return "Double";
	case ObjectId::String:
		return "String";
	case ObjectId::DateTime:
		return "DateTime";
	case ObjectId::Guid:
		return "Guid";
	case ObjectId::ByteString:
		return "ByteString";
	case ObjectId::XmlElement:
		return "XmlElement";
	case ObjectId::NodeId:
		return "NodeId";
	case ObjectId::ExpandedNodeId:
		return "ExpandedNodeId";
	case ObjectId::StatusCode:
		return "StatusCode";
	case ObjectId::QualifiedName:
		return "QualifiedName";
	case ObjectId::LocalizedText:
		return "LocalizedText";
	case ObjectId::Structure:
		return "Structure";
	case ObjectId::DataValue:
		return "DataValue";
	case ObjectId::BaseDataType:
		return "BaseDataType";
	case ObjectId::DiagnosticInfo:
		return "DiagnosticInfo";
	case ObjectId::Number:
		return "Number";
	case ObjectId::Integer:
		return "Integer";
	case ObjectId::UInteger:
		return "UInteger";
	case ObjectId::Enumeration:
		return "Enumeration";
	case ObjectId::Image:
		return "Image";
	case ObjectId::References:
		return "References";
	case ObjectId::NonHierarchicalReferences:
		return "NonHierarchicalReferences";
	case ObjectId::HierarchicalReferences:
		return "HierarchicalReferences";
	case ObjectId::HasChild:
		return "HasChild";
	case ObjectId::Organizes:
		return "Organizes";
	case ObjectId::HasEventSource:
		return "HasEventSource";
	case ObjectId::HasModellingRule:
		return "HasModellingRule";
	case ObjectId::HasEncoding:
		return "HasEncoding";
	case ObjectId::HasDescription:
		return "HasDescription";
	case ObjectId::HasTypeDefinition:
		return "HasTypeDefinition";
	case ObjectId::GeneratesEvent:
		return "GeneratesEvent";
	case ObjectId::Aggregates:
		return "Aggregates";
	case ObjectId::HasSubtype:
		return "HasSubtype";
	case ObjectId::HasProperty:
		return "HasProperty";
	case ObjectId::HasComponent:
		return "HasComponent";
	case ObjectId::HasNotifier:
		return "HasNotifier";
	case ObjectId::HasOrderedComponent:
		return "HasOrderedComponent";
	case ObjectId::FromState:
		return "FromState";
	case ObjectId::ToState:
		return "ToState";
	case ObjectId::HasCause:
		return "HasCause";
	case ObjectId::HasEffect:
		return "HasEffect";
	case ObjectId::HasHistoricalConfiguration:
		return "HasHistoricalConfiguration";
	case ObjectId::BaseObjectType:
		return "BaseObjectType";
	case ObjectId::FolderType:
		return "FolderType";
	case ObjectId::BaseVariableType:
		return "BaseVariableType";
	case ObjectId::BaseDataVariableType:
		return "BaseDataVariableType";
	case ObjectId::PropertyType:
		return "PropertyType";
	case ObjectId::DataTypeDescriptionType:
		return "DataTypeDescriptionType";
	case ObjectId::DataTypeDictionaryType:
		return "DataTypeDictionaryType";
	case ObjectId::DataTypeSystemType:
		return "DataTypeSystemType";
	case ObjectId::DataTypeEncodingType:
		return "DataTypeEncodingType";
	case ObjectId::ModellingRuleType:
		return "ModellingRuleType";
	case ObjectId::ModellingRule_Mandatory:
		return "ModellingRule_Mandatory";
	case ObjectId::ModellingRule_MandatoryShared:
		return "ModellingRule_MandatoryShared";
	case ObjectId::ModellingRule_Optional:
		return "ModellingRule_Optional";
	case ObjectId::ModellingRule_ExposesItsArray:
		return "ModellingRule_ExposesItsArray";
	case ObjectId::RootFolder:
		return "RootFolder";
	case ObjectId::ObjectsFolder:
		return "ObjectsFolder";
	case ObjectId::TypesFolder:
		return "TypesFolder";
	case ObjectId::ViewsFolder:
		return "ViewsFolder";
	case ObjectId::ObjectTypesFolder:
		return "ObjectTypesFolder";
	case ObjectId::VariableTypesFolder:
		return "VariableTypesFolder";
	case ObjectId::DataTypesFolder:
		return "DataTypesFolder";
	case ObjectId::ReferenceTypesFolder:
		return "ReferenceTypesFolder";
	case ObjectId::XmlSchema_TypeSystem:
		return "XmlSchema_TypeSystem";
	case ObjectId::OPCBinarySchema_TypeSystem:
		return "OPCBinarySchema_TypeSystem";
	case ObjectId::DataTypeDescriptionType_DataTypeVersion:
		return "DataTypeDescriptionType_DataTypeVersion";
	case ObjectId::DataTypeDescriptionType_DictionaryFragment:
		return "DataTypeDescriptionType_DictionaryFragment";
	case ObjectId::DataTypeDictionaryType_DataTypeVersion:
		return "DataTypeDictionaryType_DataTypeVersion";
	case ObjectId::DataTypeDictionaryType_NamespaceUri:
		return "DataTypeDictionaryType_NamespaceUri";
	case ObjectId::ModellingRuleType_NamingRule:
		return "ModellingRuleType_NamingRule";
	case ObjectId::ModellingRule_Mandatory_NamingRule:
		return "ModellingRule_Mandatory_NamingRule";
	case ObjectId::ModellingRule_Optional_NamingRule:
		return "ModellingRule_Optional_NamingRule";
	case ObjectId::ModellingRule_ExposesItsArray_NamingRule:
		return "ModellingRule_ExposesItsArray_NamingRule";
	case ObjectId::ModellingRule_MandatoryShared_NamingRule:
		return "ModellingRule_MandatoryShared_NamingRule";
	case ObjectId::HasSubStateMachine:
		return "HasSubStateMachine";
	case ObjectId::NamingRuleType:
		return "NamingRuleType";
	case ObjectId::IdType:
		return "IdType";
	case ObjectId::NodeClass:
		return "NodeClass";
	case ObjectId::Node:
		return "Node";
	case ObjectId::Node_Encoding_DefaultXml:
		return "Node_Encoding_DefaultXml";
	case ObjectId::Node_Encoding_DefaultBinary:
		return "Node_Encoding_DefaultBinary";
	case ObjectId::ObjectNode:
		return "ObjectNode";
	case ObjectId::ObjectNode_Encoding_DefaultXml:
		return "ObjectNode_Encoding_DefaultXml";
	case ObjectId::ObjectNode_Encoding_DefaultBinary:
		return "ObjectNode_Encoding_DefaultBinary";
	case ObjectId::ObjectTypeNode:
		return "ObjectTypeNode";
	case ObjectId::ObjectTypeNode_Encoding_DefaultXml:
		return "ObjectTypeNode_Encoding_DefaultXml";
	case ObjectId::ObjectTypeNode_Encoding_DefaultBinary:
		return "ObjectTypeNode_Encoding_DefaultBinary";
	case ObjectId::VariableNode:
		return "VariableNode";
	case ObjectId::VariableNode_Encoding_DefaultXml:
		return "VariableNode_Encoding_DefaultXml";
	case ObjectId::VariableNode_Encoding_DefaultBinary:
		return "VariableNode_Encoding_DefaultBinary";
	case ObjectId::VariableTypeNode:
		return "VariableTypeNode";
	case ObjectId::VariableTypeNode_Encoding_DefaultXml:
		return "VariableTypeNode_Encoding_DefaultXml";
	case ObjectId::VariableTypeNode_Encoding_DefaultBinary:
		return "VariableTypeNode_Encoding_DefaultBinary";
	case ObjectId::ReferenceTypeNode:
		return "ReferenceTypeNode";
	case ObjectId::ReferenceTypeNode_Encoding_DefaultXml:
		return "ReferenceTypeNode_Encoding_DefaultXml";
	case ObjectId::ReferenceTypeNode_Encoding_DefaultBinary:
		return "ReferenceTypeNode_Encoding_DefaultBinary";
	case ObjectId::MethodNode:
		return "MethodNode";
	case ObjectId::MethodNode_Encoding_DefaultXml:
		return "MethodNode_Encoding_DefaultXml";
	case ObjectId::MethodNode_Encoding_DefaultBinary:
		return "MethodNode_Encoding_DefaultBinary";
	case ObjectId::ViewNode:
		return "ViewNode";
	case ObjectId::ViewNode_Encoding_DefaultXml:
		return "ViewNode_Encoding_DefaultXml";
	case ObjectId::ViewNode_Encoding_DefaultBinary:
		return "ViewNode_Encoding_DefaultBinary";
	case ObjectId::DataTypeNode:
		return "DataTypeNode";
	case ObjectId::DataTypeNode_Encoding_DefaultXml:
		return "DataTypeNode_Encoding_DefaultXml";
	case ObjectId::DataTypeNode_Encoding_DefaultBinary:
		return "DataTypeNode_Encoding_DefaultBinary";
	case ObjectId::ReferenceNode:
		return "ReferenceNode";
	case ObjectId::ReferenceNode_Encoding_DefaultXml:
		return "ReferenceNode_Encoding_DefaultXml";
	case ObjectId::ReferenceNode_Encoding_DefaultBinary:
		return "ReferenceNode_Encoding_DefaultBinary";
	case ObjectId::IntegerId:
		return "IntegerId";
	case ObjectId::Counter:
		return "Counter";
	case ObjectId::Duration:
		return "Duration";
	case ObjectId::NumericRange:
		return "NumericRange";
	case ObjectId::Time:
		return "Time";
	case ObjectId::Date:
		return "Date";
	case ObjectId::UtcTime:
		return "UtcTime";
	case ObjectId::LocaleId:
		return "LocaleId";
	case ObjectId::Argument:
		return "Argument";
	case ObjectId::Argument_Encoding_DefaultXml:
		return "Argument_Encoding_DefaultXml";
	case ObjectId::Argument_Encoding_DefaultBinary:
		return "Argument_Encoding_DefaultBinary";
	case ObjectId::StatusResult:
		return "StatusResult";
	case ObjectId::StatusResult_Encoding_DefaultXml:
		return "StatusResult_Encoding_DefaultXml";
	case ObjectId::StatusResult_Encoding_DefaultBinary:
		return "StatusResult_Encoding_DefaultBinary";
	case ObjectId::MessageSecurityMode:
		return "MessageSecurityMode";
	case ObjectId::UserTokenType:
		return "UserTokenType";
	case ObjectId::UserTokenPolicy:
		return "UserTokenPolicy";
	case ObjectId::UserTokenPolicy_Encoding_DefaultXml:
		return "UserTokenPolicy_Encoding_DefaultXml";
	case ObjectId::UserTokenPolicy_Encoding_DefaultBinary:
		return "UserTokenPolicy_Encoding_DefaultBinary";
	case ObjectId::ApplicationType:
		return "ApplicationType";
	case ObjectId::ApplicationDescription:
		return "ApplicationDescription";
	case ObjectId::ApplicationDescription_Encoding_DefaultXml:
		return "ApplicationDescription_Encoding_DefaultXml";
	case ObjectId::ApplicationDescription_Encoding_DefaultBinary:
		return "ApplicationDescription_Encoding_DefaultBinary";
	case ObjectId::ApplicationInstanceCertificate:
		return "ApplicationInstanceCertificate";
	case ObjectId::EndpointDescription:
		return "EndpointDescription";
	case ObjectId::EndpointDescription_Encoding_DefaultXml:
		return "EndpointDescription_Encoding_DefaultXml";
	case ObjectId::EndpointDescription_Encoding_DefaultBinary:
		return "EndpointDescription_Encoding_DefaultBinary";
	case ObjectId::SecurityTokenRequestType:
		return "SecurityTokenRequestType";
	case ObjectId::UserIdentityToken:
		return "UserIdentityToken";
	case ObjectId::UserIdentityToken_Encoding_DefaultXml:
		return "UserIdentityToken_Encoding_DefaultXml";
	case ObjectId::UserIdentityToken_Encoding_DefaultBinary:
		return "UserIdentityToken_Encoding_DefaultBinary";
	case ObjectId::AnonymousIdentityToken:
		return "AnonymousIdentityToken";
	case ObjectId::AnonymousIdentityToken_Encoding_DefaultXml:
		return "AnonymousIdentityToken_Encoding_DefaultXml";
	case ObjectId::AnonymousIdentityToken_Encoding_DefaultBinary:
		return "AnonymousIdentityToken_Encoding_DefaultBinary";
	case ObjectId::UserNameIdentityToken:
		return "UserNameIdentityToken";
	case ObjectId::UserNameIdentityToken_Encoding_DefaultXml:
		return "UserNameIdentityToken_Encoding_DefaultXml";
	case ObjectId::UserNameIdentityToken_Encoding_DefaultBinary:
		return "UserNameIdentityToken_Encoding_DefaultBinary";
	case ObjectId::X509IdentityToken:
		return "X509IdentityToken";
	case ObjectId::X509IdentityToken_Encoding_DefaultXml:
		return "X509IdentityToken_Encoding_DefaultXml";
	case ObjectId::X509IdentityToken_Encoding_DefaultBinary:
		return "X509IdentityToken_Encoding_DefaultBinary";
	case ObjectId::EndpointConfiguration:
		return "EndpointConfiguration";
	case ObjectId::EndpointConfiguration_Encoding_DefaultXml:
		return "EndpointConfiguration_Encoding_DefaultXml";
	case ObjectId::EndpointConfiguration_Encoding_DefaultBinary:
		return "EndpointConfiguration_Encoding_DefaultBinary";
	case ObjectId::ComplianceLevel:
		return "ComplianceLevel";
	case ObjectId::SupportedProfile:
		return "SupportedProfile";
	case ObjectId::SupportedProfile_Encoding_DefaultXml:
		return "SupportedProfile_Encoding_DefaultXml";
	case ObjectId::SupportedProfile_Encoding_DefaultBinary:
		return "SupportedProfile_Encoding_DefaultBinary";
	case ObjectId::BuildInfo:
		return "BuildInfo";
	case ObjectId::BuildInfo_Encoding_DefaultXml:
		return "BuildInfo_Encoding_DefaultXml";
	case ObjectId::BuildInfo_Encoding_DefaultBinary:
		return "BuildInfo_Encoding_DefaultBinary";
	case ObjectId::SoftwareCertificate:
		return "SoftwareCertificate";
	case ObjectId::SoftwareCertificate_Encoding_DefaultXml:
		return "SoftwareCertificate_Encoding_DefaultXml";
	case ObjectId::SoftwareCertificate_Encoding_DefaultBinary:
		return "SoftwareCertificate_Encoding_DefaultBinary";
	case ObjectId::SignedSoftwareCertificate:
		return "SignedSoftwareCertificate";
	case ObjectId::SignedSoftwareCertificate_Encoding_DefaultXml:
		return "SignedSoftwareCertificate_Encoding_DefaultXml";
	case ObjectId::SignedSoftwareCertificate_Encoding_DefaultBinary:
		return "SignedSoftwareCertificate_Encoding_DefaultBinary";
	case ObjectId::AttributeWriteMask:
		return "AttributeWriteMask";
	case ObjectId::NodeAttributesMask:
		return "NodeAttributesMask";
	case ObjectId::NodeAttributes:
		return "NodeAttributes";
	case ObjectId::NodeAttributes_Encoding_DefaultXml:
		return "NodeAttributes_Encoding_DefaultXml";
	case ObjectId::NodeAttributes_Encoding_DefaultBinary:
		return "NodeAttributes_Encoding_DefaultBinary";
	case ObjectId::ObjectAttributes:
		return "ObjectAttributes";
	case ObjectId::ObjectAttributes_Encoding_DefaultXml:
		return "ObjectAttributes_Encoding_DefaultXml";
	case ObjectId::ObjectAttributes_Encoding_DefaultBinary:
		return "ObjectAttributes_Encoding_DefaultBinary";
	case ObjectId::VariableAttributes:
		return "VariableAttributes";
	case ObjectId::VariableAttributes_Encoding_DefaultXml:
		return "VariableAttributes_Encoding_DefaultXml";
	case ObjectId::VariableAttributes_Encoding_DefaultBinary:
		return "VariableAttributes_Encoding_DefaultBinary";
	case ObjectId::MethodAttributes:
		return "MethodAttributes";
	case ObjectId::MethodAttributes_Encoding_DefaultXml:
		return "MethodAttributes_Encoding_DefaultXml";
	case ObjectId::MethodAttributes_Encoding_DefaultBinary:
		return "MethodAttributes_Encoding_DefaultBinary";
	case ObjectId::ObjectTypeAttributes:
		return "ObjectTypeAttributes";
	case ObjectId::ObjectTypeAttributes_Encoding_DefaultXml:
		return "ObjectTypeAttributes_Encoding_DefaultXml";
	case ObjectId::ObjectTypeAttributes_Encoding_DefaultBinary:
		return "ObjectTypeAttributes_Encoding_DefaultBinary";
	case ObjectId::VariableTypeAttributes:
		return "VariableTypeAttributes";
	case ObjectId::VariableTypeAttributes_Encoding_DefaultXml:
		return "VariableTypeAttributes_Encoding_DefaultXml";
	case ObjectId::VariableTypeAttributes_Encoding_DefaultBinary:
		return "VariableTypeAttributes_Encoding_DefaultBinary";
	case ObjectId::ReferenceTypeAttributes:
		return "ReferenceTypeAttributes";
	case ObjectId::ReferenceTypeAttributes_Encoding_DefaultXml:
		return "ReferenceTypeAttributes_Encoding_DefaultXml";
	case ObjectId::ReferenceTypeAttributes_Encoding_DefaultBinary:
		return "ReferenceTypeAttributes_Encoding_DefaultBinary";
	case ObjectId::DataTypeAttributes:
		return "DataTypeAttributes";
	case ObjectId::DataTypeAttributes_Encoding_DefaultXml:
		return "DataTypeAttributes_Encoding_DefaultXml";
	case ObjectId::DataTypeAttributes_Encoding_DefaultBinary:
		return "DataTypeAttributes_Encoding_DefaultBinary";
	case ObjectId::ViewAttributes:
		return "ViewAttributes";
	case ObjectId::ViewAttributes_Encoding_DefaultXml:
		return "ViewAttributes_Encoding_DefaultXml";
	case ObjectId::ViewAttributes_Encoding_DefaultBinary:
		return "ViewAttributes_Encoding_DefaultBinary";
	case ObjectId::AddNodesItem:
		return "AddNodesItem";
	case ObjectId::AddNodesItem_Encoding_DefaultXml:
		return "AddNodesItem_Encoding_DefaultXml";
	case ObjectId::AddNodesItem_Encoding_DefaultBinary:
		return "AddNodesItem_Encoding_DefaultBinary";
	case ObjectId::AddReferencesItem:
		return "AddReferencesItem";
	case ObjectId::AddReferencesItem_Encoding_DefaultXml:
		return "AddReferencesItem_Encoding_DefaultXml";
	case ObjectId::AddReferencesItem_Encoding_DefaultBinary:
		return "AddReferencesItem_Encoding_DefaultBinary";
	case ObjectId::DeleteNodesItem:
		return "DeleteNodesItem";
	case ObjectId::DeleteNodesItem_Encoding_DefaultXml:
		return "DeleteNodesItem_Encoding_DefaultXml";
	case ObjectId::DeleteNodesItem_Encoding_DefaultBinary:
		return "DeleteNodesItem_Encoding_DefaultBinary";
	case ObjectId::DeleteReferencesItem:
		return "DeleteReferencesItem";
	case ObjectId::DeleteReferencesItem_Encoding_DefaultXml:
		return "DeleteReferencesItem_Encoding_DefaultXml";
	case ObjectId::DeleteReferencesItem_Encoding_DefaultBinary:
		return "DeleteReferencesItem_Encoding_DefaultBinary";
	case ObjectId::SessionAuthenticationToken:
		return "SessionAuthenticationToken";
	case ObjectId::RequestHeader:
		return "RequestHeader";
	case ObjectId::RequestHeader_Encoding_DefaultXml:
		return "RequestHeader_Encoding_DefaultXml";
	case ObjectId::RequestHeader_Encoding_DefaultBinary:
		return "RequestHeader_Encoding_DefaultBinary";
	case ObjectId::ResponseHeader:
		return "ResponseHeader";
	case ObjectId::ResponseHeader_Encoding_DefaultXml:
		return "ResponseHeader_Encoding_DefaultXml";
	case ObjectId::ResponseHeader_Encoding_DefaultBinary:
		return "ResponseHeader_Encoding_DefaultBinary";
	case ObjectId::ServiceFault:
		return "ServiceFault";
	case ObjectId::ServiceFault_Encoding_DefaultXml:
		return "ServiceFault_Encoding_DefaultXml";
	case ObjectId::ServiceFault_Encoding_DefaultBinary:
		return "ServiceFault_Encoding_DefaultBinary";
	case ObjectId::EnumeratedTestType:
		return "EnumeratedTestType";
	case ObjectId::ScalarTestType:
		return "ScalarTestType";
	case ObjectId::ScalarTestType_Encoding_DefaultXml:
		return "ScalarTestType_Encoding_DefaultXml";
	case ObjectId::ScalarTestType_Encoding_DefaultBinary:
		return "ScalarTestType_Encoding_DefaultBinary";
	case ObjectId::ArrayTestType:
		return "ArrayTestType";
	case ObjectId::ArrayTestType_Encoding_DefaultXml:
		return "ArrayTestType_Encoding_DefaultXml";
	case ObjectId::ArrayTestType_Encoding_DefaultBinary:
		return "ArrayTestType_Encoding_DefaultBinary";
	case ObjectId::CompositeTestType:
		return "CompositeTestType";
	case ObjectId::CompositeTestType_Encoding_DefaultXml:
		return "CompositeTestType_Encoding_DefaultXml";
	case ObjectId::CompositeTestType_Encoding_DefaultBinary:
		return "CompositeTestType_Encoding_DefaultBinary";
	case ObjectId::TestStackRequest:
		return "TestStackRequest";
	case ObjectId::TestStackRequest_Encoding_DefaultXml:
		return "TestStackRequest_Encoding_DefaultXml";
	case ObjectId::TestStackRequest_Encoding_DefaultBinary:
		return "TestStackRequest_Encoding_DefaultBinary";
	case ObjectId::TestStackResponse:
		return "TestStackResponse";
	case ObjectId::TestStackResponse_Encoding_DefaultXml:
		return "TestStackResponse_Encoding_DefaultXml";
	case ObjectId::TestStackResponse_Encoding_DefaultBinary:
		return "TestStackResponse_Encoding_DefaultBinary";
	case ObjectId::TestStackExRequest:
		return "TestStackExRequest";
	case ObjectId::TestStackExRequest_Encoding_DefaultXml:
		return "TestStackExRequest_Encoding_DefaultXml";
	case ObjectId::TestStackExRequest_Encoding_DefaultBinary:
		return "TestStackExRequest_Encoding_DefaultBinary";
	case ObjectId::TestStackExResponse:
		return "TestStackExResponse";
	case ObjectId::TestStackExResponse_Encoding_DefaultXml:
		return "TestStackExResponse_Encoding_DefaultXml";
	case ObjectId::TestStackExResponse_Encoding_DefaultBinary:
		return "TestStackExResponse_Encoding_DefaultBinary";
	case ObjectId::FindServersRequest:
		return "FindServersRequest";
	case ObjectId::FindServersRequest_Encoding_DefaultXml:
		return "FindServersRequest_Encoding_DefaultXml";
	case ObjectId::FindServersRequest_Encoding_DefaultBinary:
		return "FindServersRequest_Encoding_DefaultBinary";
	case ObjectId::FindServersResponse:
		return "FindServersResponse";
	case ObjectId::FindServersResponse_Encoding_DefaultXml:
		return "FindServersResponse_Encoding_DefaultXml";
	case ObjectId::FindServersResponse_Encoding_DefaultBinary:
		return "FindServersResponse_Encoding_DefaultBinary";
	case ObjectId::GetEndpointsRequest:
		return "GetEndpointsRequest";
	case ObjectId::GetEndpointsRequest_Encoding_DefaultXml:
		return "GetEndpointsRequest_Encoding_DefaultXml";
	case ObjectId::GetEndpointsRequest_Encoding_DefaultBinary:
		return "GetEndpointsRequest_Encoding_DefaultBinary";
	case ObjectId::GetEndpointsResponse:
		return "GetEndpointsResponse";
	case ObjectId::GetEndpointsResponse_Encoding_DefaultXml:
		return "GetEndpointsResponse_Encoding_DefaultXml";
	case ObjectId::GetEndpointsResponse_Encoding_DefaultBinary:
		return "GetEndpointsResponse_Encoding_DefaultBinary";
	case ObjectId::RegisteredServer:
		return "RegisteredServer";
	case ObjectId::RegisteredServer_Encoding_DefaultXml:
		return "RegisteredServer_Encoding_DefaultXml";
	case ObjectId::RegisteredServer_Encoding_DefaultBinary:
		return "RegisteredServer_Encoding_DefaultBinary";
	case ObjectId::RegisterServerRequest:
		return "RegisterServerRequest";
	case ObjectId::RegisterServerRequest_Encoding_DefaultXml:
		return "RegisterServerRequest_Encoding_DefaultXml";
	case ObjectId::RegisterServerRequest_Encoding_DefaultBinary:
		return "RegisterServerRequest_Encoding_DefaultBinary";
	case ObjectId::RegisterServerResponse:
		return "RegisterServerResponse";
	case ObjectId::RegisterServerResponse_Encoding_DefaultXml:
		return "RegisterServerResponse_Encoding_DefaultXml";
	case ObjectId::RegisterServerResponse_Encoding_DefaultBinary:
		return "RegisterServerResponse_Encoding_DefaultBinary";
	case ObjectId::ChannelSecurityToken:
		return "ChannelSecurityToken";
	case ObjectId::ChannelSecurityToken_Encoding_DefaultXml:
		return "ChannelSecurityToken_Encoding_DefaultXml";
	case ObjectId::ChannelSecurityToken_Encoding_DefaultBinary:
		return "ChannelSecurityToken_Encoding_DefaultBinary";
	case ObjectId::OpenSecureChannelRequest:
		return "OpenSecureChannelRequest";
	case ObjectId::OpenSecureChannelRequest_Encoding_DefaultXml:
		return "OpenSecureChannelRequest_Encoding_DefaultXml";
	case ObjectId::OpenSecureChannelRequest_Encoding_DefaultBinary:
		return "OpenSecureChannelRequest_Encoding_DefaultBinary";
	case ObjectId::OpenSecureChannelResponse:
		return "OpenSecureChannelResponse";
	case ObjectId::OpenSecureChannelResponse_Encoding_DefaultXml:
		return "OpenSecureChannelResponse_Encoding_DefaultXml";
	case ObjectId::OpenSecureChannelResponse_Encoding_DefaultBinary:
		return "OpenSecureChannelResponse_Encoding_DefaultBinary";
	case ObjectId::CloseSecureChannelRequest:
		return "CloseSecureChannelRequest";
	case ObjectId::CloseSecureChannelRequest_Encoding_DefaultXml:
		return "CloseSecureChannelRequest_Encoding_DefaultXml";
	case ObjectId::CloseSecureChannelRequest_Encoding_DefaultBinary:
		return "CloseSecureChannelRequest_Encoding_DefaultBinary";
	case ObjectId::CloseSecureChannelResponse:
		return "CloseSecureChannelResponse";
	case ObjectId::CloseSecureChannelResponse_Encoding_DefaultXml:
		return "CloseSecureChannelResponse_Encoding_DefaultXml";
	case ObjectId::CloseSecureChannelResponse_Encoding_DefaultBinary:
		return "CloseSecureChannelResponse_Encoding_DefaultBinary";
	case ObjectId::SignatureData:
		return "SignatureData";
	case ObjectId::SignatureData_Encoding_DefaultXml:
		return "SignatureData_Encoding_DefaultXml";
	case ObjectId::SignatureData_Encoding_DefaultBinary:
		return "SignatureData_Encoding_DefaultBinary";
	case ObjectId::CreateSessionRequest:
		return "CreateSessionRequest";
	case ObjectId::CreateSessionRequest_Encoding_DefaultXml:
		return "CreateSessionRequest_Encoding_DefaultXml";
	case ObjectId::CreateSessionRequest_Encoding_DefaultBinary:
		return "CreateSessionRequest_Encoding_DefaultBinary";
	case ObjectId::CreateSessionResponse:
		return "CreateSessionResponse";
	case ObjectId::CreateSessionResponse_Encoding_DefaultXml:
		return "CreateSessionResponse_Encoding_DefaultXml";
	case ObjectId::CreateSessionResponse_Encoding_DefaultBinary:
		return "CreateSessionResponse_Encoding_DefaultBinary";
	case ObjectId::ActivateSessionRequest:
		return "ActivateSessionRequest";
	case ObjectId::ActivateSessionRequest_Encoding_DefaultXml:
		return "ActivateSessionRequest_Encoding_DefaultXml";
	case ObjectId::ActivateSessionRequest_Encoding_DefaultBinary:
		return "ActivateSessionRequest_Encoding_DefaultBinary";
	case ObjectId::ActivateSessionResponse:
		return "ActivateSessionResponse";
	case ObjectId::ActivateSessionResponse_Encoding_DefaultXml:
		return "ActivateSessionResponse_Encoding_DefaultXml";
	case ObjectId::ActivateSessionResponse_Encoding_DefaultBinary:
		return "ActivateSessionResponse_Encoding_DefaultBinary";
	case ObjectId::CloseSessionRequest:
		return "CloseSessionRequest";
	case ObjectId::CloseSessionRequest_Encoding_DefaultXml:
		return "CloseSessionRequest_Encoding_DefaultXml";
	case ObjectId::CloseSessionRequest_Encoding_DefaultBinary:
		return "CloseSessionRequest_Encoding_DefaultBinary";
	case ObjectId::CloseSessionResponse:
		return "CloseSessionResponse";
	case ObjectId::CloseSessionResponse_Encoding_DefaultXml:
		return "CloseSessionResponse_Encoding_DefaultXml";
	case ObjectId::CloseSessionResponse_Encoding_DefaultBinary:
		return "CloseSessionResponse_Encoding_DefaultBinary";
	case ObjectId::CancelRequest:
		return "CancelRequest";
	case ObjectId::CancelRequest_Encoding_DefaultXml:
		return "CancelRequest_Encoding_DefaultXml";
	case ObjectId::CancelRequest_Encoding_DefaultBinary:
		return "CancelRequest_Encoding_DefaultBinary";
	case ObjectId::CancelResponse:
		return "CancelResponse";
	case ObjectId::CancelResponse_Encoding_DefaultXml:
		return "CancelResponse_Encoding_DefaultXml";
	case ObjectId::CancelResponse_Encoding_DefaultBinary:
		return "CancelResponse_Encoding_DefaultBinary";
	case ObjectId::AddNodesResult:
		return "AddNodesResult";
	case ObjectId::AddNodesResult_Encoding_DefaultXml:
		return "AddNodesResult_Encoding_DefaultXml";
	case ObjectId::AddNodesResult_Encoding_DefaultBinary:
		return "AddNodesResult_Encoding_DefaultBinary";
	case ObjectId::AddNodesRequest:
		return "AddNodesRequest";
	case ObjectId::AddNodesRequest_Encoding_DefaultXml:
		return "AddNodesRequest_Encoding_DefaultXml";
	case ObjectId::AddNodesRequest_Encoding_DefaultBinary:
		return "AddNodesRequest_Encoding_DefaultBinary";
	case ObjectId::AddNodesResponse:
		return "AddNodesResponse";
	case ObjectId::AddNodesResponse_Encoding_DefaultXml:
		return "AddNodesResponse_Encoding_DefaultXml";
	case ObjectId::AddNodesResponse_Encoding_DefaultBinary:
		return "AddNodesResponse_Encoding_DefaultBinary";
	case ObjectId::AddReferencesRequest:
		return "AddReferencesRequest";
	case ObjectId::AddReferencesRequest_Encoding_DefaultXml:
		return "AddReferencesRequest_Encoding_DefaultXml";
	case ObjectId::AddReferencesRequest_Encoding_DefaultBinary:
		return "AddReferencesRequest_Encoding_DefaultBinary";
	case ObjectId::AddReferencesResponse:
		return "AddReferencesResponse";
	case ObjectId::AddReferencesResponse_Encoding_DefaultXml:
		return "AddReferencesResponse_Encoding_DefaultXml";
	case ObjectId::AddReferencesResponse_Encoding_DefaultBinary:
		return "AddReferencesResponse_Encoding_DefaultBinary";
	case ObjectId::DeleteNodesRequest:
		return "DeleteNodesRequest";
	case ObjectId::DeleteNodesRequest_Encoding_DefaultXml:
		return "DeleteNodesRequest_Encoding_DefaultXml";
	case ObjectId::DeleteNodesRequest_Encoding_DefaultBinary:
		return "DeleteNodesRequest_Encoding_DefaultBinary";
	case ObjectId::DeleteNodesResponse:
		return "DeleteNodesResponse";
	case ObjectId::DeleteNodesResponse_Encoding_DefaultXml:
		return "DeleteNodesResponse_Encoding_DefaultXml";
	case ObjectId::DeleteNodesResponse_Encoding_DefaultBinary:
		return "DeleteNodesResponse_Encoding_DefaultBinary";
	case ObjectId::DeleteReferencesRequest:
		return "DeleteReferencesRequest";
	case ObjectId::DeleteReferencesRequest_Encoding_DefaultXml:
		return "DeleteReferencesRequest_Encoding_DefaultXml";
	case ObjectId::DeleteReferencesRequest_Encoding_DefaultBinary:
		return "DeleteReferencesRequest_Encoding_DefaultBinary";
	case ObjectId::DeleteReferencesResponse:
		return "DeleteReferencesResponse";
	case ObjectId::DeleteReferencesResponse_Encoding_DefaultXml:
		return "DeleteReferencesResponse_Encoding_DefaultXml";
	case ObjectId::DeleteReferencesResponse_Encoding_DefaultBinary:
		return "DeleteReferencesResponse_Encoding_DefaultBinary";
	case ObjectId::BrowseDirection:
		return "BrowseDirection";
	case ObjectId::ViewDescription:
		return "ViewDescription";
	case ObjectId::ViewDescription_Encoding_DefaultXml:
		return "ViewDescription_Encoding_DefaultXml";
	case ObjectId::ViewDescription_Encoding_DefaultBinary:
		return "ViewDescription_Encoding_DefaultBinary";
	case ObjectId::BrowseDescription:
		return "BrowseDescription";
	case ObjectId::BrowseDescription_Encoding_DefaultXml:
		return "BrowseDescription_Encoding_DefaultXml";
	case ObjectId::BrowseDescription_Encoding_DefaultBinary:
		return "BrowseDescription_Encoding_DefaultBinary";
	case ObjectId::BrowseResultMask:
		return "BrowseResultMask";
	case ObjectId::ReferenceDescription:
		return "ReferenceDescription";
	case ObjectId::ReferenceDescription_Encoding_DefaultXml:
		return "ReferenceDescription_Encoding_DefaultXml";
	case ObjectId::ReferenceDescription_Encoding_DefaultBinary:
		return "ReferenceDescription_Encoding_DefaultBinary";
	case ObjectId::ContinuationPoint:
		return "ContinuationPoint";
	case ObjectId::BrowseResult:
		return "BrowseResult";
	case ObjectId::BrowseResult_Encoding_DefaultXml:
		return "BrowseResult_Encoding_DefaultXml";
	case ObjectId::BrowseResult_Encoding_DefaultBinary:
		return "BrowseResult_Encoding_DefaultBinary";
	case ObjectId::BrowseRequest:
		return "BrowseRequest";
	case ObjectId::BrowseRequest_Encoding_DefaultXml:
		return "BrowseRequest_Encoding_DefaultXml";
	case ObjectId::BrowseRequest_Encoding_DefaultBinary:
		return "BrowseRequest_Encoding_DefaultBinary";
	case ObjectId::BrowseResponse:
		return "BrowseResponse";
	case ObjectId::BrowseResponse_Encoding_DefaultXml:
		return "BrowseResponse_Encoding_DefaultXml";
	case ObjectId::BrowseResponse_Encoding_DefaultBinary:
		return "BrowseResponse_Encoding_DefaultBinary";
	case ObjectId::BrowseNextRequest:
		return "BrowseNextRequest";
	case ObjectId::BrowseNextRequest_Encoding_DefaultXml:
		return "BrowseNextRequest_Encoding_DefaultXml";
	case ObjectId::BrowseNextRequest_Encoding_DefaultBinary:
		return "BrowseNextRequest_Encoding_DefaultBinary";
	case ObjectId::BrowseNextResponse:
		return "BrowseNextResponse";
	case ObjectId::BrowseNextResponse_Encoding_DefaultXml:
		return "BrowseNextResponse_Encoding_DefaultXml";
	case ObjectId::BrowseNextResponse_Encoding_DefaultBinary:
		return "BrowseNextResponse_Encoding_DefaultBinary";
	case ObjectId::RelativePathElement:
		return "RelativePathElement";
	case ObjectId::RelativePathElement_Encoding_DefaultXml:
		return "RelativePathElement_Encoding_DefaultXml";
	case ObjectId::RelativePathElement_Encoding_DefaultBinary:
		return "RelativePathElement_Encoding_DefaultBinary";
	case ObjectId::RelativePath:
		return "RelativePath";
	case ObjectId::RelativePath_Encoding_DefaultXml:
		return "RelativePath_Encoding_DefaultXml";
	case ObjectId::RelativePath_Encoding_DefaultBinary:
		return "RelativePath_Encoding_DefaultBinary";
	case ObjectId::BrowsePath:
		return "BrowsePath";
	case ObjectId::BrowsePath_Encoding_DefaultXml:
		return "BrowsePath_Encoding_DefaultXml";
	case ObjectId::BrowsePath_Encoding_DefaultBinary:
		return "BrowsePath_Encoding_DefaultBinary";
	case ObjectId::BrowsePathTarget:
		return "BrowsePathTarget";
	case ObjectId::BrowsePathTarget_Encoding_DefaultXml:
		return "BrowsePathTarget_Encoding_DefaultXml";
	case ObjectId::BrowsePathTarget_Encoding_DefaultBinary:
		return "BrowsePathTarget_Encoding_DefaultBinary";
	case ObjectId::BrowsePathResult:
		return "BrowsePathResult";
	case ObjectId::BrowsePathResult_Encoding_DefaultXml:
		return "BrowsePathResult_Encoding_DefaultXml";
	case ObjectId::BrowsePathResult_Encoding_DefaultBinary:
		return "BrowsePathResult_Encoding_DefaultBinary";
	case ObjectId::TranslateBrowsePathsToNodeIdsRequest:
		return "TranslateBrowsePathsToNodeIdsRequest";
	case ObjectId::TranslateBrowsePathsToNodeIdsRequest_Encoding_DefaultXml:
		return "TranslateBrowsePathsToNodeIdsRequest_Encoding_DefaultXml";
	case ObjectId::TranslateBrowsePathsToNodeIdsRequest_Encoding_DefaultBinary:
		return "TranslateBrowsePathsToNodeIdsRequest_Encoding_DefaultBinary";
	case ObjectId::TranslateBrowsePathsToNodeIdsResponse:
		return "TranslateBrowsePathsToNodeIdsResponse";
	case ObjectId::TranslateBrowsePathsToNodeIdsResponse_Encoding_DefaultXml:
		return "TranslateBrowsePathsToNodeIdsResponse_Encoding_DefaultXml";
	case ObjectId::TranslateBrowsePathsToNodeIdsResponse_Encoding_DefaultBinary:
		return "TranslateBrowsePathsToNodeIdsResponse_Encoding_DefaultBinary";
	case ObjectId::RegisterNodesRequest:
		return "RegisterNodesRequest";
	case ObjectId::RegisterNodesRequest_Encoding_DefaultXml:
		return "RegisterNodesRequest_Encoding_DefaultXml";
	case ObjectId::RegisterNodesRequest_Encoding_DefaultBinary:
		return "RegisterNodesRequest_Encoding_DefaultBinary";
	case ObjectId::RegisterNodesResponse:
		return "RegisterNodesResponse";
	case ObjectId::RegisterNodesResponse_Encoding_DefaultXml:
		return "RegisterNodesResponse_Encoding_DefaultXml";
	case ObjectId::RegisterNodesResponse_Encoding_DefaultBinary:
		return "RegisterNodesResponse_Encoding_DefaultBinary";
	case ObjectId::UnregisterNodesRequest:
		return "UnregisterNodesRequest";
	case ObjectId::UnregisterNodesRequest_Encoding_DefaultXml:
		return "UnregisterNodesRequest_Encoding_DefaultXml";
	case ObjectId::UnregisterNodesRequest_Encoding_DefaultBinary:
		return "UnregisterNodesRequest_Encoding_DefaultBinary";
	case ObjectId::UnregisterNodesResponse:
		return "UnregisterNodesResponse";
	case ObjectId::UnregisterNodesResponse_Encoding_DefaultXml:
		return "UnregisterNodesResponse_Encoding_DefaultXml";
	case ObjectId::UnregisterNodesResponse_Encoding_DefaultBinary:
		return "UnregisterNodesResponse_Encoding_DefaultBinary";
	case ObjectId::QueryDataDescription:
		return "QueryDataDescription";
	case ObjectId::QueryDataDescription_Encoding_DefaultXml:
		return "QueryDataDescription_Encoding_DefaultXml";
	case ObjectId::QueryDataDescription_Encoding_DefaultBinary:
		return "QueryDataDescription_Encoding_DefaultBinary";
	case ObjectId::NodeTypeDescription:
		return "NodeTypeDescription";
	case ObjectId::NodeTypeDescription_Encoding_DefaultXml:
		return "NodeTypeDescription_Encoding_DefaultXml";
	case ObjectId::NodeTypeDescription_Encoding_DefaultBinary:
		return "NodeTypeDescription_Encoding_DefaultBinary";
	case ObjectId::FilterOperator:
		return "FilterOperator";
	case ObjectId::QueryDataSet:
		return "QueryDataSet";
	case ObjectId::QueryDataSet_Encoding_DefaultXml:
		return "QueryDataSet_Encoding_DefaultXml";
	case ObjectId::QueryDataSet_Encoding_DefaultBinary:
		return "QueryDataSet_Encoding_DefaultBinary";
	case ObjectId::NodeReference:
		return "NodeReference";
	case ObjectId::NodeReference_Encoding_DefaultXml:
		return "NodeReference_Encoding_DefaultXml";
	case ObjectId::NodeReference_Encoding_DefaultBinary:
		return "NodeReference_Encoding_DefaultBinary";
	case ObjectId::ContentFilterElement:
		return "ContentFilterElement";
	case ObjectId::ContentFilterElement_Encoding_DefaultXml:
		return "ContentFilterElement_Encoding_DefaultXml";
	case ObjectId::ContentFilterElement_Encoding_DefaultBinary:
		return "ContentFilterElement_Encoding_DefaultBinary";
	case ObjectId::ContentFilter:
		return "ContentFilter";
	case ObjectId::ContentFilter_Encoding_DefaultXml:
		return "ContentFilter_Encoding_DefaultXml";
	case ObjectId::ContentFilter_Encoding_DefaultBinary:
		return "ContentFilter_Encoding_DefaultBinary";
	case ObjectId::FilterOperand:
		return "FilterOperand";
	case ObjectId::FilterOperand_Encoding_DefaultXml:
		return "FilterOperand_Encoding_DefaultXml";
	case ObjectId::FilterOperand_Encoding_DefaultBinary:
		return "FilterOperand_Encoding_DefaultBinary";
	case ObjectId::ElementOperand:
		return "ElementOperand";
	case ObjectId::ElementOperand_Encoding_DefaultXml:
		return "ElementOperand_Encoding_DefaultXml";
	case ObjectId::ElementOperand_Encoding_DefaultBinary:
		return "ElementOperand_Encoding_DefaultBinary";
	case ObjectId::LiteralOperand:
		return "LiteralOperand";
	case ObjectId::LiteralOperand_Encoding_DefaultXml:
		return "LiteralOperand_Encoding_DefaultXml";
	case ObjectId::LiteralOperand_Encoding_DefaultBinary:
		return "LiteralOperand_Encoding_DefaultBinary";
	case ObjectId::AttributeOperand:
		return "AttributeOperand";
	case ObjectId::AttributeOperand_Encoding_DefaultXml:
		return "AttributeOperand_Encoding_DefaultXml";
	case ObjectId::AttributeOperand_Encoding_DefaultBinary:
		return "AttributeOperand_Encoding_DefaultBinary";
	case ObjectId::SimpleAttributeOperand:
		return "SimpleAttributeOperand";
	case ObjectId::SimpleAttributeOperand_Encoding_DefaultXml:
		return "SimpleAttributeOperand_Encoding_DefaultXml";
	case ObjectId::SimpleAttributeOperand_Encoding_DefaultBinary:
		return "SimpleAttributeOperand_Encoding_DefaultBinary";
	case ObjectId::ContentFilterElementResult:
		return "ContentFilterElementResult";
	case ObjectId::ContentFilterElementResult_Encoding_DefaultXml:
		return "ContentFilterElementResult_Encoding_DefaultXml";
	case ObjectId::ContentFilterElementResult_Encoding_DefaultBinary:
		return "ContentFilterElementResult_Encoding_DefaultBinary";
	case ObjectId::ContentFilterResult:
		return "ContentFilterResult";
	case ObjectId::ContentFilterResult_Encoding_DefaultXml:
		return "ContentFilterResult_Encoding_DefaultXml";
	case ObjectId::ContentFilterResult_Encoding_DefaultBinary:
		return "ContentFilterResult_Encoding_DefaultBinary";
	case ObjectId::ParsingResult:
		return "ParsingResult";
	case ObjectId::ParsingResult_Encoding_DefaultXml:
		return "ParsingResult_Encoding_DefaultXml";
	case ObjectId::ParsingResult_Encoding_DefaultBinary:
		return "ParsingResult_Encoding_DefaultBinary";
	case ObjectId::QueryFirstRequest:
		return "QueryFirstRequest";
	case ObjectId::QueryFirstRequest_Encoding_DefaultXml:
		return "QueryFirstRequest_Encoding_DefaultXml";
	case ObjectId::QueryFirstRequest_Encoding_DefaultBinary:
		return "QueryFirstRequest_Encoding_DefaultBinary";
	case ObjectId::QueryFirstResponse:
		return "QueryFirstResponse";
	case ObjectId::QueryFirstResponse_Encoding_DefaultXml:
		return "QueryFirstResponse_Encoding_DefaultXml";
	case ObjectId::QueryFirstResponse_Encoding_DefaultBinary:
		return "QueryFirstResponse_Encoding_DefaultBinary";
	case ObjectId::QueryNextRequest:
		return "QueryNextRequest";
	case ObjectId::QueryNextRequest_Encoding_DefaultXml:
		return "QueryNextRequest_Encoding_DefaultXml";
	case ObjectId::QueryNextRequest_Encoding_DefaultBinary:
		return "QueryNextRequest_Encoding_DefaultBinary";
	case ObjectId::QueryNextResponse:
		return "QueryNextResponse";
	case ObjectId::QueryNextResponse_Encoding_DefaultXml:
		return "QueryNextResponse_Encoding_DefaultXml";
	case ObjectId::QueryNextResponse_Encoding_DefaultBinary:
		return "QueryNextResponse_Encoding_DefaultBinary";
	case ObjectId::TimestampsToReturn:
		return "TimestampsToReturn";
	case ObjectId::ReadValueId:
		return "ReadValueId";
	case ObjectId::ReadValueId_Encoding_DefaultXml:
		return "ReadValueId_Encoding_DefaultXml";
	case ObjectId::ReadValueId_Encoding_DefaultBinary:
		return "ReadValueId_Encoding_DefaultBinary";
	case ObjectId::ReadRequest:
		return "ReadRequest";
	case ObjectId::ReadRequest_Encoding_DefaultXml:
		return "ReadRequest_Encoding_DefaultXml";
	case ObjectId::ReadRequest_Encoding_DefaultBinary:
		return "ReadRequest_Encoding_DefaultBinary";
	case ObjectId::ReadResponse:
		return "ReadResponse";
	case ObjectId::ReadResponse_Encoding_DefaultXml:
		return "ReadResponse_Encoding_DefaultXml";
	case ObjectId::ReadResponse_Encoding_DefaultBinary:
		return "ReadResponse_Encoding_DefaultBinary";
	case ObjectId::HistoryReadValueId:
		return "HistoryReadValueId";
	case ObjectId::HistoryReadValueId_Encoding_DefaultXml:
		return "HistoryReadValueId_Encoding_DefaultXml";
	case ObjectId::HistoryReadValueId_Encoding_DefaultBinary:
		return "HistoryReadValueId_Encoding_DefaultBinary";
	case ObjectId::HistoryReadResult:
		return "HistoryReadResult";
	case ObjectId::HistoryReadResult_Encoding_DefaultXml:
		return "HistoryReadResult_Encoding_DefaultXml";
	case ObjectId::HistoryReadResult_Encoding_DefaultBinary:
		return "HistoryReadResult_Encoding_DefaultBinary";
	case ObjectId::HistoryReadDetails:
		return "HistoryReadDetails";
	case ObjectId::HistoryReadDetails_Encoding_DefaultXml:
		return "HistoryReadDetails_Encoding_DefaultXml";
	case ObjectId::HistoryReadDetails_Encoding_DefaultBinary:
		return "HistoryReadDetails_Encoding_DefaultBinary";
	case ObjectId::ReadEventDetails:
		return "ReadEventDetails";
	case ObjectId::ReadEventDetails_Encoding_DefaultXml:
		return "ReadEventDetails_Encoding_DefaultXml";
	case ObjectId::ReadEventDetails_Encoding_DefaultBinary:
		return "ReadEventDetails_Encoding_DefaultBinary";
	case ObjectId::ReadRawModifiedDetails:
		return "ReadRawModifiedDetails";
	case ObjectId::ReadRawModifiedDetails_Encoding_DefaultXml:
		return "ReadRawModifiedDetails_Encoding_DefaultXml";
	case ObjectId::ReadRawModifiedDetails_Encoding_DefaultBinary:
		return "ReadRawModifiedDetails_Encoding_DefaultBinary";
	case ObjectId::ReadProcessedDetails:
		return "ReadProcessedDetails";
	case ObjectId::ReadProcessedDetails_Encoding_DefaultXml:
		return "ReadProcessedDetails_Encoding_DefaultXml";
	case ObjectId::ReadProcessedDetails_Encoding_DefaultBinary:
		return "ReadProcessedDetails_Encoding_DefaultBinary";
	case ObjectId::ReadAtTimeDetails:
		return "ReadAtTimeDetails";
	case ObjectId::ReadAtTimeDetails_Encoding_DefaultXml:
		return "ReadAtTimeDetails_Encoding_DefaultXml";
	case ObjectId::ReadAtTimeDetails_Encoding_DefaultBinary:
		return "ReadAtTimeDetails_Encoding_DefaultBinary";
	case ObjectId::HistoryData:
		return "HistoryData";
	case ObjectId::HistoryData_Encoding_DefaultXml:
		return "HistoryData_Encoding_DefaultXml";
	case ObjectId::HistoryData_Encoding_DefaultBinary:
		return "HistoryData_Encoding_DefaultBinary";
	case ObjectId::HistoryEvent:
		return "HistoryEvent";
	case ObjectId::HistoryEvent_Encoding_DefaultXml:
		return "HistoryEvent_Encoding_DefaultXml";
	case ObjectId::HistoryEvent_Encoding_DefaultBinary:
		return "HistoryEvent_Encoding_DefaultBinary";
	case ObjectId::HistoryReadRequest:
		return "HistoryReadRequest";
	case ObjectId::HistoryReadRequest_Encoding_DefaultXml:
		return "HistoryReadRequest_Encoding_DefaultXml";
	case ObjectId::HistoryReadRequest_Encoding_DefaultBinary:
		return "HistoryReadRequest_Encoding_DefaultBinary";
	case ObjectId::HistoryReadResponse:
		return "HistoryReadResponse";
	case ObjectId::HistoryReadResponse_Encoding_DefaultXml:
		return "HistoryReadResponse_Encoding_DefaultXml";
	case ObjectId::HistoryReadResponse_Encoding_DefaultBinary:
		return "HistoryReadResponse_Encoding_DefaultBinary";
	case ObjectId::WriteValue:
		return "WriteValue";
	case ObjectId::WriteValue_Encoding_DefaultXml:
		return "WriteValue_Encoding_DefaultXml";
	case ObjectId::WriteValue_Encoding_DefaultBinary:
		return "WriteValue_Encoding_DefaultBinary";
	case ObjectId::WriteRequest:
		return "WriteRequest";
	case ObjectId::WriteRequest_Encoding_DefaultXml:
		return "WriteRequest_Encoding_DefaultXml";
	case ObjectId::WriteRequest_Encoding_DefaultBinary:
		return "WriteRequest_Encoding_DefaultBinary";
	case ObjectId::WriteResponse:
		return "WriteResponse";
	case ObjectId::WriteResponse_Encoding_DefaultXml:
		return "WriteResponse_Encoding_DefaultXml";
	case ObjectId::WriteResponse_Encoding_DefaultBinary:
		return "WriteResponse_Encoding_DefaultBinary";
	case ObjectId::HistoryUpdateDetails:
		return "HistoryUpdateDetails";
	case ObjectId::HistoryUpdateDetails_Encoding_DefaultXml:
		return "HistoryUpdateDetails_Encoding_DefaultXml";
	case ObjectId::HistoryUpdateDetails_Encoding_DefaultBinary:
		return "HistoryUpdateDetails_Encoding_DefaultBinary";
	case ObjectId::UpdateDataDetails:
		return "UpdateDataDetails";
	case ObjectId::UpdateDataDetails_Encoding_DefaultXml:
		return "UpdateDataDetails_Encoding_DefaultXml";
	case ObjectId::UpdateDataDetails_Encoding_DefaultBinary:
		return "UpdateDataDetails_Encoding_DefaultBinary";
	case ObjectId::UpdateEventDetails:
		return "UpdateEventDetails";
	case ObjectId::UpdateEventDetails_Encoding_DefaultXml:
		return "UpdateEventDetails_Encoding_DefaultXml";
	case ObjectId::UpdateEventDetails_Encoding_DefaultBinary:
		return "UpdateEventDetails_Encoding_DefaultBinary";
	case ObjectId::DeleteRawModifiedDetails:
		return "DeleteRawModifiedDetails";
	case ObjectId::DeleteRawModifiedDetails_Encoding_DefaultXml:
		return "DeleteRawModifiedDetails_Encoding_DefaultXml";
	case ObjectId::DeleteRawModifiedDetails_Encoding_DefaultBinary:
		return "DeleteRawModifiedDetails_Encoding_DefaultBinary";
	case ObjectId::DeleteAtTimeDetails:
		return "DeleteAtTimeDetails";
	case ObjectId::DeleteAtTimeDetails_Encoding_DefaultXml:
		return "DeleteAtTimeDetails_Encoding_DefaultXml";
	case ObjectId::DeleteAtTimeDetails_Encoding_DefaultBinary:
		return "DeleteAtTimeDetails_Encoding_DefaultBinary";
	case ObjectId::DeleteEventDetails:
		return "DeleteEventDetails";
	case ObjectId::DeleteEventDetails_Encoding_DefaultXml:
		return "DeleteEventDetails_Encoding_DefaultXml";
	case ObjectId::DeleteEventDetails_Encoding_DefaultBinary:
		return "DeleteEventDetails_Encoding_DefaultBinary";
	case ObjectId::HistoryUpdateResult:
		return "HistoryUpdateResult";
	case ObjectId::HistoryUpdateResult_Encoding_DefaultXml:
		return "HistoryUpdateResult_Encoding_DefaultXml";
	case ObjectId::HistoryUpdateResult_Encoding_DefaultBinary:
		return "HistoryUpdateResult_Encoding_DefaultBinary";
	case ObjectId::HistoryUpdateRequest:
		return "HistoryUpdateRequest";
	case ObjectId::HistoryUpdateRequest_Encoding_DefaultXml:
		return "HistoryUpdateRequest_Encoding_DefaultXml";
	case ObjectId::HistoryUpdateRequest_Encoding_DefaultBinary:
		return "HistoryUpdateRequest_Encoding_DefaultBinary";
	case ObjectId::HistoryUpdateResponse:
		return "HistoryUpdateResponse";
	case ObjectId::HistoryUpdateResponse_Encoding_DefaultXml:
		return "HistoryUpdateResponse_Encoding_DefaultXml";
	case ObjectId::HistoryUpdateResponse_Encoding_DefaultBinary:
		return "HistoryUpdateResponse_Encoding_DefaultBinary";
	case ObjectId::CallMethodRequest:
		return "CallMethodRequest";
	case ObjectId::CallMethodRequest_Encoding_DefaultXml:
		return "CallMethodRequest_Encoding_DefaultXml";
	case ObjectId::CallMethodRequest_Encoding_DefaultBinary:
		return "CallMethodRequest_Encoding_DefaultBinary";
	case ObjectId::CallMethodResult:
		return "CallMethodResult";
	case ObjectId::CallMethodResult_Encoding_DefaultXml:
		return "CallMethodResult_Encoding_DefaultXml";
	case ObjectId::CallMethodResult_Encoding_DefaultBinary:
		return "CallMethodResult_Encoding_DefaultBinary";
	case ObjectId::CallRequest:
		return "CallRequest";
	case ObjectId::CallRequest_Encoding_DefaultXml:
		return "CallRequest_Encoding_DefaultXml";
	case ObjectId::CallRequest_Encoding_DefaultBinary:
		return "CallRequest_Encoding_DefaultBinary";
	case ObjectId::CallResponse:
		return "CallResponse";
	case ObjectId::CallResponse_Encoding_DefaultXml:
		return "CallResponse_Encoding_DefaultXml";
	case ObjectId::CallResponse_Encoding_DefaultBinary:
		return "CallResponse_Encoding_DefaultBinary";
	case ObjectId::MonitoringMode:
		return "MonitoringMode";
	case ObjectId::DataChangeTrigger:
		return "DataChangeTrigger";
	case ObjectId::DeadbandType:
		return "DeadbandType";
	case ObjectId::MonitoringFilter:
		return "MonitoringFilter";
	case ObjectId::MonitoringFilter_Encoding_DefaultXml:
		return "MonitoringFilter_Encoding_DefaultXml";
	case ObjectId::MonitoringFilter_Encoding_DefaultBinary:
		return "MonitoringFilter_Encoding_DefaultBinary";
	case ObjectId::DataChangeFilter:
		return "DataChangeFilter";
	case ObjectId::DataChangeFilter_Encoding_DefaultXml:
		return "DataChangeFilter_Encoding_DefaultXml";
	case ObjectId::DataChangeFilter_Encoding_DefaultBinary:
		return "DataChangeFilter_Encoding_DefaultBinary";
	case ObjectId::EventFilter:
		return "EventFilter";
	case ObjectId::EventFilter_Encoding_DefaultXml:
		return "EventFilter_Encoding_DefaultXml";
	case ObjectId::EventFilter_Encoding_DefaultBinary:
		return "EventFilter_Encoding_DefaultBinary";
	case ObjectId::AggregateFilter:
		return "AggregateFilter";
	case ObjectId::AggregateFilter_Encoding_DefaultXml:
		return "AggregateFilter_Encoding_DefaultXml";
	case ObjectId::AggregateFilter_Encoding_DefaultBinary:
		return "AggregateFilter_Encoding_DefaultBinary";
	case ObjectId::MonitoringFilterResult:
		return "MonitoringFilterResult";
	case ObjectId::MonitoringFilterResult_Encoding_DefaultXml:
		return "MonitoringFilterResult_Encoding_DefaultXml";
	case ObjectId::MonitoringFilterResult_Encoding_DefaultBinary:
		return "MonitoringFilterResult_Encoding_DefaultBinary";
	case ObjectId::EventFilterResult:
		return "EventFilterResult";
	case ObjectId::EventFilterResult_Encoding_DefaultXml:
		return "EventFilterResult_Encoding_DefaultXml";
	case ObjectId::EventFilterResult_Encoding_DefaultBinary:
		return "EventFilterResult_Encoding_DefaultBinary";
	case ObjectId::AggregateFilterResult:
		return "AggregateFilterResult";
	case ObjectId::AggregateFilterResult_Encoding_DefaultXml:
		return "AggregateFilterResult_Encoding_DefaultXml";
	case ObjectId::AggregateFilterResult_Encoding_DefaultBinary:
		return "AggregateFilterResult_Encoding_DefaultBinary";
	case ObjectId::MonitoringParameters:
		return "MonitoringParameters";
	case ObjectId::MonitoringParameters_Encoding_DefaultXml:
		return "MonitoringParameters_Encoding_DefaultXml";
	case ObjectId::MonitoringParameters_Encoding_DefaultBinary:
		return "MonitoringParameters_Encoding_DefaultBinary";
	case ObjectId::MonitoredItemCreateRequest:
		return "MonitoredItemCreateRequest";
	case ObjectId::MonitoredItemCreateRequest_Encoding_DefaultXml:
		return "MonitoredItemCreateRequest_Encoding_DefaultXml";
	case ObjectId::MonitoredItemCreateRequest_Encoding_DefaultBinary:
		return "MonitoredItemCreateRequest_Encoding_DefaultBinary";
	case ObjectId::MonitoredItemCreateResult:
		return "MonitoredItemCreateResult";
	case ObjectId::MonitoredItemCreateResult_Encoding_DefaultXml:
		return "MonitoredItemCreateResult_Encoding_DefaultXml";
	case ObjectId::MonitoredItemCreateResult_Encoding_DefaultBinary:
		return "MonitoredItemCreateResult_Encoding_DefaultBinary";
	case ObjectId::CreateMonitoredItemsRequest:
		return "CreateMonitoredItemsRequest";
	case ObjectId::CreateMonitoredItemsRequest_Encoding_DefaultXml:
		return "CreateMonitoredItemsRequest_Encoding_DefaultXml";
	case ObjectId::CreateMonitoredItemsRequest_Encoding_DefaultBinary:
		return "CreateMonitoredItemsRequest_Encoding_DefaultBinary";
	case ObjectId::CreateMonitoredItemsResponse:
		return "CreateMonitoredItemsResponse";
	case ObjectId::CreateMonitoredItemsResponse_Encoding_DefaultXml:
		return "CreateMonitoredItemsResponse_Encoding_DefaultXml";
	case ObjectId::CreateMonitoredItemsResponse_Encoding_DefaultBinary:
		return "CreateMonitoredItemsResponse_Encoding_DefaultBinary";
	case ObjectId::MonitoredItemModifyRequest:
		return "MonitoredItemModifyRequest";
	case ObjectId::MonitoredItemModifyRequest_Encoding_DefaultXml:
		return "MonitoredItemModifyRequest_Encoding_DefaultXml";
	case ObjectId::MonitoredItemModifyRequest_Encoding_DefaultBinary:
		return "MonitoredItemModifyRequest_Encoding_DefaultBinary";
	case ObjectId::MonitoredItemModifyResult:
		return "MonitoredItemModifyResult";
	case ObjectId::MonitoredItemModifyResult_Encoding_DefaultXml:
		return "MonitoredItemModifyResult_Encoding_DefaultXml";
	case ObjectId::MonitoredItemModifyResult_Encoding_DefaultBinary:
		return "MonitoredItemModifyResult_Encoding_DefaultBinary";
	case ObjectId::ModifyMonitoredItemsRequest:
		return "ModifyMonitoredItemsRequest";
	case ObjectId::ModifyMonitoredItemsRequest_Encoding_DefaultXml:
		return "ModifyMonitoredItemsRequest_Encoding_DefaultXml";
	case ObjectId::ModifyMonitoredItemsRequest_Encoding_DefaultBinary:
		return "ModifyMonitoredItemsRequest_Encoding_DefaultBinary";
	case ObjectId::ModifyMonitoredItemsResponse:
		return "ModifyMonitoredItemsResponse";
	case ObjectId::ModifyMonitoredItemsResponse_Encoding_DefaultXml:
		return "ModifyMonitoredItemsResponse_Encoding_DefaultXml";
	case ObjectId::ModifyMonitoredItemsResponse_Encoding_DefaultBinary:
		return "ModifyMonitoredItemsResponse_Encoding_DefaultBinary";
	case ObjectId::SetMonitoringModeRequest:
		return "SetMonitoringModeRequest";
	case ObjectId::SetMonitoringModeRequest_Encoding_DefaultXml:
		return "SetMonitoringModeRequest_Encoding_DefaultXml";
	case ObjectId::SetMonitoringModeRequest_Encoding_DefaultBinary:
		return "SetMonitoringModeRequest_Encoding_DefaultBinary";
	case ObjectId::SetMonitoringModeResponse:
		return "SetMonitoringModeResponse";
	case ObjectId::SetMonitoringModeResponse_Encoding_DefaultXml:
		return "SetMonitoringModeResponse_Encoding_DefaultXml";
	case ObjectId::SetMonitoringModeResponse_Encoding_DefaultBinary:
		return "SetMonitoringModeResponse_Encoding_DefaultBinary";
	case ObjectId::SetTriggeringRequest:
		return "SetTriggeringRequest";
	case ObjectId::SetTriggeringRequest_Encoding_DefaultXml:
		return "SetTriggeringRequest_Encoding_DefaultXml";
	case ObjectId::SetTriggeringRequest_Encoding_DefaultBinary:
		return "SetTriggeringRequest_Encoding_DefaultBinary";
	case ObjectId::SetTriggeringResponse:
		return "SetTriggeringResponse";
	case ObjectId::SetTriggeringResponse_Encoding_DefaultXml:
		return "SetTriggeringResponse_Encoding_DefaultXml";
	case ObjectId::SetTriggeringResponse_Encoding_DefaultBinary:
		return "SetTriggeringResponse_Encoding_DefaultBinary";
	case ObjectId::DeleteMonitoredItemsRequest:
		return "DeleteMonitoredItemsRequest";
	case ObjectId::DeleteMonitoredItemsRequest_Encoding_DefaultXml:
		return "DeleteMonitoredItemsRequest_Encoding_DefaultXml";
	case ObjectId::DeleteMonitoredItemsRequest_Encoding_DefaultBinary:
		return "DeleteMonitoredItemsRequest_Encoding_DefaultBinary";
	case ObjectId::DeleteMonitoredItemsResponse:
		return "DeleteMonitoredItemsResponse";
	case ObjectId::DeleteMonitoredItemsResponse_Encoding_DefaultXml:
		return "DeleteMonitoredItemsResponse_Encoding_DefaultXml";
	case ObjectId::DeleteMonitoredItemsResponse_Encoding_DefaultBinary:
		return "DeleteMonitoredItemsResponse_Encoding_DefaultBinary";
	case ObjectId::CreateSubscriptionRequest:
		return "CreateSubscriptionRequest";
	case ObjectId::CreateSubscriptionRequest_Encoding_DefaultXml:
		return "CreateSubscriptionRequest_Encoding_DefaultXml";
	case ObjectId::CreateSubscriptionRequest_Encoding_DefaultBinary:
		return "CreateSubscriptionRequest_Encoding_DefaultBinary";
	case ObjectId::CreateSubscriptionResponse:
		return "CreateSubscriptionResponse";
	case ObjectId::CreateSubscriptionResponse_Encoding_DefaultXml:
		return "CreateSubscriptionResponse_Encoding_DefaultXml";
	case ObjectId::CreateSubscriptionResponse_Encoding_DefaultBinary:
		return "CreateSubscriptionResponse_Encoding_DefaultBinary";
	case ObjectId::ModifySubscriptionRequest:
		return "ModifySubscriptionRequest";
	case ObjectId::ModifySubscriptionRequest_Encoding_DefaultXml:
		return "ModifySubscriptionRequest_Encoding_DefaultXml";
	case ObjectId::ModifySubscriptionRequest_Encoding_DefaultBinary:
		return "ModifySubscriptionRequest_Encoding_DefaultBinary";
	case ObjectId::ModifySubscriptionResponse:
		return "ModifySubscriptionResponse";
	case ObjectId::ModifySubscriptionResponse_Encoding_DefaultXml:
		return "ModifySubscriptionResponse_Encoding_DefaultXml";
	case ObjectId::ModifySubscriptionResponse_Encoding_DefaultBinary:
		return "ModifySubscriptionResponse_Encoding_DefaultBinary";
	case ObjectId::SetPublishingModeRequest:
		return "SetPublishingModeRequest";
	case ObjectId::SetPublishingModeRequest_Encoding_DefaultXml:
		return "SetPublishingModeRequest_Encoding_DefaultXml";
	case ObjectId::SetPublishingModeRequest_Encoding_DefaultBinary:
		return "SetPublishingModeRequest_Encoding_DefaultBinary";
	case ObjectId::SetPublishingModeResponse:
		return "SetPublishingModeResponse";
	case ObjectId::SetPublishingModeResponse_Encoding_DefaultXml:
		return "SetPublishingModeResponse_Encoding_DefaultXml";
	case ObjectId::SetPublishingModeResponse_Encoding_DefaultBinary:
		return "SetPublishingModeResponse_Encoding_DefaultBinary";
	case ObjectId::NotificationMessage:
		return "NotificationMessage";
	case ObjectId::NotificationMessage_Encoding_DefaultXml:
		return "NotificationMessage_Encoding_DefaultXml";
	case ObjectId::NotificationMessage_Encoding_DefaultBinary:
		return "NotificationMessage_Encoding_DefaultBinary";
	case ObjectId::MonitoredItemNotification:
		return "MonitoredItemNotification";
	case ObjectId::MonitoredItemNotification_Encoding_DefaultXml:
		return "MonitoredItemNotification_Encoding_DefaultXml";
	case ObjectId::MonitoredItemNotification_Encoding_DefaultBinary:
		return "MonitoredItemNotification_Encoding_DefaultBinary";
	case ObjectId::DataChangeNotification:
		return "DataChangeNotification";
	case ObjectId::DataChangeNotification_Encoding_DefaultXml:
		return "DataChangeNotification_Encoding_DefaultXml";
	case ObjectId::DataChangeNotification_Encoding_DefaultBinary:
		return "DataChangeNotification_Encoding_DefaultBinary";
	case ObjectId::StatusChangeNotification:
		return "StatusChangeNotification";
	case ObjectId::StatusChangeNotification_Encoding_DefaultXml:
		return "StatusChangeNotification_Encoding_DefaultXml";
	case ObjectId::StatusChangeNotification_Encoding_DefaultBinary:
		return "StatusChangeNotification_Encoding_DefaultBinary";
	case ObjectId::SubscriptionAcknowledgement:
		return "SubscriptionAcknowledgement";
	case ObjectId::SubscriptionAcknowledgement_Encoding_DefaultXml:
		return "SubscriptionAcknowledgement_Encoding_DefaultXml";
	case ObjectId::SubscriptionAcknowledgement_Encoding_DefaultBinary:
		return "SubscriptionAcknowledgement_Encoding_DefaultBinary";
	case ObjectId::PublishRequest:
		return "PublishRequest";
	case ObjectId::PublishRequest_Encoding_DefaultXml:
		return "PublishRequest_Encoding_DefaultXml";
	case ObjectId::PublishRequest_Encoding_DefaultBinary:
		return "PublishRequest_Encoding_DefaultBinary";
	case ObjectId::PublishResponse:
		return "PublishResponse";
	case ObjectId::PublishResponse_Encoding_DefaultXml:
		return "PublishResponse_Encoding_DefaultXml";
	case ObjectId::PublishResponse_Encoding_DefaultBinary:
		return "PublishResponse_Encoding_DefaultBinary";
	case ObjectId::RepublishRequest:
		return "RepublishRequest";
	case ObjectId::RepublishRequest_Encoding_DefaultXml:
		return "RepublishRequest_Encoding_DefaultXml";
	case ObjectId::RepublishRequest_Encoding_DefaultBinary:
		return "RepublishRequest_Encoding_DefaultBinary";
	case ObjectId::RepublishResponse:
		return "RepublishResponse";
	case ObjectId::RepublishResponse_Encoding_DefaultXml:
		return "RepublishResponse_Encoding_DefaultXml";
	case ObjectId::RepublishResponse_Encoding_DefaultBinary:
		return "RepublishResponse_Encoding_DefaultBinary";
	case ObjectId::TransferResult:
		return "TransferResult";
	case ObjectId::TransferResult_Encoding_DefaultXml:
		return "TransferResult_Encoding_DefaultXml";
	case ObjectId::TransferResult_Encoding_DefaultBinary:
		return "TransferResult_Encoding_DefaultBinary";
	case ObjectId::TransferSubscriptionsRequest:
		return "TransferSubscriptionsRequest";
	case ObjectId::TransferSubscriptionsRequest_Encoding_DefaultXml:
		return "TransferSubscriptionsRequest_Encoding_DefaultXml";
	case ObjectId::TransferSubscriptionsRequest_Encoding_DefaultBinary:
		return "TransferSubscriptionsRequest_Encoding_DefaultBinary";
	case ObjectId::TransferSubscriptionsResponse:
		return "TransferSubscriptionsResponse";
	case ObjectId::TransferSubscriptionsResponse_Encoding_DefaultXml:
		return "TransferSubscriptionsResponse_Encoding_DefaultXml";
	case ObjectId::TransferSubscriptionsResponse_Encoding_DefaultBinary:
		return "TransferSubscriptionsResponse_Encoding_DefaultBinary";
	case ObjectId::DeleteSubscriptionsRequest:
		return "DeleteSubscriptionsRequest";
	case ObjectId::DeleteSubscriptionsRequest_Encoding_DefaultXml:
		return "DeleteSubscriptionsRequest_Encoding_DefaultXml";
	case ObjectId::DeleteSubscriptionsRequest_Encoding_DefaultBinary:
		return "DeleteSubscriptionsRequest_Encoding_DefaultBinary";
	case ObjectId::DeleteSubscriptionsResponse:
		return "DeleteSubscriptionsResponse";
	case ObjectId::DeleteSubscriptionsResponse_Encoding_DefaultXml:
		return "DeleteSubscriptionsResponse_Encoding_DefaultXml";
	case ObjectId::DeleteSubscriptionsResponse_Encoding_DefaultBinary:
		return "DeleteSubscriptionsResponse_Encoding_DefaultBinary";
	case ObjectId::RedundancySupport:
		return "RedundancySupport";
	case ObjectId::ServerState:
		return "ServerState";
	case ObjectId::RedundantServerDataType:
		return "RedundantServerDataType";
	case ObjectId::RedundantServerDataType_Encoding_DefaultXml:
		return "RedundantServerDataType_Encoding_DefaultXml";
	case ObjectId::RedundantServerDataType_Encoding_DefaultBinary:
		return "RedundantServerDataType_Encoding_DefaultBinary";
	case ObjectId::SamplingIntervalDiagnosticsDataType:
		return "SamplingIntervalDiagnosticsDataType";
	case ObjectId::SamplingIntervalDiagnosticsDataType_Encoding_DefaultXml:
		return "SamplingIntervalDiagnosticsDataType_Encoding_DefaultXml";
	case ObjectId::SamplingIntervalDiagnosticsDataType_Encoding_DefaultBinary:
		return "SamplingIntervalDiagnosticsDataType_Encoding_DefaultBinary";
	case ObjectId::ServerDiagnosticsSummaryDataType:
		return "ServerDiagnosticsSummaryDataType";
	case ObjectId::ServerDiagnosticsSummaryDataType_Encoding_DefaultXml:
		return "ServerDiagnosticsSummaryDataType_Encoding_DefaultXml";
	case ObjectId::ServerDiagnosticsSummaryDataType_Encoding_DefaultBinary:
		return "ServerDiagnosticsSummaryDataType_Encoding_DefaultBinary";
	case ObjectId::ServerStatusDataType:
		return "ServerStatusDataType";
	case ObjectId::ServerStatusDataType_Encoding_DefaultXml:
		return "ServerStatusDataType_Encoding_DefaultXml";
	case ObjectId::ServerStatusDataType_Encoding_DefaultBinary:
		return "ServerStatusDataType_Encoding_DefaultBinary";
	case ObjectId::SessionDiagnosticsDataType:
		return "SessionDiagnosticsDataType";
	case ObjectId::SessionDiagnosticsDataType_Encoding_DefaultXml:
		return "SessionDiagnosticsDataType_Encoding_DefaultXml";
	case ObjectId::SessionDiagnosticsDataType_Encoding_DefaultBinary:
		return "SessionDiagnosticsDataType_Encoding_DefaultBinary";
	case ObjectId::SessionSecurityDiagnosticsDataType:
		return "SessionSecurityDiagnosticsDataType";
	case ObjectId::SessionSecurityDiagnosticsDataType_Encoding_DefaultXml:
		return "SessionSecurityDiagnosticsDataType_Encoding_DefaultXml";
	case ObjectId::SessionSecurityDiagnosticsDataType_Encoding_DefaultBinary:
		return "SessionSecurityDiagnosticsDataType_Encoding_DefaultBinary";
	case ObjectId::ServiceCounterDataType:
		return "ServiceCounterDataType";
	case ObjectId::ServiceCounterDataType_Encoding_DefaultXml:
		return "ServiceCounterDataType_Encoding_DefaultXml";
	case ObjectId::ServiceCounterDataType_Encoding_DefaultBinary:
		return "ServiceCounterDataType_Encoding_DefaultBinary";
	case ObjectId::SubscriptionDiagnosticsDataType:
		return "SubscriptionDiagnosticsDataType";
	case ObjectId::SubscriptionDiagnosticsDataType_Encoding_DefaultXml:
		return "SubscriptionDiagnosticsDataType_Encoding_DefaultXml";
	case ObjectId::SubscriptionDiagnosticsDataType_Encoding_DefaultBinary:
		return "SubscriptionDiagnosticsDataType_Encoding_DefaultBinary";
	case ObjectId::ModelChangeStructureDataType:
		return "ModelChangeStructureDataType";
	case ObjectId::ModelChangeStructureDataType_Encoding_DefaultXml:
		return "ModelChangeStructureDataType_Encoding_DefaultXml";
	case ObjectId::ModelChangeStructureDataType_Encoding_DefaultBinary:
		return "ModelChangeStructureDataType_Encoding_DefaultBinary";
	case ObjectId::Range:
		return "Range";
	case ObjectId::Range_Encoding_DefaultXml:
		return "Range_Encoding_DefaultXml";
	case ObjectId::Range_Encoding_DefaultBinary:
		return "Range_Encoding_DefaultBinary";
	case ObjectId::EUInformation:
		return "EUInformation";
	case ObjectId::EUInformation_Encoding_DefaultXml:
		return "EUInformation_Encoding_DefaultXml";
	case ObjectId::EUInformation_Encoding_DefaultBinary:
		return "EUInformation_Encoding_DefaultBinary";
	case ObjectId::ExceptionDeviationFormat:
		return "ExceptionDeviationFormat";
	case ObjectId::Annotation:
		return "Annotation";
	case ObjectId::Annotation_Encoding_DefaultXml:
		return "Annotation_Encoding_DefaultXml";
	case ObjectId::Annotation_Encoding_DefaultBinary:
		return "Annotation_Encoding_DefaultBinary";
	case ObjectId::ProgramDiagnosticDataType:
		return "ProgramDiagnosticDataType";
	case ObjectId::ProgramDiagnosticDataType_Encoding_DefaultXml:
		return "ProgramDiagnosticDataType_Encoding_DefaultXml";
	case ObjectId::ProgramDiagnosticDataType_Encoding_DefaultBinary:
		return "ProgramDiagnosticDataType_Encoding_DefaultBinary";
	case ObjectId::SemanticChangeStructureDataType:
		return "SemanticChangeStructureDataType";
	case ObjectId::SemanticChangeStructureDataType_Encoding_DefaultXml:
		return "SemanticChangeStructureDataType_Encoding_DefaultXml";
	case ObjectId::SemanticChangeStructureDataType_Encoding_DefaultBinary:
		return "SemanticChangeStructureDataType_Encoding_DefaultBinary";
	case ObjectId::EventNotificationList:
		return "EventNotificationList";
	case ObjectId::EventNotificationList_Encoding_DefaultXml:
		return "EventNotificationList_Encoding_DefaultXml";
	case ObjectId::EventNotificationList_Encoding_DefaultBinary:
		return "EventNotificationList_Encoding_DefaultBinary";
	case ObjectId::EventFieldList:
		return "EventFieldList";
	case ObjectId::EventFieldList_Encoding_DefaultXml:
		return "EventFieldList_Encoding_DefaultXml";
	case ObjectId::EventFieldList_Encoding_DefaultBinary:
		return "EventFieldList_Encoding_DefaultBinary";
	case ObjectId::HistoryEventFieldList:
		return "HistoryEventFieldList";
	case ObjectId::HistoryEventFieldList_Encoding_DefaultXml:
		return "HistoryEventFieldList_Encoding_DefaultXml";
	case ObjectId::HistoryEventFieldList_Encoding_DefaultBinary:
		return "HistoryEventFieldList_Encoding_DefaultBinary";
	case ObjectId::HistoryUpdateEventResult:
		return "HistoryUpdateEventResult";
	case ObjectId::HistoryUpdateEventResult_Encoding_DefaultXml:
		return "HistoryUpdateEventResult_Encoding_DefaultXml";
	case ObjectId::HistoryUpdateEventResult_Encoding_DefaultBinary:
		return "HistoryUpdateEventResult_Encoding_DefaultBinary";
	case ObjectId::IssuedIdentityToken:
		return "IssuedIdentityToken";
	case ObjectId::IssuedIdentityToken_Encoding_DefaultXml:
		return "IssuedIdentityToken_Encoding_DefaultXml";
	case ObjectId::IssuedIdentityToken_Encoding_DefaultBinary:
		return "IssuedIdentityToken_Encoding_DefaultBinary";
	case ObjectId::NotificationData:
		return "NotificationData";
	case ObjectId::NotificationData_Encoding_DefaultXml:
		return "NotificationData_Encoding_DefaultXml";
	case ObjectId::NotificationData_Encoding_DefaultBinary:
		return "NotificationData_Encoding_DefaultBinary";
	case ObjectId::AggregateConfiguration:
		return "AggregateConfiguration";
	case ObjectId::AggregateConfiguration_Encoding_DefaultXml:
		return "AggregateConfiguration_Encoding_DefaultXml";
	case ObjectId::AggregateConfiguration_Encoding_DefaultBinary:
		return "AggregateConfiguration_Encoding_DefaultBinary";
	case ObjectId::ImageBMP:
		return "ImageBMP";
	case ObjectId::ImageGIF:
		return "ImageGIF";
	case ObjectId::ImageJPG:
		return "ImageJPG";
	case ObjectId::ImagePNG:
		return "ImagePNG";
	case ObjectId::ServerType:
		return "ServerType";
	case ObjectId::ServerType_ServerArray:
		return "ServerType_ServerArray";
	case ObjectId::ServerType_NamespaceArray:
		return "ServerType_NamespaceArray";
	case ObjectId::ServerType_ServerStatus:
		return "ServerType_ServerStatus";
	case ObjectId::ServerType_ServiceLevel:
		return "ServerType_ServiceLevel";
	case ObjectId::ServerType_ServerCapabilities:
		return "ServerType_ServerCapabilities";
	case ObjectId::ServerType_ServerDiagnostics:
		return "ServerType_ServerDiagnostics";
	case ObjectId::ServerType_VendorServerInfo:
		return "ServerType_VendorServerInfo";
	case ObjectId::ServerType_ServerRedundancy:
		return "ServerType_ServerRedundancy";
	case ObjectId::ServerCapabilitiesType:
		return "ServerCapabilitiesType";
	case ObjectId::ServerCapabilitiesType_ServerProfileArray:
		return "ServerCapabilitiesType_ServerProfileArray";
	case ObjectId::ServerCapabilitiesType_LocaleIdArray:
		return "ServerCapabilitiesType_LocaleIdArray";
	case ObjectId::ServerCapabilitiesType_MinSupportedSampleRate:
		return "ServerCapabilitiesType_MinSupportedSampleRate";
	case ObjectId::ServerCapabilitiesType_ModellingRules:
		return "ServerCapabilitiesType_ModellingRules";
	case ObjectId::ServerDiagnosticsType:
		return "ServerDiagnosticsType";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary";
	case ObjectId::ServerDiagnosticsType_SamplingIntervalDiagnosticsArray:
		return "ServerDiagnosticsType_SamplingIntervalDiagnosticsArray";
	case ObjectId::ServerDiagnosticsType_SubscriptionDiagnosticsArray:
		return "ServerDiagnosticsType_SubscriptionDiagnosticsArray";
	case ObjectId::ServerDiagnosticsType_EnabledFlag:
		return "ServerDiagnosticsType_EnabledFlag";
	case ObjectId::SessionsDiagnosticsSummaryType:
		return "SessionsDiagnosticsSummaryType";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionDiagnosticsArray:
		return "SessionsDiagnosticsSummaryType_SessionDiagnosticsArray";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionSecurityDiagnosticsArray:
		return "SessionsDiagnosticsSummaryType_SessionSecurityDiagnosticsArray";
	case ObjectId::SessionDiagnosticsObjectType:
		return "SessionDiagnosticsObjectType";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics:
		return "SessionDiagnosticsObjectType_SessionDiagnostics";
	case ObjectId::SessionDiagnosticsObjectType_SessionSecurityDiagnostics:
		return "SessionDiagnosticsObjectType_SessionSecurityDiagnostics";
	case ObjectId::SessionDiagnosticsObjectType_SubscriptionDiagnosticsArray:
		return "SessionDiagnosticsObjectType_SubscriptionDiagnosticsArray";
	case ObjectId::VendorServerInfoType:
		return "VendorServerInfoType";
	case ObjectId::ServerRedundancyType:
		return "ServerRedundancyType";
	case ObjectId::ServerRedundancyType_RedundancySupport:
		return "ServerRedundancyType_RedundancySupport";
	case ObjectId::TransparentRedundancyType:
		return "TransparentRedundancyType";
	case ObjectId::TransparentRedundancyType_CurrentServerId:
		return "TransparentRedundancyType_CurrentServerId";
	case ObjectId::TransparentRedundancyType_RedundantServerArray:
		return "TransparentRedundancyType_RedundantServerArray";
	case ObjectId::NonTransparentRedundancyType:
		return "NonTransparentRedundancyType";
	case ObjectId::NonTransparentRedundancyType_ServerUriArray:
		return "NonTransparentRedundancyType_ServerUriArray";
	case ObjectId::BaseEventType:
		return "BaseEventType";
	case ObjectId::BaseEventType_EventId:
		return "BaseEventType_EventId";
	case ObjectId::BaseEventType_EventType:
		return "BaseEventType_EventType";
	case ObjectId::BaseEventType_SourceNode:
		return "BaseEventType_SourceNode";
	case ObjectId::BaseEventType_SourceName:
		return "BaseEventType_SourceName";
	case ObjectId::BaseEventType_Time:
		return "BaseEventType_Time";
	case ObjectId::BaseEventType_ReceiveTime:
		return "BaseEventType_ReceiveTime";
	case ObjectId::BaseEventType_Message:
		return "BaseEventType_Message";
	case ObjectId::BaseEventType_Severity:
		return "BaseEventType_Severity";
	case ObjectId::AuditEventType:
		return "AuditEventType";
	case ObjectId::AuditEventType_ActionTimeStamp:
		return "AuditEventType_ActionTimeStamp";
	case ObjectId::AuditEventType_Status:
		return "AuditEventType_Status";
	case ObjectId::AuditEventType_ServerId:
		return "AuditEventType_ServerId";
	case ObjectId::AuditEventType_ClientAuditEntryId:
		return "AuditEventType_ClientAuditEntryId";
	case ObjectId::AuditEventType_ClientUserId:
		return "AuditEventType_ClientUserId";
	case ObjectId::AuditSecurityEventType:
		return "AuditSecurityEventType";
	case ObjectId::AuditChannelEventType:
		return "AuditChannelEventType";
	case ObjectId::AuditOpenSecureChannelEventType:
		return "AuditOpenSecureChannelEventType";
	case ObjectId::AuditOpenSecureChannelEventType_ClientCertificate:
		return "AuditOpenSecureChannelEventType_ClientCertificate";
	case ObjectId::AuditOpenSecureChannelEventType_RequestType:
		return "AuditOpenSecureChannelEventType_RequestType";
	case ObjectId::AuditOpenSecureChannelEventType_SecurityPolicyUri:
		return "AuditOpenSecureChannelEventType_SecurityPolicyUri";
	case ObjectId::AuditOpenSecureChannelEventType_SecurityMode:
		return "AuditOpenSecureChannelEventType_SecurityMode";
	case ObjectId::AuditOpenSecureChannelEventType_RequestedLifetime:
		return "AuditOpenSecureChannelEventType_RequestedLifetime";
	case ObjectId::AuditSessionEventType:
		return "AuditSessionEventType";
	case ObjectId::AuditSessionEventType_SessionId:
		return "AuditSessionEventType_SessionId";
	case ObjectId::AuditCreateSessionEventType:
		return "AuditCreateSessionEventType";
	case ObjectId::AuditCreateSessionEventType_SecureChannelId:
		return "AuditCreateSessionEventType_SecureChannelId";
	case ObjectId::AuditCreateSessionEventType_ClientCertificate:
		return "AuditCreateSessionEventType_ClientCertificate";
	case ObjectId::AuditCreateSessionEventType_RevisedSessionTimeout:
		return "AuditCreateSessionEventType_RevisedSessionTimeout";
	case ObjectId::AuditActivateSessionEventType:
		return "AuditActivateSessionEventType";
	case ObjectId::AuditActivateSessionEventType_ClientSoftwareCertificates:
		return "AuditActivateSessionEventType_ClientSoftwareCertificates";
	case ObjectId::AuditActivateSessionEventType_UserIdentityToken:
		return "AuditActivateSessionEventType_UserIdentityToken";
	case ObjectId::AuditCancelEventType:
		return "AuditCancelEventType";
	case ObjectId::AuditCancelEventType_RequestHandle:
		return "AuditCancelEventType_RequestHandle";
	case ObjectId::AuditCertificateEventType:
		return "AuditCertificateEventType";
	case ObjectId::AuditCertificateEventType_Certificate:
		return "AuditCertificateEventType_Certificate";
	case ObjectId::AuditCertificateDataMismatchEventType:
		return "AuditCertificateDataMismatchEventType";
	case ObjectId::AuditCertificateDataMismatchEventType_InvalidHostname:
		return "AuditCertificateDataMismatchEventType_InvalidHostname";
	case ObjectId::AuditCertificateDataMismatchEventType_InvalidUri:
		return "AuditCertificateDataMismatchEventType_InvalidUri";
	case ObjectId::AuditCertificateExpiredEventType:
		return "AuditCertificateExpiredEventType";
	case ObjectId::AuditCertificateInvalidEventType:
		return "AuditCertificateInvalidEventType";
	case ObjectId::AuditCertificateUntrustedEventType:
		return "AuditCertificateUntrustedEventType";
	case ObjectId::AuditCertificateRevokedEventType:
		return "AuditCertificateRevokedEventType";
	case ObjectId::AuditCertificateMismatchEventType:
		return "AuditCertificateMismatchEventType";
	case ObjectId::AuditNodeManagementEventType:
		return "AuditNodeManagementEventType";
	case ObjectId::AuditAddNodesEventType:
		return "AuditAddNodesEventType";
	case ObjectId::AuditAddNodesEventType_NodesToAdd:
		return "AuditAddNodesEventType_NodesToAdd";
	case ObjectId::AuditDeleteNodesEventType:
		return "AuditDeleteNodesEventType";
	case ObjectId::AuditDeleteNodesEventType_NodesToDelete:
		return "AuditDeleteNodesEventType_NodesToDelete";
	case ObjectId::AuditAddReferencesEventType:
		return "AuditAddReferencesEventType";
	case ObjectId::AuditAddReferencesEventType_ReferencesToAdd:
		return "AuditAddReferencesEventType_ReferencesToAdd";
	case ObjectId::AuditDeleteReferencesEventType:
		return "AuditDeleteReferencesEventType";
	case ObjectId::AuditDeleteReferencesEventType_ReferencesToDelete:
		return "AuditDeleteReferencesEventType_ReferencesToDelete";
	case ObjectId::AuditUpdateEventType:
		return "AuditUpdateEventType";
	case ObjectId::AuditWriteUpdateEventType:
		return "AuditWriteUpdateEventType";
	case ObjectId::AuditWriteUpdateEventType_IndexRange:
		return "AuditWriteUpdateEventType_IndexRange";
	case ObjectId::AuditWriteUpdateEventType_OldValue:
		return "AuditWriteUpdateEventType_OldValue";
	case ObjectId::AuditWriteUpdateEventType_NewValue:
		return "AuditWriteUpdateEventType_NewValue";
	case ObjectId::AuditHistoryUpdateEventType:
		return "AuditHistoryUpdateEventType";
	case ObjectId::AuditUpdateMethodEventType:
		return "AuditUpdateMethodEventType";
	case ObjectId::AuditUpdateMethodEventType_MethodId:
		return "AuditUpdateMethodEventType_MethodId";
	case ObjectId::AuditUpdateMethodEventType_InputArguments:
		return "AuditUpdateMethodEventType_InputArguments";
	case ObjectId::SystemEventType:
		return "SystemEventType";
	case ObjectId::DeviceFailureEventType:
		return "DeviceFailureEventType";
	case ObjectId::BaseModelChangeEventType:
		return "BaseModelChangeEventType";
	case ObjectId::GeneralModelChangeEventType:
		return "GeneralModelChangeEventType";
	case ObjectId::GeneralModelChangeEventType_Changes:
		return "GeneralModelChangeEventType_Changes";
	case ObjectId::ServerVendorCapabilityType:
		return "ServerVendorCapabilityType";
	case ObjectId::ServerStatusType:
		return "ServerStatusType";
	case ObjectId::ServerStatusType_StartTime:
		return "ServerStatusType_StartTime";
	case ObjectId::ServerStatusType_CurrentTime:
		return "ServerStatusType_CurrentTime";
	case ObjectId::ServerStatusType_State:
		return "ServerStatusType_State";
	case ObjectId::ServerStatusType_BuildInfo:
		return "ServerStatusType_BuildInfo";
	case ObjectId::ServerDiagnosticsSummaryType:
		return "ServerDiagnosticsSummaryType";
	case ObjectId::ServerDiagnosticsSummaryType_ServerViewCount:
		return "ServerDiagnosticsSummaryType_ServerViewCount";
	case ObjectId::ServerDiagnosticsSummaryType_CurrentSessionCount:
		return "ServerDiagnosticsSummaryType_CurrentSessionCount";
	case ObjectId::ServerDiagnosticsSummaryType_CumulatedSessionCount:
		return "ServerDiagnosticsSummaryType_CumulatedSessionCount";
	case ObjectId::ServerDiagnosticsSummaryType_SecurityRejectedSessionCount:
		return "ServerDiagnosticsSummaryType_SecurityRejectedSessionCount";
	case ObjectId::ServerDiagnosticsSummaryType_RejectedSessionCount:
		return "ServerDiagnosticsSummaryType_RejectedSessionCount";
	case ObjectId::ServerDiagnosticsSummaryType_SessionTimeoutCount:
		return "ServerDiagnosticsSummaryType_SessionTimeoutCount";
	case ObjectId::ServerDiagnosticsSummaryType_SessionAbortCount:
		return "ServerDiagnosticsSummaryType_SessionAbortCount";
	case ObjectId::ServerDiagnosticsSummaryType_PublishingIntervalCount:
		return "ServerDiagnosticsSummaryType_PublishingIntervalCount";
	case ObjectId::ServerDiagnosticsSummaryType_CurrentSubscriptionCount:
		return "ServerDiagnosticsSummaryType_CurrentSubscriptionCount";
	case ObjectId::ServerDiagnosticsSummaryType_CumulatedSubscriptionCount:
		return "ServerDiagnosticsSummaryType_CumulatedSubscriptionCount";
	case ObjectId::ServerDiagnosticsSummaryType_SecurityRejectedRequestsCount:
		return "ServerDiagnosticsSummaryType_SecurityRejectedRequestsCount";
	case ObjectId::ServerDiagnosticsSummaryType_RejectedRequestsCount:
		return "ServerDiagnosticsSummaryType_RejectedRequestsCount";
	case ObjectId::SamplingIntervalDiagnosticsArrayType:
		return "SamplingIntervalDiagnosticsArrayType";
	case ObjectId::SamplingIntervalDiagnosticsType:
		return "SamplingIntervalDiagnosticsType";
	case ObjectId::SamplingIntervalDiagnosticsType_SamplingInterval:
		return "SamplingIntervalDiagnosticsType_SamplingInterval";
	case ObjectId::SubscriptionDiagnosticsArrayType:
		return "SubscriptionDiagnosticsArrayType";
	case ObjectId::SubscriptionDiagnosticsType:
		return "SubscriptionDiagnosticsType";
	case ObjectId::SubscriptionDiagnosticsType_SessionId:
		return "SubscriptionDiagnosticsType_SessionId";
	case ObjectId::SubscriptionDiagnosticsType_SubscriptionId:
		return "SubscriptionDiagnosticsType_SubscriptionId";
	case ObjectId::SubscriptionDiagnosticsType_Priority:
		return "SubscriptionDiagnosticsType_Priority";
	case ObjectId::SubscriptionDiagnosticsType_PublishingInterval:
		return "SubscriptionDiagnosticsType_PublishingInterval";
	case ObjectId::SubscriptionDiagnosticsType_MaxKeepAliveCount:
		return "SubscriptionDiagnosticsType_MaxKeepAliveCount";
	case ObjectId::SubscriptionDiagnosticsType_MaxNotificationsPerPublish:
		return "SubscriptionDiagnosticsType_MaxNotificationsPerPublish";
	case ObjectId::SubscriptionDiagnosticsType_PublishingEnabled:
		return "SubscriptionDiagnosticsType_PublishingEnabled";
	case ObjectId::SubscriptionDiagnosticsType_ModifyCount:
		return "SubscriptionDiagnosticsType_ModifyCount";
	case ObjectId::SubscriptionDiagnosticsType_EnableCount:
		return "SubscriptionDiagnosticsType_EnableCount";
	case ObjectId::SubscriptionDiagnosticsType_DisableCount:
		return "SubscriptionDiagnosticsType_DisableCount";
	case ObjectId::SubscriptionDiagnosticsType_RepublishRequestCount:
		return "SubscriptionDiagnosticsType_RepublishRequestCount";
	case ObjectId::SubscriptionDiagnosticsType_RepublishMessageRequestCount:
		return "SubscriptionDiagnosticsType_RepublishMessageRequestCount";
	case ObjectId::SubscriptionDiagnosticsType_RepublishMessageCount:
		return "SubscriptionDiagnosticsType_RepublishMessageCount";
	case ObjectId::SubscriptionDiagnosticsType_TransferRequestCount:
		return "SubscriptionDiagnosticsType_TransferRequestCount";
	case ObjectId::SubscriptionDiagnosticsType_TransferredToAltClientCount:
		return "SubscriptionDiagnosticsType_TransferredToAltClientCount";
	case ObjectId::SubscriptionDiagnosticsType_TransferredToSameClientCount:
		return "SubscriptionDiagnosticsType_TransferredToSameClientCount";
	case ObjectId::SubscriptionDiagnosticsType_PublishRequestCount:
		return "SubscriptionDiagnosticsType_PublishRequestCount";
	case ObjectId::SubscriptionDiagnosticsType_DataChangeNotificationsCount:
		return "SubscriptionDiagnosticsType_DataChangeNotificationsCount";
	case ObjectId::SubscriptionDiagnosticsType_NotificationsCount:
		return "SubscriptionDiagnosticsType_NotificationsCount";
	case ObjectId::SessionDiagnosticsArrayType:
		return "SessionDiagnosticsArrayType";
	case ObjectId::SessionDiagnosticsVariableType:
		return "SessionDiagnosticsVariableType";
	case ObjectId::SessionDiagnosticsVariableType_SessionId:
		return "SessionDiagnosticsVariableType_SessionId";
	case ObjectId::SessionDiagnosticsVariableType_SessionName:
		return "SessionDiagnosticsVariableType_SessionName";
	case ObjectId::SessionDiagnosticsVariableType_ClientDescription:
		return "SessionDiagnosticsVariableType_ClientDescription";
	case ObjectId::SessionDiagnosticsVariableType_ServerUri:
		return "SessionDiagnosticsVariableType_ServerUri";
	case ObjectId::SessionDiagnosticsVariableType_EndpointUrl:
		return "SessionDiagnosticsVariableType_EndpointUrl";
	case ObjectId::SessionDiagnosticsVariableType_LocaleIds:
		return "SessionDiagnosticsVariableType_LocaleIds";
	case ObjectId::SessionDiagnosticsVariableType_ActualSessionTimeout:
		return "SessionDiagnosticsVariableType_ActualSessionTimeout";
	case ObjectId::SessionDiagnosticsVariableType_ClientConnectionTime:
		return "SessionDiagnosticsVariableType_ClientConnectionTime";
	case ObjectId::SessionDiagnosticsVariableType_ClientLastContactTime:
		return "SessionDiagnosticsVariableType_ClientLastContactTime";
	case ObjectId::SessionDiagnosticsVariableType_CurrentSubscriptionsCount:
		return "SessionDiagnosticsVariableType_CurrentSubscriptionsCount";
	case ObjectId::SessionDiagnosticsVariableType_CurrentMonitoredItemsCount:
		return "SessionDiagnosticsVariableType_CurrentMonitoredItemsCount";
	case ObjectId::SessionDiagnosticsVariableType_CurrentPublishRequestsInQueue:
		return "SessionDiagnosticsVariableType_CurrentPublishRequestsInQueue";
	case ObjectId::SessionDiagnosticsVariableType_ReadCount:
		return "SessionDiagnosticsVariableType_ReadCount";
	case ObjectId::SessionDiagnosticsVariableType_HistoryReadCount:
		return "SessionDiagnosticsVariableType_HistoryReadCount";
	case ObjectId::SessionDiagnosticsVariableType_WriteCount:
		return "SessionDiagnosticsVariableType_WriteCount";
	case ObjectId::SessionDiagnosticsVariableType_HistoryUpdateCount:
		return "SessionDiagnosticsVariableType_HistoryUpdateCount";
	case ObjectId::SessionDiagnosticsVariableType_CallCount:
		return "SessionDiagnosticsVariableType_CallCount";
	case ObjectId::SessionDiagnosticsVariableType_CreateMonitoredItemsCount:
		return "SessionDiagnosticsVariableType_CreateMonitoredItemsCount";
	case ObjectId::SessionDiagnosticsVariableType_ModifyMonitoredItemsCount:
		return "SessionDiagnosticsVariableType_ModifyMonitoredItemsCount";
	case ObjectId::SessionDiagnosticsVariableType_SetMonitoringModeCount:
		return "SessionDiagnosticsVariableType_SetMonitoringModeCount";
	case ObjectId::SessionDiagnosticsVariableType_SetTriggeringCount:
		return "SessionDiagnosticsVariableType_SetTriggeringCount";
	case ObjectId::SessionDiagnosticsVariableType_DeleteMonitoredItemsCount:
		return "SessionDiagnosticsVariableType_DeleteMonitoredItemsCount";
	case ObjectId::SessionDiagnosticsVariableType_CreateSubscriptionCount:
		return "SessionDiagnosticsVariableType_CreateSubscriptionCount";
	case ObjectId::SessionDiagnosticsVariableType_ModifySubscriptionCount:
		return "SessionDiagnosticsVariableType_ModifySubscriptionCount";
	case ObjectId::SessionDiagnosticsVariableType_SetPublishingModeCount:
		return "SessionDiagnosticsVariableType_SetPublishingModeCount";
	case ObjectId::SessionDiagnosticsVariableType_PublishCount:
		return "SessionDiagnosticsVariableType_PublishCount";
	case ObjectId::SessionDiagnosticsVariableType_RepublishCount:
		return "SessionDiagnosticsVariableType_RepublishCount";
	case ObjectId::SessionDiagnosticsVariableType_TransferSubscriptionsCount:
		return "SessionDiagnosticsVariableType_TransferSubscriptionsCount";
	case ObjectId::SessionDiagnosticsVariableType_DeleteSubscriptionsCount:
		return "SessionDiagnosticsVariableType_DeleteSubscriptionsCount";
	case ObjectId::SessionDiagnosticsVariableType_AddNodesCount:
		return "SessionDiagnosticsVariableType_AddNodesCount";
	case ObjectId::SessionDiagnosticsVariableType_AddReferencesCount:
		return "SessionDiagnosticsVariableType_AddReferencesCount";
	case ObjectId::SessionDiagnosticsVariableType_DeleteNodesCount:
		return "SessionDiagnosticsVariableType_DeleteNodesCount";
	case ObjectId::SessionDiagnosticsVariableType_DeleteReferencesCount:
		return "SessionDiagnosticsVariableType_DeleteReferencesCount";
	case ObjectId::SessionDiagnosticsVariableType_BrowseCount:
		return "SessionDiagnosticsVariableType_BrowseCount";
	case ObjectId::SessionDiagnosticsVariableType_BrowseNextCount:
		return "SessionDiagnosticsVariableType_BrowseNextCount";
	case ObjectId::SessionDiagnosticsVariableType_TranslateBrowsePathsToNodeIdsCount:
		return "SessionDiagnosticsVariableType_TranslateBrowsePathsToNodeIdsCount";
	case ObjectId::SessionDiagnosticsVariableType_QueryFirstCount:
		return "SessionDiagnosticsVariableType_QueryFirstCount";
	case ObjectId::SessionDiagnosticsVariableType_QueryNextCount:
		return "SessionDiagnosticsVariableType_QueryNextCount";
	case ObjectId::SessionSecurityDiagnosticsArrayType:
		return "SessionSecurityDiagnosticsArrayType";
	case ObjectId::SessionSecurityDiagnosticsType:
		return "SessionSecurityDiagnosticsType";
	case ObjectId::SessionSecurityDiagnosticsType_SessionId:
		return "SessionSecurityDiagnosticsType_SessionId";
	case ObjectId::SessionSecurityDiagnosticsType_ClientUserIdOfSession:
		return "SessionSecurityDiagnosticsType_ClientUserIdOfSession";
	case ObjectId::SessionSecurityDiagnosticsType_ClientUserIdHistory:
		return "SessionSecurityDiagnosticsType_ClientUserIdHistory";
	case ObjectId::SessionSecurityDiagnosticsType_AuthenticationMechanism:
		return "SessionSecurityDiagnosticsType_AuthenticationMechanism";
	case ObjectId::SessionSecurityDiagnosticsType_Encoding:
		return "SessionSecurityDiagnosticsType_Encoding";
	case ObjectId::SessionSecurityDiagnosticsType_TransportProtocol:
		return "SessionSecurityDiagnosticsType_TransportProtocol";
	case ObjectId::SessionSecurityDiagnosticsType_SecurityMode:
		return "SessionSecurityDiagnosticsType_SecurityMode";
	case ObjectId::SessionSecurityDiagnosticsType_SecurityPolicyUri:
		return "SessionSecurityDiagnosticsType_SecurityPolicyUri";
	case ObjectId::Server:
		return "Server";
	case ObjectId::Server_ServerArray:
		return "Server_ServerArray";
	case ObjectId::Server_NamespaceArray:
		return "Server_NamespaceArray";
	case ObjectId::Server_ServerStatus:
		return "Server_ServerStatus";
	case ObjectId::Server_ServerStatus_StartTime:
		return "Server_ServerStatus_StartTime";
	case ObjectId::Server_ServerStatus_CurrentTime:
		return "Server_ServerStatus_CurrentTime";
	case ObjectId::Server_ServerStatus_State:
		return "Server_ServerStatus_State";
	case ObjectId::Server_ServerStatus_BuildInfo:
		return "Server_ServerStatus_BuildInfo";
	case ObjectId::Server_ServerStatus_BuildInfo_ProductName:
		return "Server_ServerStatus_BuildInfo_ProductName";
	case ObjectId::Server_ServerStatus_BuildInfo_ProductUri:
		return "Server_ServerStatus_BuildInfo_ProductUri";
	case ObjectId::Server_ServerStatus_BuildInfo_ManufacturerName:
		return "Server_ServerStatus_BuildInfo_ManufacturerName";
	case ObjectId::Server_ServerStatus_BuildInfo_SoftwareVersion:
		return "Server_ServerStatus_BuildInfo_SoftwareVersion";
	case ObjectId::Server_ServerStatus_BuildInfo_BuildNumber:
		return "Server_ServerStatus_BuildInfo_BuildNumber";
	case ObjectId::Server_ServerStatus_BuildInfo_BuildDate:
		return "Server_ServerStatus_BuildInfo_BuildDate";
	case ObjectId::Server_ServiceLevel:
		return "Server_ServiceLevel";
	case ObjectId::Server_ServerCapabilities:
		return "Server_ServerCapabilities";
	case ObjectId::Server_ServerCapabilities_ServerProfileArray:
		return "Server_ServerCapabilities_ServerProfileArray";
	case ObjectId::Server_ServerCapabilities_LocaleIdArray:
		return "Server_ServerCapabilities_LocaleIdArray";
	case ObjectId::Server_ServerCapabilities_MinSupportedSampleRate:
		return "Server_ServerCapabilities_MinSupportedSampleRate";
	case ObjectId::Server_ServerDiagnostics:
		return "Server_ServerDiagnostics";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_ServerViewCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_ServerViewCount";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSessionCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSessionCount";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSessionCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSessionCount";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedSessionCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedSessionCount";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_SessionTimeoutCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_SessionTimeoutCount";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_SessionAbortCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_SessionAbortCount";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_PublishingIntervalCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_PublishingIntervalCount";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSubscriptionCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSubscriptionCount";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSubscriptionCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSubscriptionCount";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedRequestsCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedRequestsCount";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_RejectedRequestsCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_RejectedRequestsCount";
	case ObjectId::Server_ServerDiagnostics_SamplingIntervalDiagnosticsArray:
		return "Server_ServerDiagnostics_SamplingIntervalDiagnosticsArray";
	case ObjectId::Server_ServerDiagnostics_SubscriptionDiagnosticsArray:
		return "Server_ServerDiagnostics_SubscriptionDiagnosticsArray";
	case ObjectId::Server_ServerDiagnostics_EnabledFlag:
		return "Server_ServerDiagnostics_EnabledFlag";
	case ObjectId::Server_VendorServerInfo:
		return "Server_VendorServerInfo";
	case ObjectId::Server_ServerRedundancy:
		return "Server_ServerRedundancy";
	case ObjectId::StateMachineType:
		return "StateMachineType";
	case ObjectId::StateType:
		return "StateType";
	case ObjectId::StateType_StateNumber:
		return "StateType_StateNumber";
	case ObjectId::InitialStateType:
		return "InitialStateType";
	case ObjectId::TransitionType:
		return "TransitionType";
	case ObjectId::TransitionEventType:
		return "TransitionEventType";
	case ObjectId::TransitionType_TransitionNumber:
		return "TransitionType_TransitionNumber";
	case ObjectId::AuditUpdateStateEventType:
		return "AuditUpdateStateEventType";
	case ObjectId::HistoricalDataConfigurationType:
		return "HistoricalDataConfigurationType";
	case ObjectId::HistoricalDataConfigurationType_Stepped:
		return "HistoricalDataConfigurationType_Stepped";
	case ObjectId::HistoricalDataConfigurationType_Definition:
		return "HistoricalDataConfigurationType_Definition";
	case ObjectId::HistoricalDataConfigurationType_MaxTimeInterval:
		return "HistoricalDataConfigurationType_MaxTimeInterval";
	case ObjectId::HistoricalDataConfigurationType_MinTimeInterval:
		return "HistoricalDataConfigurationType_MinTimeInterval";
	case ObjectId::HistoricalDataConfigurationType_ExceptionDeviation:
		return "HistoricalDataConfigurationType_ExceptionDeviation";
	case ObjectId::HistoricalDataConfigurationType_ExceptionDeviationFormat:
		return "HistoricalDataConfigurationType_ExceptionDeviationFormat";
	case ObjectId::HistoryServerCapabilitiesType:
		return "HistoryServerCapabilitiesType";
	case ObjectId::HistoryServerCapabilitiesType_AccessHistoryDataCapability:
		return "HistoryServerCapabilitiesType_AccessHistoryDataCapability";
	case ObjectId::HistoryServerCapabilitiesType_AccessHistoryEventsCapability:
		return "HistoryServerCapabilitiesType_AccessHistoryEventsCapability";
	case ObjectId::HistoryServerCapabilitiesType_InsertDataCapability:
		return "HistoryServerCapabilitiesType_InsertDataCapability";
	case ObjectId::HistoryServerCapabilitiesType_ReplaceDataCapability:
		return "HistoryServerCapabilitiesType_ReplaceDataCapability";
	case ObjectId::HistoryServerCapabilitiesType_UpdateDataCapability:
		return "HistoryServerCapabilitiesType_UpdateDataCapability";
	case ObjectId::HistoryServerCapabilitiesType_DeleteRawCapability:
		return "HistoryServerCapabilitiesType_DeleteRawCapability";
	case ObjectId::HistoryServerCapabilitiesType_DeleteAtTimeCapability:
		return "HistoryServerCapabilitiesType_DeleteAtTimeCapability";
	case ObjectId::AggregateFunctionType:
		return "AggregateFunctionType";
	case ObjectId::AggregateFunction_Interpolative:
		return "AggregateFunction_Interpolative";
	case ObjectId::AggregateFunction_Average:
		return "AggregateFunction_Average";
	case ObjectId::AggregateFunction_TimeAverage:
		return "AggregateFunction_TimeAverage";
	case ObjectId::AggregateFunction_Total:
		return "AggregateFunction_Total";
	case ObjectId::AggregateFunction_Minimum:
		return "AggregateFunction_Minimum";
	case ObjectId::AggregateFunction_Maximum:
		return "AggregateFunction_Maximum";
	case ObjectId::AggregateFunction_MinimumActualTime:
		return "AggregateFunction_MinimumActualTime";
	case ObjectId::AggregateFunction_MaximumActualTime:
		return "AggregateFunction_MaximumActualTime";
	case ObjectId::AggregateFunction_Range:
		return "AggregateFunction_Range";
	case ObjectId::AggregateFunction_AnnotationCount:
		return "AggregateFunction_AnnotationCount";
	case ObjectId::AggregateFunction_Count:
		return "AggregateFunction_Count";
	case ObjectId::AggregateFunction_NumberOfTransitions:
		return "AggregateFunction_NumberOfTransitions";
	case ObjectId::AggregateFunction_Start:
		return "AggregateFunction_Start";
	case ObjectId::AggregateFunction_End:
		return "AggregateFunction_End";
	case ObjectId::AggregateFunction_Delta:
		return "AggregateFunction_Delta";
	case ObjectId::AggregateFunction_DurationGood:
		return "AggregateFunction_DurationGood";
	case ObjectId::AggregateFunction_DurationBad:
		return "AggregateFunction_DurationBad";
	case ObjectId::AggregateFunction_PercentGood:
		return "AggregateFunction_PercentGood";
	case ObjectId::AggregateFunction_PercentBad:
		return "AggregateFunction_PercentBad";
	case ObjectId::AggregateFunction_WorstQuality:
		return "AggregateFunction_WorstQuality";
	case ObjectId::DataItemType:
		return "DataItemType";
	case ObjectId::DataItemType_Definition:
		return "DataItemType_Definition";
	case ObjectId::DataItemType_ValuePrecision:
		return "DataItemType_ValuePrecision";
	case ObjectId::AnalogItemType:
		return "AnalogItemType";
	case ObjectId::AnalogItemType_EURange:
		return "AnalogItemType_EURange";
	case ObjectId::AnalogItemType_InstrumentRange:
		return "AnalogItemType_InstrumentRange";
	case ObjectId::AnalogItemType_EngineeringUnits:
		return "AnalogItemType_EngineeringUnits";
	case ObjectId::DiscreteItemType:
		return "DiscreteItemType";
	case ObjectId::TwoStateDiscreteType:
		return "TwoStateDiscreteType";
	case ObjectId::TwoStateDiscreteType_FalseState:
		return "TwoStateDiscreteType_FalseState";
	case ObjectId::TwoStateDiscreteType_TrueState:
		return "TwoStateDiscreteType_TrueState";
	case ObjectId::MultiStateDiscreteType:
		return "MultiStateDiscreteType";
	case ObjectId::MultiStateDiscreteType_EnumStrings:
		return "MultiStateDiscreteType_EnumStrings";
	case ObjectId::ProgramTransitionEventType:
		return "ProgramTransitionEventType";
	case ObjectId::ProgramTransitionEventType_IntermediateResult:
		return "ProgramTransitionEventType_IntermediateResult";
	case ObjectId::ProgramDiagnosticType:
		return "ProgramDiagnosticType";
	case ObjectId::ProgramDiagnosticType_CreateSessionId:
		return "ProgramDiagnosticType_CreateSessionId";
	case ObjectId::ProgramDiagnosticType_CreateClientName:
		return "ProgramDiagnosticType_CreateClientName";
	case ObjectId::ProgramDiagnosticType_InvocationCreationTime:
		return "ProgramDiagnosticType_InvocationCreationTime";
	case ObjectId::ProgramDiagnosticType_LastTransitionTime:
		return "ProgramDiagnosticType_LastTransitionTime";
	case ObjectId::ProgramDiagnosticType_LastMethodCall:
		return "ProgramDiagnosticType_LastMethodCall";
	case ObjectId::ProgramDiagnosticType_LastMethodSessionId:
		return "ProgramDiagnosticType_LastMethodSessionId";
	case ObjectId::ProgramDiagnosticType_LastMethodInputArguments:
		return "ProgramDiagnosticType_LastMethodInputArguments";
	case ObjectId::ProgramDiagnosticType_LastMethodOutputArguments:
		return "ProgramDiagnosticType_LastMethodOutputArguments";
	case ObjectId::ProgramDiagnosticType_LastMethodCallTime:
		return "ProgramDiagnosticType_LastMethodCallTime";
	case ObjectId::ProgramDiagnosticType_LastMethodReturnStatus:
		return "ProgramDiagnosticType_LastMethodReturnStatus";
	case ObjectId::ProgramStateMachineType:
		return "ProgramStateMachineType";
	case ObjectId::ProgramStateMachineType_Creatable:
		return "ProgramStateMachineType_Creatable";
	case ObjectId::ProgramStateMachineType_Deletable:
		return "ProgramStateMachineType_Deletable";
	case ObjectId::ProgramStateMachineType_AutoDelete:
		return "ProgramStateMachineType_AutoDelete";
	case ObjectId::ProgramStateMachineType_RecycleCount:
		return "ProgramStateMachineType_RecycleCount";
	case ObjectId::ProgramStateMachineType_InstanceCount:
		return "ProgramStateMachineType_InstanceCount";
	case ObjectId::ProgramStateMachineType_MaxInstanceCount:
		return "ProgramStateMachineType_MaxInstanceCount";
	case ObjectId::ProgramStateMachineType_MaxRecycleCount:
		return "ProgramStateMachineType_MaxRecycleCount";
	case ObjectId::ProgramStateMachineType_ProgramDiagnostics:
		return "ProgramStateMachineType_ProgramDiagnostics";
	case ObjectId::ProgramStateMachineType_Ready:
		return "ProgramStateMachineType_Ready";
	case ObjectId::ProgramStateMachineType_Ready_StateNumber:
		return "ProgramStateMachineType_Ready_StateNumber";
	case ObjectId::ProgramStateMachineType_Running:
		return "ProgramStateMachineType_Running";
	case ObjectId::ProgramStateMachineType_Running_StateNumber:
		return "ProgramStateMachineType_Running_StateNumber";
	case ObjectId::ProgramStateMachineType_Suspended:
		return "ProgramStateMachineType_Suspended";
	case ObjectId::ProgramStateMachineType_Suspended_StateNumber:
		return "ProgramStateMachineType_Suspended_StateNumber";
	case ObjectId::ProgramStateMachineType_Halted:
		return "ProgramStateMachineType_Halted";
	case ObjectId::ProgramStateMachineType_Halted_StateNumber:
		return "ProgramStateMachineType_Halted_StateNumber";
	case ObjectId::ProgramStateMachineType_HaltedToReady:
		return "ProgramStateMachineType_HaltedToReady";
	case ObjectId::ProgramStateMachineType_HaltedToReady_TransitionNumber:
		return "ProgramStateMachineType_HaltedToReady_TransitionNumber";
	case ObjectId::ProgramStateMachineType_ReadyToRunning:
		return "ProgramStateMachineType_ReadyToRunning";
	case ObjectId::ProgramStateMachineType_ReadyToRunning_TransitionNumber:
		return "ProgramStateMachineType_ReadyToRunning_TransitionNumber";
	case ObjectId::ProgramStateMachineType_RunningToHalted:
		return "ProgramStateMachineType_RunningToHalted";
	case ObjectId::ProgramStateMachineType_RunningToHalted_TransitionNumber:
		return "ProgramStateMachineType_RunningToHalted_TransitionNumber";
	case ObjectId::ProgramStateMachineType_RunningToReady:
		return "ProgramStateMachineType_RunningToReady";
	case ObjectId::ProgramStateMachineType_RunningToReady_TransitionNumber:
		return "ProgramStateMachineType_RunningToReady_TransitionNumber";
	case ObjectId::ProgramStateMachineType_RunningToSuspended:
		return "ProgramStateMachineType_RunningToSuspended";
	case ObjectId::ProgramStateMachineType_RunningToSuspended_TransitionNumber:
		return "ProgramStateMachineType_RunningToSuspended_TransitionNumber";
	case ObjectId::ProgramStateMachineType_SuspendedToRunning:
		return "ProgramStateMachineType_SuspendedToRunning";
	case ObjectId::ProgramStateMachineType_SuspendedToRunning_TransitionNumber:
		return "ProgramStateMachineType_SuspendedToRunning_TransitionNumber";
	case ObjectId::ProgramStateMachineType_SuspendedToHalted:
		return "ProgramStateMachineType_SuspendedToHalted";
	case ObjectId::ProgramStateMachineType_SuspendedToHalted_TransitionNumber:
		return "ProgramStateMachineType_SuspendedToHalted_TransitionNumber";
	case ObjectId::ProgramStateMachineType_SuspendedToReady:
		return "ProgramStateMachineType_SuspendedToReady";
	case ObjectId::ProgramStateMachineType_SuspendedToReady_TransitionNumber:
		return "ProgramStateMachineType_SuspendedToReady_TransitionNumber";
	case ObjectId::ProgramStateMachineType_ReadyToHalted:
		return "ProgramStateMachineType_ReadyToHalted";
	case ObjectId::ProgramStateMachineType_ReadyToHalted_TransitionNumber:
		return "ProgramStateMachineType_ReadyToHalted_TransitionNumber";
	case ObjectId::ProgramStateMachineType_Start:
		return "ProgramStateMachineType_Start";
	case ObjectId::ProgramStateMachineType_Suspend:
		return "ProgramStateMachineType_Suspend";
	case ObjectId::ProgramStateMachineType_Resume:
		return "ProgramStateMachineType_Resume";
	case ObjectId::ProgramStateMachineType_Halt:
		return "ProgramStateMachineType_Halt";
	case ObjectId::ProgramStateMachineType_Reset:
		return "ProgramStateMachineType_Reset";
	case ObjectId::SessionDiagnosticsVariableType_RegisterNodesCount:
		return "SessionDiagnosticsVariableType_RegisterNodesCount";
	case ObjectId::SessionDiagnosticsVariableType_UnregisterNodesCount:
		return "SessionDiagnosticsVariableType_UnregisterNodesCount";
	case ObjectId::ServerCapabilitiesType_MaxBrowseContinuationPoints:
		return "ServerCapabilitiesType_MaxBrowseContinuationPoints";
	case ObjectId::ServerCapabilitiesType_MaxQueryContinuationPoints:
		return "ServerCapabilitiesType_MaxQueryContinuationPoints";
	case ObjectId::ServerCapabilitiesType_MaxHistoryContinuationPoints:
		return "ServerCapabilitiesType_MaxHistoryContinuationPoints";
	case ObjectId::Server_ServerCapabilities_MaxBrowseContinuationPoints:
		return "Server_ServerCapabilities_MaxBrowseContinuationPoints";
	case ObjectId::Server_ServerCapabilities_MaxQueryContinuationPoints:
		return "Server_ServerCapabilities_MaxQueryContinuationPoints";
	case ObjectId::Server_ServerCapabilities_MaxHistoryContinuationPoints:
		return "Server_ServerCapabilities_MaxHistoryContinuationPoints";
	case ObjectId::SemanticChangeEventType:
		return "SemanticChangeEventType";
	case ObjectId::SemanticChangeEventType_Changes:
		return "SemanticChangeEventType_Changes";
	case ObjectId::ServerType_Auditing:
		return "ServerType_Auditing";
	case ObjectId::ServerDiagnosticsType_SessionsDiagnosticsSummary:
		return "ServerDiagnosticsType_SessionsDiagnosticsSummary";
	case ObjectId::AuditChannelEventType_SecureChannelId:
		return "AuditChannelEventType_SecureChannelId";
	case ObjectId::AuditOpenSecureChannelEventType_ClientCertificateThumbprint:
		return "AuditOpenSecureChannelEventType_ClientCertificateThumbprint";
	case ObjectId::AuditCreateSessionEventType_ClientCertificateThumbprint:
		return "AuditCreateSessionEventType_ClientCertificateThumbprint";
	case ObjectId::AuditUrlMismatchEventType:
		return "AuditUrlMismatchEventType";
	case ObjectId::AuditUrlMismatchEventType_EndpointUrl:
		return "AuditUrlMismatchEventType_EndpointUrl";
	case ObjectId::AuditWriteUpdateEventType_AttributeId:
		return "AuditWriteUpdateEventType_AttributeId";
	case ObjectId::AuditHistoryUpdateEventType_ParameterDataTypeId:
		return "AuditHistoryUpdateEventType_ParameterDataTypeId";
	case ObjectId::ServerStatusType_SecondsTillShutdown:
		return "ServerStatusType_SecondsTillShutdown";
	case ObjectId::ServerStatusType_ShutdownReason:
		return "ServerStatusType_ShutdownReason";
	case ObjectId::ServerCapabilitiesType_AggregateFunctions:
		return "ServerCapabilitiesType_AggregateFunctions";
	case ObjectId::StateVariableType:
		return "StateVariableType";
	case ObjectId::StateVariableType_Id:
		return "StateVariableType_Id";
	case ObjectId::StateVariableType_Name:
		return "StateVariableType_Name";
	case ObjectId::StateVariableType_Number:
		return "StateVariableType_Number";
	case ObjectId::StateVariableType_EffectiveDisplayName:
		return "StateVariableType_EffectiveDisplayName";
	case ObjectId::FiniteStateVariableType:
		return "FiniteStateVariableType";
	case ObjectId::FiniteStateVariableType_Id:
		return "FiniteStateVariableType_Id";
	case ObjectId::TransitionVariableType:
		return "TransitionVariableType";
	case ObjectId::TransitionVariableType_Id:
		return "TransitionVariableType_Id";
	case ObjectId::TransitionVariableType_Name:
		return "TransitionVariableType_Name";
	case ObjectId::TransitionVariableType_Number:
		return "TransitionVariableType_Number";
	case ObjectId::TransitionVariableType_TransitionTime:
		return "TransitionVariableType_TransitionTime";
	case ObjectId::FiniteTransitionVariableType:
		return "FiniteTransitionVariableType";
	case ObjectId::FiniteTransitionVariableType_Id:
		return "FiniteTransitionVariableType_Id";
	case ObjectId::StateMachineType_CurrentState:
		return "StateMachineType_CurrentState";
	case ObjectId::StateMachineType_LastTransition:
		return "StateMachineType_LastTransition";
	case ObjectId::FiniteStateMachineType:
		return "FiniteStateMachineType";
	case ObjectId::FiniteStateMachineType_CurrentState:
		return "FiniteStateMachineType_CurrentState";
	case ObjectId::FiniteStateMachineType_LastTransition:
		return "FiniteStateMachineType_LastTransition";
	case ObjectId::TransitionEventType_Transition:
		return "TransitionEventType_Transition";
	case ObjectId::TransitionEventType_FromState:
		return "TransitionEventType_FromState";
	case ObjectId::TransitionEventType_ToState:
		return "TransitionEventType_ToState";
	case ObjectId::AuditUpdateStateEventType_OldStateId:
		return "AuditUpdateStateEventType_OldStateId";
	case ObjectId::AuditUpdateStateEventType_NewStateId:
		return "AuditUpdateStateEventType_NewStateId";
	case ObjectId::ConditionType:
		return "ConditionType";
	case ObjectId::RefreshStartEventType:
		return "RefreshStartEventType";
	case ObjectId::RefreshEndEventType:
		return "RefreshEndEventType";
	case ObjectId::RefreshRequiredEventType:
		return "RefreshRequiredEventType";
	case ObjectId::AuditConditionEventType:
		return "AuditConditionEventType";
	case ObjectId::AuditConditionEnableEventType:
		return "AuditConditionEnableEventType";
	case ObjectId::AuditConditionCommentEventType:
		return "AuditConditionCommentEventType";
	case ObjectId::DialogConditionType:
		return "DialogConditionType";
	case ObjectId::DialogConditionType_Prompt:
		return "DialogConditionType_Prompt";
	case ObjectId::AcknowledgeableConditionType:
		return "AcknowledgeableConditionType";
	case ObjectId::AlarmConditionType:
		return "AlarmConditionType";
	case ObjectId::ShelvedStateMachineType:
		return "ShelvedStateMachineType";
	case ObjectId::ShelvedStateMachineType_Unshelved:
		return "ShelvedStateMachineType_Unshelved";
	case ObjectId::ShelvedStateMachineType_TimedShelved:
		return "ShelvedStateMachineType_TimedShelved";
	case ObjectId::ShelvedStateMachineType_OneShotShelved:
		return "ShelvedStateMachineType_OneShotShelved";
	case ObjectId::ShelvedStateMachineType_UnshelvedToTimedShelved:
		return "ShelvedStateMachineType_UnshelvedToTimedShelved";
	case ObjectId::ShelvedStateMachineType_UnshelvedToOneShotShelved:
		return "ShelvedStateMachineType_UnshelvedToOneShotShelved";
	case ObjectId::ShelvedStateMachineType_TimedShelvedToUnshelved:
		return "ShelvedStateMachineType_TimedShelvedToUnshelved";
	case ObjectId::ShelvedStateMachineType_TimedShelvedToOneShotShelved:
		return "ShelvedStateMachineType_TimedShelvedToOneShotShelved";
	case ObjectId::ShelvedStateMachineType_OneShotShelvedToUnshelved:
		return "ShelvedStateMachineType_OneShotShelvedToUnshelved";
	case ObjectId::ShelvedStateMachineType_OneShotShelvedToTimedShelved:
		return "ShelvedStateMachineType_OneShotShelvedToTimedShelved";
	case ObjectId::ShelvedStateMachineType_Unshelve:
		return "ShelvedStateMachineType_Unshelve";
	case ObjectId::ShelvedStateMachineType_OneShotShelve:
		return "ShelvedStateMachineType_OneShotShelve";
	case ObjectId::ShelvedStateMachineType_TimedShelve:
		return "ShelvedStateMachineType_TimedShelve";
	case ObjectId::LimitAlarmType:
		return "LimitAlarmType";
	case ObjectId::ShelvedStateMachineType_TimedShelve_InputArguments:
		return "ShelvedStateMachineType_TimedShelve_InputArguments";
	case ObjectId::Server_ServerStatus_SecondsTillShutdown:
		return "Server_ServerStatus_SecondsTillShutdown";
	case ObjectId::Server_ServerStatus_ShutdownReason:
		return "Server_ServerStatus_ShutdownReason";
	case ObjectId::Server_Auditing:
		return "Server_Auditing";
	case ObjectId::Server_ServerCapabilities_ModellingRules:
		return "Server_ServerCapabilities_ModellingRules";
	case ObjectId::Server_ServerCapabilities_AggregateFunctions:
		return "Server_ServerCapabilities_AggregateFunctions";
	case ObjectId::SubscriptionDiagnosticsType_EventNotificationsCount:
		return "SubscriptionDiagnosticsType_EventNotificationsCount";
	case ObjectId::AuditHistoryEventUpdateEventType:
		return "AuditHistoryEventUpdateEventType";
	case ObjectId::AuditHistoryEventUpdateEventType_Filter:
		return "AuditHistoryEventUpdateEventType_Filter";
	case ObjectId::AuditHistoryValueUpdateEventType:
		return "AuditHistoryValueUpdateEventType";
	case ObjectId::AuditHistoryDeleteEventType:
		return "AuditHistoryDeleteEventType";
	case ObjectId::AuditHistoryRawModifyDeleteEventType:
		return "AuditHistoryRawModifyDeleteEventType";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_IsDeleteModified:
		return "AuditHistoryRawModifyDeleteEventType_IsDeleteModified";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_StartTime:
		return "AuditHistoryRawModifyDeleteEventType_StartTime";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_EndTime:
		return "AuditHistoryRawModifyDeleteEventType_EndTime";
	case ObjectId::AuditHistoryAtTimeDeleteEventType:
		return "AuditHistoryAtTimeDeleteEventType";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_ReqTimes:
		return "AuditHistoryAtTimeDeleteEventType_ReqTimes";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_OldValues:
		return "AuditHistoryAtTimeDeleteEventType_OldValues";
	case ObjectId::AuditHistoryEventDeleteEventType:
		return "AuditHistoryEventDeleteEventType";
	case ObjectId::AuditHistoryEventDeleteEventType_EventIds:
		return "AuditHistoryEventDeleteEventType_EventIds";
	case ObjectId::AuditHistoryEventDeleteEventType_OldValues:
		return "AuditHistoryEventDeleteEventType_OldValues";
	case ObjectId::AuditHistoryEventUpdateEventType_UpdatedNode:
		return "AuditHistoryEventUpdateEventType_UpdatedNode";
	case ObjectId::AuditHistoryValueUpdateEventType_UpdatedNode:
		return "AuditHistoryValueUpdateEventType_UpdatedNode";
	case ObjectId::AuditHistoryDeleteEventType_UpdatedNode:
		return "AuditHistoryDeleteEventType_UpdatedNode";
	case ObjectId::AuditHistoryEventUpdateEventType_PerformInsertReplace:
		return "AuditHistoryEventUpdateEventType_PerformInsertReplace";
	case ObjectId::AuditHistoryEventUpdateEventType_NewValues:
		return "AuditHistoryEventUpdateEventType_NewValues";
	case ObjectId::AuditHistoryEventUpdateEventType_OldValues:
		return "AuditHistoryEventUpdateEventType_OldValues";
	case ObjectId::AuditHistoryValueUpdateEventType_PerformInsertReplace:
		return "AuditHistoryValueUpdateEventType_PerformInsertReplace";
	case ObjectId::AuditHistoryValueUpdateEventType_NewValues:
		return "AuditHistoryValueUpdateEventType_NewValues";
	case ObjectId::AuditHistoryValueUpdateEventType_OldValues:
		return "AuditHistoryValueUpdateEventType_OldValues";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_OldValues:
		return "AuditHistoryRawModifyDeleteEventType_OldValues";
	case ObjectId::EventQueueOverflowEventType:
		return "EventQueueOverflowEventType";
	case ObjectId::EventTypesFolder:
		return "EventTypesFolder";
	case ObjectId::ServerCapabilitiesType_SoftwareCertificates:
		return "ServerCapabilitiesType_SoftwareCertificates";
	case ObjectId::SessionDiagnosticsVariableType_MaxResponseMessageSize:
		return "SessionDiagnosticsVariableType_MaxResponseMessageSize";
	case ObjectId::BuildInfoType:
		return "BuildInfoType";
	case ObjectId::BuildInfoType_ProductUri:
		return "BuildInfoType_ProductUri";
	case ObjectId::BuildInfoType_ManufacturerName:
		return "BuildInfoType_ManufacturerName";
	case ObjectId::BuildInfoType_ProductName:
		return "BuildInfoType_ProductName";
	case ObjectId::BuildInfoType_SoftwareVersion:
		return "BuildInfoType_SoftwareVersion";
	case ObjectId::BuildInfoType_BuildNumber:
		return "BuildInfoType_BuildNumber";
	case ObjectId::BuildInfoType_BuildDate:
		return "BuildInfoType_BuildDate";
	case ObjectId::SessionSecurityDiagnosticsType_ClientCertificate:
		return "SessionSecurityDiagnosticsType_ClientCertificate";
	case ObjectId::HistoricalDataConfigurationType_AggregateConfiguration:
		return "HistoricalDataConfigurationType_AggregateConfiguration";
	case ObjectId::DefaultBinary:
		return "DefaultBinary";
	case ObjectId::DefaultXml:
		return "DefaultXml";
	case ObjectId::AlwaysGeneratesEvent:
		return "AlwaysGeneratesEvent";
	case ObjectId::Icon:
		return "Icon";
	case ObjectId::NodeVersion:
		return "NodeVersion";
	case ObjectId::LocalTime:
		return "LocalTime";
	case ObjectId::AllowNulls:
		return "AllowNulls";
	case ObjectId::EnumValues:
		return "EnumValues";
	case ObjectId::InputArguments:
		return "InputArguments";
	case ObjectId::OutputArguments:
		return "OutputArguments";
	case ObjectId::ServerType_ServerStatus_StartTime:
		return "ServerType_ServerStatus_StartTime";
	case ObjectId::ServerType_ServerStatus_CurrentTime:
		return "ServerType_ServerStatus_CurrentTime";
	case ObjectId::ServerType_ServerStatus_State:
		return "ServerType_ServerStatus_State";
	case ObjectId::ServerType_ServerStatus_BuildInfo:
		return "ServerType_ServerStatus_BuildInfo";
	case ObjectId::ServerType_ServerStatus_BuildInfo_ProductUri:
		return "ServerType_ServerStatus_BuildInfo_ProductUri";
	case ObjectId::ServerType_ServerStatus_BuildInfo_ManufacturerName:
		return "ServerType_ServerStatus_BuildInfo_ManufacturerName";
	case ObjectId::ServerType_ServerStatus_BuildInfo_ProductName:
		return "ServerType_ServerStatus_BuildInfo_ProductName";
	case ObjectId::ServerType_ServerStatus_BuildInfo_SoftwareVersion:
		return "ServerType_ServerStatus_BuildInfo_SoftwareVersion";
	case ObjectId::ServerType_ServerStatus_BuildInfo_BuildNumber:
		return "ServerType_ServerStatus_BuildInfo_BuildNumber";
	case ObjectId::ServerType_ServerStatus_BuildInfo_BuildDate:
		return "ServerType_ServerStatus_BuildInfo_BuildDate";
	case ObjectId::ServerType_ServerStatus_SecondsTillShutdown:
		return "ServerType_ServerStatus_SecondsTillShutdown";
	case ObjectId::ServerType_ServerStatus_ShutdownReason:
		return "ServerType_ServerStatus_ShutdownReason";
	case ObjectId::ServerType_ServerCapabilities_ServerProfileArray:
		return "ServerType_ServerCapabilities_ServerProfileArray";
	case ObjectId::ServerType_ServerCapabilities_LocaleIdArray:
		return "ServerType_ServerCapabilities_LocaleIdArray";
	case ObjectId::ServerType_ServerCapabilities_MinSupportedSampleRate:
		return "ServerType_ServerCapabilities_MinSupportedSampleRate";
	case ObjectId::ServerType_ServerCapabilities_MaxBrowseContinuationPoints:
		return "ServerType_ServerCapabilities_MaxBrowseContinuationPoints";
	case ObjectId::ServerType_ServerCapabilities_MaxQueryContinuationPoints:
		return "ServerType_ServerCapabilities_MaxQueryContinuationPoints";
	case ObjectId::ServerType_ServerCapabilities_MaxHistoryContinuationPoints:
		return "ServerType_ServerCapabilities_MaxHistoryContinuationPoints";
	case ObjectId::ServerType_ServerCapabilities_SoftwareCertificates:
		return "ServerType_ServerCapabilities_SoftwareCertificates";
	case ObjectId::ServerType_ServerCapabilities_ModellingRules:
		return "ServerType_ServerCapabilities_ModellingRules";
	case ObjectId::ServerType_ServerCapabilities_AggregateFunctions:
		return "ServerType_ServerCapabilities_AggregateFunctions";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_ServerViewCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_ServerViewCount";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSessionCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSessionCount";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSessionCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSessionCount";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedSessionCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedSessionCount";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_RejectedSessionCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_RejectedSessionCount";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SessionTimeoutCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SessionTimeoutCount";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SessionAbortCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SessionAbortCount";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_PublishingIntervalCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_PublishingIntervalCount";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSubscriptionCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CurrentSubscriptionCount";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSubscriptionCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_CumulatedSubscriptionCount";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedRequestsCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_SecurityRejectedRequestsCount";
	case ObjectId::ServerType_ServerDiagnostics_ServerDiagnosticsSummary_RejectedRequestsCount:
		return "ServerType_ServerDiagnostics_ServerDiagnosticsSummary_RejectedRequestsCount";
	case ObjectId::ServerType_ServerDiagnostics_SamplingIntervalDiagnosticsArray:
		return "ServerType_ServerDiagnostics_SamplingIntervalDiagnosticsArray";
	case ObjectId::ServerType_ServerDiagnostics_SubscriptionDiagnosticsArray:
		return "ServerType_ServerDiagnostics_SubscriptionDiagnosticsArray";
	case ObjectId::ServerType_ServerDiagnostics_SessionsDiagnosticsSummary:
		return "ServerType_ServerDiagnostics_SessionsDiagnosticsSummary";
	case ObjectId::ServerType_ServerDiagnostics_SessionsDiagnosticsSummary_SessionDiagnosticsArray:
		return "ServerType_ServerDiagnostics_SessionsDiagnosticsSummary_SessionDiagnosticsArray";
	case ObjectId::ServerType_ServerDiagnostics_SessionsDiagnosticsSummary_SessionSecurityDiagnosticsArray:
		return "ServerType_ServerDiagnostics_SessionsDiagnosticsSummary_SessionSecurityDiagnosticsArray";
	case ObjectId::ServerType_ServerDiagnostics_EnabledFlag:
		return "ServerType_ServerDiagnostics_EnabledFlag";
	case ObjectId::ServerType_ServerRedundancy_RedundancySupport:
		return "ServerType_ServerRedundancy_RedundancySupport";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_ServerViewCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_ServerViewCount";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_CurrentSessionCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_CurrentSessionCount";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_CumulatedSessionCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_CumulatedSessionCount";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_SecurityRejectedSessionCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_SecurityRejectedSessionCount";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_RejectedSessionCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_RejectedSessionCount";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_SessionTimeoutCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_SessionTimeoutCount";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_SessionAbortCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_SessionAbortCount";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_PublishingIntervalCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_PublishingIntervalCount";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_CurrentSubscriptionCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_CurrentSubscriptionCount";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_CumulatedSubscriptionCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_CumulatedSubscriptionCount";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_SecurityRejectedRequestsCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_SecurityRejectedRequestsCount";
	case ObjectId::ServerDiagnosticsType_ServerDiagnosticsSummary_RejectedRequestsCount:
		return "ServerDiagnosticsType_ServerDiagnosticsSummary_RejectedRequestsCount";
	case ObjectId::ServerDiagnosticsType_SessionsDiagnosticsSummary_SessionDiagnosticsArray:
		return "ServerDiagnosticsType_SessionsDiagnosticsSummary_SessionDiagnosticsArray";
	case ObjectId::ServerDiagnosticsType_SessionsDiagnosticsSummary_SessionSecurityDiagnosticsArray:
		return "ServerDiagnosticsType_SessionsDiagnosticsSummary_SessionSecurityDiagnosticsArray";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_SessionId:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_SessionId";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_SessionName:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_SessionName";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_ClientDescription:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_ClientDescription";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_ServerUri:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_ServerUri";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_EndpointUrl:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_EndpointUrl";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_LocaleIds:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_LocaleIds";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_ActualSessionTimeout:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_ActualSessionTimeout";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_MaxResponseMessageSize:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_MaxResponseMessageSize";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_ClientConnectionTime:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_ClientConnectionTime";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_ClientLastContactTime:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_ClientLastContactTime";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_CurrentSubscriptionsCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_CurrentSubscriptionsCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_CurrentMonitoredItemsCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_CurrentMonitoredItemsCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_CurrentPublishRequestsInQueue:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_CurrentPublishRequestsInQueue";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_ReadCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_ReadCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_HistoryReadCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_HistoryReadCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_WriteCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_WriteCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_HistoryUpdateCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_HistoryUpdateCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_CallCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_CallCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_CreateMonitoredItemsCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_CreateMonitoredItemsCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_ModifyMonitoredItemsCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_ModifyMonitoredItemsCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_SetMonitoringModeCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_SetMonitoringModeCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_SetTriggeringCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_SetTriggeringCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_DeleteMonitoredItemsCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_DeleteMonitoredItemsCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_CreateSubscriptionCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_CreateSubscriptionCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_ModifySubscriptionCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_ModifySubscriptionCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_SetPublishingModeCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_SetPublishingModeCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_PublishCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_PublishCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_RepublishCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_RepublishCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_TransferSubscriptionsCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_TransferSubscriptionsCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_DeleteSubscriptionsCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_DeleteSubscriptionsCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_AddNodesCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_AddNodesCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_AddReferencesCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_AddReferencesCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_DeleteNodesCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_DeleteNodesCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_DeleteReferencesCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_DeleteReferencesCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_BrowseCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_BrowseCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_BrowseNextCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_BrowseNextCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_TranslateBrowsePathsToNodeIdsCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_TranslateBrowsePathsToNodeIdsCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_QueryFirstCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_QueryFirstCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_QueryNextCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_QueryNextCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_RegisterNodesCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_RegisterNodesCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_UnregisterNodesCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_UnregisterNodesCount";
	case ObjectId::SessionDiagnosticsObjectType_SessionSecurityDiagnostics_SessionId:
		return "SessionDiagnosticsObjectType_SessionSecurityDiagnostics_SessionId";
	case ObjectId::SessionDiagnosticsObjectType_SessionSecurityDiagnostics_ClientUserIdOfSession:
		return "SessionDiagnosticsObjectType_SessionSecurityDiagnostics_ClientUserIdOfSession";
	case ObjectId::SessionDiagnosticsObjectType_SessionSecurityDiagnostics_ClientUserIdHistory:
		return "SessionDiagnosticsObjectType_SessionSecurityDiagnostics_ClientUserIdHistory";
	case ObjectId::SessionDiagnosticsObjectType_SessionSecurityDiagnostics_AuthenticationMechanism:
		return "SessionDiagnosticsObjectType_SessionSecurityDiagnostics_AuthenticationMechanism";
	case ObjectId::SessionDiagnosticsObjectType_SessionSecurityDiagnostics_Encoding:
		return "SessionDiagnosticsObjectType_SessionSecurityDiagnostics_Encoding";
	case ObjectId::SessionDiagnosticsObjectType_SessionSecurityDiagnostics_TransportProtocol:
		return "SessionDiagnosticsObjectType_SessionSecurityDiagnostics_TransportProtocol";
	case ObjectId::SessionDiagnosticsObjectType_SessionSecurityDiagnostics_SecurityMode:
		return "SessionDiagnosticsObjectType_SessionSecurityDiagnostics_SecurityMode";
	case ObjectId::SessionDiagnosticsObjectType_SessionSecurityDiagnostics_SecurityPolicyUri:
		return "SessionDiagnosticsObjectType_SessionSecurityDiagnostics_SecurityPolicyUri";
	case ObjectId::SessionDiagnosticsObjectType_SessionSecurityDiagnostics_ClientCertificate:
		return "SessionDiagnosticsObjectType_SessionSecurityDiagnostics_ClientCertificate";
	case ObjectId::TransparentRedundancyType_RedundancySupport:
		return "TransparentRedundancyType_RedundancySupport";
	case ObjectId::NonTransparentRedundancyType_RedundancySupport:
		return "NonTransparentRedundancyType_RedundancySupport";
	case ObjectId::BaseEventType_LocalTime:
		return "BaseEventType_LocalTime";
	case ObjectId::EventQueueOverflowEventType_EventId:
		return "EventQueueOverflowEventType_EventId";
	case ObjectId::EventQueueOverflowEventType_EventType:
		return "EventQueueOverflowEventType_EventType";
	case ObjectId::EventQueueOverflowEventType_SourceNode:
		return "EventQueueOverflowEventType_SourceNode";
	case ObjectId::EventQueueOverflowEventType_SourceName:
		return "EventQueueOverflowEventType_SourceName";
	case ObjectId::EventQueueOverflowEventType_Time:
		return "EventQueueOverflowEventType_Time";
	case ObjectId::EventQueueOverflowEventType_ReceiveTime:
		return "EventQueueOverflowEventType_ReceiveTime";
	case ObjectId::EventQueueOverflowEventType_LocalTime:
		return "EventQueueOverflowEventType_LocalTime";
	case ObjectId::EventQueueOverflowEventType_Message:
		return "EventQueueOverflowEventType_Message";
	case ObjectId::EventQueueOverflowEventType_Severity:
		return "EventQueueOverflowEventType_Severity";
	case ObjectId::AuditEventType_EventId:
		return "AuditEventType_EventId";
	case ObjectId::AuditEventType_EventType:
		return "AuditEventType_EventType";
	case ObjectId::AuditEventType_SourceNode:
		return "AuditEventType_SourceNode";
	case ObjectId::AuditEventType_SourceName:
		return "AuditEventType_SourceName";
	case ObjectId::AuditEventType_Time:
		return "AuditEventType_Time";
	case ObjectId::AuditEventType_ReceiveTime:
		return "AuditEventType_ReceiveTime";
	case ObjectId::AuditEventType_LocalTime:
		return "AuditEventType_LocalTime";
	case ObjectId::AuditEventType_Message:
		return "AuditEventType_Message";
	case ObjectId::AuditEventType_Severity:
		return "AuditEventType_Severity";
	case ObjectId::AuditSecurityEventType_EventId:
		return "AuditSecurityEventType_EventId";
	case ObjectId::AuditSecurityEventType_EventType:
		return "AuditSecurityEventType_EventType";
	case ObjectId::AuditSecurityEventType_SourceNode:
		return "AuditSecurityEventType_SourceNode";
	case ObjectId::AuditSecurityEventType_SourceName:
		return "AuditSecurityEventType_SourceName";
	case ObjectId::AuditSecurityEventType_Time:
		return "AuditSecurityEventType_Time";
	case ObjectId::AuditSecurityEventType_ReceiveTime:
		return "AuditSecurityEventType_ReceiveTime";
	case ObjectId::AuditSecurityEventType_LocalTime:
		return "AuditSecurityEventType_LocalTime";
	case ObjectId::AuditSecurityEventType_Message:
		return "AuditSecurityEventType_Message";
	case ObjectId::AuditSecurityEventType_Severity:
		return "AuditSecurityEventType_Severity";
	case ObjectId::AuditSecurityEventType_ActionTimeStamp:
		return "AuditSecurityEventType_ActionTimeStamp";
	case ObjectId::AuditSecurityEventType_Status:
		return "AuditSecurityEventType_Status";
	case ObjectId::AuditSecurityEventType_ServerId:
		return "AuditSecurityEventType_ServerId";
	case ObjectId::AuditSecurityEventType_ClientAuditEntryId:
		return "AuditSecurityEventType_ClientAuditEntryId";
	case ObjectId::AuditSecurityEventType_ClientUserId:
		return "AuditSecurityEventType_ClientUserId";
	case ObjectId::AuditChannelEventType_EventId:
		return "AuditChannelEventType_EventId";
	case ObjectId::AuditChannelEventType_EventType:
		return "AuditChannelEventType_EventType";
	case ObjectId::AuditChannelEventType_SourceNode:
		return "AuditChannelEventType_SourceNode";
	case ObjectId::AuditChannelEventType_SourceName:
		return "AuditChannelEventType_SourceName";
	case ObjectId::AuditChannelEventType_Time:
		return "AuditChannelEventType_Time";
	case ObjectId::AuditChannelEventType_ReceiveTime:
		return "AuditChannelEventType_ReceiveTime";
	case ObjectId::AuditChannelEventType_LocalTime:
		return "AuditChannelEventType_LocalTime";
	case ObjectId::AuditChannelEventType_Message:
		return "AuditChannelEventType_Message";
	case ObjectId::AuditChannelEventType_Severity:
		return "AuditChannelEventType_Severity";
	case ObjectId::AuditChannelEventType_ActionTimeStamp:
		return "AuditChannelEventType_ActionTimeStamp";
	case ObjectId::AuditChannelEventType_Status:
		return "AuditChannelEventType_Status";
	case ObjectId::AuditChannelEventType_ServerId:
		return "AuditChannelEventType_ServerId";
	case ObjectId::AuditChannelEventType_ClientAuditEntryId:
		return "AuditChannelEventType_ClientAuditEntryId";
	case ObjectId::AuditChannelEventType_ClientUserId:
		return "AuditChannelEventType_ClientUserId";
	case ObjectId::AuditOpenSecureChannelEventType_EventId:
		return "AuditOpenSecureChannelEventType_EventId";
	case ObjectId::AuditOpenSecureChannelEventType_EventType:
		return "AuditOpenSecureChannelEventType_EventType";
	case ObjectId::AuditOpenSecureChannelEventType_SourceNode:
		return "AuditOpenSecureChannelEventType_SourceNode";
	case ObjectId::AuditOpenSecureChannelEventType_SourceName:
		return "AuditOpenSecureChannelEventType_SourceName";
	case ObjectId::AuditOpenSecureChannelEventType_Time:
		return "AuditOpenSecureChannelEventType_Time";
	case ObjectId::AuditOpenSecureChannelEventType_ReceiveTime:
		return "AuditOpenSecureChannelEventType_ReceiveTime";
	case ObjectId::AuditOpenSecureChannelEventType_LocalTime:
		return "AuditOpenSecureChannelEventType_LocalTime";
	case ObjectId::AuditOpenSecureChannelEventType_Message:
		return "AuditOpenSecureChannelEventType_Message";
	case ObjectId::AuditOpenSecureChannelEventType_Severity:
		return "AuditOpenSecureChannelEventType_Severity";
	case ObjectId::AuditOpenSecureChannelEventType_ActionTimeStamp:
		return "AuditOpenSecureChannelEventType_ActionTimeStamp";
	case ObjectId::AuditOpenSecureChannelEventType_Status:
		return "AuditOpenSecureChannelEventType_Status";
	case ObjectId::AuditOpenSecureChannelEventType_ServerId:
		return "AuditOpenSecureChannelEventType_ServerId";
	case ObjectId::AuditOpenSecureChannelEventType_ClientAuditEntryId:
		return "AuditOpenSecureChannelEventType_ClientAuditEntryId";
	case ObjectId::AuditOpenSecureChannelEventType_ClientUserId:
		return "AuditOpenSecureChannelEventType_ClientUserId";
	case ObjectId::AuditOpenSecureChannelEventType_SecureChannelId:
		return "AuditOpenSecureChannelEventType_SecureChannelId";
	case ObjectId::AuditSessionEventType_EventId:
		return "AuditSessionEventType_EventId";
	case ObjectId::AuditSessionEventType_EventType:
		return "AuditSessionEventType_EventType";
	case ObjectId::AuditSessionEventType_SourceNode:
		return "AuditSessionEventType_SourceNode";
	case ObjectId::AuditSessionEventType_SourceName:
		return "AuditSessionEventType_SourceName";
	case ObjectId::AuditSessionEventType_Time:
		return "AuditSessionEventType_Time";
	case ObjectId::AuditSessionEventType_ReceiveTime:
		return "AuditSessionEventType_ReceiveTime";
	case ObjectId::AuditSessionEventType_LocalTime:
		return "AuditSessionEventType_LocalTime";
	case ObjectId::AuditSessionEventType_Message:
		return "AuditSessionEventType_Message";
	case ObjectId::AuditSessionEventType_Severity:
		return "AuditSessionEventType_Severity";
	case ObjectId::AuditSessionEventType_ActionTimeStamp:
		return "AuditSessionEventType_ActionTimeStamp";
	case ObjectId::AuditSessionEventType_Status:
		return "AuditSessionEventType_Status";
	case ObjectId::AuditSessionEventType_ServerId:
		return "AuditSessionEventType_ServerId";
	case ObjectId::AuditSessionEventType_ClientAuditEntryId:
		return "AuditSessionEventType_ClientAuditEntryId";
	case ObjectId::AuditSessionEventType_ClientUserId:
		return "AuditSessionEventType_ClientUserId";
	case ObjectId::AuditCreateSessionEventType_EventId:
		return "AuditCreateSessionEventType_EventId";
	case ObjectId::AuditCreateSessionEventType_EventType:
		return "AuditCreateSessionEventType_EventType";
	case ObjectId::AuditCreateSessionEventType_SourceNode:
		return "AuditCreateSessionEventType_SourceNode";
	case ObjectId::AuditCreateSessionEventType_SourceName:
		return "AuditCreateSessionEventType_SourceName";
	case ObjectId::AuditCreateSessionEventType_Time:
		return "AuditCreateSessionEventType_Time";
	case ObjectId::AuditCreateSessionEventType_ReceiveTime:
		return "AuditCreateSessionEventType_ReceiveTime";
	case ObjectId::AuditCreateSessionEventType_LocalTime:
		return "AuditCreateSessionEventType_LocalTime";
	case ObjectId::AuditCreateSessionEventType_Message:
		return "AuditCreateSessionEventType_Message";
	case ObjectId::AuditCreateSessionEventType_Severity:
		return "AuditCreateSessionEventType_Severity";
	case ObjectId::AuditCreateSessionEventType_ActionTimeStamp:
		return "AuditCreateSessionEventType_ActionTimeStamp";
	case ObjectId::AuditCreateSessionEventType_Status:
		return "AuditCreateSessionEventType_Status";
	case ObjectId::AuditCreateSessionEventType_ServerId:
		return "AuditCreateSessionEventType_ServerId";
	case ObjectId::AuditCreateSessionEventType_ClientAuditEntryId:
		return "AuditCreateSessionEventType_ClientAuditEntryId";
	case ObjectId::AuditCreateSessionEventType_ClientUserId:
		return "AuditCreateSessionEventType_ClientUserId";
	case ObjectId::AuditCreateSessionEventType_SessionId:
		return "AuditCreateSessionEventType_SessionId";
	case ObjectId::AuditUrlMismatchEventType_EventId:
		return "AuditUrlMismatchEventType_EventId";
	case ObjectId::AuditUrlMismatchEventType_EventType:
		return "AuditUrlMismatchEventType_EventType";
	case ObjectId::AuditUrlMismatchEventType_SourceNode:
		return "AuditUrlMismatchEventType_SourceNode";
	case ObjectId::AuditUrlMismatchEventType_SourceName:
		return "AuditUrlMismatchEventType_SourceName";
	case ObjectId::AuditUrlMismatchEventType_Time:
		return "AuditUrlMismatchEventType_Time";
	case ObjectId::AuditUrlMismatchEventType_ReceiveTime:
		return "AuditUrlMismatchEventType_ReceiveTime";
	case ObjectId::AuditUrlMismatchEventType_LocalTime:
		return "AuditUrlMismatchEventType_LocalTime";
	case ObjectId::AuditUrlMismatchEventType_Message:
		return "AuditUrlMismatchEventType_Message";
	case ObjectId::AuditUrlMismatchEventType_Severity:
		return "AuditUrlMismatchEventType_Severity";
	case ObjectId::AuditUrlMismatchEventType_ActionTimeStamp:
		return "AuditUrlMismatchEventType_ActionTimeStamp";
	case ObjectId::AuditUrlMismatchEventType_Status:
		return "AuditUrlMismatchEventType_Status";
	case ObjectId::AuditUrlMismatchEventType_ServerId:
		return "AuditUrlMismatchEventType_ServerId";
	case ObjectId::AuditUrlMismatchEventType_ClientAuditEntryId:
		return "AuditUrlMismatchEventType_ClientAuditEntryId";
	case ObjectId::AuditUrlMismatchEventType_ClientUserId:
		return "AuditUrlMismatchEventType_ClientUserId";
	case ObjectId::AuditUrlMismatchEventType_SessionId:
		return "AuditUrlMismatchEventType_SessionId";
	case ObjectId::AuditUrlMismatchEventType_SecureChannelId:
		return "AuditUrlMismatchEventType_SecureChannelId";
	case ObjectId::AuditUrlMismatchEventType_ClientCertificate:
		return "AuditUrlMismatchEventType_ClientCertificate";
	case ObjectId::AuditUrlMismatchEventType_ClientCertificateThumbprint:
		return "AuditUrlMismatchEventType_ClientCertificateThumbprint";
	case ObjectId::AuditUrlMismatchEventType_RevisedSessionTimeout:
		return "AuditUrlMismatchEventType_RevisedSessionTimeout";
	case ObjectId::AuditActivateSessionEventType_EventId:
		return "AuditActivateSessionEventType_EventId";
	case ObjectId::AuditActivateSessionEventType_EventType:
		return "AuditActivateSessionEventType_EventType";
	case ObjectId::AuditActivateSessionEventType_SourceNode:
		return "AuditActivateSessionEventType_SourceNode";
	case ObjectId::AuditActivateSessionEventType_SourceName:
		return "AuditActivateSessionEventType_SourceName";
	case ObjectId::AuditActivateSessionEventType_Time:
		return "AuditActivateSessionEventType_Time";
	case ObjectId::AuditActivateSessionEventType_ReceiveTime:
		return "AuditActivateSessionEventType_ReceiveTime";
	case ObjectId::AuditActivateSessionEventType_LocalTime:
		return "AuditActivateSessionEventType_LocalTime";
	case ObjectId::AuditActivateSessionEventType_Message:
		return "AuditActivateSessionEventType_Message";
	case ObjectId::AuditActivateSessionEventType_Severity:
		return "AuditActivateSessionEventType_Severity";
	case ObjectId::AuditActivateSessionEventType_ActionTimeStamp:
		return "AuditActivateSessionEventType_ActionTimeStamp";
	case ObjectId::AuditActivateSessionEventType_Status:
		return "AuditActivateSessionEventType_Status";
	case ObjectId::AuditActivateSessionEventType_ServerId:
		return "AuditActivateSessionEventType_ServerId";
	case ObjectId::AuditActivateSessionEventType_ClientAuditEntryId:
		return "AuditActivateSessionEventType_ClientAuditEntryId";
	case ObjectId::AuditActivateSessionEventType_ClientUserId:
		return "AuditActivateSessionEventType_ClientUserId";
	case ObjectId::AuditActivateSessionEventType_SessionId:
		return "AuditActivateSessionEventType_SessionId";
	case ObjectId::AuditCancelEventType_EventId:
		return "AuditCancelEventType_EventId";
	case ObjectId::AuditCancelEventType_EventType:
		return "AuditCancelEventType_EventType";
	case ObjectId::AuditCancelEventType_SourceNode:
		return "AuditCancelEventType_SourceNode";
	case ObjectId::AuditCancelEventType_SourceName:
		return "AuditCancelEventType_SourceName";
	case ObjectId::AuditCancelEventType_Time:
		return "AuditCancelEventType_Time";
	case ObjectId::AuditCancelEventType_ReceiveTime:
		return "AuditCancelEventType_ReceiveTime";
	case ObjectId::AuditCancelEventType_LocalTime:
		return "AuditCancelEventType_LocalTime";
	case ObjectId::AuditCancelEventType_Message:
		return "AuditCancelEventType_Message";
	case ObjectId::AuditCancelEventType_Severity:
		return "AuditCancelEventType_Severity";
	case ObjectId::AuditCancelEventType_ActionTimeStamp:
		return "AuditCancelEventType_ActionTimeStamp";
	case ObjectId::AuditCancelEventType_Status:
		return "AuditCancelEventType_Status";
	case ObjectId::AuditCancelEventType_ServerId:
		return "AuditCancelEventType_ServerId";
	case ObjectId::AuditCancelEventType_ClientAuditEntryId:
		return "AuditCancelEventType_ClientAuditEntryId";
	case ObjectId::AuditCancelEventType_ClientUserId:
		return "AuditCancelEventType_ClientUserId";
	case ObjectId::AuditCancelEventType_SessionId:
		return "AuditCancelEventType_SessionId";
	case ObjectId::AuditCertificateEventType_EventId:
		return "AuditCertificateEventType_EventId";
	case ObjectId::AuditCertificateEventType_EventType:
		return "AuditCertificateEventType_EventType";
	case ObjectId::AuditCertificateEventType_SourceNode:
		return "AuditCertificateEventType_SourceNode";
	case ObjectId::AuditCertificateEventType_SourceName:
		return "AuditCertificateEventType_SourceName";
	case ObjectId::AuditCertificateEventType_Time:
		return "AuditCertificateEventType_Time";
	case ObjectId::AuditCertificateEventType_ReceiveTime:
		return "AuditCertificateEventType_ReceiveTime";
	case ObjectId::AuditCertificateEventType_LocalTime:
		return "AuditCertificateEventType_LocalTime";
	case ObjectId::AuditCertificateEventType_Message:
		return "AuditCertificateEventType_Message";
	case ObjectId::AuditCertificateEventType_Severity:
		return "AuditCertificateEventType_Severity";
	case ObjectId::AuditCertificateEventType_ActionTimeStamp:
		return "AuditCertificateEventType_ActionTimeStamp";
	case ObjectId::AuditCertificateEventType_Status:
		return "AuditCertificateEventType_Status";
	case ObjectId::AuditCertificateEventType_ServerId:
		return "AuditCertificateEventType_ServerId";
	case ObjectId::AuditCertificateEventType_ClientAuditEntryId:
		return "AuditCertificateEventType_ClientAuditEntryId";
	case ObjectId::AuditCertificateEventType_ClientUserId:
		return "AuditCertificateEventType_ClientUserId";
	case ObjectId::AuditCertificateDataMismatchEventType_EventId:
		return "AuditCertificateDataMismatchEventType_EventId";
	case ObjectId::AuditCertificateDataMismatchEventType_EventType:
		return "AuditCertificateDataMismatchEventType_EventType";
	case ObjectId::AuditCertificateDataMismatchEventType_SourceNode:
		return "AuditCertificateDataMismatchEventType_SourceNode";
	case ObjectId::AuditCertificateDataMismatchEventType_SourceName:
		return "AuditCertificateDataMismatchEventType_SourceName";
	case ObjectId::AuditCertificateDataMismatchEventType_Time:
		return "AuditCertificateDataMismatchEventType_Time";
	case ObjectId::AuditCertificateDataMismatchEventType_ReceiveTime:
		return "AuditCertificateDataMismatchEventType_ReceiveTime";
	case ObjectId::AuditCertificateDataMismatchEventType_LocalTime:
		return "AuditCertificateDataMismatchEventType_LocalTime";
	case ObjectId::AuditCertificateDataMismatchEventType_Message:
		return "AuditCertificateDataMismatchEventType_Message";
	case ObjectId::AuditCertificateDataMismatchEventType_Severity:
		return "AuditCertificateDataMismatchEventType_Severity";
	case ObjectId::AuditCertificateDataMismatchEventType_ActionTimeStamp:
		return "AuditCertificateDataMismatchEventType_ActionTimeStamp";
	case ObjectId::AuditCertificateDataMismatchEventType_Status:
		return "AuditCertificateDataMismatchEventType_Status";
	case ObjectId::AuditCertificateDataMismatchEventType_ServerId:
		return "AuditCertificateDataMismatchEventType_ServerId";
	case ObjectId::AuditCertificateDataMismatchEventType_ClientAuditEntryId:
		return "AuditCertificateDataMismatchEventType_ClientAuditEntryId";
	case ObjectId::AuditCertificateDataMismatchEventType_ClientUserId:
		return "AuditCertificateDataMismatchEventType_ClientUserId";
	case ObjectId::AuditCertificateDataMismatchEventType_Certificate:
		return "AuditCertificateDataMismatchEventType_Certificate";
	case ObjectId::AuditCertificateExpiredEventType_EventId:
		return "AuditCertificateExpiredEventType_EventId";
	case ObjectId::AuditCertificateExpiredEventType_EventType:
		return "AuditCertificateExpiredEventType_EventType";
	case ObjectId::AuditCertificateExpiredEventType_SourceNode:
		return "AuditCertificateExpiredEventType_SourceNode";
	case ObjectId::AuditCertificateExpiredEventType_SourceName:
		return "AuditCertificateExpiredEventType_SourceName";
	case ObjectId::AuditCertificateExpiredEventType_Time:
		return "AuditCertificateExpiredEventType_Time";
	case ObjectId::AuditCertificateExpiredEventType_ReceiveTime:
		return "AuditCertificateExpiredEventType_ReceiveTime";
	case ObjectId::AuditCertificateExpiredEventType_LocalTime:
		return "AuditCertificateExpiredEventType_LocalTime";
	case ObjectId::AuditCertificateExpiredEventType_Message:
		return "AuditCertificateExpiredEventType_Message";
	case ObjectId::AuditCertificateExpiredEventType_Severity:
		return "AuditCertificateExpiredEventType_Severity";
	case ObjectId::AuditCertificateExpiredEventType_ActionTimeStamp:
		return "AuditCertificateExpiredEventType_ActionTimeStamp";
	case ObjectId::AuditCertificateExpiredEventType_Status:
		return "AuditCertificateExpiredEventType_Status";
	case ObjectId::AuditCertificateExpiredEventType_ServerId:
		return "AuditCertificateExpiredEventType_ServerId";
	case ObjectId::AuditCertificateExpiredEventType_ClientAuditEntryId:
		return "AuditCertificateExpiredEventType_ClientAuditEntryId";
	case ObjectId::AuditCertificateExpiredEventType_ClientUserId:
		return "AuditCertificateExpiredEventType_ClientUserId";
	case ObjectId::AuditCertificateExpiredEventType_Certificate:
		return "AuditCertificateExpiredEventType_Certificate";
	case ObjectId::AuditCertificateInvalidEventType_EventId:
		return "AuditCertificateInvalidEventType_EventId";
	case ObjectId::AuditCertificateInvalidEventType_EventType:
		return "AuditCertificateInvalidEventType_EventType";
	case ObjectId::AuditCertificateInvalidEventType_SourceNode:
		return "AuditCertificateInvalidEventType_SourceNode";
	case ObjectId::AuditCertificateInvalidEventType_SourceName:
		return "AuditCertificateInvalidEventType_SourceName";
	case ObjectId::AuditCertificateInvalidEventType_Time:
		return "AuditCertificateInvalidEventType_Time";
	case ObjectId::AuditCertificateInvalidEventType_ReceiveTime:
		return "AuditCertificateInvalidEventType_ReceiveTime";
	case ObjectId::AuditCertificateInvalidEventType_LocalTime:
		return "AuditCertificateInvalidEventType_LocalTime";
	case ObjectId::AuditCertificateInvalidEventType_Message:
		return "AuditCertificateInvalidEventType_Message";
	case ObjectId::AuditCertificateInvalidEventType_Severity:
		return "AuditCertificateInvalidEventType_Severity";
	case ObjectId::AuditCertificateInvalidEventType_ActionTimeStamp:
		return "AuditCertificateInvalidEventType_ActionTimeStamp";
	case ObjectId::AuditCertificateInvalidEventType_Status:
		return "AuditCertificateInvalidEventType_Status";
	case ObjectId::AuditCertificateInvalidEventType_ServerId:
		return "AuditCertificateInvalidEventType_ServerId";
	case ObjectId::AuditCertificateInvalidEventType_ClientAuditEntryId:
		return "AuditCertificateInvalidEventType_ClientAuditEntryId";
	case ObjectId::AuditCertificateInvalidEventType_ClientUserId:
		return "AuditCertificateInvalidEventType_ClientUserId";
	case ObjectId::AuditCertificateInvalidEventType_Certificate:
		return "AuditCertificateInvalidEventType_Certificate";
	case ObjectId::AuditCertificateUntrustedEventType_EventId:
		return "AuditCertificateUntrustedEventType_EventId";
	case ObjectId::AuditCertificateUntrustedEventType_EventType:
		return "AuditCertificateUntrustedEventType_EventType";
	case ObjectId::AuditCertificateUntrustedEventType_SourceNode:
		return "AuditCertificateUntrustedEventType_SourceNode";
	case ObjectId::AuditCertificateUntrustedEventType_SourceName:
		return "AuditCertificateUntrustedEventType_SourceName";
	case ObjectId::AuditCertificateUntrustedEventType_Time:
		return "AuditCertificateUntrustedEventType_Time";
	case ObjectId::AuditCertificateUntrustedEventType_ReceiveTime:
		return "AuditCertificateUntrustedEventType_ReceiveTime";
	case ObjectId::AuditCertificateUntrustedEventType_LocalTime:
		return "AuditCertificateUntrustedEventType_LocalTime";
	case ObjectId::AuditCertificateUntrustedEventType_Message:
		return "AuditCertificateUntrustedEventType_Message";
	case ObjectId::AuditCertificateUntrustedEventType_Severity:
		return "AuditCertificateUntrustedEventType_Severity";
	case ObjectId::AuditCertificateUntrustedEventType_ActionTimeStamp:
		return "AuditCertificateUntrustedEventType_ActionTimeStamp";
	case ObjectId::AuditCertificateUntrustedEventType_Status:
		return "AuditCertificateUntrustedEventType_Status";
	case ObjectId::AuditCertificateUntrustedEventType_ServerId:
		return "AuditCertificateUntrustedEventType_ServerId";
	case ObjectId::AuditCertificateUntrustedEventType_ClientAuditEntryId:
		return "AuditCertificateUntrustedEventType_ClientAuditEntryId";
	case ObjectId::AuditCertificateUntrustedEventType_ClientUserId:
		return "AuditCertificateUntrustedEventType_ClientUserId";
	case ObjectId::AuditCertificateUntrustedEventType_Certificate:
		return "AuditCertificateUntrustedEventType_Certificate";
	case ObjectId::AuditCertificateRevokedEventType_EventId:
		return "AuditCertificateRevokedEventType_EventId";
	case ObjectId::AuditCertificateRevokedEventType_EventType:
		return "AuditCertificateRevokedEventType_EventType";
	case ObjectId::AuditCertificateRevokedEventType_SourceNode:
		return "AuditCertificateRevokedEventType_SourceNode";
	case ObjectId::AuditCertificateRevokedEventType_SourceName:
		return "AuditCertificateRevokedEventType_SourceName";
	case ObjectId::AuditCertificateRevokedEventType_Time:
		return "AuditCertificateRevokedEventType_Time";
	case ObjectId::AuditCertificateRevokedEventType_ReceiveTime:
		return "AuditCertificateRevokedEventType_ReceiveTime";
	case ObjectId::AuditCertificateRevokedEventType_LocalTime:
		return "AuditCertificateRevokedEventType_LocalTime";
	case ObjectId::AuditCertificateRevokedEventType_Message:
		return "AuditCertificateRevokedEventType_Message";
	case ObjectId::AuditCertificateRevokedEventType_Severity:
		return "AuditCertificateRevokedEventType_Severity";
	case ObjectId::AuditCertificateRevokedEventType_ActionTimeStamp:
		return "AuditCertificateRevokedEventType_ActionTimeStamp";
	case ObjectId::AuditCertificateRevokedEventType_Status:
		return "AuditCertificateRevokedEventType_Status";
	case ObjectId::AuditCertificateRevokedEventType_ServerId:
		return "AuditCertificateRevokedEventType_ServerId";
	case ObjectId::AuditCertificateRevokedEventType_ClientAuditEntryId:
		return "AuditCertificateRevokedEventType_ClientAuditEntryId";
	case ObjectId::AuditCertificateRevokedEventType_ClientUserId:
		return "AuditCertificateRevokedEventType_ClientUserId";
	case ObjectId::AuditCertificateRevokedEventType_Certificate:
		return "AuditCertificateRevokedEventType_Certificate";
	case ObjectId::AuditCertificateMismatchEventType_EventId:
		return "AuditCertificateMismatchEventType_EventId";
	case ObjectId::AuditCertificateMismatchEventType_EventType:
		return "AuditCertificateMismatchEventType_EventType";
	case ObjectId::AuditCertificateMismatchEventType_SourceNode:
		return "AuditCertificateMismatchEventType_SourceNode";
	case ObjectId::AuditCertificateMismatchEventType_SourceName:
		return "AuditCertificateMismatchEventType_SourceName";
	case ObjectId::AuditCertificateMismatchEventType_Time:
		return "AuditCertificateMismatchEventType_Time";
	case ObjectId::AuditCertificateMismatchEventType_ReceiveTime:
		return "AuditCertificateMismatchEventType_ReceiveTime";
	case ObjectId::AuditCertificateMismatchEventType_LocalTime:
		return "AuditCertificateMismatchEventType_LocalTime";
	case ObjectId::AuditCertificateMismatchEventType_Message:
		return "AuditCertificateMismatchEventType_Message";
	case ObjectId::AuditCertificateMismatchEventType_Severity:
		return "AuditCertificateMismatchEventType_Severity";
	case ObjectId::AuditCertificateMismatchEventType_ActionTimeStamp:
		return "AuditCertificateMismatchEventType_ActionTimeStamp";
	case ObjectId::AuditCertificateMismatchEventType_Status:
		return "AuditCertificateMismatchEventType_Status";
	case ObjectId::AuditCertificateMismatchEventType_ServerId:
		return "AuditCertificateMismatchEventType_ServerId";
	case ObjectId::AuditCertificateMismatchEventType_ClientAuditEntryId:
		return "AuditCertificateMismatchEventType_ClientAuditEntryId";
	case ObjectId::AuditCertificateMismatchEventType_ClientUserId:
		return "AuditCertificateMismatchEventType_ClientUserId";
	case ObjectId::AuditCertificateMismatchEventType_Certificate:
		return "AuditCertificateMismatchEventType_Certificate";
	case ObjectId::AuditNodeManagementEventType_EventId:
		return "AuditNodeManagementEventType_EventId";
	case ObjectId::AuditNodeManagementEventType_EventType:
		return "AuditNodeManagementEventType_EventType";
	case ObjectId::AuditNodeManagementEventType_SourceNode:
		return "AuditNodeManagementEventType_SourceNode";
	case ObjectId::AuditNodeManagementEventType_SourceName:
		return "AuditNodeManagementEventType_SourceName";
	case ObjectId::AuditNodeManagementEventType_Time:
		return "AuditNodeManagementEventType_Time";
	case ObjectId::AuditNodeManagementEventType_ReceiveTime:
		return "AuditNodeManagementEventType_ReceiveTime";
	case ObjectId::AuditNodeManagementEventType_LocalTime:
		return "AuditNodeManagementEventType_LocalTime";
	case ObjectId::AuditNodeManagementEventType_Message:
		return "AuditNodeManagementEventType_Message";
	case ObjectId::AuditNodeManagementEventType_Severity:
		return "AuditNodeManagementEventType_Severity";
	case ObjectId::AuditNodeManagementEventType_ActionTimeStamp:
		return "AuditNodeManagementEventType_ActionTimeStamp";
	case ObjectId::AuditNodeManagementEventType_Status:
		return "AuditNodeManagementEventType_Status";
	case ObjectId::AuditNodeManagementEventType_ServerId:
		return "AuditNodeManagementEventType_ServerId";
	case ObjectId::AuditNodeManagementEventType_ClientAuditEntryId:
		return "AuditNodeManagementEventType_ClientAuditEntryId";
	case ObjectId::AuditNodeManagementEventType_ClientUserId:
		return "AuditNodeManagementEventType_ClientUserId";
	case ObjectId::AuditAddNodesEventType_EventId:
		return "AuditAddNodesEventType_EventId";
	case ObjectId::AuditAddNodesEventType_EventType:
		return "AuditAddNodesEventType_EventType";
	case ObjectId::AuditAddNodesEventType_SourceNode:
		return "AuditAddNodesEventType_SourceNode";
	case ObjectId::AuditAddNodesEventType_SourceName:
		return "AuditAddNodesEventType_SourceName";
	case ObjectId::AuditAddNodesEventType_Time:
		return "AuditAddNodesEventType_Time";
	case ObjectId::AuditAddNodesEventType_ReceiveTime:
		return "AuditAddNodesEventType_ReceiveTime";
	case ObjectId::AuditAddNodesEventType_LocalTime:
		return "AuditAddNodesEventType_LocalTime";
	case ObjectId::AuditAddNodesEventType_Message:
		return "AuditAddNodesEventType_Message";
	case ObjectId::AuditAddNodesEventType_Severity:
		return "AuditAddNodesEventType_Severity";
	case ObjectId::AuditAddNodesEventType_ActionTimeStamp:
		return "AuditAddNodesEventType_ActionTimeStamp";
	case ObjectId::AuditAddNodesEventType_Status:
		return "AuditAddNodesEventType_Status";
	case ObjectId::AuditAddNodesEventType_ServerId:
		return "AuditAddNodesEventType_ServerId";
	case ObjectId::AuditAddNodesEventType_ClientAuditEntryId:
		return "AuditAddNodesEventType_ClientAuditEntryId";
	case ObjectId::AuditAddNodesEventType_ClientUserId:
		return "AuditAddNodesEventType_ClientUserId";
	case ObjectId::AuditDeleteNodesEventType_EventId:
		return "AuditDeleteNodesEventType_EventId";
	case ObjectId::AuditDeleteNodesEventType_EventType:
		return "AuditDeleteNodesEventType_EventType";
	case ObjectId::AuditDeleteNodesEventType_SourceNode:
		return "AuditDeleteNodesEventType_SourceNode";
	case ObjectId::AuditDeleteNodesEventType_SourceName:
		return "AuditDeleteNodesEventType_SourceName";
	case ObjectId::AuditDeleteNodesEventType_Time:
		return "AuditDeleteNodesEventType_Time";
	case ObjectId::AuditDeleteNodesEventType_ReceiveTime:
		return "AuditDeleteNodesEventType_ReceiveTime";
	case ObjectId::AuditDeleteNodesEventType_LocalTime:
		return "AuditDeleteNodesEventType_LocalTime";
	case ObjectId::AuditDeleteNodesEventType_Message:
		return "AuditDeleteNodesEventType_Message";
	case ObjectId::AuditDeleteNodesEventType_Severity:
		return "AuditDeleteNodesEventType_Severity";
	case ObjectId::AuditDeleteNodesEventType_ActionTimeStamp:
		return "AuditDeleteNodesEventType_ActionTimeStamp";
	case ObjectId::AuditDeleteNodesEventType_Status:
		return "AuditDeleteNodesEventType_Status";
	case ObjectId::AuditDeleteNodesEventType_ServerId:
		return "AuditDeleteNodesEventType_ServerId";
	case ObjectId::AuditDeleteNodesEventType_ClientAuditEntryId:
		return "AuditDeleteNodesEventType_ClientAuditEntryId";
	case ObjectId::AuditDeleteNodesEventType_ClientUserId:
		return "AuditDeleteNodesEventType_ClientUserId";
	case ObjectId::AuditAddReferencesEventType_EventId:
		return "AuditAddReferencesEventType_EventId";
	case ObjectId::AuditAddReferencesEventType_EventType:
		return "AuditAddReferencesEventType_EventType";
	case ObjectId::AuditAddReferencesEventType_SourceNode:
		return "AuditAddReferencesEventType_SourceNode";
	case ObjectId::AuditAddReferencesEventType_SourceName:
		return "AuditAddReferencesEventType_SourceName";
	case ObjectId::AuditAddReferencesEventType_Time:
		return "AuditAddReferencesEventType_Time";
	case ObjectId::AuditAddReferencesEventType_ReceiveTime:
		return "AuditAddReferencesEventType_ReceiveTime";
	case ObjectId::AuditAddReferencesEventType_LocalTime:
		return "AuditAddReferencesEventType_LocalTime";
	case ObjectId::AuditAddReferencesEventType_Message:
		return "AuditAddReferencesEventType_Message";
	case ObjectId::AuditAddReferencesEventType_Severity:
		return "AuditAddReferencesEventType_Severity";
	case ObjectId::AuditAddReferencesEventType_ActionTimeStamp:
		return "AuditAddReferencesEventType_ActionTimeStamp";
	case ObjectId::AuditAddReferencesEventType_Status:
		return "AuditAddReferencesEventType_Status";
	case ObjectId::AuditAddReferencesEventType_ServerId:
		return "AuditAddReferencesEventType_ServerId";
	case ObjectId::AuditAddReferencesEventType_ClientAuditEntryId:
		return "AuditAddReferencesEventType_ClientAuditEntryId";
	case ObjectId::AuditAddReferencesEventType_ClientUserId:
		return "AuditAddReferencesEventType_ClientUserId";
	case ObjectId::AuditDeleteReferencesEventType_EventId:
		return "AuditDeleteReferencesEventType_EventId";
	case ObjectId::AuditDeleteReferencesEventType_EventType:
		return "AuditDeleteReferencesEventType_EventType";
	case ObjectId::AuditDeleteReferencesEventType_SourceNode:
		return "AuditDeleteReferencesEventType_SourceNode";
	case ObjectId::AuditDeleteReferencesEventType_SourceName:
		return "AuditDeleteReferencesEventType_SourceName";
	case ObjectId::AuditDeleteReferencesEventType_Time:
		return "AuditDeleteReferencesEventType_Time";
	case ObjectId::AuditDeleteReferencesEventType_ReceiveTime:
		return "AuditDeleteReferencesEventType_ReceiveTime";
	case ObjectId::AuditDeleteReferencesEventType_LocalTime:
		return "AuditDeleteReferencesEventType_LocalTime";
	case ObjectId::AuditDeleteReferencesEventType_Message:
		return "AuditDeleteReferencesEventType_Message";
	case ObjectId::AuditDeleteReferencesEventType_Severity:
		return "AuditDeleteReferencesEventType_Severity";
	case ObjectId::AuditDeleteReferencesEventType_ActionTimeStamp:
		return "AuditDeleteReferencesEventType_ActionTimeStamp";
	case ObjectId::AuditDeleteReferencesEventType_Status:
		return "AuditDeleteReferencesEventType_Status";
	case ObjectId::AuditDeleteReferencesEventType_ServerId:
		return "AuditDeleteReferencesEventType_ServerId";
	case ObjectId::AuditDeleteReferencesEventType_ClientAuditEntryId:
		return "AuditDeleteReferencesEventType_ClientAuditEntryId";
	case ObjectId::AuditDeleteReferencesEventType_ClientUserId:
		return "AuditDeleteReferencesEventType_ClientUserId";
	case ObjectId::AuditUpdateEventType_EventId:
		return "AuditUpdateEventType_EventId";
	case ObjectId::AuditUpdateEventType_EventType:
		return "AuditUpdateEventType_EventType";
	case ObjectId::AuditUpdateEventType_SourceNode:
		return "AuditUpdateEventType_SourceNode";
	case ObjectId::AuditUpdateEventType_SourceName:
		return "AuditUpdateEventType_SourceName";
	case ObjectId::AuditUpdateEventType_Time:
		return "AuditUpdateEventType_Time";
	case ObjectId::AuditUpdateEventType_ReceiveTime:
		return "AuditUpdateEventType_ReceiveTime";
	case ObjectId::AuditUpdateEventType_LocalTime:
		return "AuditUpdateEventType_LocalTime";
	case ObjectId::AuditUpdateEventType_Message:
		return "AuditUpdateEventType_Message";
	case ObjectId::AuditUpdateEventType_Severity:
		return "AuditUpdateEventType_Severity";
	case ObjectId::AuditUpdateEventType_ActionTimeStamp:
		return "AuditUpdateEventType_ActionTimeStamp";
	case ObjectId::AuditUpdateEventType_Status:
		return "AuditUpdateEventType_Status";
	case ObjectId::AuditUpdateEventType_ServerId:
		return "AuditUpdateEventType_ServerId";
	case ObjectId::AuditUpdateEventType_ClientAuditEntryId:
		return "AuditUpdateEventType_ClientAuditEntryId";
	case ObjectId::AuditUpdateEventType_ClientUserId:
		return "AuditUpdateEventType_ClientUserId";
	case ObjectId::AuditWriteUpdateEventType_EventId:
		return "AuditWriteUpdateEventType_EventId";
	case ObjectId::AuditWriteUpdateEventType_EventType:
		return "AuditWriteUpdateEventType_EventType";
	case ObjectId::AuditWriteUpdateEventType_SourceNode:
		return "AuditWriteUpdateEventType_SourceNode";
	case ObjectId::AuditWriteUpdateEventType_SourceName:
		return "AuditWriteUpdateEventType_SourceName";
	case ObjectId::AuditWriteUpdateEventType_Time:
		return "AuditWriteUpdateEventType_Time";
	case ObjectId::AuditWriteUpdateEventType_ReceiveTime:
		return "AuditWriteUpdateEventType_ReceiveTime";
	case ObjectId::AuditWriteUpdateEventType_LocalTime:
		return "AuditWriteUpdateEventType_LocalTime";
	case ObjectId::AuditWriteUpdateEventType_Message:
		return "AuditWriteUpdateEventType_Message";
	case ObjectId::AuditWriteUpdateEventType_Severity:
		return "AuditWriteUpdateEventType_Severity";
	case ObjectId::AuditWriteUpdateEventType_ActionTimeStamp:
		return "AuditWriteUpdateEventType_ActionTimeStamp";
	case ObjectId::AuditWriteUpdateEventType_Status:
		return "AuditWriteUpdateEventType_Status";
	case ObjectId::AuditWriteUpdateEventType_ServerId:
		return "AuditWriteUpdateEventType_ServerId";
	case ObjectId::AuditWriteUpdateEventType_ClientAuditEntryId:
		return "AuditWriteUpdateEventType_ClientAuditEntryId";
	case ObjectId::AuditWriteUpdateEventType_ClientUserId:
		return "AuditWriteUpdateEventType_ClientUserId";
	case ObjectId::AuditHistoryUpdateEventType_EventId:
		return "AuditHistoryUpdateEventType_EventId";
	case ObjectId::AuditHistoryUpdateEventType_EventType:
		return "AuditHistoryUpdateEventType_EventType";
	case ObjectId::AuditHistoryUpdateEventType_SourceNode:
		return "AuditHistoryUpdateEventType_SourceNode";
	case ObjectId::AuditHistoryUpdateEventType_SourceName:
		return "AuditHistoryUpdateEventType_SourceName";
	case ObjectId::AuditHistoryUpdateEventType_Time:
		return "AuditHistoryUpdateEventType_Time";
	case ObjectId::AuditHistoryUpdateEventType_ReceiveTime:
		return "AuditHistoryUpdateEventType_ReceiveTime";
	case ObjectId::AuditHistoryUpdateEventType_LocalTime:
		return "AuditHistoryUpdateEventType_LocalTime";
	case ObjectId::AuditHistoryUpdateEventType_Message:
		return "AuditHistoryUpdateEventType_Message";
	case ObjectId::AuditHistoryUpdateEventType_Severity:
		return "AuditHistoryUpdateEventType_Severity";
	case ObjectId::AuditHistoryUpdateEventType_ActionTimeStamp:
		return "AuditHistoryUpdateEventType_ActionTimeStamp";
	case ObjectId::AuditHistoryUpdateEventType_Status:
		return "AuditHistoryUpdateEventType_Status";
	case ObjectId::AuditHistoryUpdateEventType_ServerId:
		return "AuditHistoryUpdateEventType_ServerId";
	case ObjectId::AuditHistoryUpdateEventType_ClientAuditEntryId:
		return "AuditHistoryUpdateEventType_ClientAuditEntryId";
	case ObjectId::AuditHistoryUpdateEventType_ClientUserId:
		return "AuditHistoryUpdateEventType_ClientUserId";
	case ObjectId::AuditHistoryEventUpdateEventType_EventId:
		return "AuditHistoryEventUpdateEventType_EventId";
	case ObjectId::AuditHistoryEventUpdateEventType_EventType:
		return "AuditHistoryEventUpdateEventType_EventType";
	case ObjectId::AuditHistoryEventUpdateEventType_SourceNode:
		return "AuditHistoryEventUpdateEventType_SourceNode";
	case ObjectId::AuditHistoryEventUpdateEventType_SourceName:
		return "AuditHistoryEventUpdateEventType_SourceName";
	case ObjectId::AuditHistoryEventUpdateEventType_Time:
		return "AuditHistoryEventUpdateEventType_Time";
	case ObjectId::AuditHistoryEventUpdateEventType_ReceiveTime:
		return "AuditHistoryEventUpdateEventType_ReceiveTime";
	case ObjectId::AuditHistoryEventUpdateEventType_LocalTime:
		return "AuditHistoryEventUpdateEventType_LocalTime";
	case ObjectId::AuditHistoryEventUpdateEventType_Message:
		return "AuditHistoryEventUpdateEventType_Message";
	case ObjectId::AuditHistoryEventUpdateEventType_Severity:
		return "AuditHistoryEventUpdateEventType_Severity";
	case ObjectId::AuditHistoryEventUpdateEventType_ActionTimeStamp:
		return "AuditHistoryEventUpdateEventType_ActionTimeStamp";
	case ObjectId::AuditHistoryEventUpdateEventType_Status:
		return "AuditHistoryEventUpdateEventType_Status";
	case ObjectId::AuditHistoryEventUpdateEventType_ServerId:
		return "AuditHistoryEventUpdateEventType_ServerId";
	case ObjectId::AuditHistoryEventUpdateEventType_ClientAuditEntryId:
		return "AuditHistoryEventUpdateEventType_ClientAuditEntryId";
	case ObjectId::AuditHistoryEventUpdateEventType_ClientUserId:
		return "AuditHistoryEventUpdateEventType_ClientUserId";
	case ObjectId::AuditHistoryEventUpdateEventType_ParameterDataTypeId:
		return "AuditHistoryEventUpdateEventType_ParameterDataTypeId";
	case ObjectId::AuditHistoryValueUpdateEventType_EventId:
		return "AuditHistoryValueUpdateEventType_EventId";
	case ObjectId::AuditHistoryValueUpdateEventType_EventType:
		return "AuditHistoryValueUpdateEventType_EventType";
	case ObjectId::AuditHistoryValueUpdateEventType_SourceNode:
		return "AuditHistoryValueUpdateEventType_SourceNode";
	case ObjectId::AuditHistoryValueUpdateEventType_SourceName:
		return "AuditHistoryValueUpdateEventType_SourceName";
	case ObjectId::AuditHistoryValueUpdateEventType_Time:
		return "AuditHistoryValueUpdateEventType_Time";
	case ObjectId::AuditHistoryValueUpdateEventType_ReceiveTime:
		return "AuditHistoryValueUpdateEventType_ReceiveTime";
	case ObjectId::AuditHistoryValueUpdateEventType_LocalTime:
		return "AuditHistoryValueUpdateEventType_LocalTime";
	case ObjectId::AuditHistoryValueUpdateEventType_Message:
		return "AuditHistoryValueUpdateEventType_Message";
	case ObjectId::AuditHistoryValueUpdateEventType_Severity:
		return "AuditHistoryValueUpdateEventType_Severity";
	case ObjectId::AuditHistoryValueUpdateEventType_ActionTimeStamp:
		return "AuditHistoryValueUpdateEventType_ActionTimeStamp";
	case ObjectId::AuditHistoryValueUpdateEventType_Status:
		return "AuditHistoryValueUpdateEventType_Status";
	case ObjectId::AuditHistoryValueUpdateEventType_ServerId:
		return "AuditHistoryValueUpdateEventType_ServerId";
	case ObjectId::AuditHistoryValueUpdateEventType_ClientAuditEntryId:
		return "AuditHistoryValueUpdateEventType_ClientAuditEntryId";
	case ObjectId::AuditHistoryValueUpdateEventType_ClientUserId:
		return "AuditHistoryValueUpdateEventType_ClientUserId";
	case ObjectId::AuditHistoryValueUpdateEventType_ParameterDataTypeId:
		return "AuditHistoryValueUpdateEventType_ParameterDataTypeId";
	case ObjectId::AuditHistoryDeleteEventType_EventId:
		return "AuditHistoryDeleteEventType_EventId";
	case ObjectId::AuditHistoryDeleteEventType_EventType:
		return "AuditHistoryDeleteEventType_EventType";
	case ObjectId::AuditHistoryDeleteEventType_SourceNode:
		return "AuditHistoryDeleteEventType_SourceNode";
	case ObjectId::AuditHistoryDeleteEventType_SourceName:
		return "AuditHistoryDeleteEventType_SourceName";
	case ObjectId::AuditHistoryDeleteEventType_Time:
		return "AuditHistoryDeleteEventType_Time";
	case ObjectId::AuditHistoryDeleteEventType_ReceiveTime:
		return "AuditHistoryDeleteEventType_ReceiveTime";
	case ObjectId::AuditHistoryDeleteEventType_LocalTime:
		return "AuditHistoryDeleteEventType_LocalTime";
	case ObjectId::AuditHistoryDeleteEventType_Message:
		return "AuditHistoryDeleteEventType_Message";
	case ObjectId::AuditHistoryDeleteEventType_Severity:
		return "AuditHistoryDeleteEventType_Severity";
	case ObjectId::AuditHistoryDeleteEventType_ActionTimeStamp:
		return "AuditHistoryDeleteEventType_ActionTimeStamp";
	case ObjectId::AuditHistoryDeleteEventType_Status:
		return "AuditHistoryDeleteEventType_Status";
	case ObjectId::AuditHistoryDeleteEventType_ServerId:
		return "AuditHistoryDeleteEventType_ServerId";
	case ObjectId::AuditHistoryDeleteEventType_ClientAuditEntryId:
		return "AuditHistoryDeleteEventType_ClientAuditEntryId";
	case ObjectId::AuditHistoryDeleteEventType_ClientUserId:
		return "AuditHistoryDeleteEventType_ClientUserId";
	case ObjectId::AuditHistoryDeleteEventType_ParameterDataTypeId:
		return "AuditHistoryDeleteEventType_ParameterDataTypeId";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_EventId:
		return "AuditHistoryRawModifyDeleteEventType_EventId";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_EventType:
		return "AuditHistoryRawModifyDeleteEventType_EventType";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_SourceNode:
		return "AuditHistoryRawModifyDeleteEventType_SourceNode";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_SourceName:
		return "AuditHistoryRawModifyDeleteEventType_SourceName";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_Time:
		return "AuditHistoryRawModifyDeleteEventType_Time";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_ReceiveTime:
		return "AuditHistoryRawModifyDeleteEventType_ReceiveTime";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_LocalTime:
		return "AuditHistoryRawModifyDeleteEventType_LocalTime";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_Message:
		return "AuditHistoryRawModifyDeleteEventType_Message";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_Severity:
		return "AuditHistoryRawModifyDeleteEventType_Severity";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_ActionTimeStamp:
		return "AuditHistoryRawModifyDeleteEventType_ActionTimeStamp";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_Status:
		return "AuditHistoryRawModifyDeleteEventType_Status";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_ServerId:
		return "AuditHistoryRawModifyDeleteEventType_ServerId";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_ClientAuditEntryId:
		return "AuditHistoryRawModifyDeleteEventType_ClientAuditEntryId";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_ClientUserId:
		return "AuditHistoryRawModifyDeleteEventType_ClientUserId";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_ParameterDataTypeId:
		return "AuditHistoryRawModifyDeleteEventType_ParameterDataTypeId";
	case ObjectId::AuditHistoryRawModifyDeleteEventType_UpdatedNode:
		return "AuditHistoryRawModifyDeleteEventType_UpdatedNode";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_EventId:
		return "AuditHistoryAtTimeDeleteEventType_EventId";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_EventType:
		return "AuditHistoryAtTimeDeleteEventType_EventType";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_SourceNode:
		return "AuditHistoryAtTimeDeleteEventType_SourceNode";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_SourceName:
		return "AuditHistoryAtTimeDeleteEventType_SourceName";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_Time:
		return "AuditHistoryAtTimeDeleteEventType_Time";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_ReceiveTime:
		return "AuditHistoryAtTimeDeleteEventType_ReceiveTime";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_LocalTime:
		return "AuditHistoryAtTimeDeleteEventType_LocalTime";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_Message:
		return "AuditHistoryAtTimeDeleteEventType_Message";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_Severity:
		return "AuditHistoryAtTimeDeleteEventType_Severity";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_ActionTimeStamp:
		return "AuditHistoryAtTimeDeleteEventType_ActionTimeStamp";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_Status:
		return "AuditHistoryAtTimeDeleteEventType_Status";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_ServerId:
		return "AuditHistoryAtTimeDeleteEventType_ServerId";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_ClientAuditEntryId:
		return "AuditHistoryAtTimeDeleteEventType_ClientAuditEntryId";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_ClientUserId:
		return "AuditHistoryAtTimeDeleteEventType_ClientUserId";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_ParameterDataTypeId:
		return "AuditHistoryAtTimeDeleteEventType_ParameterDataTypeId";
	case ObjectId::AuditHistoryAtTimeDeleteEventType_UpdatedNode:
		return "AuditHistoryAtTimeDeleteEventType_UpdatedNode";
	case ObjectId::AuditHistoryEventDeleteEventType_EventId:
		return "AuditHistoryEventDeleteEventType_EventId";
	case ObjectId::AuditHistoryEventDeleteEventType_EventType:
		return "AuditHistoryEventDeleteEventType_EventType";
	case ObjectId::AuditHistoryEventDeleteEventType_SourceNode:
		return "AuditHistoryEventDeleteEventType_SourceNode";
	case ObjectId::AuditHistoryEventDeleteEventType_SourceName:
		return "AuditHistoryEventDeleteEventType_SourceName";
	case ObjectId::AuditHistoryEventDeleteEventType_Time:
		return "AuditHistoryEventDeleteEventType_Time";
	case ObjectId::AuditHistoryEventDeleteEventType_ReceiveTime:
		return "AuditHistoryEventDeleteEventType_ReceiveTime";
	case ObjectId::AuditHistoryEventDeleteEventType_LocalTime:
		return "AuditHistoryEventDeleteEventType_LocalTime";
	case ObjectId::AuditHistoryEventDeleteEventType_Message:
		return "AuditHistoryEventDeleteEventType_Message";
	case ObjectId::AuditHistoryEventDeleteEventType_Severity:
		return "AuditHistoryEventDeleteEventType_Severity";
	case ObjectId::AuditHistoryEventDeleteEventType_ActionTimeStamp:
		return "AuditHistoryEventDeleteEventType_ActionTimeStamp";
	case ObjectId::AuditHistoryEventDeleteEventType_Status:
		return "AuditHistoryEventDeleteEventType_Status";
	case ObjectId::AuditHistoryEventDeleteEventType_ServerId:
		return "AuditHistoryEventDeleteEventType_ServerId";
	case ObjectId::AuditHistoryEventDeleteEventType_ClientAuditEntryId:
		return "AuditHistoryEventDeleteEventType_ClientAuditEntryId";
	case ObjectId::AuditHistoryEventDeleteEventType_ClientUserId:
		return "AuditHistoryEventDeleteEventType_ClientUserId";
	case ObjectId::AuditHistoryEventDeleteEventType_ParameterDataTypeId:
		return "AuditHistoryEventDeleteEventType_ParameterDataTypeId";
	case ObjectId::AuditHistoryEventDeleteEventType_UpdatedNode:
		return "AuditHistoryEventDeleteEventType_UpdatedNode";
	case ObjectId::AuditUpdateMethodEventType_EventId:
		return "AuditUpdateMethodEventType_EventId";
	case ObjectId::AuditUpdateMethodEventType_EventType:
		return "AuditUpdateMethodEventType_EventType";
	case ObjectId::AuditUpdateMethodEventType_SourceNode:
		return "AuditUpdateMethodEventType_SourceNode";
	case ObjectId::AuditUpdateMethodEventType_SourceName:
		return "AuditUpdateMethodEventType_SourceName";
	case ObjectId::AuditUpdateMethodEventType_Time:
		return "AuditUpdateMethodEventType_Time";
	case ObjectId::AuditUpdateMethodEventType_ReceiveTime:
		return "AuditUpdateMethodEventType_ReceiveTime";
	case ObjectId::AuditUpdateMethodEventType_LocalTime:
		return "AuditUpdateMethodEventType_LocalTime";
	case ObjectId::AuditUpdateMethodEventType_Message:
		return "AuditUpdateMethodEventType_Message";
	case ObjectId::AuditUpdateMethodEventType_Severity:
		return "AuditUpdateMethodEventType_Severity";
	case ObjectId::AuditUpdateMethodEventType_ActionTimeStamp:
		return "AuditUpdateMethodEventType_ActionTimeStamp";
	case ObjectId::AuditUpdateMethodEventType_Status:
		return "AuditUpdateMethodEventType_Status";
	case ObjectId::AuditUpdateMethodEventType_ServerId:
		return "AuditUpdateMethodEventType_ServerId";
	case ObjectId::AuditUpdateMethodEventType_ClientAuditEntryId:
		return "AuditUpdateMethodEventType_ClientAuditEntryId";
	case ObjectId::AuditUpdateMethodEventType_ClientUserId:
		return "AuditUpdateMethodEventType_ClientUserId";
	case ObjectId::SystemEventType_EventId:
		return "SystemEventType_EventId";
	case ObjectId::SystemEventType_EventType:
		return "SystemEventType_EventType";
	case ObjectId::SystemEventType_SourceNode:
		return "SystemEventType_SourceNode";
	case ObjectId::SystemEventType_SourceName:
		return "SystemEventType_SourceName";
	case ObjectId::SystemEventType_Time:
		return "SystemEventType_Time";
	case ObjectId::SystemEventType_ReceiveTime:
		return "SystemEventType_ReceiveTime";
	case ObjectId::SystemEventType_LocalTime:
		return "SystemEventType_LocalTime";
	case ObjectId::SystemEventType_Message:
		return "SystemEventType_Message";
	case ObjectId::SystemEventType_Severity:
		return "SystemEventType_Severity";
	case ObjectId::DeviceFailureEventType_EventId:
		return "DeviceFailureEventType_EventId";
	case ObjectId::DeviceFailureEventType_EventType:
		return "DeviceFailureEventType_EventType";
	case ObjectId::DeviceFailureEventType_SourceNode:
		return "DeviceFailureEventType_SourceNode";
	case ObjectId::DeviceFailureEventType_SourceName:
		return "DeviceFailureEventType_SourceName";
	case ObjectId::DeviceFailureEventType_Time:
		return "DeviceFailureEventType_Time";
	case ObjectId::DeviceFailureEventType_ReceiveTime:
		return "DeviceFailureEventType_ReceiveTime";
	case ObjectId::DeviceFailureEventType_LocalTime:
		return "DeviceFailureEventType_LocalTime";
	case ObjectId::DeviceFailureEventType_Message:
		return "DeviceFailureEventType_Message";
	case ObjectId::DeviceFailureEventType_Severity:
		return "DeviceFailureEventType_Severity";
	case ObjectId::BaseModelChangeEventType_EventId:
		return "BaseModelChangeEventType_EventId";
	case ObjectId::BaseModelChangeEventType_EventType:
		return "BaseModelChangeEventType_EventType";
	case ObjectId::BaseModelChangeEventType_SourceNode:
		return "BaseModelChangeEventType_SourceNode";
	case ObjectId::BaseModelChangeEventType_SourceName:
		return "BaseModelChangeEventType_SourceName";
	case ObjectId::BaseModelChangeEventType_Time:
		return "BaseModelChangeEventType_Time";
	case ObjectId::BaseModelChangeEventType_ReceiveTime:
		return "BaseModelChangeEventType_ReceiveTime";
	case ObjectId::BaseModelChangeEventType_LocalTime:
		return "BaseModelChangeEventType_LocalTime";
	case ObjectId::BaseModelChangeEventType_Message:
		return "BaseModelChangeEventType_Message";
	case ObjectId::BaseModelChangeEventType_Severity:
		return "BaseModelChangeEventType_Severity";
	case ObjectId::GeneralModelChangeEventType_EventId:
		return "GeneralModelChangeEventType_EventId";
	case ObjectId::GeneralModelChangeEventType_EventType:
		return "GeneralModelChangeEventType_EventType";
	case ObjectId::GeneralModelChangeEventType_SourceNode:
		return "GeneralModelChangeEventType_SourceNode";
	case ObjectId::GeneralModelChangeEventType_SourceName:
		return "GeneralModelChangeEventType_SourceName";
	case ObjectId::GeneralModelChangeEventType_Time:
		return "GeneralModelChangeEventType_Time";
	case ObjectId::GeneralModelChangeEventType_ReceiveTime:
		return "GeneralModelChangeEventType_ReceiveTime";
	case ObjectId::GeneralModelChangeEventType_LocalTime:
		return "GeneralModelChangeEventType_LocalTime";
	case ObjectId::GeneralModelChangeEventType_Message:
		return "GeneralModelChangeEventType_Message";
	case ObjectId::GeneralModelChangeEventType_Severity:
		return "GeneralModelChangeEventType_Severity";
	case ObjectId::SemanticChangeEventType_EventId:
		return "SemanticChangeEventType_EventId";
	case ObjectId::SemanticChangeEventType_EventType:
		return "SemanticChangeEventType_EventType";
	case ObjectId::SemanticChangeEventType_SourceNode:
		return "SemanticChangeEventType_SourceNode";
	case ObjectId::SemanticChangeEventType_SourceName:
		return "SemanticChangeEventType_SourceName";
	case ObjectId::SemanticChangeEventType_Time:
		return "SemanticChangeEventType_Time";
	case ObjectId::SemanticChangeEventType_ReceiveTime:
		return "SemanticChangeEventType_ReceiveTime";
	case ObjectId::SemanticChangeEventType_LocalTime:
		return "SemanticChangeEventType_LocalTime";
	case ObjectId::SemanticChangeEventType_Message:
		return "SemanticChangeEventType_Message";
	case ObjectId::SemanticChangeEventType_Severity:
		return "SemanticChangeEventType_Severity";
	case ObjectId::ServerStatusType_BuildInfo_ProductUri:
		return "ServerStatusType_BuildInfo_ProductUri";
	case ObjectId::ServerStatusType_BuildInfo_ManufacturerName:
		return "ServerStatusType_BuildInfo_ManufacturerName";
	case ObjectId::ServerStatusType_BuildInfo_ProductName:
		return "ServerStatusType_BuildInfo_ProductName";
	case ObjectId::ServerStatusType_BuildInfo_SoftwareVersion:
		return "ServerStatusType_BuildInfo_SoftwareVersion";
	case ObjectId::ServerStatusType_BuildInfo_BuildNumber:
		return "ServerStatusType_BuildInfo_BuildNumber";
	case ObjectId::ServerStatusType_BuildInfo_BuildDate:
		return "ServerStatusType_BuildInfo_BuildDate";
	case ObjectId::Server_ServerCapabilities_SoftwareCertificates:
		return "Server_ServerCapabilities_SoftwareCertificates";
	case ObjectId::Server_ServerDiagnostics_ServerDiagnosticsSummary_RejectedSessionCount:
		return "Server_ServerDiagnostics_ServerDiagnosticsSummary_RejectedSessionCount";
	case ObjectId::Server_ServerDiagnostics_SessionsDiagnosticsSummary:
		return "Server_ServerDiagnostics_SessionsDiagnosticsSummary";
	case ObjectId::Server_ServerDiagnostics_SessionsDiagnosticsSummary_SessionDiagnosticsArray:
		return "Server_ServerDiagnostics_SessionsDiagnosticsSummary_SessionDiagnosticsArray";
	case ObjectId::Server_ServerDiagnostics_SessionsDiagnosticsSummary_SessionSecurityDiagnosticsArray:
		return "Server_ServerDiagnostics_SessionsDiagnosticsSummary_SessionSecurityDiagnosticsArray";
	case ObjectId::Server_ServerRedundancy_RedundancySupport:
		return "Server_ServerRedundancy_RedundancySupport";
	case ObjectId::FiniteStateVariableType_Name:
		return "FiniteStateVariableType_Name";
	case ObjectId::FiniteStateVariableType_Number:
		return "FiniteStateVariableType_Number";
	case ObjectId::FiniteStateVariableType_EffectiveDisplayName:
		return "FiniteStateVariableType_EffectiveDisplayName";
	case ObjectId::FiniteTransitionVariableType_Name:
		return "FiniteTransitionVariableType_Name";
	case ObjectId::FiniteTransitionVariableType_Number:
		return "FiniteTransitionVariableType_Number";
	case ObjectId::FiniteTransitionVariableType_TransitionTime:
		return "FiniteTransitionVariableType_TransitionTime";
	case ObjectId::StateMachineType_CurrentState_Id:
		return "StateMachineType_CurrentState_Id";
	case ObjectId::StateMachineType_CurrentState_Name:
		return "StateMachineType_CurrentState_Name";
	case ObjectId::StateMachineType_CurrentState_Number:
		return "StateMachineType_CurrentState_Number";
	case ObjectId::StateMachineType_CurrentState_EffectiveDisplayName:
		return "StateMachineType_CurrentState_EffectiveDisplayName";
	case ObjectId::StateMachineType_LastTransition_Id:
		return "StateMachineType_LastTransition_Id";
	case ObjectId::StateMachineType_LastTransition_Name:
		return "StateMachineType_LastTransition_Name";
	case ObjectId::StateMachineType_LastTransition_Number:
		return "StateMachineType_LastTransition_Number";
	case ObjectId::StateMachineType_LastTransition_TransitionTime:
		return "StateMachineType_LastTransition_TransitionTime";
	case ObjectId::FiniteStateMachineType_CurrentState_Id:
		return "FiniteStateMachineType_CurrentState_Id";
	case ObjectId::FiniteStateMachineType_CurrentState_Name:
		return "FiniteStateMachineType_CurrentState_Name";
	case ObjectId::FiniteStateMachineType_CurrentState_Number:
		return "FiniteStateMachineType_CurrentState_Number";
	case ObjectId::FiniteStateMachineType_CurrentState_EffectiveDisplayName:
		return "FiniteStateMachineType_CurrentState_EffectiveDisplayName";
	case ObjectId::FiniteStateMachineType_LastTransition_Id:
		return "FiniteStateMachineType_LastTransition_Id";
	case ObjectId::FiniteStateMachineType_LastTransition_Name:
		return "FiniteStateMachineType_LastTransition_Name";
	case ObjectId::FiniteStateMachineType_LastTransition_Number:
		return "FiniteStateMachineType_LastTransition_Number";
	case ObjectId::FiniteStateMachineType_LastTransition_TransitionTime:
		return "FiniteStateMachineType_LastTransition_TransitionTime";
	case ObjectId::InitialStateType_StateNumber:
		return "InitialStateType_StateNumber";
	case ObjectId::TransitionEventType_EventId:
		return "TransitionEventType_EventId";
	case ObjectId::TransitionEventType_EventType:
		return "TransitionEventType_EventType";
	case ObjectId::TransitionEventType_SourceNode:
		return "TransitionEventType_SourceNode";
	case ObjectId::TransitionEventType_SourceName:
		return "TransitionEventType_SourceName";
	case ObjectId::TransitionEventType_Time:
		return "TransitionEventType_Time";
	case ObjectId::TransitionEventType_ReceiveTime:
		return "TransitionEventType_ReceiveTime";
	case ObjectId::TransitionEventType_LocalTime:
		return "TransitionEventType_LocalTime";
	case ObjectId::TransitionEventType_Message:
		return "TransitionEventType_Message";
	case ObjectId::TransitionEventType_Severity:
		return "TransitionEventType_Severity";
	case ObjectId::TransitionEventType_FromState_Id:
		return "TransitionEventType_FromState_Id";
	case ObjectId::TransitionEventType_FromState_Name:
		return "TransitionEventType_FromState_Name";
	case ObjectId::TransitionEventType_FromState_Number:
		return "TransitionEventType_FromState_Number";
	case ObjectId::TransitionEventType_FromState_EffectiveDisplayName:
		return "TransitionEventType_FromState_EffectiveDisplayName";
	case ObjectId::TransitionEventType_ToState_Id:
		return "TransitionEventType_ToState_Id";
	case ObjectId::TransitionEventType_ToState_Name:
		return "TransitionEventType_ToState_Name";
	case ObjectId::TransitionEventType_ToState_Number:
		return "TransitionEventType_ToState_Number";
	case ObjectId::TransitionEventType_ToState_EffectiveDisplayName:
		return "TransitionEventType_ToState_EffectiveDisplayName";
	case ObjectId::TransitionEventType_Transition_Id:
		return "TransitionEventType_Transition_Id";
	case ObjectId::TransitionEventType_Transition_Name:
		return "TransitionEventType_Transition_Name";
	case ObjectId::TransitionEventType_Transition_Number:
		return "TransitionEventType_Transition_Number";
	case ObjectId::TransitionEventType_Transition_TransitionTime:
		return "TransitionEventType_Transition_TransitionTime";
	case ObjectId::AuditUpdateStateEventType_EventId:
		return "AuditUpdateStateEventType_EventId";
	case ObjectId::AuditUpdateStateEventType_EventType:
		return "AuditUpdateStateEventType_EventType";
	case ObjectId::AuditUpdateStateEventType_SourceNode:
		return "AuditUpdateStateEventType_SourceNode";
	case ObjectId::AuditUpdateStateEventType_SourceName:
		return "AuditUpdateStateEventType_SourceName";
	case ObjectId::AuditUpdateStateEventType_Time:
		return "AuditUpdateStateEventType_Time";
	case ObjectId::AuditUpdateStateEventType_ReceiveTime:
		return "AuditUpdateStateEventType_ReceiveTime";
	case ObjectId::AuditUpdateStateEventType_LocalTime:
		return "AuditUpdateStateEventType_LocalTime";
	case ObjectId::AuditUpdateStateEventType_Message:
		return "AuditUpdateStateEventType_Message";
	case ObjectId::AuditUpdateStateEventType_Severity:
		return "AuditUpdateStateEventType_Severity";
	case ObjectId::AuditUpdateStateEventType_ActionTimeStamp:
		return "AuditUpdateStateEventType_ActionTimeStamp";
	case ObjectId::AuditUpdateStateEventType_Status:
		return "AuditUpdateStateEventType_Status";
	case ObjectId::AuditUpdateStateEventType_ServerId:
		return "AuditUpdateStateEventType_ServerId";
	case ObjectId::AuditUpdateStateEventType_ClientAuditEntryId:
		return "AuditUpdateStateEventType_ClientAuditEntryId";
	case ObjectId::AuditUpdateStateEventType_ClientUserId:
		return "AuditUpdateStateEventType_ClientUserId";
	case ObjectId::AuditUpdateStateEventType_MethodId:
		return "AuditUpdateStateEventType_MethodId";
	case ObjectId::AuditUpdateStateEventType_InputArguments:
		return "AuditUpdateStateEventType_InputArguments";
	case ObjectId::AnalogItemType_Definition:
		return "AnalogItemType_Definition";
	case ObjectId::AnalogItemType_ValuePrecision:
		return "AnalogItemType_ValuePrecision";
	case ObjectId::DiscreteItemType_Definition:
		return "DiscreteItemType_Definition";
	case ObjectId::DiscreteItemType_ValuePrecision:
		return "DiscreteItemType_ValuePrecision";
	case ObjectId::TwoStateDiscreteType_Definition:
		return "TwoStateDiscreteType_Definition";
	case ObjectId::TwoStateDiscreteType_ValuePrecision:
		return "TwoStateDiscreteType_ValuePrecision";
	case ObjectId::MultiStateDiscreteType_Definition:
		return "MultiStateDiscreteType_Definition";
	case ObjectId::MultiStateDiscreteType_ValuePrecision:
		return "MultiStateDiscreteType_ValuePrecision";
	case ObjectId::ProgramTransitionEventType_EventId:
		return "ProgramTransitionEventType_EventId";
	case ObjectId::ProgramTransitionEventType_EventType:
		return "ProgramTransitionEventType_EventType";
	case ObjectId::ProgramTransitionEventType_SourceNode:
		return "ProgramTransitionEventType_SourceNode";
	case ObjectId::ProgramTransitionEventType_SourceName:
		return "ProgramTransitionEventType_SourceName";
	case ObjectId::ProgramTransitionEventType_Time:
		return "ProgramTransitionEventType_Time";
	case ObjectId::ProgramTransitionEventType_ReceiveTime:
		return "ProgramTransitionEventType_ReceiveTime";
	case ObjectId::ProgramTransitionEventType_LocalTime:
		return "ProgramTransitionEventType_LocalTime";
	case ObjectId::ProgramTransitionEventType_Message:
		return "ProgramTransitionEventType_Message";
	case ObjectId::ProgramTransitionEventType_Severity:
		return "ProgramTransitionEventType_Severity";
	case ObjectId::ProgramTransitionEventType_FromState:
		return "ProgramTransitionEventType_FromState";
	case ObjectId::ProgramTransitionEventType_FromState_Id:
		return "ProgramTransitionEventType_FromState_Id";
	case ObjectId::ProgramTransitionEventType_FromState_Name:
		return "ProgramTransitionEventType_FromState_Name";
	case ObjectId::ProgramTransitionEventType_FromState_Number:
		return "ProgramTransitionEventType_FromState_Number";
	case ObjectId::ProgramTransitionEventType_FromState_EffectiveDisplayName:
		return "ProgramTransitionEventType_FromState_EffectiveDisplayName";
	case ObjectId::ProgramTransitionEventType_ToState:
		return "ProgramTransitionEventType_ToState";
	case ObjectId::ProgramTransitionEventType_ToState_Id:
		return "ProgramTransitionEventType_ToState_Id";
	case ObjectId::ProgramTransitionEventType_ToState_Name:
		return "ProgramTransitionEventType_ToState_Name";
	case ObjectId::ProgramTransitionEventType_ToState_Number:
		return "ProgramTransitionEventType_ToState_Number";
	case ObjectId::ProgramTransitionEventType_ToState_EffectiveDisplayName:
		return "ProgramTransitionEventType_ToState_EffectiveDisplayName";
	case ObjectId::ProgramTransitionEventType_Transition:
		return "ProgramTransitionEventType_Transition";
	case ObjectId::ProgramTransitionEventType_Transition_Id:
		return "ProgramTransitionEventType_Transition_Id";
	case ObjectId::ProgramTransitionEventType_Transition_Name:
		return "ProgramTransitionEventType_Transition_Name";
	case ObjectId::ProgramTransitionEventType_Transition_Number:
		return "ProgramTransitionEventType_Transition_Number";
	case ObjectId::ProgramTransitionEventType_Transition_TransitionTime:
		return "ProgramTransitionEventType_Transition_TransitionTime";
	case ObjectId::ProgramTransitionAuditEventType:
		return "ProgramTransitionAuditEventType";
	case ObjectId::ProgramTransitionAuditEventType_EventId:
		return "ProgramTransitionAuditEventType_EventId";
	case ObjectId::ProgramTransitionAuditEventType_EventType:
		return "ProgramTransitionAuditEventType_EventType";
	case ObjectId::ProgramTransitionAuditEventType_SourceNode:
		return "ProgramTransitionAuditEventType_SourceNode";
	case ObjectId::ProgramTransitionAuditEventType_SourceName:
		return "ProgramTransitionAuditEventType_SourceName";
	case ObjectId::ProgramTransitionAuditEventType_Time:
		return "ProgramTransitionAuditEventType_Time";
	case ObjectId::ProgramTransitionAuditEventType_ReceiveTime:
		return "ProgramTransitionAuditEventType_ReceiveTime";
	case ObjectId::ProgramTransitionAuditEventType_LocalTime:
		return "ProgramTransitionAuditEventType_LocalTime";
	case ObjectId::ProgramTransitionAuditEventType_Message:
		return "ProgramTransitionAuditEventType_Message";
	case ObjectId::ProgramTransitionAuditEventType_Severity:
		return "ProgramTransitionAuditEventType_Severity";
	case ObjectId::ProgramTransitionAuditEventType_ActionTimeStamp:
		return "ProgramTransitionAuditEventType_ActionTimeStamp";
	case ObjectId::ProgramTransitionAuditEventType_Status:
		return "ProgramTransitionAuditEventType_Status";
	case ObjectId::ProgramTransitionAuditEventType_ServerId:
		return "ProgramTransitionAuditEventType_ServerId";
	case ObjectId::ProgramTransitionAuditEventType_ClientAuditEntryId:
		return "ProgramTransitionAuditEventType_ClientAuditEntryId";
	case ObjectId::ProgramTransitionAuditEventType_ClientUserId:
		return "ProgramTransitionAuditEventType_ClientUserId";
	case ObjectId::ProgramTransitionAuditEventType_MethodId:
		return "ProgramTransitionAuditEventType_MethodId";
	case ObjectId::ProgramTransitionAuditEventType_InputArguments:
		return "ProgramTransitionAuditEventType_InputArguments";
	case ObjectId::ProgramTransitionAuditEventType_OldStateId:
		return "ProgramTransitionAuditEventType_OldStateId";
	case ObjectId::ProgramTransitionAuditEventType_NewStateId:
		return "ProgramTransitionAuditEventType_NewStateId";
	case ObjectId::ProgramTransitionAuditEventType_Transition:
		return "ProgramTransitionAuditEventType_Transition";
	case ObjectId::ProgramTransitionAuditEventType_Transition_Id:
		return "ProgramTransitionAuditEventType_Transition_Id";
	case ObjectId::ProgramTransitionAuditEventType_Transition_Name:
		return "ProgramTransitionAuditEventType_Transition_Name";
	case ObjectId::ProgramTransitionAuditEventType_Transition_Number:
		return "ProgramTransitionAuditEventType_Transition_Number";
	case ObjectId::ProgramTransitionAuditEventType_Transition_TransitionTime:
		return "ProgramTransitionAuditEventType_Transition_TransitionTime";
	case ObjectId::ProgramStateMachineType_CurrentState:
		return "ProgramStateMachineType_CurrentState";
	case ObjectId::ProgramStateMachineType_CurrentState_Id:
		return "ProgramStateMachineType_CurrentState_Id";
	case ObjectId::ProgramStateMachineType_CurrentState_Name:
		return "ProgramStateMachineType_CurrentState_Name";
	case ObjectId::ProgramStateMachineType_CurrentState_Number:
		return "ProgramStateMachineType_CurrentState_Number";
	case ObjectId::ProgramStateMachineType_CurrentState_EffectiveDisplayName:
		return "ProgramStateMachineType_CurrentState_EffectiveDisplayName";
	case ObjectId::ProgramStateMachineType_LastTransition:
		return "ProgramStateMachineType_LastTransition";
	case ObjectId::ProgramStateMachineType_LastTransition_Id:
		return "ProgramStateMachineType_LastTransition_Id";
	case ObjectId::ProgramStateMachineType_LastTransition_Name:
		return "ProgramStateMachineType_LastTransition_Name";
	case ObjectId::ProgramStateMachineType_LastTransition_Number:
		return "ProgramStateMachineType_LastTransition_Number";
	case ObjectId::ProgramStateMachineType_LastTransition_TransitionTime:
		return "ProgramStateMachineType_LastTransition_TransitionTime";
	case ObjectId::ProgramStateMachineType_ProgramDiagnostics_CreateSessionId:
		return "ProgramStateMachineType_ProgramDiagnostics_CreateSessionId";
	case ObjectId::ProgramStateMachineType_ProgramDiagnostics_CreateClientName:
		return "ProgramStateMachineType_ProgramDiagnostics_CreateClientName";
	case ObjectId::ProgramStateMachineType_ProgramDiagnostics_InvocationCreationTime:
		return "ProgramStateMachineType_ProgramDiagnostics_InvocationCreationTime";
	case ObjectId::ProgramStateMachineType_ProgramDiagnostics_LastTransitionTime:
		return "ProgramStateMachineType_ProgramDiagnostics_LastTransitionTime";
	case ObjectId::ProgramStateMachineType_ProgramDiagnostics_LastMethodCall:
		return "ProgramStateMachineType_ProgramDiagnostics_LastMethodCall";
	case ObjectId::ProgramStateMachineType_ProgramDiagnostics_LastMethodSessionId:
		return "ProgramStateMachineType_ProgramDiagnostics_LastMethodSessionId";
	case ObjectId::ProgramStateMachineType_ProgramDiagnostics_LastMethodInputArguments:
		return "ProgramStateMachineType_ProgramDiagnostics_LastMethodInputArguments";
	case ObjectId::ProgramStateMachineType_ProgramDiagnostics_LastMethodOutputArguments:
		return "ProgramStateMachineType_ProgramDiagnostics_LastMethodOutputArguments";
	case ObjectId::ProgramStateMachineType_ProgramDiagnostics_LastMethodCallTime:
		return "ProgramStateMachineType_ProgramDiagnostics_LastMethodCallTime";
	case ObjectId::ProgramStateMachineType_ProgramDiagnostics_LastMethodReturnStatus:
		return "ProgramStateMachineType_ProgramDiagnostics_LastMethodReturnStatus";
	case ObjectId::ProgramStateMachineType_FinalResultData:
		return "ProgramStateMachineType_FinalResultData";
	case ObjectId::AddCommentMethodType:
		return "AddCommentMethodType";
	case ObjectId::AddCommentMethodType_InputArguments:
		return "AddCommentMethodType_InputArguments";
	case ObjectId::ConditionType_EventId:
		return "ConditionType_EventId";
	case ObjectId::ConditionType_EventType:
		return "ConditionType_EventType";
	case ObjectId::ConditionType_SourceNode:
		return "ConditionType_SourceNode";
	case ObjectId::ConditionType_SourceName:
		return "ConditionType_SourceName";
	case ObjectId::ConditionType_Time:
		return "ConditionType_Time";
	case ObjectId::ConditionType_ReceiveTime:
		return "ConditionType_ReceiveTime";
	case ObjectId::ConditionType_LocalTime:
		return "ConditionType_LocalTime";
	case ObjectId::ConditionType_Message:
		return "ConditionType_Message";
	case ObjectId::ConditionType_Severity:
		return "ConditionType_Severity";
	case ObjectId::ConditionType_Retain:
		return "ConditionType_Retain";
	case ObjectId::ConditionType_ConditionRefresh:
		return "ConditionType_ConditionRefresh";
	case ObjectId::ConditionType_ConditionRefresh_InputArguments:
		return "ConditionType_ConditionRefresh_InputArguments";
	case ObjectId::RefreshStartEventType_EventId:
		return "RefreshStartEventType_EventId";
	case ObjectId::RefreshStartEventType_EventType:
		return "RefreshStartEventType_EventType";
	case ObjectId::RefreshStartEventType_SourceNode:
		return "RefreshStartEventType_SourceNode";
	case ObjectId::RefreshStartEventType_SourceName:
		return "RefreshStartEventType_SourceName";
	case ObjectId::RefreshStartEventType_Time:
		return "RefreshStartEventType_Time";
	case ObjectId::RefreshStartEventType_ReceiveTime:
		return "RefreshStartEventType_ReceiveTime";
	case ObjectId::RefreshStartEventType_LocalTime:
		return "RefreshStartEventType_LocalTime";
	case ObjectId::RefreshStartEventType_Message:
		return "RefreshStartEventType_Message";
	case ObjectId::RefreshStartEventType_Severity:
		return "RefreshStartEventType_Severity";
	case ObjectId::RefreshEndEventType_EventId:
		return "RefreshEndEventType_EventId";
	case ObjectId::RefreshEndEventType_EventType:
		return "RefreshEndEventType_EventType";
	case ObjectId::RefreshEndEventType_SourceNode:
		return "RefreshEndEventType_SourceNode";
	case ObjectId::RefreshEndEventType_SourceName:
		return "RefreshEndEventType_SourceName";
	case ObjectId::RefreshEndEventType_Time:
		return "RefreshEndEventType_Time";
	case ObjectId::RefreshEndEventType_ReceiveTime:
		return "RefreshEndEventType_ReceiveTime";
	case ObjectId::RefreshEndEventType_LocalTime:
		return "RefreshEndEventType_LocalTime";
	case ObjectId::RefreshEndEventType_Message:
		return "RefreshEndEventType_Message";
	case ObjectId::RefreshEndEventType_Severity:
		return "RefreshEndEventType_Severity";
	case ObjectId::RefreshRequiredEventType_EventId:
		return "RefreshRequiredEventType_EventId";
	case ObjectId::RefreshRequiredEventType_EventType:
		return "RefreshRequiredEventType_EventType";
	case ObjectId::RefreshRequiredEventType_SourceNode:
		return "RefreshRequiredEventType_SourceNode";
	case ObjectId::RefreshRequiredEventType_SourceName:
		return "RefreshRequiredEventType_SourceName";
	case ObjectId::RefreshRequiredEventType_Time:
		return "RefreshRequiredEventType_Time";
	case ObjectId::RefreshRequiredEventType_ReceiveTime:
		return "RefreshRequiredEventType_ReceiveTime";
	case ObjectId::RefreshRequiredEventType_LocalTime:
		return "RefreshRequiredEventType_LocalTime";
	case ObjectId::RefreshRequiredEventType_Message:
		return "RefreshRequiredEventType_Message";
	case ObjectId::RefreshRequiredEventType_Severity:
		return "RefreshRequiredEventType_Severity";
	case ObjectId::AuditConditionEventType_EventId:
		return "AuditConditionEventType_EventId";
	case ObjectId::AuditConditionEventType_EventType:
		return "AuditConditionEventType_EventType";
	case ObjectId::AuditConditionEventType_SourceNode:
		return "AuditConditionEventType_SourceNode";
	case ObjectId::AuditConditionEventType_SourceName:
		return "AuditConditionEventType_SourceName";
	case ObjectId::AuditConditionEventType_Time:
		return "AuditConditionEventType_Time";
	case ObjectId::AuditConditionEventType_ReceiveTime:
		return "AuditConditionEventType_ReceiveTime";
	case ObjectId::AuditConditionEventType_LocalTime:
		return "AuditConditionEventType_LocalTime";
	case ObjectId::AuditConditionEventType_Message:
		return "AuditConditionEventType_Message";
	case ObjectId::AuditConditionEventType_Severity:
		return "AuditConditionEventType_Severity";
	case ObjectId::AuditConditionEventType_ActionTimeStamp:
		return "AuditConditionEventType_ActionTimeStamp";
	case ObjectId::AuditConditionEventType_Status:
		return "AuditConditionEventType_Status";
	case ObjectId::AuditConditionEventType_ServerId:
		return "AuditConditionEventType_ServerId";
	case ObjectId::AuditConditionEventType_ClientAuditEntryId:
		return "AuditConditionEventType_ClientAuditEntryId";
	case ObjectId::AuditConditionEventType_ClientUserId:
		return "AuditConditionEventType_ClientUserId";
	case ObjectId::AuditConditionEventType_MethodId:
		return "AuditConditionEventType_MethodId";
	case ObjectId::AuditConditionEventType_InputArguments:
		return "AuditConditionEventType_InputArguments";
	case ObjectId::AuditConditionEnableEventType_EventId:
		return "AuditConditionEnableEventType_EventId";
	case ObjectId::AuditConditionEnableEventType_EventType:
		return "AuditConditionEnableEventType_EventType";
	case ObjectId::AuditConditionEnableEventType_SourceNode:
		return "AuditConditionEnableEventType_SourceNode";
	case ObjectId::AuditConditionEnableEventType_SourceName:
		return "AuditConditionEnableEventType_SourceName";
	case ObjectId::AuditConditionEnableEventType_Time:
		return "AuditConditionEnableEventType_Time";
	case ObjectId::AuditConditionEnableEventType_ReceiveTime:
		return "AuditConditionEnableEventType_ReceiveTime";
	case ObjectId::AuditConditionEnableEventType_LocalTime:
		return "AuditConditionEnableEventType_LocalTime";
	case ObjectId::AuditConditionEnableEventType_Message:
		return "AuditConditionEnableEventType_Message";
	case ObjectId::AuditConditionEnableEventType_Severity:
		return "AuditConditionEnableEventType_Severity";
	case ObjectId::AuditConditionEnableEventType_ActionTimeStamp:
		return "AuditConditionEnableEventType_ActionTimeStamp";
	case ObjectId::AuditConditionEnableEventType_Status:
		return "AuditConditionEnableEventType_Status";
	case ObjectId::AuditConditionEnableEventType_ServerId:
		return "AuditConditionEnableEventType_ServerId";
	case ObjectId::AuditConditionEnableEventType_ClientAuditEntryId:
		return "AuditConditionEnableEventType_ClientAuditEntryId";
	case ObjectId::AuditConditionEnableEventType_ClientUserId:
		return "AuditConditionEnableEventType_ClientUserId";
	case ObjectId::AuditConditionEnableEventType_MethodId:
		return "AuditConditionEnableEventType_MethodId";
	case ObjectId::AuditConditionEnableEventType_InputArguments:
		return "AuditConditionEnableEventType_InputArguments";
	case ObjectId::AuditConditionCommentEventType_EventId:
		return "AuditConditionCommentEventType_EventId";
	case ObjectId::AuditConditionCommentEventType_EventType:
		return "AuditConditionCommentEventType_EventType";
	case ObjectId::AuditConditionCommentEventType_SourceNode:
		return "AuditConditionCommentEventType_SourceNode";
	case ObjectId::AuditConditionCommentEventType_SourceName:
		return "AuditConditionCommentEventType_SourceName";
	case ObjectId::AuditConditionCommentEventType_Time:
		return "AuditConditionCommentEventType_Time";
	case ObjectId::AuditConditionCommentEventType_ReceiveTime:
		return "AuditConditionCommentEventType_ReceiveTime";
	case ObjectId::AuditConditionCommentEventType_LocalTime:
		return "AuditConditionCommentEventType_LocalTime";
	case ObjectId::AuditConditionCommentEventType_Message:
		return "AuditConditionCommentEventType_Message";
	case ObjectId::AuditConditionCommentEventType_Severity:
		return "AuditConditionCommentEventType_Severity";
	case ObjectId::AuditConditionCommentEventType_ActionTimeStamp:
		return "AuditConditionCommentEventType_ActionTimeStamp";
	case ObjectId::AuditConditionCommentEventType_Status:
		return "AuditConditionCommentEventType_Status";
	case ObjectId::AuditConditionCommentEventType_ServerId:
		return "AuditConditionCommentEventType_ServerId";
	case ObjectId::AuditConditionCommentEventType_ClientAuditEntryId:
		return "AuditConditionCommentEventType_ClientAuditEntryId";
	case ObjectId::AuditConditionCommentEventType_ClientUserId:
		return "AuditConditionCommentEventType_ClientUserId";
	case ObjectId::AuditConditionCommentEventType_MethodId:
		return "AuditConditionCommentEventType_MethodId";
	case ObjectId::AuditConditionCommentEventType_InputArguments:
		return "AuditConditionCommentEventType_InputArguments";
	case ObjectId::DialogConditionType_EventId:
		return "DialogConditionType_EventId";
	case ObjectId::DialogConditionType_EventType:
		return "DialogConditionType_EventType";
	case ObjectId::DialogConditionType_SourceNode:
		return "DialogConditionType_SourceNode";
	case ObjectId::DialogConditionType_SourceName:
		return "DialogConditionType_SourceName";
	case ObjectId::DialogConditionType_Time:
		return "DialogConditionType_Time";
	case ObjectId::DialogConditionType_ReceiveTime:
		return "DialogConditionType_ReceiveTime";
	case ObjectId::DialogConditionType_LocalTime:
		return "DialogConditionType_LocalTime";
	case ObjectId::DialogConditionType_Message:
		return "DialogConditionType_Message";
	case ObjectId::DialogConditionType_Severity:
		return "DialogConditionType_Severity";
	case ObjectId::DialogConditionType_Retain:
		return "DialogConditionType_Retain";
	case ObjectId::DialogConditionType_ConditionRefresh:
		return "DialogConditionType_ConditionRefresh";
	case ObjectId::DialogConditionType_ConditionRefresh_InputArguments:
		return "DialogConditionType_ConditionRefresh_InputArguments";
	case ObjectId::AcknowledgeableConditionType_EventId:
		return "AcknowledgeableConditionType_EventId";
	case ObjectId::AcknowledgeableConditionType_EventType:
		return "AcknowledgeableConditionType_EventType";
	case ObjectId::AcknowledgeableConditionType_SourceNode:
		return "AcknowledgeableConditionType_SourceNode";
	case ObjectId::AcknowledgeableConditionType_SourceName:
		return "AcknowledgeableConditionType_SourceName";
	case ObjectId::AcknowledgeableConditionType_Time:
		return "AcknowledgeableConditionType_Time";
	case ObjectId::AcknowledgeableConditionType_ReceiveTime:
		return "AcknowledgeableConditionType_ReceiveTime";
	case ObjectId::AcknowledgeableConditionType_LocalTime:
		return "AcknowledgeableConditionType_LocalTime";
	case ObjectId::AcknowledgeableConditionType_Message:
		return "AcknowledgeableConditionType_Message";
	case ObjectId::AcknowledgeableConditionType_Severity:
		return "AcknowledgeableConditionType_Severity";
	case ObjectId::AcknowledgeableConditionType_Retain:
		return "AcknowledgeableConditionType_Retain";
	case ObjectId::AcknowledgeableConditionType_ConditionRefresh:
		return "AcknowledgeableConditionType_ConditionRefresh";
	case ObjectId::AcknowledgeableConditionType_ConditionRefresh_InputArguments:
		return "AcknowledgeableConditionType_ConditionRefresh_InputArguments";
	case ObjectId::AlarmConditionType_EventId:
		return "AlarmConditionType_EventId";
	case ObjectId::AlarmConditionType_EventType:
		return "AlarmConditionType_EventType";
	case ObjectId::AlarmConditionType_SourceNode:
		return "AlarmConditionType_SourceNode";
	case ObjectId::AlarmConditionType_SourceName:
		return "AlarmConditionType_SourceName";
	case ObjectId::AlarmConditionType_Time:
		return "AlarmConditionType_Time";
	case ObjectId::AlarmConditionType_ReceiveTime:
		return "AlarmConditionType_ReceiveTime";
	case ObjectId::AlarmConditionType_LocalTime:
		return "AlarmConditionType_LocalTime";
	case ObjectId::AlarmConditionType_Message:
		return "AlarmConditionType_Message";
	case ObjectId::AlarmConditionType_Severity:
		return "AlarmConditionType_Severity";
	case ObjectId::AlarmConditionType_Retain:
		return "AlarmConditionType_Retain";
	case ObjectId::AlarmConditionType_ConditionRefresh:
		return "AlarmConditionType_ConditionRefresh";
	case ObjectId::AlarmConditionType_ConditionRefresh_InputArguments:
		return "AlarmConditionType_ConditionRefresh_InputArguments";
	case ObjectId::ShelvedStateMachineType_CurrentState:
		return "ShelvedStateMachineType_CurrentState";
	case ObjectId::ShelvedStateMachineType_CurrentState_Id:
		return "ShelvedStateMachineType_CurrentState_Id";
	case ObjectId::ShelvedStateMachineType_CurrentState_Name:
		return "ShelvedStateMachineType_CurrentState_Name";
	case ObjectId::ShelvedStateMachineType_CurrentState_Number:
		return "ShelvedStateMachineType_CurrentState_Number";
	case ObjectId::ShelvedStateMachineType_CurrentState_EffectiveDisplayName:
		return "ShelvedStateMachineType_CurrentState_EffectiveDisplayName";
	case ObjectId::ShelvedStateMachineType_LastTransition:
		return "ShelvedStateMachineType_LastTransition";
	case ObjectId::ShelvedStateMachineType_LastTransition_Id:
		return "ShelvedStateMachineType_LastTransition_Id";
	case ObjectId::ShelvedStateMachineType_LastTransition_Name:
		return "ShelvedStateMachineType_LastTransition_Name";
	case ObjectId::ShelvedStateMachineType_LastTransition_Number:
		return "ShelvedStateMachineType_LastTransition_Number";
	case ObjectId::ShelvedStateMachineType_LastTransition_TransitionTime:
		return "ShelvedStateMachineType_LastTransition_TransitionTime";
	case ObjectId::ShelvedStateMachineType_Unshelved_StateNumber:
		return "ShelvedStateMachineType_Unshelved_StateNumber";
	case ObjectId::ShelvedStateMachineType_TimedShelved_StateNumber:
		return "ShelvedStateMachineType_TimedShelved_StateNumber";
	case ObjectId::ShelvedStateMachineType_OneShotShelved_StateNumber:
		return "ShelvedStateMachineType_OneShotShelved_StateNumber";
	case ObjectId::TimedShelveMethodType:
		return "TimedShelveMethodType";
	case ObjectId::TimedShelveMethodType_InputArguments:
		return "TimedShelveMethodType_InputArguments";
	case ObjectId::LimitAlarmType_EventId:
		return "LimitAlarmType_EventId";
	case ObjectId::LimitAlarmType_EventType:
		return "LimitAlarmType_EventType";
	case ObjectId::LimitAlarmType_SourceNode:
		return "LimitAlarmType_SourceNode";
	case ObjectId::LimitAlarmType_SourceName:
		return "LimitAlarmType_SourceName";
	case ObjectId::LimitAlarmType_Time:
		return "LimitAlarmType_Time";
	case ObjectId::LimitAlarmType_ReceiveTime:
		return "LimitAlarmType_ReceiveTime";
	case ObjectId::LimitAlarmType_LocalTime:
		return "LimitAlarmType_LocalTime";
	case ObjectId::LimitAlarmType_Message:
		return "LimitAlarmType_Message";
	case ObjectId::LimitAlarmType_Severity:
		return "LimitAlarmType_Severity";
	case ObjectId::LimitAlarmType_Retain:
		return "LimitAlarmType_Retain";
	case ObjectId::LimitAlarmType_ConditionRefresh:
		return "LimitAlarmType_ConditionRefresh";
	case ObjectId::LimitAlarmType_ConditionRefresh_InputArguments:
		return "LimitAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::IdType_EnumStrings:
		return "IdType_EnumStrings";
	case ObjectId::EnumValueType:
		return "EnumValueType";
	case ObjectId::MessageSecurityMode_EnumStrings:
		return "MessageSecurityMode_EnumStrings";
	case ObjectId::UserTokenType_EnumStrings:
		return "UserTokenType_EnumStrings";
	case ObjectId::ApplicationType_EnumStrings:
		return "ApplicationType_EnumStrings";
	case ObjectId::SecurityTokenRequestType_EnumStrings:
		return "SecurityTokenRequestType_EnumStrings";
	case ObjectId::ComplianceLevel_EnumStrings:
		return "ComplianceLevel_EnumStrings";
	case ObjectId::BrowseDirection_EnumStrings:
		return "BrowseDirection_EnumStrings";
	case ObjectId::FilterOperator_EnumStrings:
		return "FilterOperator_EnumStrings";
	case ObjectId::TimestampsToReturn_EnumStrings:
		return "TimestampsToReturn_EnumStrings";
	case ObjectId::MonitoringMode_EnumStrings:
		return "MonitoringMode_EnumStrings";
	case ObjectId::DataChangeTrigger_EnumStrings:
		return "DataChangeTrigger_EnumStrings";
	case ObjectId::DeadbandType_EnumStrings:
		return "DeadbandType_EnumStrings";
	case ObjectId::RedundancySupport_EnumStrings:
		return "RedundancySupport_EnumStrings";
	case ObjectId::ServerState_EnumStrings:
		return "ServerState_EnumStrings";
	case ObjectId::ExceptionDeviationFormat_EnumStrings:
		return "ExceptionDeviationFormat_EnumStrings";
	case ObjectId::EnumValueType_Encoding_DefaultXml:
		return "EnumValueType_Encoding_DefaultXml";
	case ObjectId::OpcUa_BinarySchema:
		return "OpcUa_BinarySchema";
	case ObjectId::OpcUa_BinarySchema_DataTypeVersion:
		return "OpcUa_BinarySchema_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_NamespaceUri:
		return "OpcUa_BinarySchema_NamespaceUri";
	case ObjectId::OpcUa_BinarySchema_Argument:
		return "OpcUa_BinarySchema_Argument";
	case ObjectId::OpcUa_BinarySchema_Argument_DataTypeVersion:
		return "OpcUa_BinarySchema_Argument_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_Argument_DictionaryFragment:
		return "OpcUa_BinarySchema_Argument_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_EnumValueType:
		return "OpcUa_BinarySchema_EnumValueType";
	case ObjectId::OpcUa_BinarySchema_EnumValueType_DataTypeVersion:
		return "OpcUa_BinarySchema_EnumValueType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_EnumValueType_DictionaryFragment:
		return "OpcUa_BinarySchema_EnumValueType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_StatusResult:
		return "OpcUa_BinarySchema_StatusResult";
	case ObjectId::OpcUa_BinarySchema_StatusResult_DataTypeVersion:
		return "OpcUa_BinarySchema_StatusResult_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_StatusResult_DictionaryFragment:
		return "OpcUa_BinarySchema_StatusResult_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_UserTokenPolicy:
		return "OpcUa_BinarySchema_UserTokenPolicy";
	case ObjectId::OpcUa_BinarySchema_UserTokenPolicy_DataTypeVersion:
		return "OpcUa_BinarySchema_UserTokenPolicy_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_UserTokenPolicy_DictionaryFragment:
		return "OpcUa_BinarySchema_UserTokenPolicy_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_ApplicationDescription:
		return "OpcUa_BinarySchema_ApplicationDescription";
	case ObjectId::OpcUa_BinarySchema_ApplicationDescription_DataTypeVersion:
		return "OpcUa_BinarySchema_ApplicationDescription_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ApplicationDescription_DictionaryFragment:
		return "OpcUa_BinarySchema_ApplicationDescription_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_EndpointDescription:
		return "OpcUa_BinarySchema_EndpointDescription";
	case ObjectId::OpcUa_BinarySchema_EndpointDescription_DataTypeVersion:
		return "OpcUa_BinarySchema_EndpointDescription_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_EndpointDescription_DictionaryFragment:
		return "OpcUa_BinarySchema_EndpointDescription_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_UserIdentityToken:
		return "OpcUa_BinarySchema_UserIdentityToken";
	case ObjectId::OpcUa_BinarySchema_UserIdentityToken_DataTypeVersion:
		return "OpcUa_BinarySchema_UserIdentityToken_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_UserIdentityToken_DictionaryFragment:
		return "OpcUa_BinarySchema_UserIdentityToken_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_AnonymousIdentityToken:
		return "OpcUa_BinarySchema_AnonymousIdentityToken";
	case ObjectId::OpcUa_BinarySchema_AnonymousIdentityToken_DataTypeVersion:
		return "OpcUa_BinarySchema_AnonymousIdentityToken_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_AnonymousIdentityToken_DictionaryFragment:
		return "OpcUa_BinarySchema_AnonymousIdentityToken_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_UserNameIdentityToken:
		return "OpcUa_BinarySchema_UserNameIdentityToken";
	case ObjectId::OpcUa_BinarySchema_UserNameIdentityToken_DataTypeVersion:
		return "OpcUa_BinarySchema_UserNameIdentityToken_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_UserNameIdentityToken_DictionaryFragment:
		return "OpcUa_BinarySchema_UserNameIdentityToken_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_X509IdentityToken:
		return "OpcUa_BinarySchema_X509IdentityToken";
	case ObjectId::OpcUa_BinarySchema_X509IdentityToken_DataTypeVersion:
		return "OpcUa_BinarySchema_X509IdentityToken_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_X509IdentityToken_DictionaryFragment:
		return "OpcUa_BinarySchema_X509IdentityToken_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_IssuedIdentityToken:
		return "OpcUa_BinarySchema_IssuedIdentityToken";
	case ObjectId::OpcUa_BinarySchema_IssuedIdentityToken_DataTypeVersion:
		return "OpcUa_BinarySchema_IssuedIdentityToken_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_IssuedIdentityToken_DictionaryFragment:
		return "OpcUa_BinarySchema_IssuedIdentityToken_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_EndpointConfiguration:
		return "OpcUa_BinarySchema_EndpointConfiguration";
	case ObjectId::OpcUa_BinarySchema_EndpointConfiguration_DataTypeVersion:
		return "OpcUa_BinarySchema_EndpointConfiguration_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_EndpointConfiguration_DictionaryFragment:
		return "OpcUa_BinarySchema_EndpointConfiguration_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_SupportedProfile:
		return "OpcUa_BinarySchema_SupportedProfile";
	case ObjectId::OpcUa_BinarySchema_SupportedProfile_DataTypeVersion:
		return "OpcUa_BinarySchema_SupportedProfile_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_SupportedProfile_DictionaryFragment:
		return "OpcUa_BinarySchema_SupportedProfile_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_BuildInfo:
		return "OpcUa_BinarySchema_BuildInfo";
	case ObjectId::OpcUa_BinarySchema_BuildInfo_DataTypeVersion:
		return "OpcUa_BinarySchema_BuildInfo_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_BuildInfo_DictionaryFragment:
		return "OpcUa_BinarySchema_BuildInfo_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_SoftwareCertificate:
		return "OpcUa_BinarySchema_SoftwareCertificate";
	case ObjectId::OpcUa_BinarySchema_SoftwareCertificate_DataTypeVersion:
		return "OpcUa_BinarySchema_SoftwareCertificate_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_SoftwareCertificate_DictionaryFragment:
		return "OpcUa_BinarySchema_SoftwareCertificate_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_SignedSoftwareCertificate:
		return "OpcUa_BinarySchema_SignedSoftwareCertificate";
	case ObjectId::OpcUa_BinarySchema_SignedSoftwareCertificate_DataTypeVersion:
		return "OpcUa_BinarySchema_SignedSoftwareCertificate_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_SignedSoftwareCertificate_DictionaryFragment:
		return "OpcUa_BinarySchema_SignedSoftwareCertificate_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_AddNodesItem:
		return "OpcUa_BinarySchema_AddNodesItem";
	case ObjectId::OpcUa_BinarySchema_AddNodesItem_DataTypeVersion:
		return "OpcUa_BinarySchema_AddNodesItem_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_AddNodesItem_DictionaryFragment:
		return "OpcUa_BinarySchema_AddNodesItem_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_AddReferencesItem:
		return "OpcUa_BinarySchema_AddReferencesItem";
	case ObjectId::OpcUa_BinarySchema_AddReferencesItem_DataTypeVersion:
		return "OpcUa_BinarySchema_AddReferencesItem_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_AddReferencesItem_DictionaryFragment:
		return "OpcUa_BinarySchema_AddReferencesItem_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_DeleteNodesItem:
		return "OpcUa_BinarySchema_DeleteNodesItem";
	case ObjectId::OpcUa_BinarySchema_DeleteNodesItem_DataTypeVersion:
		return "OpcUa_BinarySchema_DeleteNodesItem_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_DeleteNodesItem_DictionaryFragment:
		return "OpcUa_BinarySchema_DeleteNodesItem_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_DeleteReferencesItem:
		return "OpcUa_BinarySchema_DeleteReferencesItem";
	case ObjectId::OpcUa_BinarySchema_DeleteReferencesItem_DataTypeVersion:
		return "OpcUa_BinarySchema_DeleteReferencesItem_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_DeleteReferencesItem_DictionaryFragment:
		return "OpcUa_BinarySchema_DeleteReferencesItem_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_ScalarTestType:
		return "OpcUa_BinarySchema_ScalarTestType";
	case ObjectId::OpcUa_BinarySchema_ScalarTestType_DataTypeVersion:
		return "OpcUa_BinarySchema_ScalarTestType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ScalarTestType_DictionaryFragment:
		return "OpcUa_BinarySchema_ScalarTestType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_ArrayTestType:
		return "OpcUa_BinarySchema_ArrayTestType";
	case ObjectId::OpcUa_BinarySchema_ArrayTestType_DataTypeVersion:
		return "OpcUa_BinarySchema_ArrayTestType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ArrayTestType_DictionaryFragment:
		return "OpcUa_BinarySchema_ArrayTestType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_CompositeTestType:
		return "OpcUa_BinarySchema_CompositeTestType";
	case ObjectId::OpcUa_BinarySchema_CompositeTestType_DataTypeVersion:
		return "OpcUa_BinarySchema_CompositeTestType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_CompositeTestType_DictionaryFragment:
		return "OpcUa_BinarySchema_CompositeTestType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_RegisteredServer:
		return "OpcUa_BinarySchema_RegisteredServer";
	case ObjectId::OpcUa_BinarySchema_RegisteredServer_DataTypeVersion:
		return "OpcUa_BinarySchema_RegisteredServer_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_RegisteredServer_DictionaryFragment:
		return "OpcUa_BinarySchema_RegisteredServer_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_ContentFilterElement:
		return "OpcUa_BinarySchema_ContentFilterElement";
	case ObjectId::OpcUa_BinarySchema_ContentFilterElement_DataTypeVersion:
		return "OpcUa_BinarySchema_ContentFilterElement_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ContentFilterElement_DictionaryFragment:
		return "OpcUa_BinarySchema_ContentFilterElement_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_ContentFilter:
		return "OpcUa_BinarySchema_ContentFilter";
	case ObjectId::OpcUa_BinarySchema_ContentFilter_DataTypeVersion:
		return "OpcUa_BinarySchema_ContentFilter_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ContentFilter_DictionaryFragment:
		return "OpcUa_BinarySchema_ContentFilter_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_FilterOperand:
		return "OpcUa_BinarySchema_FilterOperand";
	case ObjectId::OpcUa_BinarySchema_FilterOperand_DataTypeVersion:
		return "OpcUa_BinarySchema_FilterOperand_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_FilterOperand_DictionaryFragment:
		return "OpcUa_BinarySchema_FilterOperand_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_ElementOperand:
		return "OpcUa_BinarySchema_ElementOperand";
	case ObjectId::OpcUa_BinarySchema_ElementOperand_DataTypeVersion:
		return "OpcUa_BinarySchema_ElementOperand_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ElementOperand_DictionaryFragment:
		return "OpcUa_BinarySchema_ElementOperand_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_LiteralOperand:
		return "OpcUa_BinarySchema_LiteralOperand";
	case ObjectId::OpcUa_BinarySchema_LiteralOperand_DataTypeVersion:
		return "OpcUa_BinarySchema_LiteralOperand_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_LiteralOperand_DictionaryFragment:
		return "OpcUa_BinarySchema_LiteralOperand_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_AttributeOperand:
		return "OpcUa_BinarySchema_AttributeOperand";
	case ObjectId::OpcUa_BinarySchema_AttributeOperand_DataTypeVersion:
		return "OpcUa_BinarySchema_AttributeOperand_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_AttributeOperand_DictionaryFragment:
		return "OpcUa_BinarySchema_AttributeOperand_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_SimpleAttributeOperand:
		return "OpcUa_BinarySchema_SimpleAttributeOperand";
	case ObjectId::OpcUa_BinarySchema_SimpleAttributeOperand_DataTypeVersion:
		return "OpcUa_BinarySchema_SimpleAttributeOperand_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_SimpleAttributeOperand_DictionaryFragment:
		return "OpcUa_BinarySchema_SimpleAttributeOperand_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_HistoryEvent:
		return "OpcUa_BinarySchema_HistoryEvent";
	case ObjectId::OpcUa_BinarySchema_HistoryEvent_DataTypeVersion:
		return "OpcUa_BinarySchema_HistoryEvent_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_HistoryEvent_DictionaryFragment:
		return "OpcUa_BinarySchema_HistoryEvent_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_MonitoringFilter:
		return "OpcUa_BinarySchema_MonitoringFilter";
	case ObjectId::OpcUa_BinarySchema_MonitoringFilter_DataTypeVersion:
		return "OpcUa_BinarySchema_MonitoringFilter_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_MonitoringFilter_DictionaryFragment:
		return "OpcUa_BinarySchema_MonitoringFilter_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_EventFilter:
		return "OpcUa_BinarySchema_EventFilter";
	case ObjectId::OpcUa_BinarySchema_EventFilter_DataTypeVersion:
		return "OpcUa_BinarySchema_EventFilter_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_EventFilter_DictionaryFragment:
		return "OpcUa_BinarySchema_EventFilter_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_AggregateConfiguration:
		return "OpcUa_BinarySchema_AggregateConfiguration";
	case ObjectId::OpcUa_BinarySchema_AggregateConfiguration_DataTypeVersion:
		return "OpcUa_BinarySchema_AggregateConfiguration_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_AggregateConfiguration_DictionaryFragment:
		return "OpcUa_BinarySchema_AggregateConfiguration_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_HistoryEventFieldList:
		return "OpcUa_BinarySchema_HistoryEventFieldList";
	case ObjectId::OpcUa_BinarySchema_HistoryEventFieldList_DataTypeVersion:
		return "OpcUa_BinarySchema_HistoryEventFieldList_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_HistoryEventFieldList_DictionaryFragment:
		return "OpcUa_BinarySchema_HistoryEventFieldList_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_RedundantServerDataType:
		return "OpcUa_BinarySchema_RedundantServerDataType";
	case ObjectId::OpcUa_BinarySchema_RedundantServerDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_RedundantServerDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_RedundantServerDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_RedundantServerDataType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_SamplingIntervalDiagnosticsDataType:
		return "OpcUa_BinarySchema_SamplingIntervalDiagnosticsDataType";
	case ObjectId::OpcUa_BinarySchema_SamplingIntervalDiagnosticsDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_SamplingIntervalDiagnosticsDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_SamplingIntervalDiagnosticsDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_SamplingIntervalDiagnosticsDataType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_ServerDiagnosticsSummaryDataType:
		return "OpcUa_BinarySchema_ServerDiagnosticsSummaryDataType";
	case ObjectId::OpcUa_BinarySchema_ServerDiagnosticsSummaryDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_ServerDiagnosticsSummaryDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ServerDiagnosticsSummaryDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_ServerDiagnosticsSummaryDataType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_ServerStatusDataType:
		return "OpcUa_BinarySchema_ServerStatusDataType";
	case ObjectId::OpcUa_BinarySchema_ServerStatusDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_ServerStatusDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ServerStatusDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_ServerStatusDataType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_SessionDiagnosticsDataType:
		return "OpcUa_BinarySchema_SessionDiagnosticsDataType";
	case ObjectId::OpcUa_BinarySchema_SessionDiagnosticsDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_SessionDiagnosticsDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_SessionDiagnosticsDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_SessionDiagnosticsDataType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_SessionSecurityDiagnosticsDataType:
		return "OpcUa_BinarySchema_SessionSecurityDiagnosticsDataType";
	case ObjectId::OpcUa_BinarySchema_SessionSecurityDiagnosticsDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_SessionSecurityDiagnosticsDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_SessionSecurityDiagnosticsDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_SessionSecurityDiagnosticsDataType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_ServiceCounterDataType:
		return "OpcUa_BinarySchema_ServiceCounterDataType";
	case ObjectId::OpcUa_BinarySchema_ServiceCounterDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_ServiceCounterDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ServiceCounterDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_ServiceCounterDataType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_SubscriptionDiagnosticsDataType:
		return "OpcUa_BinarySchema_SubscriptionDiagnosticsDataType";
	case ObjectId::OpcUa_BinarySchema_SubscriptionDiagnosticsDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_SubscriptionDiagnosticsDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_SubscriptionDiagnosticsDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_SubscriptionDiagnosticsDataType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_ModelChangeStructureDataType:
		return "OpcUa_BinarySchema_ModelChangeStructureDataType";
	case ObjectId::OpcUa_BinarySchema_ModelChangeStructureDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_ModelChangeStructureDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ModelChangeStructureDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_ModelChangeStructureDataType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_SemanticChangeStructureDataType:
		return "OpcUa_BinarySchema_SemanticChangeStructureDataType";
	case ObjectId::OpcUa_BinarySchema_SemanticChangeStructureDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_SemanticChangeStructureDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_SemanticChangeStructureDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_SemanticChangeStructureDataType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_Range:
		return "OpcUa_BinarySchema_Range";
	case ObjectId::OpcUa_BinarySchema_Range_DataTypeVersion:
		return "OpcUa_BinarySchema_Range_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_Range_DictionaryFragment:
		return "OpcUa_BinarySchema_Range_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_EUInformation:
		return "OpcUa_BinarySchema_EUInformation";
	case ObjectId::OpcUa_BinarySchema_EUInformation_DataTypeVersion:
		return "OpcUa_BinarySchema_EUInformation_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_EUInformation_DictionaryFragment:
		return "OpcUa_BinarySchema_EUInformation_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_Annotation:
		return "OpcUa_BinarySchema_Annotation";
	case ObjectId::OpcUa_BinarySchema_Annotation_DataTypeVersion:
		return "OpcUa_BinarySchema_Annotation_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_Annotation_DictionaryFragment:
		return "OpcUa_BinarySchema_Annotation_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_ProgramDiagnosticDataType:
		return "OpcUa_BinarySchema_ProgramDiagnosticDataType";
	case ObjectId::OpcUa_BinarySchema_ProgramDiagnosticDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_ProgramDiagnosticDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ProgramDiagnosticDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_ProgramDiagnosticDataType_DictionaryFragment";
	case ObjectId::EnumValueType_Encoding_DefaultBinary:
		return "EnumValueType_Encoding_DefaultBinary";
	case ObjectId::OpcUa_XmlSchema:
		return "OpcUa_XmlSchema";
	case ObjectId::OpcUa_XmlSchema_DataTypeVersion:
		return "OpcUa_XmlSchema_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_NamespaceUri:
		return "OpcUa_XmlSchema_NamespaceUri";
	case ObjectId::OpcUa_XmlSchema_Argument:
		return "OpcUa_XmlSchema_Argument";
	case ObjectId::OpcUa_XmlSchema_Argument_DataTypeVersion:
		return "OpcUa_XmlSchema_Argument_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_Argument_DictionaryFragment:
		return "OpcUa_XmlSchema_Argument_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_EnumValueType:
		return "OpcUa_XmlSchema_EnumValueType";
	case ObjectId::OpcUa_XmlSchema_EnumValueType_DataTypeVersion:
		return "OpcUa_XmlSchema_EnumValueType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_EnumValueType_DictionaryFragment:
		return "OpcUa_XmlSchema_EnumValueType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_StatusResult:
		return "OpcUa_XmlSchema_StatusResult";
	case ObjectId::OpcUa_XmlSchema_StatusResult_DataTypeVersion:
		return "OpcUa_XmlSchema_StatusResult_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_StatusResult_DictionaryFragment:
		return "OpcUa_XmlSchema_StatusResult_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_UserTokenPolicy:
		return "OpcUa_XmlSchema_UserTokenPolicy";
	case ObjectId::OpcUa_XmlSchema_UserTokenPolicy_DataTypeVersion:
		return "OpcUa_XmlSchema_UserTokenPolicy_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_UserTokenPolicy_DictionaryFragment:
		return "OpcUa_XmlSchema_UserTokenPolicy_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_ApplicationDescription:
		return "OpcUa_XmlSchema_ApplicationDescription";
	case ObjectId::OpcUa_XmlSchema_ApplicationDescription_DataTypeVersion:
		return "OpcUa_XmlSchema_ApplicationDescription_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ApplicationDescription_DictionaryFragment:
		return "OpcUa_XmlSchema_ApplicationDescription_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_EndpointDescription:
		return "OpcUa_XmlSchema_EndpointDescription";
	case ObjectId::OpcUa_XmlSchema_EndpointDescription_DataTypeVersion:
		return "OpcUa_XmlSchema_EndpointDescription_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_EndpointDescription_DictionaryFragment:
		return "OpcUa_XmlSchema_EndpointDescription_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_UserIdentityToken:
		return "OpcUa_XmlSchema_UserIdentityToken";
	case ObjectId::OpcUa_XmlSchema_UserIdentityToken_DataTypeVersion:
		return "OpcUa_XmlSchema_UserIdentityToken_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_UserIdentityToken_DictionaryFragment:
		return "OpcUa_XmlSchema_UserIdentityToken_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_AnonymousIdentityToken:
		return "OpcUa_XmlSchema_AnonymousIdentityToken";
	case ObjectId::OpcUa_XmlSchema_AnonymousIdentityToken_DataTypeVersion:
		return "OpcUa_XmlSchema_AnonymousIdentityToken_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_AnonymousIdentityToken_DictionaryFragment:
		return "OpcUa_XmlSchema_AnonymousIdentityToken_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_UserNameIdentityToken:
		return "OpcUa_XmlSchema_UserNameIdentityToken";
	case ObjectId::OpcUa_XmlSchema_UserNameIdentityToken_DataTypeVersion:
		return "OpcUa_XmlSchema_UserNameIdentityToken_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_UserNameIdentityToken_DictionaryFragment:
		return "OpcUa_XmlSchema_UserNameIdentityToken_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_X509IdentityToken:
		return "OpcUa_XmlSchema_X509IdentityToken";
	case ObjectId::OpcUa_XmlSchema_X509IdentityToken_DataTypeVersion:
		return "OpcUa_XmlSchema_X509IdentityToken_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_X509IdentityToken_DictionaryFragment:
		return "OpcUa_XmlSchema_X509IdentityToken_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_IssuedIdentityToken:
		return "OpcUa_XmlSchema_IssuedIdentityToken";
	case ObjectId::OpcUa_XmlSchema_IssuedIdentityToken_DataTypeVersion:
		return "OpcUa_XmlSchema_IssuedIdentityToken_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_IssuedIdentityToken_DictionaryFragment:
		return "OpcUa_XmlSchema_IssuedIdentityToken_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_EndpointConfiguration:
		return "OpcUa_XmlSchema_EndpointConfiguration";
	case ObjectId::OpcUa_XmlSchema_EndpointConfiguration_DataTypeVersion:
		return "OpcUa_XmlSchema_EndpointConfiguration_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_EndpointConfiguration_DictionaryFragment:
		return "OpcUa_XmlSchema_EndpointConfiguration_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_SupportedProfile:
		return "OpcUa_XmlSchema_SupportedProfile";
	case ObjectId::OpcUa_XmlSchema_SupportedProfile_DataTypeVersion:
		return "OpcUa_XmlSchema_SupportedProfile_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_SupportedProfile_DictionaryFragment:
		return "OpcUa_XmlSchema_SupportedProfile_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_BuildInfo:
		return "OpcUa_XmlSchema_BuildInfo";
	case ObjectId::OpcUa_XmlSchema_BuildInfo_DataTypeVersion:
		return "OpcUa_XmlSchema_BuildInfo_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_BuildInfo_DictionaryFragment:
		return "OpcUa_XmlSchema_BuildInfo_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_SoftwareCertificate:
		return "OpcUa_XmlSchema_SoftwareCertificate";
	case ObjectId::OpcUa_XmlSchema_SoftwareCertificate_DataTypeVersion:
		return "OpcUa_XmlSchema_SoftwareCertificate_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_SoftwareCertificate_DictionaryFragment:
		return "OpcUa_XmlSchema_SoftwareCertificate_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_SignedSoftwareCertificate:
		return "OpcUa_XmlSchema_SignedSoftwareCertificate";
	case ObjectId::OpcUa_XmlSchema_SignedSoftwareCertificate_DataTypeVersion:
		return "OpcUa_XmlSchema_SignedSoftwareCertificate_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_SignedSoftwareCertificate_DictionaryFragment:
		return "OpcUa_XmlSchema_SignedSoftwareCertificate_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_AddNodesItem:
		return "OpcUa_XmlSchema_AddNodesItem";
	case ObjectId::OpcUa_XmlSchema_AddNodesItem_DataTypeVersion:
		return "OpcUa_XmlSchema_AddNodesItem_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_AddNodesItem_DictionaryFragment:
		return "OpcUa_XmlSchema_AddNodesItem_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_AddReferencesItem:
		return "OpcUa_XmlSchema_AddReferencesItem";
	case ObjectId::OpcUa_XmlSchema_AddReferencesItem_DataTypeVersion:
		return "OpcUa_XmlSchema_AddReferencesItem_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_AddReferencesItem_DictionaryFragment:
		return "OpcUa_XmlSchema_AddReferencesItem_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_DeleteNodesItem:
		return "OpcUa_XmlSchema_DeleteNodesItem";
	case ObjectId::OpcUa_XmlSchema_DeleteNodesItem_DataTypeVersion:
		return "OpcUa_XmlSchema_DeleteNodesItem_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_DeleteNodesItem_DictionaryFragment:
		return "OpcUa_XmlSchema_DeleteNodesItem_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_DeleteReferencesItem:
		return "OpcUa_XmlSchema_DeleteReferencesItem";
	case ObjectId::OpcUa_XmlSchema_DeleteReferencesItem_DataTypeVersion:
		return "OpcUa_XmlSchema_DeleteReferencesItem_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_DeleteReferencesItem_DictionaryFragment:
		return "OpcUa_XmlSchema_DeleteReferencesItem_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_ScalarTestType:
		return "OpcUa_XmlSchema_ScalarTestType";
	case ObjectId::OpcUa_XmlSchema_ScalarTestType_DataTypeVersion:
		return "OpcUa_XmlSchema_ScalarTestType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ScalarTestType_DictionaryFragment:
		return "OpcUa_XmlSchema_ScalarTestType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_ArrayTestType:
		return "OpcUa_XmlSchema_ArrayTestType";
	case ObjectId::OpcUa_XmlSchema_ArrayTestType_DataTypeVersion:
		return "OpcUa_XmlSchema_ArrayTestType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ArrayTestType_DictionaryFragment:
		return "OpcUa_XmlSchema_ArrayTestType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_CompositeTestType:
		return "OpcUa_XmlSchema_CompositeTestType";
	case ObjectId::OpcUa_XmlSchema_CompositeTestType_DataTypeVersion:
		return "OpcUa_XmlSchema_CompositeTestType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_CompositeTestType_DictionaryFragment:
		return "OpcUa_XmlSchema_CompositeTestType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_RegisteredServer:
		return "OpcUa_XmlSchema_RegisteredServer";
	case ObjectId::OpcUa_XmlSchema_RegisteredServer_DataTypeVersion:
		return "OpcUa_XmlSchema_RegisteredServer_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_RegisteredServer_DictionaryFragment:
		return "OpcUa_XmlSchema_RegisteredServer_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_ContentFilterElement:
		return "OpcUa_XmlSchema_ContentFilterElement";
	case ObjectId::OpcUa_XmlSchema_ContentFilterElement_DataTypeVersion:
		return "OpcUa_XmlSchema_ContentFilterElement_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ContentFilterElement_DictionaryFragment:
		return "OpcUa_XmlSchema_ContentFilterElement_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_ContentFilter:
		return "OpcUa_XmlSchema_ContentFilter";
	case ObjectId::OpcUa_XmlSchema_ContentFilter_DataTypeVersion:
		return "OpcUa_XmlSchema_ContentFilter_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ContentFilter_DictionaryFragment:
		return "OpcUa_XmlSchema_ContentFilter_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_FilterOperand:
		return "OpcUa_XmlSchema_FilterOperand";
	case ObjectId::OpcUa_XmlSchema_FilterOperand_DataTypeVersion:
		return "OpcUa_XmlSchema_FilterOperand_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_FilterOperand_DictionaryFragment:
		return "OpcUa_XmlSchema_FilterOperand_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_ElementOperand:
		return "OpcUa_XmlSchema_ElementOperand";
	case ObjectId::OpcUa_XmlSchema_ElementOperand_DataTypeVersion:
		return "OpcUa_XmlSchema_ElementOperand_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ElementOperand_DictionaryFragment:
		return "OpcUa_XmlSchema_ElementOperand_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_LiteralOperand:
		return "OpcUa_XmlSchema_LiteralOperand";
	case ObjectId::OpcUa_XmlSchema_LiteralOperand_DataTypeVersion:
		return "OpcUa_XmlSchema_LiteralOperand_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_LiteralOperand_DictionaryFragment:
		return "OpcUa_XmlSchema_LiteralOperand_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_AttributeOperand:
		return "OpcUa_XmlSchema_AttributeOperand";
	case ObjectId::OpcUa_XmlSchema_AttributeOperand_DataTypeVersion:
		return "OpcUa_XmlSchema_AttributeOperand_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_AttributeOperand_DictionaryFragment:
		return "OpcUa_XmlSchema_AttributeOperand_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_SimpleAttributeOperand:
		return "OpcUa_XmlSchema_SimpleAttributeOperand";
	case ObjectId::OpcUa_XmlSchema_SimpleAttributeOperand_DataTypeVersion:
		return "OpcUa_XmlSchema_SimpleAttributeOperand_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_SimpleAttributeOperand_DictionaryFragment:
		return "OpcUa_XmlSchema_SimpleAttributeOperand_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_HistoryEvent:
		return "OpcUa_XmlSchema_HistoryEvent";
	case ObjectId::OpcUa_XmlSchema_HistoryEvent_DataTypeVersion:
		return "OpcUa_XmlSchema_HistoryEvent_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_HistoryEvent_DictionaryFragment:
		return "OpcUa_XmlSchema_HistoryEvent_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_MonitoringFilter:
		return "OpcUa_XmlSchema_MonitoringFilter";
	case ObjectId::OpcUa_XmlSchema_MonitoringFilter_DataTypeVersion:
		return "OpcUa_XmlSchema_MonitoringFilter_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_MonitoringFilter_DictionaryFragment:
		return "OpcUa_XmlSchema_MonitoringFilter_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_EventFilter:
		return "OpcUa_XmlSchema_EventFilter";
	case ObjectId::OpcUa_XmlSchema_EventFilter_DataTypeVersion:
		return "OpcUa_XmlSchema_EventFilter_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_EventFilter_DictionaryFragment:
		return "OpcUa_XmlSchema_EventFilter_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_AggregateConfiguration:
		return "OpcUa_XmlSchema_AggregateConfiguration";
	case ObjectId::OpcUa_XmlSchema_AggregateConfiguration_DataTypeVersion:
		return "OpcUa_XmlSchema_AggregateConfiguration_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_AggregateConfiguration_DictionaryFragment:
		return "OpcUa_XmlSchema_AggregateConfiguration_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_HistoryEventFieldList:
		return "OpcUa_XmlSchema_HistoryEventFieldList";
	case ObjectId::OpcUa_XmlSchema_HistoryEventFieldList_DataTypeVersion:
		return "OpcUa_XmlSchema_HistoryEventFieldList_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_HistoryEventFieldList_DictionaryFragment:
		return "OpcUa_XmlSchema_HistoryEventFieldList_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_RedundantServerDataType:
		return "OpcUa_XmlSchema_RedundantServerDataType";
	case ObjectId::OpcUa_XmlSchema_RedundantServerDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_RedundantServerDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_RedundantServerDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_RedundantServerDataType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_SamplingIntervalDiagnosticsDataType:
		return "OpcUa_XmlSchema_SamplingIntervalDiagnosticsDataType";
	case ObjectId::OpcUa_XmlSchema_SamplingIntervalDiagnosticsDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_SamplingIntervalDiagnosticsDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_SamplingIntervalDiagnosticsDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_SamplingIntervalDiagnosticsDataType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_ServerDiagnosticsSummaryDataType:
		return "OpcUa_XmlSchema_ServerDiagnosticsSummaryDataType";
	case ObjectId::OpcUa_XmlSchema_ServerDiagnosticsSummaryDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_ServerDiagnosticsSummaryDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ServerDiagnosticsSummaryDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_ServerDiagnosticsSummaryDataType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_ServerStatusDataType:
		return "OpcUa_XmlSchema_ServerStatusDataType";
	case ObjectId::OpcUa_XmlSchema_ServerStatusDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_ServerStatusDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ServerStatusDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_ServerStatusDataType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_SessionDiagnosticsDataType:
		return "OpcUa_XmlSchema_SessionDiagnosticsDataType";
	case ObjectId::OpcUa_XmlSchema_SessionDiagnosticsDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_SessionDiagnosticsDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_SessionDiagnosticsDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_SessionDiagnosticsDataType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_SessionSecurityDiagnosticsDataType:
		return "OpcUa_XmlSchema_SessionSecurityDiagnosticsDataType";
	case ObjectId::OpcUa_XmlSchema_SessionSecurityDiagnosticsDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_SessionSecurityDiagnosticsDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_SessionSecurityDiagnosticsDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_SessionSecurityDiagnosticsDataType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_ServiceCounterDataType:
		return "OpcUa_XmlSchema_ServiceCounterDataType";
	case ObjectId::OpcUa_XmlSchema_ServiceCounterDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_ServiceCounterDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ServiceCounterDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_ServiceCounterDataType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_SubscriptionDiagnosticsDataType:
		return "OpcUa_XmlSchema_SubscriptionDiagnosticsDataType";
	case ObjectId::OpcUa_XmlSchema_SubscriptionDiagnosticsDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_SubscriptionDiagnosticsDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_SubscriptionDiagnosticsDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_SubscriptionDiagnosticsDataType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_ModelChangeStructureDataType:
		return "OpcUa_XmlSchema_ModelChangeStructureDataType";
	case ObjectId::OpcUa_XmlSchema_ModelChangeStructureDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_ModelChangeStructureDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ModelChangeStructureDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_ModelChangeStructureDataType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_SemanticChangeStructureDataType:
		return "OpcUa_XmlSchema_SemanticChangeStructureDataType";
	case ObjectId::OpcUa_XmlSchema_SemanticChangeStructureDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_SemanticChangeStructureDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_SemanticChangeStructureDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_SemanticChangeStructureDataType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_Range:
		return "OpcUa_XmlSchema_Range";
	case ObjectId::OpcUa_XmlSchema_Range_DataTypeVersion:
		return "OpcUa_XmlSchema_Range_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_Range_DictionaryFragment:
		return "OpcUa_XmlSchema_Range_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_EUInformation:
		return "OpcUa_XmlSchema_EUInformation";
	case ObjectId::OpcUa_XmlSchema_EUInformation_DataTypeVersion:
		return "OpcUa_XmlSchema_EUInformation_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_EUInformation_DictionaryFragment:
		return "OpcUa_XmlSchema_EUInformation_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_Annotation:
		return "OpcUa_XmlSchema_Annotation";
	case ObjectId::OpcUa_XmlSchema_Annotation_DataTypeVersion:
		return "OpcUa_XmlSchema_Annotation_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_Annotation_DictionaryFragment:
		return "OpcUa_XmlSchema_Annotation_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_ProgramDiagnosticDataType:
		return "OpcUa_XmlSchema_ProgramDiagnosticDataType";
	case ObjectId::OpcUa_XmlSchema_ProgramDiagnosticDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_ProgramDiagnosticDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ProgramDiagnosticDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_ProgramDiagnosticDataType_DictionaryFragment";
	case ObjectId::SubscriptionDiagnosticsType_MaxLifetimeCount:
		return "SubscriptionDiagnosticsType_MaxLifetimeCount";
	case ObjectId::SubscriptionDiagnosticsType_LatePublishRequestCount:
		return "SubscriptionDiagnosticsType_LatePublishRequestCount";
	case ObjectId::SubscriptionDiagnosticsType_CurrentKeepAliveCount:
		return "SubscriptionDiagnosticsType_CurrentKeepAliveCount";
	case ObjectId::SubscriptionDiagnosticsType_CurrentLifetimeCount:
		return "SubscriptionDiagnosticsType_CurrentLifetimeCount";
	case ObjectId::SubscriptionDiagnosticsType_UnacknowledgedMessageCount:
		return "SubscriptionDiagnosticsType_UnacknowledgedMessageCount";
	case ObjectId::SubscriptionDiagnosticsType_DiscardedMessageCount:
		return "SubscriptionDiagnosticsType_DiscardedMessageCount";
	case ObjectId::SubscriptionDiagnosticsType_MonitoredItemCount:
		return "SubscriptionDiagnosticsType_MonitoredItemCount";
	case ObjectId::SubscriptionDiagnosticsType_DisabledMonitoredItemCount:
		return "SubscriptionDiagnosticsType_DisabledMonitoredItemCount";
	case ObjectId::SubscriptionDiagnosticsType_MonitoringQueueOverflowCount:
		return "SubscriptionDiagnosticsType_MonitoringQueueOverflowCount";
	case ObjectId::SubscriptionDiagnosticsType_NextSequenceNumber:
		return "SubscriptionDiagnosticsType_NextSequenceNumber";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_TotalRequestCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_TotalRequestCount";
	case ObjectId::SessionDiagnosticsVariableType_TotalRequestCount:
		return "SessionDiagnosticsVariableType_TotalRequestCount";
	case ObjectId::SubscriptionDiagnosticsType_EventQueueOverFlowCount:
		return "SubscriptionDiagnosticsType_EventQueueOverFlowCount";
	case ObjectId::TimeZoneDataType:
		return "TimeZoneDataType";
	case ObjectId::TimeZoneDataType_Encoding_DefaultXml:
		return "TimeZoneDataType_Encoding_DefaultXml";
	case ObjectId::OpcUa_BinarySchema_TimeZoneDataType:
		return "OpcUa_BinarySchema_TimeZoneDataType";
	case ObjectId::OpcUa_BinarySchema_TimeZoneDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_TimeZoneDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_TimeZoneDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_TimeZoneDataType_DictionaryFragment";
	case ObjectId::TimeZoneDataType_Encoding_DefaultBinary:
		return "TimeZoneDataType_Encoding_DefaultBinary";
	case ObjectId::OpcUa_XmlSchema_TimeZoneDataType:
		return "OpcUa_XmlSchema_TimeZoneDataType";
	case ObjectId::OpcUa_XmlSchema_TimeZoneDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_TimeZoneDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_TimeZoneDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_TimeZoneDataType_DictionaryFragment";
	case ObjectId::LockType:
		return "LockType";
	case ObjectId::LockType_Lock:
		return "LockType_Lock";
	case ObjectId::LockType_Unlock:
		return "LockType_Unlock";
	case ObjectId::ServerLock:
		return "ServerLock";
	case ObjectId::ServerLock_Lock:
		return "ServerLock_Lock";
	case ObjectId::ServerLock_Unlock:
		return "ServerLock_Unlock";
	case ObjectId::AuditConditionRespondEventType:
		return "AuditConditionRespondEventType";
	case ObjectId::AuditConditionRespondEventType_EventId:
		return "AuditConditionRespondEventType_EventId";
	case ObjectId::AuditConditionRespondEventType_EventType:
		return "AuditConditionRespondEventType_EventType";
	case ObjectId::AuditConditionRespondEventType_SourceNode:
		return "AuditConditionRespondEventType_SourceNode";
	case ObjectId::AuditConditionRespondEventType_SourceName:
		return "AuditConditionRespondEventType_SourceName";
	case ObjectId::AuditConditionRespondEventType_Time:
		return "AuditConditionRespondEventType_Time";
	case ObjectId::AuditConditionRespondEventType_ReceiveTime:
		return "AuditConditionRespondEventType_ReceiveTime";
	case ObjectId::AuditConditionRespondEventType_LocalTime:
		return "AuditConditionRespondEventType_LocalTime";
	case ObjectId::AuditConditionRespondEventType_Message:
		return "AuditConditionRespondEventType_Message";
	case ObjectId::AuditConditionRespondEventType_Severity:
		return "AuditConditionRespondEventType_Severity";
	case ObjectId::AuditConditionRespondEventType_ActionTimeStamp:
		return "AuditConditionRespondEventType_ActionTimeStamp";
	case ObjectId::AuditConditionRespondEventType_Status:
		return "AuditConditionRespondEventType_Status";
	case ObjectId::AuditConditionRespondEventType_ServerId:
		return "AuditConditionRespondEventType_ServerId";
	case ObjectId::AuditConditionRespondEventType_ClientAuditEntryId:
		return "AuditConditionRespondEventType_ClientAuditEntryId";
	case ObjectId::AuditConditionRespondEventType_ClientUserId:
		return "AuditConditionRespondEventType_ClientUserId";
	case ObjectId::AuditConditionRespondEventType_MethodId:
		return "AuditConditionRespondEventType_MethodId";
	case ObjectId::AuditConditionRespondEventType_InputArguments:
		return "AuditConditionRespondEventType_InputArguments";
	case ObjectId::AuditConditionAcknowledgeEventType:
		return "AuditConditionAcknowledgeEventType";
	case ObjectId::AuditConditionAcknowledgeEventType_EventId:
		return "AuditConditionAcknowledgeEventType_EventId";
	case ObjectId::AuditConditionAcknowledgeEventType_EventType:
		return "AuditConditionAcknowledgeEventType_EventType";
	case ObjectId::AuditConditionAcknowledgeEventType_SourceNode:
		return "AuditConditionAcknowledgeEventType_SourceNode";
	case ObjectId::AuditConditionAcknowledgeEventType_SourceName:
		return "AuditConditionAcknowledgeEventType_SourceName";
	case ObjectId::AuditConditionAcknowledgeEventType_Time:
		return "AuditConditionAcknowledgeEventType_Time";
	case ObjectId::AuditConditionAcknowledgeEventType_ReceiveTime:
		return "AuditConditionAcknowledgeEventType_ReceiveTime";
	case ObjectId::AuditConditionAcknowledgeEventType_LocalTime:
		return "AuditConditionAcknowledgeEventType_LocalTime";
	case ObjectId::AuditConditionAcknowledgeEventType_Message:
		return "AuditConditionAcknowledgeEventType_Message";
	case ObjectId::AuditConditionAcknowledgeEventType_Severity:
		return "AuditConditionAcknowledgeEventType_Severity";
	case ObjectId::AuditConditionAcknowledgeEventType_ActionTimeStamp:
		return "AuditConditionAcknowledgeEventType_ActionTimeStamp";
	case ObjectId::AuditConditionAcknowledgeEventType_Status:
		return "AuditConditionAcknowledgeEventType_Status";
	case ObjectId::AuditConditionAcknowledgeEventType_ServerId:
		return "AuditConditionAcknowledgeEventType_ServerId";
	case ObjectId::AuditConditionAcknowledgeEventType_ClientAuditEntryId:
		return "AuditConditionAcknowledgeEventType_ClientAuditEntryId";
	case ObjectId::AuditConditionAcknowledgeEventType_ClientUserId:
		return "AuditConditionAcknowledgeEventType_ClientUserId";
	case ObjectId::AuditConditionAcknowledgeEventType_MethodId:
		return "AuditConditionAcknowledgeEventType_MethodId";
	case ObjectId::AuditConditionAcknowledgeEventType_InputArguments:
		return "AuditConditionAcknowledgeEventType_InputArguments";
	case ObjectId::AuditConditionConfirmEventType:
		return "AuditConditionConfirmEventType";
	case ObjectId::AuditConditionConfirmEventType_EventId:
		return "AuditConditionConfirmEventType_EventId";
	case ObjectId::AuditConditionConfirmEventType_EventType:
		return "AuditConditionConfirmEventType_EventType";
	case ObjectId::AuditConditionConfirmEventType_SourceNode:
		return "AuditConditionConfirmEventType_SourceNode";
	case ObjectId::AuditConditionConfirmEventType_SourceName:
		return "AuditConditionConfirmEventType_SourceName";
	case ObjectId::AuditConditionConfirmEventType_Time:
		return "AuditConditionConfirmEventType_Time";
	case ObjectId::AuditConditionConfirmEventType_ReceiveTime:
		return "AuditConditionConfirmEventType_ReceiveTime";
	case ObjectId::AuditConditionConfirmEventType_LocalTime:
		return "AuditConditionConfirmEventType_LocalTime";
	case ObjectId::AuditConditionConfirmEventType_Message:
		return "AuditConditionConfirmEventType_Message";
	case ObjectId::AuditConditionConfirmEventType_Severity:
		return "AuditConditionConfirmEventType_Severity";
	case ObjectId::AuditConditionConfirmEventType_ActionTimeStamp:
		return "AuditConditionConfirmEventType_ActionTimeStamp";
	case ObjectId::AuditConditionConfirmEventType_Status:
		return "AuditConditionConfirmEventType_Status";
	case ObjectId::AuditConditionConfirmEventType_ServerId:
		return "AuditConditionConfirmEventType_ServerId";
	case ObjectId::AuditConditionConfirmEventType_ClientAuditEntryId:
		return "AuditConditionConfirmEventType_ClientAuditEntryId";
	case ObjectId::AuditConditionConfirmEventType_ClientUserId:
		return "AuditConditionConfirmEventType_ClientUserId";
	case ObjectId::AuditConditionConfirmEventType_MethodId:
		return "AuditConditionConfirmEventType_MethodId";
	case ObjectId::AuditConditionConfirmEventType_InputArguments:
		return "AuditConditionConfirmEventType_InputArguments";
	case ObjectId::TwoStateVariableType:
		return "TwoStateVariableType";
	case ObjectId::TwoStateVariableType_Id:
		return "TwoStateVariableType_Id";
	case ObjectId::TwoStateVariableType_Name:
		return "TwoStateVariableType_Name";
	case ObjectId::TwoStateVariableType_Number:
		return "TwoStateVariableType_Number";
	case ObjectId::TwoStateVariableType_EffectiveDisplayName:
		return "TwoStateVariableType_EffectiveDisplayName";
	case ObjectId::TwoStateVariableType_TransitionTime:
		return "TwoStateVariableType_TransitionTime";
	case ObjectId::TwoStateVariableType_EffectiveTransitionTime:
		return "TwoStateVariableType_EffectiveTransitionTime";
	case ObjectId::ConditionVariableType:
		return "ConditionVariableType";
	case ObjectId::ConditionVariableType_SourceTimestamp:
		return "ConditionVariableType_SourceTimestamp";
	case ObjectId::HasTrueSubState:
		return "HasTrueSubState";
	case ObjectId::HasFalseSubState:
		return "HasFalseSubState";
	case ObjectId::HasCondition:
		return "HasCondition";
	case ObjectId::ConditionRefreshMethodType:
		return "ConditionRefreshMethodType";
	case ObjectId::ConditionRefreshMethodType_InputArguments:
		return "ConditionRefreshMethodType_InputArguments";
	case ObjectId::ConditionType_ConditionName:
		return "ConditionType_ConditionName";
	case ObjectId::ConditionType_BranchId:
		return "ConditionType_BranchId";
	case ObjectId::ConditionType_EnabledState:
		return "ConditionType_EnabledState";
	case ObjectId::ConditionType_EnabledState_Id:
		return "ConditionType_EnabledState_Id";
	case ObjectId::ConditionType_EnabledState_Name:
		return "ConditionType_EnabledState_Name";
	case ObjectId::ConditionType_EnabledState_Number:
		return "ConditionType_EnabledState_Number";
	case ObjectId::ConditionType_EnabledState_EffectiveDisplayName:
		return "ConditionType_EnabledState_EffectiveDisplayName";
	case ObjectId::ConditionType_EnabledState_TransitionTime:
		return "ConditionType_EnabledState_TransitionTime";
	case ObjectId::ConditionType_EnabledState_EffectiveTransitionTime:
		return "ConditionType_EnabledState_EffectiveTransitionTime";
	case ObjectId::ConditionType_EnabledState_TrueState:
		return "ConditionType_EnabledState_TrueState";
	case ObjectId::ConditionType_EnabledState_FalseState:
		return "ConditionType_EnabledState_FalseState";
	case ObjectId::ConditionType_Quality:
		return "ConditionType_Quality";
	case ObjectId::ConditionType_Quality_SourceTimestamp:
		return "ConditionType_Quality_SourceTimestamp";
	case ObjectId::ConditionType_LastSeverity:
		return "ConditionType_LastSeverity";
	case ObjectId::ConditionType_LastSeverity_SourceTimestamp:
		return "ConditionType_LastSeverity_SourceTimestamp";
	case ObjectId::ConditionType_Comment:
		return "ConditionType_Comment";
	case ObjectId::ConditionType_Comment_SourceTimestamp:
		return "ConditionType_Comment_SourceTimestamp";
	case ObjectId::ConditionType_ClientUserId:
		return "ConditionType_ClientUserId";
	case ObjectId::ConditionType_Enable:
		return "ConditionType_Enable";
	case ObjectId::ConditionType_Disable:
		return "ConditionType_Disable";
	case ObjectId::ConditionType_AddComment:
		return "ConditionType_AddComment";
	case ObjectId::ConditionType_AddComment_InputArguments:
		return "ConditionType_AddComment_InputArguments";
	case ObjectId::DialogResponseMethodType:
		return "DialogResponseMethodType";
	case ObjectId::DialogResponseMethodType_InputArguments:
		return "DialogResponseMethodType_InputArguments";
	case ObjectId::DialogConditionType_ConditionName:
		return "DialogConditionType_ConditionName";
	case ObjectId::DialogConditionType_BranchId:
		return "DialogConditionType_BranchId";
	case ObjectId::DialogConditionType_EnabledState:
		return "DialogConditionType_EnabledState";
	case ObjectId::DialogConditionType_EnabledState_Id:
		return "DialogConditionType_EnabledState_Id";
	case ObjectId::DialogConditionType_EnabledState_Name:
		return "DialogConditionType_EnabledState_Name";
	case ObjectId::DialogConditionType_EnabledState_Number:
		return "DialogConditionType_EnabledState_Number";
	case ObjectId::DialogConditionType_EnabledState_EffectiveDisplayName:
		return "DialogConditionType_EnabledState_EffectiveDisplayName";
	case ObjectId::DialogConditionType_EnabledState_TransitionTime:
		return "DialogConditionType_EnabledState_TransitionTime";
	case ObjectId::DialogConditionType_EnabledState_EffectiveTransitionTime:
		return "DialogConditionType_EnabledState_EffectiveTransitionTime";
	case ObjectId::DialogConditionType_EnabledState_TrueState:
		return "DialogConditionType_EnabledState_TrueState";
	case ObjectId::DialogConditionType_EnabledState_FalseState:
		return "DialogConditionType_EnabledState_FalseState";
	case ObjectId::DialogConditionType_Quality:
		return "DialogConditionType_Quality";
	case ObjectId::DialogConditionType_Quality_SourceTimestamp:
		return "DialogConditionType_Quality_SourceTimestamp";
	case ObjectId::DialogConditionType_LastSeverity:
		return "DialogConditionType_LastSeverity";
	case ObjectId::DialogConditionType_LastSeverity_SourceTimestamp:
		return "DialogConditionType_LastSeverity_SourceTimestamp";
	case ObjectId::DialogConditionType_Comment:
		return "DialogConditionType_Comment";
	case ObjectId::DialogConditionType_Comment_SourceTimestamp:
		return "DialogConditionType_Comment_SourceTimestamp";
	case ObjectId::DialogConditionType_ClientUserId:
		return "DialogConditionType_ClientUserId";
	case ObjectId::DialogConditionType_Enable:
		return "DialogConditionType_Enable";
	case ObjectId::DialogConditionType_Disable:
		return "DialogConditionType_Disable";
	case ObjectId::DialogConditionType_AddComment:
		return "DialogConditionType_AddComment";
	case ObjectId::DialogConditionType_AddComment_InputArguments:
		return "DialogConditionType_AddComment_InputArguments";
	case ObjectId::DialogConditionType_DialogState:
		return "DialogConditionType_DialogState";
	case ObjectId::DialogConditionType_DialogState_Id:
		return "DialogConditionType_DialogState_Id";
	case ObjectId::DialogConditionType_DialogState_Name:
		return "DialogConditionType_DialogState_Name";
	case ObjectId::DialogConditionType_DialogState_Number:
		return "DialogConditionType_DialogState_Number";
	case ObjectId::DialogConditionType_DialogState_EffectiveDisplayName:
		return "DialogConditionType_DialogState_EffectiveDisplayName";
	case ObjectId::DialogConditionType_DialogState_TransitionTime:
		return "DialogConditionType_DialogState_TransitionTime";
	case ObjectId::DialogConditionType_DialogState_EffectiveTransitionTime:
		return "DialogConditionType_DialogState_EffectiveTransitionTime";
	case ObjectId::DialogConditionType_DialogState_TrueState:
		return "DialogConditionType_DialogState_TrueState";
	case ObjectId::DialogConditionType_DialogState_FalseState:
		return "DialogConditionType_DialogState_FalseState";
	case ObjectId::DialogConditionType_ResponseOptionSet:
		return "DialogConditionType_ResponseOptionSet";
	case ObjectId::DialogConditionType_DefaultResponse:
		return "DialogConditionType_DefaultResponse";
	case ObjectId::DialogConditionType_OkResponse:
		return "DialogConditionType_OkResponse";
	case ObjectId::DialogConditionType_CancelResponse:
		return "DialogConditionType_CancelResponse";
	case ObjectId::DialogConditionType_LastResponse:
		return "DialogConditionType_LastResponse";
	case ObjectId::DialogConditionType_Respond:
		return "DialogConditionType_Respond";
	case ObjectId::DialogConditionType_Respond_InputArguments:
		return "DialogConditionType_Respond_InputArguments";
	case ObjectId::AcknowledgeableConditionType_ConditionName:
		return "AcknowledgeableConditionType_ConditionName";
	case ObjectId::AcknowledgeableConditionType_BranchId:
		return "AcknowledgeableConditionType_BranchId";
	case ObjectId::AcknowledgeableConditionType_EnabledState:
		return "AcknowledgeableConditionType_EnabledState";
	case ObjectId::AcknowledgeableConditionType_EnabledState_Id:
		return "AcknowledgeableConditionType_EnabledState_Id";
	case ObjectId::AcknowledgeableConditionType_EnabledState_Name:
		return "AcknowledgeableConditionType_EnabledState_Name";
	case ObjectId::AcknowledgeableConditionType_EnabledState_Number:
		return "AcknowledgeableConditionType_EnabledState_Number";
	case ObjectId::AcknowledgeableConditionType_EnabledState_EffectiveDisplayName:
		return "AcknowledgeableConditionType_EnabledState_EffectiveDisplayName";
	case ObjectId::AcknowledgeableConditionType_EnabledState_TransitionTime:
		return "AcknowledgeableConditionType_EnabledState_TransitionTime";
	case ObjectId::AcknowledgeableConditionType_EnabledState_EffectiveTransitionTime:
		return "AcknowledgeableConditionType_EnabledState_EffectiveTransitionTime";
	case ObjectId::AcknowledgeableConditionType_EnabledState_TrueState:
		return "AcknowledgeableConditionType_EnabledState_TrueState";
	case ObjectId::AcknowledgeableConditionType_EnabledState_FalseState:
		return "AcknowledgeableConditionType_EnabledState_FalseState";
	case ObjectId::AcknowledgeableConditionType_Quality:
		return "AcknowledgeableConditionType_Quality";
	case ObjectId::AcknowledgeableConditionType_Quality_SourceTimestamp:
		return "AcknowledgeableConditionType_Quality_SourceTimestamp";
	case ObjectId::AcknowledgeableConditionType_LastSeverity:
		return "AcknowledgeableConditionType_LastSeverity";
	case ObjectId::AcknowledgeableConditionType_LastSeverity_SourceTimestamp:
		return "AcknowledgeableConditionType_LastSeverity_SourceTimestamp";
	case ObjectId::AcknowledgeableConditionType_Comment:
		return "AcknowledgeableConditionType_Comment";
	case ObjectId::AcknowledgeableConditionType_Comment_SourceTimestamp:
		return "AcknowledgeableConditionType_Comment_SourceTimestamp";
	case ObjectId::AcknowledgeableConditionType_ClientUserId:
		return "AcknowledgeableConditionType_ClientUserId";
	case ObjectId::AcknowledgeableConditionType_Enable:
		return "AcknowledgeableConditionType_Enable";
	case ObjectId::AcknowledgeableConditionType_Disable:
		return "AcknowledgeableConditionType_Disable";
	case ObjectId::AcknowledgeableConditionType_AddComment:
		return "AcknowledgeableConditionType_AddComment";
	case ObjectId::AcknowledgeableConditionType_AddComment_InputArguments:
		return "AcknowledgeableConditionType_AddComment_InputArguments";
	case ObjectId::AcknowledgeableConditionType_AckedState:
		return "AcknowledgeableConditionType_AckedState";
	case ObjectId::AcknowledgeableConditionType_AckedState_Id:
		return "AcknowledgeableConditionType_AckedState_Id";
	case ObjectId::AcknowledgeableConditionType_AckedState_Name:
		return "AcknowledgeableConditionType_AckedState_Name";
	case ObjectId::AcknowledgeableConditionType_AckedState_Number:
		return "AcknowledgeableConditionType_AckedState_Number";
	case ObjectId::AcknowledgeableConditionType_AckedState_EffectiveDisplayName:
		return "AcknowledgeableConditionType_AckedState_EffectiveDisplayName";
	case ObjectId::AcknowledgeableConditionType_AckedState_TransitionTime:
		return "AcknowledgeableConditionType_AckedState_TransitionTime";
	case ObjectId::AcknowledgeableConditionType_AckedState_EffectiveTransitionTime:
		return "AcknowledgeableConditionType_AckedState_EffectiveTransitionTime";
	case ObjectId::AcknowledgeableConditionType_AckedState_TrueState:
		return "AcknowledgeableConditionType_AckedState_TrueState";
	case ObjectId::AcknowledgeableConditionType_AckedState_FalseState:
		return "AcknowledgeableConditionType_AckedState_FalseState";
	case ObjectId::AcknowledgeableConditionType_ConfirmedState:
		return "AcknowledgeableConditionType_ConfirmedState";
	case ObjectId::AcknowledgeableConditionType_ConfirmedState_Id:
		return "AcknowledgeableConditionType_ConfirmedState_Id";
	case ObjectId::AcknowledgeableConditionType_ConfirmedState_Name:
		return "AcknowledgeableConditionType_ConfirmedState_Name";
	case ObjectId::AcknowledgeableConditionType_ConfirmedState_Number:
		return "AcknowledgeableConditionType_ConfirmedState_Number";
	case ObjectId::AcknowledgeableConditionType_ConfirmedState_EffectiveDisplayName:
		return "AcknowledgeableConditionType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::AcknowledgeableConditionType_ConfirmedState_TransitionTime:
		return "AcknowledgeableConditionType_ConfirmedState_TransitionTime";
	case ObjectId::AcknowledgeableConditionType_ConfirmedState_EffectiveTransitionTime:
		return "AcknowledgeableConditionType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::AcknowledgeableConditionType_ConfirmedState_TrueState:
		return "AcknowledgeableConditionType_ConfirmedState_TrueState";
	case ObjectId::AcknowledgeableConditionType_ConfirmedState_FalseState:
		return "AcknowledgeableConditionType_ConfirmedState_FalseState";
	case ObjectId::AcknowledgeableConditionType_Acknowledge:
		return "AcknowledgeableConditionType_Acknowledge";
	case ObjectId::AcknowledgeableConditionType_Acknowledge_InputArguments:
		return "AcknowledgeableConditionType_Acknowledge_InputArguments";
	case ObjectId::AcknowledgeableConditionType_Confirm:
		return "AcknowledgeableConditionType_Confirm";
	case ObjectId::AcknowledgeableConditionType_Confirm_InputArguments:
		return "AcknowledgeableConditionType_Confirm_InputArguments";
	case ObjectId::ShelvedStateMachineType_UnshelveTime:
		return "ShelvedStateMachineType_UnshelveTime";
	case ObjectId::AlarmConditionType_ConditionName:
		return "AlarmConditionType_ConditionName";
	case ObjectId::AlarmConditionType_BranchId:
		return "AlarmConditionType_BranchId";
	case ObjectId::AlarmConditionType_EnabledState:
		return "AlarmConditionType_EnabledState";
	case ObjectId::AlarmConditionType_EnabledState_Id:
		return "AlarmConditionType_EnabledState_Id";
	case ObjectId::AlarmConditionType_EnabledState_Name:
		return "AlarmConditionType_EnabledState_Name";
	case ObjectId::AlarmConditionType_EnabledState_Number:
		return "AlarmConditionType_EnabledState_Number";
	case ObjectId::AlarmConditionType_EnabledState_EffectiveDisplayName:
		return "AlarmConditionType_EnabledState_EffectiveDisplayName";
	case ObjectId::AlarmConditionType_EnabledState_TransitionTime:
		return "AlarmConditionType_EnabledState_TransitionTime";
	case ObjectId::AlarmConditionType_EnabledState_EffectiveTransitionTime:
		return "AlarmConditionType_EnabledState_EffectiveTransitionTime";
	case ObjectId::AlarmConditionType_EnabledState_TrueState:
		return "AlarmConditionType_EnabledState_TrueState";
	case ObjectId::AlarmConditionType_EnabledState_FalseState:
		return "AlarmConditionType_EnabledState_FalseState";
	case ObjectId::AlarmConditionType_Quality:
		return "AlarmConditionType_Quality";
	case ObjectId::AlarmConditionType_Quality_SourceTimestamp:
		return "AlarmConditionType_Quality_SourceTimestamp";
	case ObjectId::AlarmConditionType_LastSeverity:
		return "AlarmConditionType_LastSeverity";
	case ObjectId::AlarmConditionType_LastSeverity_SourceTimestamp:
		return "AlarmConditionType_LastSeverity_SourceTimestamp";
	case ObjectId::AlarmConditionType_Comment:
		return "AlarmConditionType_Comment";
	case ObjectId::AlarmConditionType_Comment_SourceTimestamp:
		return "AlarmConditionType_Comment_SourceTimestamp";
	case ObjectId::AlarmConditionType_ClientUserId:
		return "AlarmConditionType_ClientUserId";
	case ObjectId::AlarmConditionType_Enable:
		return "AlarmConditionType_Enable";
	case ObjectId::AlarmConditionType_Disable:
		return "AlarmConditionType_Disable";
	case ObjectId::AlarmConditionType_AddComment:
		return "AlarmConditionType_AddComment";
	case ObjectId::AlarmConditionType_AddComment_InputArguments:
		return "AlarmConditionType_AddComment_InputArguments";
	case ObjectId::AlarmConditionType_AckedState:
		return "AlarmConditionType_AckedState";
	case ObjectId::AlarmConditionType_AckedState_Id:
		return "AlarmConditionType_AckedState_Id";
	case ObjectId::AlarmConditionType_AckedState_Name:
		return "AlarmConditionType_AckedState_Name";
	case ObjectId::AlarmConditionType_AckedState_Number:
		return "AlarmConditionType_AckedState_Number";
	case ObjectId::AlarmConditionType_AckedState_EffectiveDisplayName:
		return "AlarmConditionType_AckedState_EffectiveDisplayName";
	case ObjectId::AlarmConditionType_AckedState_TransitionTime:
		return "AlarmConditionType_AckedState_TransitionTime";
	case ObjectId::AlarmConditionType_AckedState_EffectiveTransitionTime:
		return "AlarmConditionType_AckedState_EffectiveTransitionTime";
	case ObjectId::AlarmConditionType_AckedState_TrueState:
		return "AlarmConditionType_AckedState_TrueState";
	case ObjectId::AlarmConditionType_AckedState_FalseState:
		return "AlarmConditionType_AckedState_FalseState";
	case ObjectId::AlarmConditionType_ConfirmedState:
		return "AlarmConditionType_ConfirmedState";
	case ObjectId::AlarmConditionType_ConfirmedState_Id:
		return "AlarmConditionType_ConfirmedState_Id";
	case ObjectId::AlarmConditionType_ConfirmedState_Name:
		return "AlarmConditionType_ConfirmedState_Name";
	case ObjectId::AlarmConditionType_ConfirmedState_Number:
		return "AlarmConditionType_ConfirmedState_Number";
	case ObjectId::AlarmConditionType_ConfirmedState_EffectiveDisplayName:
		return "AlarmConditionType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::AlarmConditionType_ConfirmedState_TransitionTime:
		return "AlarmConditionType_ConfirmedState_TransitionTime";
	case ObjectId::AlarmConditionType_ConfirmedState_EffectiveTransitionTime:
		return "AlarmConditionType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::AlarmConditionType_ConfirmedState_TrueState:
		return "AlarmConditionType_ConfirmedState_TrueState";
	case ObjectId::AlarmConditionType_ConfirmedState_FalseState:
		return "AlarmConditionType_ConfirmedState_FalseState";
	case ObjectId::AlarmConditionType_Acknowledge:
		return "AlarmConditionType_Acknowledge";
	case ObjectId::AlarmConditionType_Acknowledge_InputArguments:
		return "AlarmConditionType_Acknowledge_InputArguments";
	case ObjectId::AlarmConditionType_Confirm:
		return "AlarmConditionType_Confirm";
	case ObjectId::AlarmConditionType_Confirm_InputArguments:
		return "AlarmConditionType_Confirm_InputArguments";
	case ObjectId::AlarmConditionType_ActiveState:
		return "AlarmConditionType_ActiveState";
	case ObjectId::AlarmConditionType_ActiveState_Id:
		return "AlarmConditionType_ActiveState_Id";
	case ObjectId::AlarmConditionType_ActiveState_Name:
		return "AlarmConditionType_ActiveState_Name";
	case ObjectId::AlarmConditionType_ActiveState_Number:
		return "AlarmConditionType_ActiveState_Number";
	case ObjectId::AlarmConditionType_ActiveState_EffectiveDisplayName:
		return "AlarmConditionType_ActiveState_EffectiveDisplayName";
	case ObjectId::AlarmConditionType_ActiveState_TransitionTime:
		return "AlarmConditionType_ActiveState_TransitionTime";
	case ObjectId::AlarmConditionType_ActiveState_EffectiveTransitionTime:
		return "AlarmConditionType_ActiveState_EffectiveTransitionTime";
	case ObjectId::AlarmConditionType_ActiveState_TrueState:
		return "AlarmConditionType_ActiveState_TrueState";
	case ObjectId::AlarmConditionType_ActiveState_FalseState:
		return "AlarmConditionType_ActiveState_FalseState";
	case ObjectId::AlarmConditionType_SuppressedState:
		return "AlarmConditionType_SuppressedState";
	case ObjectId::AlarmConditionType_SuppressedState_Id:
		return "AlarmConditionType_SuppressedState_Id";
	case ObjectId::AlarmConditionType_SuppressedState_Name:
		return "AlarmConditionType_SuppressedState_Name";
	case ObjectId::AlarmConditionType_SuppressedState_Number:
		return "AlarmConditionType_SuppressedState_Number";
	case ObjectId::AlarmConditionType_SuppressedState_EffectiveDisplayName:
		return "AlarmConditionType_SuppressedState_EffectiveDisplayName";
	case ObjectId::AlarmConditionType_SuppressedState_TransitionTime:
		return "AlarmConditionType_SuppressedState_TransitionTime";
	case ObjectId::AlarmConditionType_SuppressedState_EffectiveTransitionTime:
		return "AlarmConditionType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::AlarmConditionType_SuppressedState_TrueState:
		return "AlarmConditionType_SuppressedState_TrueState";
	case ObjectId::AlarmConditionType_SuppressedState_FalseState:
		return "AlarmConditionType_SuppressedState_FalseState";
	case ObjectId::AlarmConditionType_ShelvingState:
		return "AlarmConditionType_ShelvingState";
	case ObjectId::AlarmConditionType_ShelvingState_CurrentState:
		return "AlarmConditionType_ShelvingState_CurrentState";
	case ObjectId::AlarmConditionType_ShelvingState_CurrentState_Id:
		return "AlarmConditionType_ShelvingState_CurrentState_Id";
	case ObjectId::AlarmConditionType_ShelvingState_CurrentState_Name:
		return "AlarmConditionType_ShelvingState_CurrentState_Name";
	case ObjectId::AlarmConditionType_ShelvingState_CurrentState_Number:
		return "AlarmConditionType_ShelvingState_CurrentState_Number";
	case ObjectId::AlarmConditionType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "AlarmConditionType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::AlarmConditionType_ShelvingState_LastTransition:
		return "AlarmConditionType_ShelvingState_LastTransition";
	case ObjectId::AlarmConditionType_ShelvingState_LastTransition_Id:
		return "AlarmConditionType_ShelvingState_LastTransition_Id";
	case ObjectId::AlarmConditionType_ShelvingState_LastTransition_Name:
		return "AlarmConditionType_ShelvingState_LastTransition_Name";
	case ObjectId::AlarmConditionType_ShelvingState_LastTransition_Number:
		return "AlarmConditionType_ShelvingState_LastTransition_Number";
	case ObjectId::AlarmConditionType_ShelvingState_LastTransition_TransitionTime:
		return "AlarmConditionType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::AlarmConditionType_ShelvingState_UnshelveTime:
		return "AlarmConditionType_ShelvingState_UnshelveTime";
	case ObjectId::AlarmConditionType_ShelvingState_Unshelve:
		return "AlarmConditionType_ShelvingState_Unshelve";
	case ObjectId::AlarmConditionType_ShelvingState_OneShotShelve:
		return "AlarmConditionType_ShelvingState_OneShotShelve";
	case ObjectId::AlarmConditionType_ShelvingState_TimedShelve:
		return "AlarmConditionType_ShelvingState_TimedShelve";
	case ObjectId::AlarmConditionType_ShelvingState_TimedShelve_InputArguments:
		return "AlarmConditionType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::AlarmConditionType_SuppressedOrShelved:
		return "AlarmConditionType_SuppressedOrShelved";
	case ObjectId::AlarmConditionType_MaxTimeShelved:
		return "AlarmConditionType_MaxTimeShelved";
	case ObjectId::LimitAlarmType_ConditionName:
		return "LimitAlarmType_ConditionName";
	case ObjectId::LimitAlarmType_BranchId:
		return "LimitAlarmType_BranchId";
	case ObjectId::LimitAlarmType_EnabledState:
		return "LimitAlarmType_EnabledState";
	case ObjectId::LimitAlarmType_EnabledState_Id:
		return "LimitAlarmType_EnabledState_Id";
	case ObjectId::LimitAlarmType_EnabledState_Name:
		return "LimitAlarmType_EnabledState_Name";
	case ObjectId::LimitAlarmType_EnabledState_Number:
		return "LimitAlarmType_EnabledState_Number";
	case ObjectId::LimitAlarmType_EnabledState_EffectiveDisplayName:
		return "LimitAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::LimitAlarmType_EnabledState_TransitionTime:
		return "LimitAlarmType_EnabledState_TransitionTime";
	case ObjectId::LimitAlarmType_EnabledState_EffectiveTransitionTime:
		return "LimitAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::LimitAlarmType_EnabledState_TrueState:
		return "LimitAlarmType_EnabledState_TrueState";
	case ObjectId::LimitAlarmType_EnabledState_FalseState:
		return "LimitAlarmType_EnabledState_FalseState";
	case ObjectId::LimitAlarmType_Quality:
		return "LimitAlarmType_Quality";
	case ObjectId::LimitAlarmType_Quality_SourceTimestamp:
		return "LimitAlarmType_Quality_SourceTimestamp";
	case ObjectId::LimitAlarmType_LastSeverity:
		return "LimitAlarmType_LastSeverity";
	case ObjectId::LimitAlarmType_LastSeverity_SourceTimestamp:
		return "LimitAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::LimitAlarmType_Comment:
		return "LimitAlarmType_Comment";
	case ObjectId::LimitAlarmType_Comment_SourceTimestamp:
		return "LimitAlarmType_Comment_SourceTimestamp";
	case ObjectId::LimitAlarmType_ClientUserId:
		return "LimitAlarmType_ClientUserId";
	case ObjectId::LimitAlarmType_Enable:
		return "LimitAlarmType_Enable";
	case ObjectId::LimitAlarmType_Disable:
		return "LimitAlarmType_Disable";
	case ObjectId::LimitAlarmType_AddComment:
		return "LimitAlarmType_AddComment";
	case ObjectId::LimitAlarmType_AddComment_InputArguments:
		return "LimitAlarmType_AddComment_InputArguments";
	case ObjectId::LimitAlarmType_AckedState:
		return "LimitAlarmType_AckedState";
	case ObjectId::LimitAlarmType_AckedState_Id:
		return "LimitAlarmType_AckedState_Id";
	case ObjectId::LimitAlarmType_AckedState_Name:
		return "LimitAlarmType_AckedState_Name";
	case ObjectId::LimitAlarmType_AckedState_Number:
		return "LimitAlarmType_AckedState_Number";
	case ObjectId::LimitAlarmType_AckedState_EffectiveDisplayName:
		return "LimitAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::LimitAlarmType_AckedState_TransitionTime:
		return "LimitAlarmType_AckedState_TransitionTime";
	case ObjectId::LimitAlarmType_AckedState_EffectiveTransitionTime:
		return "LimitAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::LimitAlarmType_AckedState_TrueState:
		return "LimitAlarmType_AckedState_TrueState";
	case ObjectId::LimitAlarmType_AckedState_FalseState:
		return "LimitAlarmType_AckedState_FalseState";
	case ObjectId::LimitAlarmType_ConfirmedState:
		return "LimitAlarmType_ConfirmedState";
	case ObjectId::LimitAlarmType_ConfirmedState_Id:
		return "LimitAlarmType_ConfirmedState_Id";
	case ObjectId::LimitAlarmType_ConfirmedState_Name:
		return "LimitAlarmType_ConfirmedState_Name";
	case ObjectId::LimitAlarmType_ConfirmedState_Number:
		return "LimitAlarmType_ConfirmedState_Number";
	case ObjectId::LimitAlarmType_ConfirmedState_EffectiveDisplayName:
		return "LimitAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::LimitAlarmType_ConfirmedState_TransitionTime:
		return "LimitAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::LimitAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "LimitAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::LimitAlarmType_ConfirmedState_TrueState:
		return "LimitAlarmType_ConfirmedState_TrueState";
	case ObjectId::LimitAlarmType_ConfirmedState_FalseState:
		return "LimitAlarmType_ConfirmedState_FalseState";
	case ObjectId::LimitAlarmType_Acknowledge:
		return "LimitAlarmType_Acknowledge";
	case ObjectId::LimitAlarmType_Acknowledge_InputArguments:
		return "LimitAlarmType_Acknowledge_InputArguments";
	case ObjectId::LimitAlarmType_Confirm:
		return "LimitAlarmType_Confirm";
	case ObjectId::LimitAlarmType_Confirm_InputArguments:
		return "LimitAlarmType_Confirm_InputArguments";
	case ObjectId::LimitAlarmType_ActiveState:
		return "LimitAlarmType_ActiveState";
	case ObjectId::LimitAlarmType_ActiveState_Id:
		return "LimitAlarmType_ActiveState_Id";
	case ObjectId::LimitAlarmType_ActiveState_Name:
		return "LimitAlarmType_ActiveState_Name";
	case ObjectId::LimitAlarmType_ActiveState_Number:
		return "LimitAlarmType_ActiveState_Number";
	case ObjectId::LimitAlarmType_ActiveState_EffectiveDisplayName:
		return "LimitAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::LimitAlarmType_ActiveState_TransitionTime:
		return "LimitAlarmType_ActiveState_TransitionTime";
	case ObjectId::LimitAlarmType_ActiveState_EffectiveTransitionTime:
		return "LimitAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::LimitAlarmType_ActiveState_TrueState:
		return "LimitAlarmType_ActiveState_TrueState";
	case ObjectId::LimitAlarmType_ActiveState_FalseState:
		return "LimitAlarmType_ActiveState_FalseState";
	case ObjectId::LimitAlarmType_SuppressedState:
		return "LimitAlarmType_SuppressedState";
	case ObjectId::LimitAlarmType_SuppressedState_Id:
		return "LimitAlarmType_SuppressedState_Id";
	case ObjectId::LimitAlarmType_SuppressedState_Name:
		return "LimitAlarmType_SuppressedState_Name";
	case ObjectId::LimitAlarmType_SuppressedState_Number:
		return "LimitAlarmType_SuppressedState_Number";
	case ObjectId::LimitAlarmType_SuppressedState_EffectiveDisplayName:
		return "LimitAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::LimitAlarmType_SuppressedState_TransitionTime:
		return "LimitAlarmType_SuppressedState_TransitionTime";
	case ObjectId::LimitAlarmType_SuppressedState_EffectiveTransitionTime:
		return "LimitAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::LimitAlarmType_SuppressedState_TrueState:
		return "LimitAlarmType_SuppressedState_TrueState";
	case ObjectId::LimitAlarmType_SuppressedState_FalseState:
		return "LimitAlarmType_SuppressedState_FalseState";
	case ObjectId::LimitAlarmType_ShelvingState:
		return "LimitAlarmType_ShelvingState";
	case ObjectId::LimitAlarmType_ShelvingState_CurrentState:
		return "LimitAlarmType_ShelvingState_CurrentState";
	case ObjectId::LimitAlarmType_ShelvingState_CurrentState_Id:
		return "LimitAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::LimitAlarmType_ShelvingState_CurrentState_Name:
		return "LimitAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::LimitAlarmType_ShelvingState_CurrentState_Number:
		return "LimitAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::LimitAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "LimitAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::LimitAlarmType_ShelvingState_LastTransition:
		return "LimitAlarmType_ShelvingState_LastTransition";
	case ObjectId::LimitAlarmType_ShelvingState_LastTransition_Id:
		return "LimitAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::LimitAlarmType_ShelvingState_LastTransition_Name:
		return "LimitAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::LimitAlarmType_ShelvingState_LastTransition_Number:
		return "LimitAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::LimitAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "LimitAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::LimitAlarmType_ShelvingState_UnshelveTime:
		return "LimitAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::LimitAlarmType_ShelvingState_Unshelve:
		return "LimitAlarmType_ShelvingState_Unshelve";
	case ObjectId::LimitAlarmType_ShelvingState_OneShotShelve:
		return "LimitAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::LimitAlarmType_ShelvingState_TimedShelve:
		return "LimitAlarmType_ShelvingState_TimedShelve";
	case ObjectId::LimitAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "LimitAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::LimitAlarmType_SuppressedOrShelved:
		return "LimitAlarmType_SuppressedOrShelved";
	case ObjectId::LimitAlarmType_MaxTimeShelved:
		return "LimitAlarmType_MaxTimeShelved";
	case ObjectId::ExclusiveLimitStateMachineType:
		return "ExclusiveLimitStateMachineType";
	case ObjectId::ExclusiveLimitStateMachineType_CurrentState:
		return "ExclusiveLimitStateMachineType_CurrentState";
	case ObjectId::ExclusiveLimitStateMachineType_CurrentState_Id:
		return "ExclusiveLimitStateMachineType_CurrentState_Id";
	case ObjectId::ExclusiveLimitStateMachineType_CurrentState_Name:
		return "ExclusiveLimitStateMachineType_CurrentState_Name";
	case ObjectId::ExclusiveLimitStateMachineType_CurrentState_Number:
		return "ExclusiveLimitStateMachineType_CurrentState_Number";
	case ObjectId::ExclusiveLimitStateMachineType_CurrentState_EffectiveDisplayName:
		return "ExclusiveLimitStateMachineType_CurrentState_EffectiveDisplayName";
	case ObjectId::ExclusiveLimitStateMachineType_LastTransition:
		return "ExclusiveLimitStateMachineType_LastTransition";
	case ObjectId::ExclusiveLimitStateMachineType_LastTransition_Id:
		return "ExclusiveLimitStateMachineType_LastTransition_Id";
	case ObjectId::ExclusiveLimitStateMachineType_LastTransition_Name:
		return "ExclusiveLimitStateMachineType_LastTransition_Name";
	case ObjectId::ExclusiveLimitStateMachineType_LastTransition_Number:
		return "ExclusiveLimitStateMachineType_LastTransition_Number";
	case ObjectId::ExclusiveLimitStateMachineType_LastTransition_TransitionTime:
		return "ExclusiveLimitStateMachineType_LastTransition_TransitionTime";
	case ObjectId::ExclusiveLimitStateMachineType_HighHigh:
		return "ExclusiveLimitStateMachineType_HighHigh";
	case ObjectId::ExclusiveLimitStateMachineType_HighHigh_StateNumber:
		return "ExclusiveLimitStateMachineType_HighHigh_StateNumber";
	case ObjectId::ExclusiveLimitStateMachineType_High:
		return "ExclusiveLimitStateMachineType_High";
	case ObjectId::ExclusiveLimitStateMachineType_High_StateNumber:
		return "ExclusiveLimitStateMachineType_High_StateNumber";
	case ObjectId::ExclusiveLimitStateMachineType_Low:
		return "ExclusiveLimitStateMachineType_Low";
	case ObjectId::ExclusiveLimitStateMachineType_Low_StateNumber:
		return "ExclusiveLimitStateMachineType_Low_StateNumber";
	case ObjectId::ExclusiveLimitStateMachineType_LowLow:
		return "ExclusiveLimitStateMachineType_LowLow";
	case ObjectId::ExclusiveLimitStateMachineType_LowLow_StateNumber:
		return "ExclusiveLimitStateMachineType_LowLow_StateNumber";
	case ObjectId::ExclusiveLimitStateMachineType_LowLowToLow:
		return "ExclusiveLimitStateMachineType_LowLowToLow";
	case ObjectId::ExclusiveLimitStateMachineType_LowToLowLow:
		return "ExclusiveLimitStateMachineType_LowToLowLow";
	case ObjectId::ExclusiveLimitStateMachineType_HighHighToHigh:
		return "ExclusiveLimitStateMachineType_HighHighToHigh";
	case ObjectId::ExclusiveLimitStateMachineType_HighToHighHigh:
		return "ExclusiveLimitStateMachineType_HighToHighHigh";
	case ObjectId::ExclusiveLimitAlarmType:
		return "ExclusiveLimitAlarmType";
	case ObjectId::ExclusiveLimitAlarmType_EventId:
		return "ExclusiveLimitAlarmType_EventId";
	case ObjectId::ExclusiveLimitAlarmType_EventType:
		return "ExclusiveLimitAlarmType_EventType";
	case ObjectId::ExclusiveLimitAlarmType_SourceNode:
		return "ExclusiveLimitAlarmType_SourceNode";
	case ObjectId::ExclusiveLimitAlarmType_SourceName:
		return "ExclusiveLimitAlarmType_SourceName";
	case ObjectId::ExclusiveLimitAlarmType_Time:
		return "ExclusiveLimitAlarmType_Time";
	case ObjectId::ExclusiveLimitAlarmType_ReceiveTime:
		return "ExclusiveLimitAlarmType_ReceiveTime";
	case ObjectId::ExclusiveLimitAlarmType_LocalTime:
		return "ExclusiveLimitAlarmType_LocalTime";
	case ObjectId::ExclusiveLimitAlarmType_Message:
		return "ExclusiveLimitAlarmType_Message";
	case ObjectId::ExclusiveLimitAlarmType_Severity:
		return "ExclusiveLimitAlarmType_Severity";
	case ObjectId::ExclusiveLimitAlarmType_ConditionName:
		return "ExclusiveLimitAlarmType_ConditionName";
	case ObjectId::ExclusiveLimitAlarmType_BranchId:
		return "ExclusiveLimitAlarmType_BranchId";
	case ObjectId::ExclusiveLimitAlarmType_Retain:
		return "ExclusiveLimitAlarmType_Retain";
	case ObjectId::ExclusiveLimitAlarmType_EnabledState:
		return "ExclusiveLimitAlarmType_EnabledState";
	case ObjectId::ExclusiveLimitAlarmType_EnabledState_Id:
		return "ExclusiveLimitAlarmType_EnabledState_Id";
	case ObjectId::ExclusiveLimitAlarmType_EnabledState_Name:
		return "ExclusiveLimitAlarmType_EnabledState_Name";
	case ObjectId::ExclusiveLimitAlarmType_EnabledState_Number:
		return "ExclusiveLimitAlarmType_EnabledState_Number";
	case ObjectId::ExclusiveLimitAlarmType_EnabledState_EffectiveDisplayName:
		return "ExclusiveLimitAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::ExclusiveLimitAlarmType_EnabledState_TransitionTime:
		return "ExclusiveLimitAlarmType_EnabledState_TransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_EnabledState_EffectiveTransitionTime:
		return "ExclusiveLimitAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_EnabledState_TrueState:
		return "ExclusiveLimitAlarmType_EnabledState_TrueState";
	case ObjectId::ExclusiveLimitAlarmType_EnabledState_FalseState:
		return "ExclusiveLimitAlarmType_EnabledState_FalseState";
	case ObjectId::ExclusiveLimitAlarmType_Quality:
		return "ExclusiveLimitAlarmType_Quality";
	case ObjectId::ExclusiveLimitAlarmType_Quality_SourceTimestamp:
		return "ExclusiveLimitAlarmType_Quality_SourceTimestamp";
	case ObjectId::ExclusiveLimitAlarmType_LastSeverity:
		return "ExclusiveLimitAlarmType_LastSeverity";
	case ObjectId::ExclusiveLimitAlarmType_LastSeverity_SourceTimestamp:
		return "ExclusiveLimitAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::ExclusiveLimitAlarmType_Comment:
		return "ExclusiveLimitAlarmType_Comment";
	case ObjectId::ExclusiveLimitAlarmType_Comment_SourceTimestamp:
		return "ExclusiveLimitAlarmType_Comment_SourceTimestamp";
	case ObjectId::ExclusiveLimitAlarmType_ClientUserId:
		return "ExclusiveLimitAlarmType_ClientUserId";
	case ObjectId::ExclusiveLimitAlarmType_Enable:
		return "ExclusiveLimitAlarmType_Enable";
	case ObjectId::ExclusiveLimitAlarmType_Disable:
		return "ExclusiveLimitAlarmType_Disable";
	case ObjectId::ExclusiveLimitAlarmType_AddComment:
		return "ExclusiveLimitAlarmType_AddComment";
	case ObjectId::ExclusiveLimitAlarmType_AddComment_InputArguments:
		return "ExclusiveLimitAlarmType_AddComment_InputArguments";
	case ObjectId::ExclusiveLimitAlarmType_ConditionRefresh:
		return "ExclusiveLimitAlarmType_ConditionRefresh";
	case ObjectId::ExclusiveLimitAlarmType_ConditionRefresh_InputArguments:
		return "ExclusiveLimitAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::ExclusiveLimitAlarmType_AckedState:
		return "ExclusiveLimitAlarmType_AckedState";
	case ObjectId::ExclusiveLimitAlarmType_AckedState_Id:
		return "ExclusiveLimitAlarmType_AckedState_Id";
	case ObjectId::ExclusiveLimitAlarmType_AckedState_Name:
		return "ExclusiveLimitAlarmType_AckedState_Name";
	case ObjectId::ExclusiveLimitAlarmType_AckedState_Number:
		return "ExclusiveLimitAlarmType_AckedState_Number";
	case ObjectId::ExclusiveLimitAlarmType_AckedState_EffectiveDisplayName:
		return "ExclusiveLimitAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::ExclusiveLimitAlarmType_AckedState_TransitionTime:
		return "ExclusiveLimitAlarmType_AckedState_TransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_AckedState_EffectiveTransitionTime:
		return "ExclusiveLimitAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_AckedState_TrueState:
		return "ExclusiveLimitAlarmType_AckedState_TrueState";
	case ObjectId::ExclusiveLimitAlarmType_AckedState_FalseState:
		return "ExclusiveLimitAlarmType_AckedState_FalseState";
	case ObjectId::ExclusiveLimitAlarmType_ConfirmedState:
		return "ExclusiveLimitAlarmType_ConfirmedState";
	case ObjectId::ExclusiveLimitAlarmType_ConfirmedState_Id:
		return "ExclusiveLimitAlarmType_ConfirmedState_Id";
	case ObjectId::ExclusiveLimitAlarmType_ConfirmedState_Name:
		return "ExclusiveLimitAlarmType_ConfirmedState_Name";
	case ObjectId::ExclusiveLimitAlarmType_ConfirmedState_Number:
		return "ExclusiveLimitAlarmType_ConfirmedState_Number";
	case ObjectId::ExclusiveLimitAlarmType_ConfirmedState_EffectiveDisplayName:
		return "ExclusiveLimitAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::ExclusiveLimitAlarmType_ConfirmedState_TransitionTime:
		return "ExclusiveLimitAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "ExclusiveLimitAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_ConfirmedState_TrueState:
		return "ExclusiveLimitAlarmType_ConfirmedState_TrueState";
	case ObjectId::ExclusiveLimitAlarmType_ConfirmedState_FalseState:
		return "ExclusiveLimitAlarmType_ConfirmedState_FalseState";
	case ObjectId::ExclusiveLimitAlarmType_Acknowledge:
		return "ExclusiveLimitAlarmType_Acknowledge";
	case ObjectId::ExclusiveLimitAlarmType_Acknowledge_InputArguments:
		return "ExclusiveLimitAlarmType_Acknowledge_InputArguments";
	case ObjectId::ExclusiveLimitAlarmType_Confirm:
		return "ExclusiveLimitAlarmType_Confirm";
	case ObjectId::ExclusiveLimitAlarmType_Confirm_InputArguments:
		return "ExclusiveLimitAlarmType_Confirm_InputArguments";
	case ObjectId::ExclusiveLimitAlarmType_ActiveState:
		return "ExclusiveLimitAlarmType_ActiveState";
	case ObjectId::ExclusiveLimitAlarmType_ActiveState_Id:
		return "ExclusiveLimitAlarmType_ActiveState_Id";
	case ObjectId::ExclusiveLimitAlarmType_ActiveState_Name:
		return "ExclusiveLimitAlarmType_ActiveState_Name";
	case ObjectId::ExclusiveLimitAlarmType_ActiveState_Number:
		return "ExclusiveLimitAlarmType_ActiveState_Number";
	case ObjectId::ExclusiveLimitAlarmType_ActiveState_EffectiveDisplayName:
		return "ExclusiveLimitAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::ExclusiveLimitAlarmType_ActiveState_TransitionTime:
		return "ExclusiveLimitAlarmType_ActiveState_TransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_ActiveState_EffectiveTransitionTime:
		return "ExclusiveLimitAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_ActiveState_TrueState:
		return "ExclusiveLimitAlarmType_ActiveState_TrueState";
	case ObjectId::ExclusiveLimitAlarmType_ActiveState_FalseState:
		return "ExclusiveLimitAlarmType_ActiveState_FalseState";
	case ObjectId::ExclusiveLimitAlarmType_SuppressedState:
		return "ExclusiveLimitAlarmType_SuppressedState";
	case ObjectId::ExclusiveLimitAlarmType_SuppressedState_Id:
		return "ExclusiveLimitAlarmType_SuppressedState_Id";
	case ObjectId::ExclusiveLimitAlarmType_SuppressedState_Name:
		return "ExclusiveLimitAlarmType_SuppressedState_Name";
	case ObjectId::ExclusiveLimitAlarmType_SuppressedState_Number:
		return "ExclusiveLimitAlarmType_SuppressedState_Number";
	case ObjectId::ExclusiveLimitAlarmType_SuppressedState_EffectiveDisplayName:
		return "ExclusiveLimitAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::ExclusiveLimitAlarmType_SuppressedState_TransitionTime:
		return "ExclusiveLimitAlarmType_SuppressedState_TransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_SuppressedState_EffectiveTransitionTime:
		return "ExclusiveLimitAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_SuppressedState_TrueState:
		return "ExclusiveLimitAlarmType_SuppressedState_TrueState";
	case ObjectId::ExclusiveLimitAlarmType_SuppressedState_FalseState:
		return "ExclusiveLimitAlarmType_SuppressedState_FalseState";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState:
		return "ExclusiveLimitAlarmType_ShelvingState";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_CurrentState:
		return "ExclusiveLimitAlarmType_ShelvingState_CurrentState";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_CurrentState_Id:
		return "ExclusiveLimitAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_CurrentState_Name:
		return "ExclusiveLimitAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_CurrentState_Number:
		return "ExclusiveLimitAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "ExclusiveLimitAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_LastTransition:
		return "ExclusiveLimitAlarmType_ShelvingState_LastTransition";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_LastTransition_Id:
		return "ExclusiveLimitAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_LastTransition_Name:
		return "ExclusiveLimitAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_LastTransition_Number:
		return "ExclusiveLimitAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "ExclusiveLimitAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_UnshelveTime:
		return "ExclusiveLimitAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_Unshelve:
		return "ExclusiveLimitAlarmType_ShelvingState_Unshelve";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_OneShotShelve:
		return "ExclusiveLimitAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_TimedShelve:
		return "ExclusiveLimitAlarmType_ShelvingState_TimedShelve";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "ExclusiveLimitAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::ExclusiveLimitAlarmType_SuppressedOrShelved:
		return "ExclusiveLimitAlarmType_SuppressedOrShelved";
	case ObjectId::ExclusiveLimitAlarmType_MaxTimeShelved:
		return "ExclusiveLimitAlarmType_MaxTimeShelved";
	case ObjectId::ExclusiveLimitAlarmType_LimitState:
		return "ExclusiveLimitAlarmType_LimitState";
	case ObjectId::ExclusiveLimitAlarmType_LimitState_CurrentState:
		return "ExclusiveLimitAlarmType_LimitState_CurrentState";
	case ObjectId::ExclusiveLimitAlarmType_LimitState_CurrentState_Id:
		return "ExclusiveLimitAlarmType_LimitState_CurrentState_Id";
	case ObjectId::ExclusiveLimitAlarmType_LimitState_CurrentState_Name:
		return "ExclusiveLimitAlarmType_LimitState_CurrentState_Name";
	case ObjectId::ExclusiveLimitAlarmType_LimitState_CurrentState_Number:
		return "ExclusiveLimitAlarmType_LimitState_CurrentState_Number";
	case ObjectId::ExclusiveLimitAlarmType_LimitState_CurrentState_EffectiveDisplayName:
		return "ExclusiveLimitAlarmType_LimitState_CurrentState_EffectiveDisplayName";
	case ObjectId::ExclusiveLimitAlarmType_LimitState_LastTransition:
		return "ExclusiveLimitAlarmType_LimitState_LastTransition";
	case ObjectId::ExclusiveLimitAlarmType_LimitState_LastTransition_Id:
		return "ExclusiveLimitAlarmType_LimitState_LastTransition_Id";
	case ObjectId::ExclusiveLimitAlarmType_LimitState_LastTransition_Name:
		return "ExclusiveLimitAlarmType_LimitState_LastTransition_Name";
	case ObjectId::ExclusiveLimitAlarmType_LimitState_LastTransition_Number:
		return "ExclusiveLimitAlarmType_LimitState_LastTransition_Number";
	case ObjectId::ExclusiveLimitAlarmType_LimitState_LastTransition_TransitionTime:
		return "ExclusiveLimitAlarmType_LimitState_LastTransition_TransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_HighHighLimit:
		return "ExclusiveLimitAlarmType_HighHighLimit";
	case ObjectId::ExclusiveLimitAlarmType_HighLimit:
		return "ExclusiveLimitAlarmType_HighLimit";
	case ObjectId::ExclusiveLimitAlarmType_LowLimit:
		return "ExclusiveLimitAlarmType_LowLimit";
	case ObjectId::ExclusiveLimitAlarmType_LowLowLimit:
		return "ExclusiveLimitAlarmType_LowLowLimit";
	case ObjectId::ExclusiveLevelAlarmType:
		return "ExclusiveLevelAlarmType";
	case ObjectId::ExclusiveLevelAlarmType_EventId:
		return "ExclusiveLevelAlarmType_EventId";
	case ObjectId::ExclusiveLevelAlarmType_EventType:
		return "ExclusiveLevelAlarmType_EventType";
	case ObjectId::ExclusiveLevelAlarmType_SourceNode:
		return "ExclusiveLevelAlarmType_SourceNode";
	case ObjectId::ExclusiveLevelAlarmType_SourceName:
		return "ExclusiveLevelAlarmType_SourceName";
	case ObjectId::ExclusiveLevelAlarmType_Time:
		return "ExclusiveLevelAlarmType_Time";
	case ObjectId::ExclusiveLevelAlarmType_ReceiveTime:
		return "ExclusiveLevelAlarmType_ReceiveTime";
	case ObjectId::ExclusiveLevelAlarmType_LocalTime:
		return "ExclusiveLevelAlarmType_LocalTime";
	case ObjectId::ExclusiveLevelAlarmType_Message:
		return "ExclusiveLevelAlarmType_Message";
	case ObjectId::ExclusiveLevelAlarmType_Severity:
		return "ExclusiveLevelAlarmType_Severity";
	case ObjectId::ExclusiveLevelAlarmType_ConditionName:
		return "ExclusiveLevelAlarmType_ConditionName";
	case ObjectId::ExclusiveLevelAlarmType_BranchId:
		return "ExclusiveLevelAlarmType_BranchId";
	case ObjectId::ExclusiveLevelAlarmType_Retain:
		return "ExclusiveLevelAlarmType_Retain";
	case ObjectId::ExclusiveLevelAlarmType_EnabledState:
		return "ExclusiveLevelAlarmType_EnabledState";
	case ObjectId::ExclusiveLevelAlarmType_EnabledState_Id:
		return "ExclusiveLevelAlarmType_EnabledState_Id";
	case ObjectId::ExclusiveLevelAlarmType_EnabledState_Name:
		return "ExclusiveLevelAlarmType_EnabledState_Name";
	case ObjectId::ExclusiveLevelAlarmType_EnabledState_Number:
		return "ExclusiveLevelAlarmType_EnabledState_Number";
	case ObjectId::ExclusiveLevelAlarmType_EnabledState_EffectiveDisplayName:
		return "ExclusiveLevelAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::ExclusiveLevelAlarmType_EnabledState_TransitionTime:
		return "ExclusiveLevelAlarmType_EnabledState_TransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_EnabledState_EffectiveTransitionTime:
		return "ExclusiveLevelAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_EnabledState_TrueState:
		return "ExclusiveLevelAlarmType_EnabledState_TrueState";
	case ObjectId::ExclusiveLevelAlarmType_EnabledState_FalseState:
		return "ExclusiveLevelAlarmType_EnabledState_FalseState";
	case ObjectId::ExclusiveLevelAlarmType_Quality:
		return "ExclusiveLevelAlarmType_Quality";
	case ObjectId::ExclusiveLevelAlarmType_Quality_SourceTimestamp:
		return "ExclusiveLevelAlarmType_Quality_SourceTimestamp";
	case ObjectId::ExclusiveLevelAlarmType_LastSeverity:
		return "ExclusiveLevelAlarmType_LastSeverity";
	case ObjectId::ExclusiveLevelAlarmType_LastSeverity_SourceTimestamp:
		return "ExclusiveLevelAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::ExclusiveLevelAlarmType_Comment:
		return "ExclusiveLevelAlarmType_Comment";
	case ObjectId::ExclusiveLevelAlarmType_Comment_SourceTimestamp:
		return "ExclusiveLevelAlarmType_Comment_SourceTimestamp";
	case ObjectId::ExclusiveLevelAlarmType_ClientUserId:
		return "ExclusiveLevelAlarmType_ClientUserId";
	case ObjectId::ExclusiveLevelAlarmType_Enable:
		return "ExclusiveLevelAlarmType_Enable";
	case ObjectId::ExclusiveLevelAlarmType_Disable:
		return "ExclusiveLevelAlarmType_Disable";
	case ObjectId::ExclusiveLevelAlarmType_AddComment:
		return "ExclusiveLevelAlarmType_AddComment";
	case ObjectId::ExclusiveLevelAlarmType_AddComment_InputArguments:
		return "ExclusiveLevelAlarmType_AddComment_InputArguments";
	case ObjectId::ExclusiveLevelAlarmType_ConditionRefresh:
		return "ExclusiveLevelAlarmType_ConditionRefresh";
	case ObjectId::ExclusiveLevelAlarmType_ConditionRefresh_InputArguments:
		return "ExclusiveLevelAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::ExclusiveLevelAlarmType_AckedState:
		return "ExclusiveLevelAlarmType_AckedState";
	case ObjectId::ExclusiveLevelAlarmType_AckedState_Id:
		return "ExclusiveLevelAlarmType_AckedState_Id";
	case ObjectId::ExclusiveLevelAlarmType_AckedState_Name:
		return "ExclusiveLevelAlarmType_AckedState_Name";
	case ObjectId::ExclusiveLevelAlarmType_AckedState_Number:
		return "ExclusiveLevelAlarmType_AckedState_Number";
	case ObjectId::ExclusiveLevelAlarmType_AckedState_EffectiveDisplayName:
		return "ExclusiveLevelAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::ExclusiveLevelAlarmType_AckedState_TransitionTime:
		return "ExclusiveLevelAlarmType_AckedState_TransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_AckedState_EffectiveTransitionTime:
		return "ExclusiveLevelAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_AckedState_TrueState:
		return "ExclusiveLevelAlarmType_AckedState_TrueState";
	case ObjectId::ExclusiveLevelAlarmType_AckedState_FalseState:
		return "ExclusiveLevelAlarmType_AckedState_FalseState";
	case ObjectId::ExclusiveLevelAlarmType_ConfirmedState:
		return "ExclusiveLevelAlarmType_ConfirmedState";
	case ObjectId::ExclusiveLevelAlarmType_ConfirmedState_Id:
		return "ExclusiveLevelAlarmType_ConfirmedState_Id";
	case ObjectId::ExclusiveLevelAlarmType_ConfirmedState_Name:
		return "ExclusiveLevelAlarmType_ConfirmedState_Name";
	case ObjectId::ExclusiveLevelAlarmType_ConfirmedState_Number:
		return "ExclusiveLevelAlarmType_ConfirmedState_Number";
	case ObjectId::ExclusiveLevelAlarmType_ConfirmedState_EffectiveDisplayName:
		return "ExclusiveLevelAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::ExclusiveLevelAlarmType_ConfirmedState_TransitionTime:
		return "ExclusiveLevelAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "ExclusiveLevelAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_ConfirmedState_TrueState:
		return "ExclusiveLevelAlarmType_ConfirmedState_TrueState";
	case ObjectId::ExclusiveLevelAlarmType_ConfirmedState_FalseState:
		return "ExclusiveLevelAlarmType_ConfirmedState_FalseState";
	case ObjectId::ExclusiveLevelAlarmType_Acknowledge:
		return "ExclusiveLevelAlarmType_Acknowledge";
	case ObjectId::ExclusiveLevelAlarmType_Acknowledge_InputArguments:
		return "ExclusiveLevelAlarmType_Acknowledge_InputArguments";
	case ObjectId::ExclusiveLevelAlarmType_Confirm:
		return "ExclusiveLevelAlarmType_Confirm";
	case ObjectId::ExclusiveLevelAlarmType_Confirm_InputArguments:
		return "ExclusiveLevelAlarmType_Confirm_InputArguments";
	case ObjectId::ExclusiveLevelAlarmType_ActiveState:
		return "ExclusiveLevelAlarmType_ActiveState";
	case ObjectId::ExclusiveLevelAlarmType_ActiveState_Id:
		return "ExclusiveLevelAlarmType_ActiveState_Id";
	case ObjectId::ExclusiveLevelAlarmType_ActiveState_Name:
		return "ExclusiveLevelAlarmType_ActiveState_Name";
	case ObjectId::ExclusiveLevelAlarmType_ActiveState_Number:
		return "ExclusiveLevelAlarmType_ActiveState_Number";
	case ObjectId::ExclusiveLevelAlarmType_ActiveState_EffectiveDisplayName:
		return "ExclusiveLevelAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::ExclusiveLevelAlarmType_ActiveState_TransitionTime:
		return "ExclusiveLevelAlarmType_ActiveState_TransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_ActiveState_EffectiveTransitionTime:
		return "ExclusiveLevelAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_ActiveState_TrueState:
		return "ExclusiveLevelAlarmType_ActiveState_TrueState";
	case ObjectId::ExclusiveLevelAlarmType_ActiveState_FalseState:
		return "ExclusiveLevelAlarmType_ActiveState_FalseState";
	case ObjectId::ExclusiveLevelAlarmType_SuppressedState:
		return "ExclusiveLevelAlarmType_SuppressedState";
	case ObjectId::ExclusiveLevelAlarmType_SuppressedState_Id:
		return "ExclusiveLevelAlarmType_SuppressedState_Id";
	case ObjectId::ExclusiveLevelAlarmType_SuppressedState_Name:
		return "ExclusiveLevelAlarmType_SuppressedState_Name";
	case ObjectId::ExclusiveLevelAlarmType_SuppressedState_Number:
		return "ExclusiveLevelAlarmType_SuppressedState_Number";
	case ObjectId::ExclusiveLevelAlarmType_SuppressedState_EffectiveDisplayName:
		return "ExclusiveLevelAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::ExclusiveLevelAlarmType_SuppressedState_TransitionTime:
		return "ExclusiveLevelAlarmType_SuppressedState_TransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_SuppressedState_EffectiveTransitionTime:
		return "ExclusiveLevelAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_SuppressedState_TrueState:
		return "ExclusiveLevelAlarmType_SuppressedState_TrueState";
	case ObjectId::ExclusiveLevelAlarmType_SuppressedState_FalseState:
		return "ExclusiveLevelAlarmType_SuppressedState_FalseState";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState:
		return "ExclusiveLevelAlarmType_ShelvingState";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_CurrentState:
		return "ExclusiveLevelAlarmType_ShelvingState_CurrentState";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_CurrentState_Id:
		return "ExclusiveLevelAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_CurrentState_Name:
		return "ExclusiveLevelAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_CurrentState_Number:
		return "ExclusiveLevelAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "ExclusiveLevelAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_LastTransition:
		return "ExclusiveLevelAlarmType_ShelvingState_LastTransition";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_LastTransition_Id:
		return "ExclusiveLevelAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_LastTransition_Name:
		return "ExclusiveLevelAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_LastTransition_Number:
		return "ExclusiveLevelAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "ExclusiveLevelAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_UnshelveTime:
		return "ExclusiveLevelAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_Unshelve:
		return "ExclusiveLevelAlarmType_ShelvingState_Unshelve";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_OneShotShelve:
		return "ExclusiveLevelAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_TimedShelve:
		return "ExclusiveLevelAlarmType_ShelvingState_TimedShelve";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "ExclusiveLevelAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::ExclusiveLevelAlarmType_SuppressedOrShelved:
		return "ExclusiveLevelAlarmType_SuppressedOrShelved";
	case ObjectId::ExclusiveLevelAlarmType_MaxTimeShelved:
		return "ExclusiveLevelAlarmType_MaxTimeShelved";
	case ObjectId::ExclusiveLevelAlarmType_LimitState:
		return "ExclusiveLevelAlarmType_LimitState";
	case ObjectId::ExclusiveLevelAlarmType_LimitState_CurrentState:
		return "ExclusiveLevelAlarmType_LimitState_CurrentState";
	case ObjectId::ExclusiveLevelAlarmType_LimitState_CurrentState_Id:
		return "ExclusiveLevelAlarmType_LimitState_CurrentState_Id";
	case ObjectId::ExclusiveLevelAlarmType_LimitState_CurrentState_Name:
		return "ExclusiveLevelAlarmType_LimitState_CurrentState_Name";
	case ObjectId::ExclusiveLevelAlarmType_LimitState_CurrentState_Number:
		return "ExclusiveLevelAlarmType_LimitState_CurrentState_Number";
	case ObjectId::ExclusiveLevelAlarmType_LimitState_CurrentState_EffectiveDisplayName:
		return "ExclusiveLevelAlarmType_LimitState_CurrentState_EffectiveDisplayName";
	case ObjectId::ExclusiveLevelAlarmType_LimitState_LastTransition:
		return "ExclusiveLevelAlarmType_LimitState_LastTransition";
	case ObjectId::ExclusiveLevelAlarmType_LimitState_LastTransition_Id:
		return "ExclusiveLevelAlarmType_LimitState_LastTransition_Id";
	case ObjectId::ExclusiveLevelAlarmType_LimitState_LastTransition_Name:
		return "ExclusiveLevelAlarmType_LimitState_LastTransition_Name";
	case ObjectId::ExclusiveLevelAlarmType_LimitState_LastTransition_Number:
		return "ExclusiveLevelAlarmType_LimitState_LastTransition_Number";
	case ObjectId::ExclusiveLevelAlarmType_LimitState_LastTransition_TransitionTime:
		return "ExclusiveLevelAlarmType_LimitState_LastTransition_TransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_HighHighLimit:
		return "ExclusiveLevelAlarmType_HighHighLimit";
	case ObjectId::ExclusiveLevelAlarmType_HighLimit:
		return "ExclusiveLevelAlarmType_HighLimit";
	case ObjectId::ExclusiveLevelAlarmType_LowLimit:
		return "ExclusiveLevelAlarmType_LowLimit";
	case ObjectId::ExclusiveLevelAlarmType_LowLowLimit:
		return "ExclusiveLevelAlarmType_LowLowLimit";
	case ObjectId::ExclusiveRateOfChangeAlarmType:
		return "ExclusiveRateOfChangeAlarmType";
	case ObjectId::ExclusiveRateOfChangeAlarmType_EventId:
		return "ExclusiveRateOfChangeAlarmType_EventId";
	case ObjectId::ExclusiveRateOfChangeAlarmType_EventType:
		return "ExclusiveRateOfChangeAlarmType_EventType";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SourceNode:
		return "ExclusiveRateOfChangeAlarmType_SourceNode";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SourceName:
		return "ExclusiveRateOfChangeAlarmType_SourceName";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Time:
		return "ExclusiveRateOfChangeAlarmType_Time";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ReceiveTime:
		return "ExclusiveRateOfChangeAlarmType_ReceiveTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LocalTime:
		return "ExclusiveRateOfChangeAlarmType_LocalTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Message:
		return "ExclusiveRateOfChangeAlarmType_Message";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Severity:
		return "ExclusiveRateOfChangeAlarmType_Severity";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConditionName:
		return "ExclusiveRateOfChangeAlarmType_ConditionName";
	case ObjectId::ExclusiveRateOfChangeAlarmType_BranchId:
		return "ExclusiveRateOfChangeAlarmType_BranchId";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Retain:
		return "ExclusiveRateOfChangeAlarmType_Retain";
	case ObjectId::ExclusiveRateOfChangeAlarmType_EnabledState:
		return "ExclusiveRateOfChangeAlarmType_EnabledState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_EnabledState_Id:
		return "ExclusiveRateOfChangeAlarmType_EnabledState_Id";
	case ObjectId::ExclusiveRateOfChangeAlarmType_EnabledState_Name:
		return "ExclusiveRateOfChangeAlarmType_EnabledState_Name";
	case ObjectId::ExclusiveRateOfChangeAlarmType_EnabledState_Number:
		return "ExclusiveRateOfChangeAlarmType_EnabledState_Number";
	case ObjectId::ExclusiveRateOfChangeAlarmType_EnabledState_EffectiveDisplayName:
		return "ExclusiveRateOfChangeAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::ExclusiveRateOfChangeAlarmType_EnabledState_TransitionTime:
		return "ExclusiveRateOfChangeAlarmType_EnabledState_TransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_EnabledState_EffectiveTransitionTime:
		return "ExclusiveRateOfChangeAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_EnabledState_TrueState:
		return "ExclusiveRateOfChangeAlarmType_EnabledState_TrueState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_EnabledState_FalseState:
		return "ExclusiveRateOfChangeAlarmType_EnabledState_FalseState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Quality:
		return "ExclusiveRateOfChangeAlarmType_Quality";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Quality_SourceTimestamp:
		return "ExclusiveRateOfChangeAlarmType_Quality_SourceTimestamp";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LastSeverity:
		return "ExclusiveRateOfChangeAlarmType_LastSeverity";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LastSeverity_SourceTimestamp:
		return "ExclusiveRateOfChangeAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Comment:
		return "ExclusiveRateOfChangeAlarmType_Comment";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Comment_SourceTimestamp:
		return "ExclusiveRateOfChangeAlarmType_Comment_SourceTimestamp";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ClientUserId:
		return "ExclusiveRateOfChangeAlarmType_ClientUserId";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Enable:
		return "ExclusiveRateOfChangeAlarmType_Enable";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Disable:
		return "ExclusiveRateOfChangeAlarmType_Disable";
	case ObjectId::ExclusiveRateOfChangeAlarmType_AddComment:
		return "ExclusiveRateOfChangeAlarmType_AddComment";
	case ObjectId::ExclusiveRateOfChangeAlarmType_AddComment_InputArguments:
		return "ExclusiveRateOfChangeAlarmType_AddComment_InputArguments";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConditionRefresh:
		return "ExclusiveRateOfChangeAlarmType_ConditionRefresh";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConditionRefresh_InputArguments:
		return "ExclusiveRateOfChangeAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::ExclusiveRateOfChangeAlarmType_AckedState:
		return "ExclusiveRateOfChangeAlarmType_AckedState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_AckedState_Id:
		return "ExclusiveRateOfChangeAlarmType_AckedState_Id";
	case ObjectId::ExclusiveRateOfChangeAlarmType_AckedState_Name:
		return "ExclusiveRateOfChangeAlarmType_AckedState_Name";
	case ObjectId::ExclusiveRateOfChangeAlarmType_AckedState_Number:
		return "ExclusiveRateOfChangeAlarmType_AckedState_Number";
	case ObjectId::ExclusiveRateOfChangeAlarmType_AckedState_EffectiveDisplayName:
		return "ExclusiveRateOfChangeAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::ExclusiveRateOfChangeAlarmType_AckedState_TransitionTime:
		return "ExclusiveRateOfChangeAlarmType_AckedState_TransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_AckedState_EffectiveTransitionTime:
		return "ExclusiveRateOfChangeAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_AckedState_TrueState:
		return "ExclusiveRateOfChangeAlarmType_AckedState_TrueState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_AckedState_FalseState:
		return "ExclusiveRateOfChangeAlarmType_AckedState_FalseState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConfirmedState:
		return "ExclusiveRateOfChangeAlarmType_ConfirmedState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConfirmedState_Id:
		return "ExclusiveRateOfChangeAlarmType_ConfirmedState_Id";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConfirmedState_Name:
		return "ExclusiveRateOfChangeAlarmType_ConfirmedState_Name";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConfirmedState_Number:
		return "ExclusiveRateOfChangeAlarmType_ConfirmedState_Number";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveDisplayName:
		return "ExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConfirmedState_TransitionTime:
		return "ExclusiveRateOfChangeAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "ExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConfirmedState_TrueState:
		return "ExclusiveRateOfChangeAlarmType_ConfirmedState_TrueState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConfirmedState_FalseState:
		return "ExclusiveRateOfChangeAlarmType_ConfirmedState_FalseState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Acknowledge:
		return "ExclusiveRateOfChangeAlarmType_Acknowledge";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Acknowledge_InputArguments:
		return "ExclusiveRateOfChangeAlarmType_Acknowledge_InputArguments";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Confirm:
		return "ExclusiveRateOfChangeAlarmType_Confirm";
	case ObjectId::ExclusiveRateOfChangeAlarmType_Confirm_InputArguments:
		return "ExclusiveRateOfChangeAlarmType_Confirm_InputArguments";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ActiveState:
		return "ExclusiveRateOfChangeAlarmType_ActiveState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ActiveState_Id:
		return "ExclusiveRateOfChangeAlarmType_ActiveState_Id";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ActiveState_Name:
		return "ExclusiveRateOfChangeAlarmType_ActiveState_Name";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ActiveState_Number:
		return "ExclusiveRateOfChangeAlarmType_ActiveState_Number";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ActiveState_EffectiveDisplayName:
		return "ExclusiveRateOfChangeAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ActiveState_TransitionTime:
		return "ExclusiveRateOfChangeAlarmType_ActiveState_TransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ActiveState_EffectiveTransitionTime:
		return "ExclusiveRateOfChangeAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ActiveState_TrueState:
		return "ExclusiveRateOfChangeAlarmType_ActiveState_TrueState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ActiveState_FalseState:
		return "ExclusiveRateOfChangeAlarmType_ActiveState_FalseState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SuppressedState:
		return "ExclusiveRateOfChangeAlarmType_SuppressedState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SuppressedState_Id:
		return "ExclusiveRateOfChangeAlarmType_SuppressedState_Id";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SuppressedState_Name:
		return "ExclusiveRateOfChangeAlarmType_SuppressedState_Name";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SuppressedState_Number:
		return "ExclusiveRateOfChangeAlarmType_SuppressedState_Number";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveDisplayName:
		return "ExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SuppressedState_TransitionTime:
		return "ExclusiveRateOfChangeAlarmType_SuppressedState_TransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveTransitionTime:
		return "ExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SuppressedState_TrueState:
		return "ExclusiveRateOfChangeAlarmType_SuppressedState_TrueState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SuppressedState_FalseState:
		return "ExclusiveRateOfChangeAlarmType_SuppressedState_FalseState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Id:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Name:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Number:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Id:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Name:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Number:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_UnshelveTime:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_Unshelve:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_Unshelve";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_OneShotShelve:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::ExclusiveRateOfChangeAlarmType_SuppressedOrShelved:
		return "ExclusiveRateOfChangeAlarmType_SuppressedOrShelved";
	case ObjectId::ExclusiveRateOfChangeAlarmType_MaxTimeShelved:
		return "ExclusiveRateOfChangeAlarmType_MaxTimeShelved";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState:
		return "ExclusiveRateOfChangeAlarmType_LimitState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState_CurrentState:
		return "ExclusiveRateOfChangeAlarmType_LimitState_CurrentState";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_Id:
		return "ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_Id";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_Name:
		return "ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_Name";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_Number:
		return "ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_Number";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_EffectiveDisplayName:
		return "ExclusiveRateOfChangeAlarmType_LimitState_CurrentState_EffectiveDisplayName";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState_LastTransition:
		return "ExclusiveRateOfChangeAlarmType_LimitState_LastTransition";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_Id:
		return "ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_Id";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_Name:
		return "ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_Name";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_Number:
		return "ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_Number";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_TransitionTime:
		return "ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_TransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_HighHighLimit:
		return "ExclusiveRateOfChangeAlarmType_HighHighLimit";
	case ObjectId::ExclusiveRateOfChangeAlarmType_HighLimit:
		return "ExclusiveRateOfChangeAlarmType_HighLimit";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LowLimit:
		return "ExclusiveRateOfChangeAlarmType_LowLimit";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LowLowLimit:
		return "ExclusiveRateOfChangeAlarmType_LowLowLimit";
	case ObjectId::ExclusiveDeviationAlarmType:
		return "ExclusiveDeviationAlarmType";
	case ObjectId::ExclusiveDeviationAlarmType_EventId:
		return "ExclusiveDeviationAlarmType_EventId";
	case ObjectId::ExclusiveDeviationAlarmType_EventType:
		return "ExclusiveDeviationAlarmType_EventType";
	case ObjectId::ExclusiveDeviationAlarmType_SourceNode:
		return "ExclusiveDeviationAlarmType_SourceNode";
	case ObjectId::ExclusiveDeviationAlarmType_SourceName:
		return "ExclusiveDeviationAlarmType_SourceName";
	case ObjectId::ExclusiveDeviationAlarmType_Time:
		return "ExclusiveDeviationAlarmType_Time";
	case ObjectId::ExclusiveDeviationAlarmType_ReceiveTime:
		return "ExclusiveDeviationAlarmType_ReceiveTime";
	case ObjectId::ExclusiveDeviationAlarmType_LocalTime:
		return "ExclusiveDeviationAlarmType_LocalTime";
	case ObjectId::ExclusiveDeviationAlarmType_Message:
		return "ExclusiveDeviationAlarmType_Message";
	case ObjectId::ExclusiveDeviationAlarmType_Severity:
		return "ExclusiveDeviationAlarmType_Severity";
	case ObjectId::ExclusiveDeviationAlarmType_ConditionName:
		return "ExclusiveDeviationAlarmType_ConditionName";
	case ObjectId::ExclusiveDeviationAlarmType_BranchId:
		return "ExclusiveDeviationAlarmType_BranchId";
	case ObjectId::ExclusiveDeviationAlarmType_Retain:
		return "ExclusiveDeviationAlarmType_Retain";
	case ObjectId::ExclusiveDeviationAlarmType_EnabledState:
		return "ExclusiveDeviationAlarmType_EnabledState";
	case ObjectId::ExclusiveDeviationAlarmType_EnabledState_Id:
		return "ExclusiveDeviationAlarmType_EnabledState_Id";
	case ObjectId::ExclusiveDeviationAlarmType_EnabledState_Name:
		return "ExclusiveDeviationAlarmType_EnabledState_Name";
	case ObjectId::ExclusiveDeviationAlarmType_EnabledState_Number:
		return "ExclusiveDeviationAlarmType_EnabledState_Number";
	case ObjectId::ExclusiveDeviationAlarmType_EnabledState_EffectiveDisplayName:
		return "ExclusiveDeviationAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::ExclusiveDeviationAlarmType_EnabledState_TransitionTime:
		return "ExclusiveDeviationAlarmType_EnabledState_TransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_EnabledState_EffectiveTransitionTime:
		return "ExclusiveDeviationAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_EnabledState_TrueState:
		return "ExclusiveDeviationAlarmType_EnabledState_TrueState";
	case ObjectId::ExclusiveDeviationAlarmType_EnabledState_FalseState:
		return "ExclusiveDeviationAlarmType_EnabledState_FalseState";
	case ObjectId::ExclusiveDeviationAlarmType_Quality:
		return "ExclusiveDeviationAlarmType_Quality";
	case ObjectId::ExclusiveDeviationAlarmType_Quality_SourceTimestamp:
		return "ExclusiveDeviationAlarmType_Quality_SourceTimestamp";
	case ObjectId::ExclusiveDeviationAlarmType_LastSeverity:
		return "ExclusiveDeviationAlarmType_LastSeverity";
	case ObjectId::ExclusiveDeviationAlarmType_LastSeverity_SourceTimestamp:
		return "ExclusiveDeviationAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::ExclusiveDeviationAlarmType_Comment:
		return "ExclusiveDeviationAlarmType_Comment";
	case ObjectId::ExclusiveDeviationAlarmType_Comment_SourceTimestamp:
		return "ExclusiveDeviationAlarmType_Comment_SourceTimestamp";
	case ObjectId::ExclusiveDeviationAlarmType_ClientUserId:
		return "ExclusiveDeviationAlarmType_ClientUserId";
	case ObjectId::ExclusiveDeviationAlarmType_Enable:
		return "ExclusiveDeviationAlarmType_Enable";
	case ObjectId::ExclusiveDeviationAlarmType_Disable:
		return "ExclusiveDeviationAlarmType_Disable";
	case ObjectId::ExclusiveDeviationAlarmType_AddComment:
		return "ExclusiveDeviationAlarmType_AddComment";
	case ObjectId::ExclusiveDeviationAlarmType_AddComment_InputArguments:
		return "ExclusiveDeviationAlarmType_AddComment_InputArguments";
	case ObjectId::ExclusiveDeviationAlarmType_ConditionRefresh:
		return "ExclusiveDeviationAlarmType_ConditionRefresh";
	case ObjectId::ExclusiveDeviationAlarmType_ConditionRefresh_InputArguments:
		return "ExclusiveDeviationAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::ExclusiveDeviationAlarmType_AckedState:
		return "ExclusiveDeviationAlarmType_AckedState";
	case ObjectId::ExclusiveDeviationAlarmType_AckedState_Id:
		return "ExclusiveDeviationAlarmType_AckedState_Id";
	case ObjectId::ExclusiveDeviationAlarmType_AckedState_Name:
		return "ExclusiveDeviationAlarmType_AckedState_Name";
	case ObjectId::ExclusiveDeviationAlarmType_AckedState_Number:
		return "ExclusiveDeviationAlarmType_AckedState_Number";
	case ObjectId::ExclusiveDeviationAlarmType_AckedState_EffectiveDisplayName:
		return "ExclusiveDeviationAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::ExclusiveDeviationAlarmType_AckedState_TransitionTime:
		return "ExclusiveDeviationAlarmType_AckedState_TransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_AckedState_EffectiveTransitionTime:
		return "ExclusiveDeviationAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_AckedState_TrueState:
		return "ExclusiveDeviationAlarmType_AckedState_TrueState";
	case ObjectId::ExclusiveDeviationAlarmType_AckedState_FalseState:
		return "ExclusiveDeviationAlarmType_AckedState_FalseState";
	case ObjectId::ExclusiveDeviationAlarmType_ConfirmedState:
		return "ExclusiveDeviationAlarmType_ConfirmedState";
	case ObjectId::ExclusiveDeviationAlarmType_ConfirmedState_Id:
		return "ExclusiveDeviationAlarmType_ConfirmedState_Id";
	case ObjectId::ExclusiveDeviationAlarmType_ConfirmedState_Name:
		return "ExclusiveDeviationAlarmType_ConfirmedState_Name";
	case ObjectId::ExclusiveDeviationAlarmType_ConfirmedState_Number:
		return "ExclusiveDeviationAlarmType_ConfirmedState_Number";
	case ObjectId::ExclusiveDeviationAlarmType_ConfirmedState_EffectiveDisplayName:
		return "ExclusiveDeviationAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::ExclusiveDeviationAlarmType_ConfirmedState_TransitionTime:
		return "ExclusiveDeviationAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "ExclusiveDeviationAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_ConfirmedState_TrueState:
		return "ExclusiveDeviationAlarmType_ConfirmedState_TrueState";
	case ObjectId::ExclusiveDeviationAlarmType_ConfirmedState_FalseState:
		return "ExclusiveDeviationAlarmType_ConfirmedState_FalseState";
	case ObjectId::ExclusiveDeviationAlarmType_Acknowledge:
		return "ExclusiveDeviationAlarmType_Acknowledge";
	case ObjectId::ExclusiveDeviationAlarmType_Acknowledge_InputArguments:
		return "ExclusiveDeviationAlarmType_Acknowledge_InputArguments";
	case ObjectId::ExclusiveDeviationAlarmType_Confirm:
		return "ExclusiveDeviationAlarmType_Confirm";
	case ObjectId::ExclusiveDeviationAlarmType_Confirm_InputArguments:
		return "ExclusiveDeviationAlarmType_Confirm_InputArguments";
	case ObjectId::ExclusiveDeviationAlarmType_ActiveState:
		return "ExclusiveDeviationAlarmType_ActiveState";
	case ObjectId::ExclusiveDeviationAlarmType_ActiveState_Id:
		return "ExclusiveDeviationAlarmType_ActiveState_Id";
	case ObjectId::ExclusiveDeviationAlarmType_ActiveState_Name:
		return "ExclusiveDeviationAlarmType_ActiveState_Name";
	case ObjectId::ExclusiveDeviationAlarmType_ActiveState_Number:
		return "ExclusiveDeviationAlarmType_ActiveState_Number";
	case ObjectId::ExclusiveDeviationAlarmType_ActiveState_EffectiveDisplayName:
		return "ExclusiveDeviationAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::ExclusiveDeviationAlarmType_ActiveState_TransitionTime:
		return "ExclusiveDeviationAlarmType_ActiveState_TransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_ActiveState_EffectiveTransitionTime:
		return "ExclusiveDeviationAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_ActiveState_TrueState:
		return "ExclusiveDeviationAlarmType_ActiveState_TrueState";
	case ObjectId::ExclusiveDeviationAlarmType_ActiveState_FalseState:
		return "ExclusiveDeviationAlarmType_ActiveState_FalseState";
	case ObjectId::ExclusiveDeviationAlarmType_SuppressedState:
		return "ExclusiveDeviationAlarmType_SuppressedState";
	case ObjectId::ExclusiveDeviationAlarmType_SuppressedState_Id:
		return "ExclusiveDeviationAlarmType_SuppressedState_Id";
	case ObjectId::ExclusiveDeviationAlarmType_SuppressedState_Name:
		return "ExclusiveDeviationAlarmType_SuppressedState_Name";
	case ObjectId::ExclusiveDeviationAlarmType_SuppressedState_Number:
		return "ExclusiveDeviationAlarmType_SuppressedState_Number";
	case ObjectId::ExclusiveDeviationAlarmType_SuppressedState_EffectiveDisplayName:
		return "ExclusiveDeviationAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::ExclusiveDeviationAlarmType_SuppressedState_TransitionTime:
		return "ExclusiveDeviationAlarmType_SuppressedState_TransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_SuppressedState_EffectiveTransitionTime:
		return "ExclusiveDeviationAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_SuppressedState_TrueState:
		return "ExclusiveDeviationAlarmType_SuppressedState_TrueState";
	case ObjectId::ExclusiveDeviationAlarmType_SuppressedState_FalseState:
		return "ExclusiveDeviationAlarmType_SuppressedState_FalseState";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState:
		return "ExclusiveDeviationAlarmType_ShelvingState";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_CurrentState:
		return "ExclusiveDeviationAlarmType_ShelvingState_CurrentState";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_CurrentState_Id:
		return "ExclusiveDeviationAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_CurrentState_Name:
		return "ExclusiveDeviationAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_CurrentState_Number:
		return "ExclusiveDeviationAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "ExclusiveDeviationAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_LastTransition:
		return "ExclusiveDeviationAlarmType_ShelvingState_LastTransition";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_LastTransition_Id:
		return "ExclusiveDeviationAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_LastTransition_Name:
		return "ExclusiveDeviationAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_LastTransition_Number:
		return "ExclusiveDeviationAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "ExclusiveDeviationAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_UnshelveTime:
		return "ExclusiveDeviationAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_Unshelve:
		return "ExclusiveDeviationAlarmType_ShelvingState_Unshelve";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_OneShotShelve:
		return "ExclusiveDeviationAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_TimedShelve:
		return "ExclusiveDeviationAlarmType_ShelvingState_TimedShelve";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "ExclusiveDeviationAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::ExclusiveDeviationAlarmType_SuppressedOrShelved:
		return "ExclusiveDeviationAlarmType_SuppressedOrShelved";
	case ObjectId::ExclusiveDeviationAlarmType_MaxTimeShelved:
		return "ExclusiveDeviationAlarmType_MaxTimeShelved";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState:
		return "ExclusiveDeviationAlarmType_LimitState";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState_CurrentState:
		return "ExclusiveDeviationAlarmType_LimitState_CurrentState";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState_CurrentState_Id:
		return "ExclusiveDeviationAlarmType_LimitState_CurrentState_Id";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState_CurrentState_Name:
		return "ExclusiveDeviationAlarmType_LimitState_CurrentState_Name";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState_CurrentState_Number:
		return "ExclusiveDeviationAlarmType_LimitState_CurrentState_Number";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState_CurrentState_EffectiveDisplayName:
		return "ExclusiveDeviationAlarmType_LimitState_CurrentState_EffectiveDisplayName";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState_LastTransition:
		return "ExclusiveDeviationAlarmType_LimitState_LastTransition";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState_LastTransition_Id:
		return "ExclusiveDeviationAlarmType_LimitState_LastTransition_Id";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState_LastTransition_Name:
		return "ExclusiveDeviationAlarmType_LimitState_LastTransition_Name";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState_LastTransition_Number:
		return "ExclusiveDeviationAlarmType_LimitState_LastTransition_Number";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState_LastTransition_TransitionTime:
		return "ExclusiveDeviationAlarmType_LimitState_LastTransition_TransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_HighHighLimit:
		return "ExclusiveDeviationAlarmType_HighHighLimit";
	case ObjectId::ExclusiveDeviationAlarmType_HighLimit:
		return "ExclusiveDeviationAlarmType_HighLimit";
	case ObjectId::ExclusiveDeviationAlarmType_LowLimit:
		return "ExclusiveDeviationAlarmType_LowLimit";
	case ObjectId::ExclusiveDeviationAlarmType_LowLowLimit:
		return "ExclusiveDeviationAlarmType_LowLowLimit";
	case ObjectId::ExclusiveDeviationAlarmType_SetpointNode:
		return "ExclusiveDeviationAlarmType_SetpointNode";
	case ObjectId::NonExclusiveLimitAlarmType:
		return "NonExclusiveLimitAlarmType";
	case ObjectId::NonExclusiveLimitAlarmType_EventId:
		return "NonExclusiveLimitAlarmType_EventId";
	case ObjectId::NonExclusiveLimitAlarmType_EventType:
		return "NonExclusiveLimitAlarmType_EventType";
	case ObjectId::NonExclusiveLimitAlarmType_SourceNode:
		return "NonExclusiveLimitAlarmType_SourceNode";
	case ObjectId::NonExclusiveLimitAlarmType_SourceName:
		return "NonExclusiveLimitAlarmType_SourceName";
	case ObjectId::NonExclusiveLimitAlarmType_Time:
		return "NonExclusiveLimitAlarmType_Time";
	case ObjectId::NonExclusiveLimitAlarmType_ReceiveTime:
		return "NonExclusiveLimitAlarmType_ReceiveTime";
	case ObjectId::NonExclusiveLimitAlarmType_LocalTime:
		return "NonExclusiveLimitAlarmType_LocalTime";
	case ObjectId::NonExclusiveLimitAlarmType_Message:
		return "NonExclusiveLimitAlarmType_Message";
	case ObjectId::NonExclusiveLimitAlarmType_Severity:
		return "NonExclusiveLimitAlarmType_Severity";
	case ObjectId::NonExclusiveLimitAlarmType_ConditionName:
		return "NonExclusiveLimitAlarmType_ConditionName";
	case ObjectId::NonExclusiveLimitAlarmType_BranchId:
		return "NonExclusiveLimitAlarmType_BranchId";
	case ObjectId::NonExclusiveLimitAlarmType_Retain:
		return "NonExclusiveLimitAlarmType_Retain";
	case ObjectId::NonExclusiveLimitAlarmType_EnabledState:
		return "NonExclusiveLimitAlarmType_EnabledState";
	case ObjectId::NonExclusiveLimitAlarmType_EnabledState_Id:
		return "NonExclusiveLimitAlarmType_EnabledState_Id";
	case ObjectId::NonExclusiveLimitAlarmType_EnabledState_Name:
		return "NonExclusiveLimitAlarmType_EnabledState_Name";
	case ObjectId::NonExclusiveLimitAlarmType_EnabledState_Number:
		return "NonExclusiveLimitAlarmType_EnabledState_Number";
	case ObjectId::NonExclusiveLimitAlarmType_EnabledState_EffectiveDisplayName:
		return "NonExclusiveLimitAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLimitAlarmType_EnabledState_TransitionTime:
		return "NonExclusiveLimitAlarmType_EnabledState_TransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_EnabledState_EffectiveTransitionTime:
		return "NonExclusiveLimitAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_EnabledState_TrueState:
		return "NonExclusiveLimitAlarmType_EnabledState_TrueState";
	case ObjectId::NonExclusiveLimitAlarmType_EnabledState_FalseState:
		return "NonExclusiveLimitAlarmType_EnabledState_FalseState";
	case ObjectId::NonExclusiveLimitAlarmType_Quality:
		return "NonExclusiveLimitAlarmType_Quality";
	case ObjectId::NonExclusiveLimitAlarmType_Quality_SourceTimestamp:
		return "NonExclusiveLimitAlarmType_Quality_SourceTimestamp";
	case ObjectId::NonExclusiveLimitAlarmType_LastSeverity:
		return "NonExclusiveLimitAlarmType_LastSeverity";
	case ObjectId::NonExclusiveLimitAlarmType_LastSeverity_SourceTimestamp:
		return "NonExclusiveLimitAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::NonExclusiveLimitAlarmType_Comment:
		return "NonExclusiveLimitAlarmType_Comment";
	case ObjectId::NonExclusiveLimitAlarmType_Comment_SourceTimestamp:
		return "NonExclusiveLimitAlarmType_Comment_SourceTimestamp";
	case ObjectId::NonExclusiveLimitAlarmType_ClientUserId:
		return "NonExclusiveLimitAlarmType_ClientUserId";
	case ObjectId::NonExclusiveLimitAlarmType_Enable:
		return "NonExclusiveLimitAlarmType_Enable";
	case ObjectId::NonExclusiveLimitAlarmType_Disable:
		return "NonExclusiveLimitAlarmType_Disable";
	case ObjectId::NonExclusiveLimitAlarmType_AddComment:
		return "NonExclusiveLimitAlarmType_AddComment";
	case ObjectId::NonExclusiveLimitAlarmType_AddComment_InputArguments:
		return "NonExclusiveLimitAlarmType_AddComment_InputArguments";
	case ObjectId::NonExclusiveLimitAlarmType_ConditionRefresh:
		return "NonExclusiveLimitAlarmType_ConditionRefresh";
	case ObjectId::NonExclusiveLimitAlarmType_ConditionRefresh_InputArguments:
		return "NonExclusiveLimitAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::NonExclusiveLimitAlarmType_AckedState:
		return "NonExclusiveLimitAlarmType_AckedState";
	case ObjectId::NonExclusiveLimitAlarmType_AckedState_Id:
		return "NonExclusiveLimitAlarmType_AckedState_Id";
	case ObjectId::NonExclusiveLimitAlarmType_AckedState_Name:
		return "NonExclusiveLimitAlarmType_AckedState_Name";
	case ObjectId::NonExclusiveLimitAlarmType_AckedState_Number:
		return "NonExclusiveLimitAlarmType_AckedState_Number";
	case ObjectId::NonExclusiveLimitAlarmType_AckedState_EffectiveDisplayName:
		return "NonExclusiveLimitAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLimitAlarmType_AckedState_TransitionTime:
		return "NonExclusiveLimitAlarmType_AckedState_TransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_AckedState_EffectiveTransitionTime:
		return "NonExclusiveLimitAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_AckedState_TrueState:
		return "NonExclusiveLimitAlarmType_AckedState_TrueState";
	case ObjectId::NonExclusiveLimitAlarmType_AckedState_FalseState:
		return "NonExclusiveLimitAlarmType_AckedState_FalseState";
	case ObjectId::NonExclusiveLimitAlarmType_ConfirmedState:
		return "NonExclusiveLimitAlarmType_ConfirmedState";
	case ObjectId::NonExclusiveLimitAlarmType_ConfirmedState_Id:
		return "NonExclusiveLimitAlarmType_ConfirmedState_Id";
	case ObjectId::NonExclusiveLimitAlarmType_ConfirmedState_Name:
		return "NonExclusiveLimitAlarmType_ConfirmedState_Name";
	case ObjectId::NonExclusiveLimitAlarmType_ConfirmedState_Number:
		return "NonExclusiveLimitAlarmType_ConfirmedState_Number";
	case ObjectId::NonExclusiveLimitAlarmType_ConfirmedState_EffectiveDisplayName:
		return "NonExclusiveLimitAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLimitAlarmType_ConfirmedState_TransitionTime:
		return "NonExclusiveLimitAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "NonExclusiveLimitAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_ConfirmedState_TrueState:
		return "NonExclusiveLimitAlarmType_ConfirmedState_TrueState";
	case ObjectId::NonExclusiveLimitAlarmType_ConfirmedState_FalseState:
		return "NonExclusiveLimitAlarmType_ConfirmedState_FalseState";
	case ObjectId::NonExclusiveLimitAlarmType_Acknowledge:
		return "NonExclusiveLimitAlarmType_Acknowledge";
	case ObjectId::NonExclusiveLimitAlarmType_Acknowledge_InputArguments:
		return "NonExclusiveLimitAlarmType_Acknowledge_InputArguments";
	case ObjectId::NonExclusiveLimitAlarmType_Confirm:
		return "NonExclusiveLimitAlarmType_Confirm";
	case ObjectId::NonExclusiveLimitAlarmType_Confirm_InputArguments:
		return "NonExclusiveLimitAlarmType_Confirm_InputArguments";
	case ObjectId::NonExclusiveLimitAlarmType_ActiveState:
		return "NonExclusiveLimitAlarmType_ActiveState";
	case ObjectId::NonExclusiveLimitAlarmType_ActiveState_Id:
		return "NonExclusiveLimitAlarmType_ActiveState_Id";
	case ObjectId::NonExclusiveLimitAlarmType_ActiveState_Name:
		return "NonExclusiveLimitAlarmType_ActiveState_Name";
	case ObjectId::NonExclusiveLimitAlarmType_ActiveState_Number:
		return "NonExclusiveLimitAlarmType_ActiveState_Number";
	case ObjectId::NonExclusiveLimitAlarmType_ActiveState_EffectiveDisplayName:
		return "NonExclusiveLimitAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLimitAlarmType_ActiveState_TransitionTime:
		return "NonExclusiveLimitAlarmType_ActiveState_TransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_ActiveState_EffectiveTransitionTime:
		return "NonExclusiveLimitAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_ActiveState_TrueState:
		return "NonExclusiveLimitAlarmType_ActiveState_TrueState";
	case ObjectId::NonExclusiveLimitAlarmType_ActiveState_FalseState:
		return "NonExclusiveLimitAlarmType_ActiveState_FalseState";
	case ObjectId::NonExclusiveLimitAlarmType_SuppressedState:
		return "NonExclusiveLimitAlarmType_SuppressedState";
	case ObjectId::NonExclusiveLimitAlarmType_SuppressedState_Id:
		return "NonExclusiveLimitAlarmType_SuppressedState_Id";
	case ObjectId::NonExclusiveLimitAlarmType_SuppressedState_Name:
		return "NonExclusiveLimitAlarmType_SuppressedState_Name";
	case ObjectId::NonExclusiveLimitAlarmType_SuppressedState_Number:
		return "NonExclusiveLimitAlarmType_SuppressedState_Number";
	case ObjectId::NonExclusiveLimitAlarmType_SuppressedState_EffectiveDisplayName:
		return "NonExclusiveLimitAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLimitAlarmType_SuppressedState_TransitionTime:
		return "NonExclusiveLimitAlarmType_SuppressedState_TransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_SuppressedState_EffectiveTransitionTime:
		return "NonExclusiveLimitAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_SuppressedState_TrueState:
		return "NonExclusiveLimitAlarmType_SuppressedState_TrueState";
	case ObjectId::NonExclusiveLimitAlarmType_SuppressedState_FalseState:
		return "NonExclusiveLimitAlarmType_SuppressedState_FalseState";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState:
		return "NonExclusiveLimitAlarmType_ShelvingState";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_CurrentState:
		return "NonExclusiveLimitAlarmType_ShelvingState_CurrentState";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_CurrentState_Id:
		return "NonExclusiveLimitAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_CurrentState_Name:
		return "NonExclusiveLimitAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_CurrentState_Number:
		return "NonExclusiveLimitAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "NonExclusiveLimitAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_LastTransition:
		return "NonExclusiveLimitAlarmType_ShelvingState_LastTransition";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_LastTransition_Id:
		return "NonExclusiveLimitAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_LastTransition_Name:
		return "NonExclusiveLimitAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_LastTransition_Number:
		return "NonExclusiveLimitAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "NonExclusiveLimitAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_UnshelveTime:
		return "NonExclusiveLimitAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_Unshelve:
		return "NonExclusiveLimitAlarmType_ShelvingState_Unshelve";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_OneShotShelve:
		return "NonExclusiveLimitAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_TimedShelve:
		return "NonExclusiveLimitAlarmType_ShelvingState_TimedShelve";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "NonExclusiveLimitAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::NonExclusiveLimitAlarmType_SuppressedOrShelved:
		return "NonExclusiveLimitAlarmType_SuppressedOrShelved";
	case ObjectId::NonExclusiveLimitAlarmType_MaxTimeShelved:
		return "NonExclusiveLimitAlarmType_MaxTimeShelved";
	case ObjectId::NonExclusiveLimitAlarmType_HighHighState:
		return "NonExclusiveLimitAlarmType_HighHighState";
	case ObjectId::NonExclusiveLimitAlarmType_HighHighState_Id:
		return "NonExclusiveLimitAlarmType_HighHighState_Id";
	case ObjectId::NonExclusiveLimitAlarmType_HighHighState_Name:
		return "NonExclusiveLimitAlarmType_HighHighState_Name";
	case ObjectId::NonExclusiveLimitAlarmType_HighHighState_Number:
		return "NonExclusiveLimitAlarmType_HighHighState_Number";
	case ObjectId::NonExclusiveLimitAlarmType_HighHighState_EffectiveDisplayName:
		return "NonExclusiveLimitAlarmType_HighHighState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLimitAlarmType_HighHighState_TransitionTime:
		return "NonExclusiveLimitAlarmType_HighHighState_TransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_HighHighState_EffectiveTransitionTime:
		return "NonExclusiveLimitAlarmType_HighHighState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_HighHighState_TrueState:
		return "NonExclusiveLimitAlarmType_HighHighState_TrueState";
	case ObjectId::NonExclusiveLimitAlarmType_HighHighState_FalseState:
		return "NonExclusiveLimitAlarmType_HighHighState_FalseState";
	case ObjectId::NonExclusiveLimitAlarmType_HighState:
		return "NonExclusiveLimitAlarmType_HighState";
	case ObjectId::NonExclusiveLimitAlarmType_HighState_Id:
		return "NonExclusiveLimitAlarmType_HighState_Id";
	case ObjectId::NonExclusiveLimitAlarmType_HighState_Name:
		return "NonExclusiveLimitAlarmType_HighState_Name";
	case ObjectId::NonExclusiveLimitAlarmType_HighState_Number:
		return "NonExclusiveLimitAlarmType_HighState_Number";
	case ObjectId::NonExclusiveLimitAlarmType_HighState_EffectiveDisplayName:
		return "NonExclusiveLimitAlarmType_HighState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLimitAlarmType_HighState_TransitionTime:
		return "NonExclusiveLimitAlarmType_HighState_TransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_HighState_EffectiveTransitionTime:
		return "NonExclusiveLimitAlarmType_HighState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_HighState_TrueState:
		return "NonExclusiveLimitAlarmType_HighState_TrueState";
	case ObjectId::NonExclusiveLimitAlarmType_HighState_FalseState:
		return "NonExclusiveLimitAlarmType_HighState_FalseState";
	case ObjectId::NonExclusiveLimitAlarmType_LowState:
		return "NonExclusiveLimitAlarmType_LowState";
	case ObjectId::NonExclusiveLimitAlarmType_LowState_Id:
		return "NonExclusiveLimitAlarmType_LowState_Id";
	case ObjectId::NonExclusiveLimitAlarmType_LowState_Name:
		return "NonExclusiveLimitAlarmType_LowState_Name";
	case ObjectId::NonExclusiveLimitAlarmType_LowState_Number:
		return "NonExclusiveLimitAlarmType_LowState_Number";
	case ObjectId::NonExclusiveLimitAlarmType_LowState_EffectiveDisplayName:
		return "NonExclusiveLimitAlarmType_LowState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLimitAlarmType_LowState_TransitionTime:
		return "NonExclusiveLimitAlarmType_LowState_TransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_LowState_EffectiveTransitionTime:
		return "NonExclusiveLimitAlarmType_LowState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_LowState_TrueState:
		return "NonExclusiveLimitAlarmType_LowState_TrueState";
	case ObjectId::NonExclusiveLimitAlarmType_LowState_FalseState:
		return "NonExclusiveLimitAlarmType_LowState_FalseState";
	case ObjectId::NonExclusiveLimitAlarmType_LowLowState:
		return "NonExclusiveLimitAlarmType_LowLowState";
	case ObjectId::NonExclusiveLimitAlarmType_LowLowState_Id:
		return "NonExclusiveLimitAlarmType_LowLowState_Id";
	case ObjectId::NonExclusiveLimitAlarmType_LowLowState_Name:
		return "NonExclusiveLimitAlarmType_LowLowState_Name";
	case ObjectId::NonExclusiveLimitAlarmType_LowLowState_Number:
		return "NonExclusiveLimitAlarmType_LowLowState_Number";
	case ObjectId::NonExclusiveLimitAlarmType_LowLowState_EffectiveDisplayName:
		return "NonExclusiveLimitAlarmType_LowLowState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLimitAlarmType_LowLowState_TransitionTime:
		return "NonExclusiveLimitAlarmType_LowLowState_TransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_LowLowState_EffectiveTransitionTime:
		return "NonExclusiveLimitAlarmType_LowLowState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_LowLowState_TrueState:
		return "NonExclusiveLimitAlarmType_LowLowState_TrueState";
	case ObjectId::NonExclusiveLimitAlarmType_LowLowState_FalseState:
		return "NonExclusiveLimitAlarmType_LowLowState_FalseState";
	case ObjectId::NonExclusiveLimitAlarmType_HighHighLimit:
		return "NonExclusiveLimitAlarmType_HighHighLimit";
	case ObjectId::NonExclusiveLimitAlarmType_HighLimit:
		return "NonExclusiveLimitAlarmType_HighLimit";
	case ObjectId::NonExclusiveLimitAlarmType_LowLimit:
		return "NonExclusiveLimitAlarmType_LowLimit";
	case ObjectId::NonExclusiveLimitAlarmType_LowLowLimit:
		return "NonExclusiveLimitAlarmType_LowLowLimit";
	case ObjectId::NonExclusiveLevelAlarmType:
		return "NonExclusiveLevelAlarmType";
	case ObjectId::NonExclusiveLevelAlarmType_EventId:
		return "NonExclusiveLevelAlarmType_EventId";
	case ObjectId::NonExclusiveLevelAlarmType_EventType:
		return "NonExclusiveLevelAlarmType_EventType";
	case ObjectId::NonExclusiveLevelAlarmType_SourceNode:
		return "NonExclusiveLevelAlarmType_SourceNode";
	case ObjectId::NonExclusiveLevelAlarmType_SourceName:
		return "NonExclusiveLevelAlarmType_SourceName";
	case ObjectId::NonExclusiveLevelAlarmType_Time:
		return "NonExclusiveLevelAlarmType_Time";
	case ObjectId::NonExclusiveLevelAlarmType_ReceiveTime:
		return "NonExclusiveLevelAlarmType_ReceiveTime";
	case ObjectId::NonExclusiveLevelAlarmType_LocalTime:
		return "NonExclusiveLevelAlarmType_LocalTime";
	case ObjectId::NonExclusiveLevelAlarmType_Message:
		return "NonExclusiveLevelAlarmType_Message";
	case ObjectId::NonExclusiveLevelAlarmType_Severity:
		return "NonExclusiveLevelAlarmType_Severity";
	case ObjectId::NonExclusiveLevelAlarmType_ConditionName:
		return "NonExclusiveLevelAlarmType_ConditionName";
	case ObjectId::NonExclusiveLevelAlarmType_BranchId:
		return "NonExclusiveLevelAlarmType_BranchId";
	case ObjectId::NonExclusiveLevelAlarmType_Retain:
		return "NonExclusiveLevelAlarmType_Retain";
	case ObjectId::NonExclusiveLevelAlarmType_EnabledState:
		return "NonExclusiveLevelAlarmType_EnabledState";
	case ObjectId::NonExclusiveLevelAlarmType_EnabledState_Id:
		return "NonExclusiveLevelAlarmType_EnabledState_Id";
	case ObjectId::NonExclusiveLevelAlarmType_EnabledState_Name:
		return "NonExclusiveLevelAlarmType_EnabledState_Name";
	case ObjectId::NonExclusiveLevelAlarmType_EnabledState_Number:
		return "NonExclusiveLevelAlarmType_EnabledState_Number";
	case ObjectId::NonExclusiveLevelAlarmType_EnabledState_EffectiveDisplayName:
		return "NonExclusiveLevelAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLevelAlarmType_EnabledState_TransitionTime:
		return "NonExclusiveLevelAlarmType_EnabledState_TransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_EnabledState_EffectiveTransitionTime:
		return "NonExclusiveLevelAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_EnabledState_TrueState:
		return "NonExclusiveLevelAlarmType_EnabledState_TrueState";
	case ObjectId::NonExclusiveLevelAlarmType_EnabledState_FalseState:
		return "NonExclusiveLevelAlarmType_EnabledState_FalseState";
	case ObjectId::NonExclusiveLevelAlarmType_Quality:
		return "NonExclusiveLevelAlarmType_Quality";
	case ObjectId::NonExclusiveLevelAlarmType_Quality_SourceTimestamp:
		return "NonExclusiveLevelAlarmType_Quality_SourceTimestamp";
	case ObjectId::NonExclusiveLevelAlarmType_LastSeverity:
		return "NonExclusiveLevelAlarmType_LastSeverity";
	case ObjectId::NonExclusiveLevelAlarmType_LastSeverity_SourceTimestamp:
		return "NonExclusiveLevelAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::NonExclusiveLevelAlarmType_Comment:
		return "NonExclusiveLevelAlarmType_Comment";
	case ObjectId::NonExclusiveLevelAlarmType_Comment_SourceTimestamp:
		return "NonExclusiveLevelAlarmType_Comment_SourceTimestamp";
	case ObjectId::NonExclusiveLevelAlarmType_ClientUserId:
		return "NonExclusiveLevelAlarmType_ClientUserId";
	case ObjectId::NonExclusiveLevelAlarmType_Enable:
		return "NonExclusiveLevelAlarmType_Enable";
	case ObjectId::NonExclusiveLevelAlarmType_Disable:
		return "NonExclusiveLevelAlarmType_Disable";
	case ObjectId::NonExclusiveLevelAlarmType_AddComment:
		return "NonExclusiveLevelAlarmType_AddComment";
	case ObjectId::NonExclusiveLevelAlarmType_AddComment_InputArguments:
		return "NonExclusiveLevelAlarmType_AddComment_InputArguments";
	case ObjectId::NonExclusiveLevelAlarmType_ConditionRefresh:
		return "NonExclusiveLevelAlarmType_ConditionRefresh";
	case ObjectId::NonExclusiveLevelAlarmType_ConditionRefresh_InputArguments:
		return "NonExclusiveLevelAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::NonExclusiveLevelAlarmType_AckedState:
		return "NonExclusiveLevelAlarmType_AckedState";
	case ObjectId::NonExclusiveLevelAlarmType_AckedState_Id:
		return "NonExclusiveLevelAlarmType_AckedState_Id";
	case ObjectId::NonExclusiveLevelAlarmType_AckedState_Name:
		return "NonExclusiveLevelAlarmType_AckedState_Name";
	case ObjectId::NonExclusiveLevelAlarmType_AckedState_Number:
		return "NonExclusiveLevelAlarmType_AckedState_Number";
	case ObjectId::NonExclusiveLevelAlarmType_AckedState_EffectiveDisplayName:
		return "NonExclusiveLevelAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLevelAlarmType_AckedState_TransitionTime:
		return "NonExclusiveLevelAlarmType_AckedState_TransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_AckedState_EffectiveTransitionTime:
		return "NonExclusiveLevelAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_AckedState_TrueState:
		return "NonExclusiveLevelAlarmType_AckedState_TrueState";
	case ObjectId::NonExclusiveLevelAlarmType_AckedState_FalseState:
		return "NonExclusiveLevelAlarmType_AckedState_FalseState";
	case ObjectId::NonExclusiveLevelAlarmType_ConfirmedState:
		return "NonExclusiveLevelAlarmType_ConfirmedState";
	case ObjectId::NonExclusiveLevelAlarmType_ConfirmedState_Id:
		return "NonExclusiveLevelAlarmType_ConfirmedState_Id";
	case ObjectId::NonExclusiveLevelAlarmType_ConfirmedState_Name:
		return "NonExclusiveLevelAlarmType_ConfirmedState_Name";
	case ObjectId::NonExclusiveLevelAlarmType_ConfirmedState_Number:
		return "NonExclusiveLevelAlarmType_ConfirmedState_Number";
	case ObjectId::NonExclusiveLevelAlarmType_ConfirmedState_EffectiveDisplayName:
		return "NonExclusiveLevelAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLevelAlarmType_ConfirmedState_TransitionTime:
		return "NonExclusiveLevelAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "NonExclusiveLevelAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_ConfirmedState_TrueState:
		return "NonExclusiveLevelAlarmType_ConfirmedState_TrueState";
	case ObjectId::NonExclusiveLevelAlarmType_ConfirmedState_FalseState:
		return "NonExclusiveLevelAlarmType_ConfirmedState_FalseState";
	case ObjectId::NonExclusiveLevelAlarmType_Acknowledge:
		return "NonExclusiveLevelAlarmType_Acknowledge";
	case ObjectId::NonExclusiveLevelAlarmType_Acknowledge_InputArguments:
		return "NonExclusiveLevelAlarmType_Acknowledge_InputArguments";
	case ObjectId::NonExclusiveLevelAlarmType_Confirm:
		return "NonExclusiveLevelAlarmType_Confirm";
	case ObjectId::NonExclusiveLevelAlarmType_Confirm_InputArguments:
		return "NonExclusiveLevelAlarmType_Confirm_InputArguments";
	case ObjectId::NonExclusiveLevelAlarmType_ActiveState:
		return "NonExclusiveLevelAlarmType_ActiveState";
	case ObjectId::NonExclusiveLevelAlarmType_ActiveState_Id:
		return "NonExclusiveLevelAlarmType_ActiveState_Id";
	case ObjectId::NonExclusiveLevelAlarmType_ActiveState_Name:
		return "NonExclusiveLevelAlarmType_ActiveState_Name";
	case ObjectId::NonExclusiveLevelAlarmType_ActiveState_Number:
		return "NonExclusiveLevelAlarmType_ActiveState_Number";
	case ObjectId::NonExclusiveLevelAlarmType_ActiveState_EffectiveDisplayName:
		return "NonExclusiveLevelAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLevelAlarmType_ActiveState_TransitionTime:
		return "NonExclusiveLevelAlarmType_ActiveState_TransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_ActiveState_EffectiveTransitionTime:
		return "NonExclusiveLevelAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_ActiveState_TrueState:
		return "NonExclusiveLevelAlarmType_ActiveState_TrueState";
	case ObjectId::NonExclusiveLevelAlarmType_ActiveState_FalseState:
		return "NonExclusiveLevelAlarmType_ActiveState_FalseState";
	case ObjectId::NonExclusiveLevelAlarmType_SuppressedState:
		return "NonExclusiveLevelAlarmType_SuppressedState";
	case ObjectId::NonExclusiveLevelAlarmType_SuppressedState_Id:
		return "NonExclusiveLevelAlarmType_SuppressedState_Id";
	case ObjectId::NonExclusiveLevelAlarmType_SuppressedState_Name:
		return "NonExclusiveLevelAlarmType_SuppressedState_Name";
	case ObjectId::NonExclusiveLevelAlarmType_SuppressedState_Number:
		return "NonExclusiveLevelAlarmType_SuppressedState_Number";
	case ObjectId::NonExclusiveLevelAlarmType_SuppressedState_EffectiveDisplayName:
		return "NonExclusiveLevelAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLevelAlarmType_SuppressedState_TransitionTime:
		return "NonExclusiveLevelAlarmType_SuppressedState_TransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_SuppressedState_EffectiveTransitionTime:
		return "NonExclusiveLevelAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_SuppressedState_TrueState:
		return "NonExclusiveLevelAlarmType_SuppressedState_TrueState";
	case ObjectId::NonExclusiveLevelAlarmType_SuppressedState_FalseState:
		return "NonExclusiveLevelAlarmType_SuppressedState_FalseState";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState:
		return "NonExclusiveLevelAlarmType_ShelvingState";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_CurrentState:
		return "NonExclusiveLevelAlarmType_ShelvingState_CurrentState";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_CurrentState_Id:
		return "NonExclusiveLevelAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_CurrentState_Name:
		return "NonExclusiveLevelAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_CurrentState_Number:
		return "NonExclusiveLevelAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "NonExclusiveLevelAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_LastTransition:
		return "NonExclusiveLevelAlarmType_ShelvingState_LastTransition";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_LastTransition_Id:
		return "NonExclusiveLevelAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_LastTransition_Name:
		return "NonExclusiveLevelAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_LastTransition_Number:
		return "NonExclusiveLevelAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "NonExclusiveLevelAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_UnshelveTime:
		return "NonExclusiveLevelAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_Unshelve:
		return "NonExclusiveLevelAlarmType_ShelvingState_Unshelve";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_OneShotShelve:
		return "NonExclusiveLevelAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_TimedShelve:
		return "NonExclusiveLevelAlarmType_ShelvingState_TimedShelve";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "NonExclusiveLevelAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::NonExclusiveLevelAlarmType_SuppressedOrShelved:
		return "NonExclusiveLevelAlarmType_SuppressedOrShelved";
	case ObjectId::NonExclusiveLevelAlarmType_MaxTimeShelved:
		return "NonExclusiveLevelAlarmType_MaxTimeShelved";
	case ObjectId::NonExclusiveLevelAlarmType_HighHighState:
		return "NonExclusiveLevelAlarmType_HighHighState";
	case ObjectId::NonExclusiveLevelAlarmType_HighHighState_Id:
		return "NonExclusiveLevelAlarmType_HighHighState_Id";
	case ObjectId::NonExclusiveLevelAlarmType_HighHighState_Name:
		return "NonExclusiveLevelAlarmType_HighHighState_Name";
	case ObjectId::NonExclusiveLevelAlarmType_HighHighState_Number:
		return "NonExclusiveLevelAlarmType_HighHighState_Number";
	case ObjectId::NonExclusiveLevelAlarmType_HighHighState_EffectiveDisplayName:
		return "NonExclusiveLevelAlarmType_HighHighState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLevelAlarmType_HighHighState_TransitionTime:
		return "NonExclusiveLevelAlarmType_HighHighState_TransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_HighHighState_EffectiveTransitionTime:
		return "NonExclusiveLevelAlarmType_HighHighState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_HighHighState_TrueState:
		return "NonExclusiveLevelAlarmType_HighHighState_TrueState";
	case ObjectId::NonExclusiveLevelAlarmType_HighHighState_FalseState:
		return "NonExclusiveLevelAlarmType_HighHighState_FalseState";
	case ObjectId::NonExclusiveLevelAlarmType_HighState:
		return "NonExclusiveLevelAlarmType_HighState";
	case ObjectId::NonExclusiveLevelAlarmType_HighState_Id:
		return "NonExclusiveLevelAlarmType_HighState_Id";
	case ObjectId::NonExclusiveLevelAlarmType_HighState_Name:
		return "NonExclusiveLevelAlarmType_HighState_Name";
	case ObjectId::NonExclusiveLevelAlarmType_HighState_Number:
		return "NonExclusiveLevelAlarmType_HighState_Number";
	case ObjectId::NonExclusiveLevelAlarmType_HighState_EffectiveDisplayName:
		return "NonExclusiveLevelAlarmType_HighState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLevelAlarmType_HighState_TransitionTime:
		return "NonExclusiveLevelAlarmType_HighState_TransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_HighState_EffectiveTransitionTime:
		return "NonExclusiveLevelAlarmType_HighState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_HighState_TrueState:
		return "NonExclusiveLevelAlarmType_HighState_TrueState";
	case ObjectId::NonExclusiveLevelAlarmType_HighState_FalseState:
		return "NonExclusiveLevelAlarmType_HighState_FalseState";
	case ObjectId::NonExclusiveLevelAlarmType_LowState:
		return "NonExclusiveLevelAlarmType_LowState";
	case ObjectId::NonExclusiveLevelAlarmType_LowState_Id:
		return "NonExclusiveLevelAlarmType_LowState_Id";
	case ObjectId::NonExclusiveLevelAlarmType_LowState_Name:
		return "NonExclusiveLevelAlarmType_LowState_Name";
	case ObjectId::NonExclusiveLevelAlarmType_LowState_Number:
		return "NonExclusiveLevelAlarmType_LowState_Number";
	case ObjectId::NonExclusiveLevelAlarmType_LowState_EffectiveDisplayName:
		return "NonExclusiveLevelAlarmType_LowState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLevelAlarmType_LowState_TransitionTime:
		return "NonExclusiveLevelAlarmType_LowState_TransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_LowState_EffectiveTransitionTime:
		return "NonExclusiveLevelAlarmType_LowState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_LowState_TrueState:
		return "NonExclusiveLevelAlarmType_LowState_TrueState";
	case ObjectId::NonExclusiveLevelAlarmType_LowState_FalseState:
		return "NonExclusiveLevelAlarmType_LowState_FalseState";
	case ObjectId::NonExclusiveLevelAlarmType_LowLowState:
		return "NonExclusiveLevelAlarmType_LowLowState";
	case ObjectId::NonExclusiveLevelAlarmType_LowLowState_Id:
		return "NonExclusiveLevelAlarmType_LowLowState_Id";
	case ObjectId::NonExclusiveLevelAlarmType_LowLowState_Name:
		return "NonExclusiveLevelAlarmType_LowLowState_Name";
	case ObjectId::NonExclusiveLevelAlarmType_LowLowState_Number:
		return "NonExclusiveLevelAlarmType_LowLowState_Number";
	case ObjectId::NonExclusiveLevelAlarmType_LowLowState_EffectiveDisplayName:
		return "NonExclusiveLevelAlarmType_LowLowState_EffectiveDisplayName";
	case ObjectId::NonExclusiveLevelAlarmType_LowLowState_TransitionTime:
		return "NonExclusiveLevelAlarmType_LowLowState_TransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_LowLowState_EffectiveTransitionTime:
		return "NonExclusiveLevelAlarmType_LowLowState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_LowLowState_TrueState:
		return "NonExclusiveLevelAlarmType_LowLowState_TrueState";
	case ObjectId::NonExclusiveLevelAlarmType_LowLowState_FalseState:
		return "NonExclusiveLevelAlarmType_LowLowState_FalseState";
	case ObjectId::NonExclusiveLevelAlarmType_HighHighLimit:
		return "NonExclusiveLevelAlarmType_HighHighLimit";
	case ObjectId::NonExclusiveLevelAlarmType_HighLimit:
		return "NonExclusiveLevelAlarmType_HighLimit";
	case ObjectId::NonExclusiveLevelAlarmType_LowLimit:
		return "NonExclusiveLevelAlarmType_LowLimit";
	case ObjectId::NonExclusiveLevelAlarmType_LowLowLimit:
		return "NonExclusiveLevelAlarmType_LowLowLimit";
	case ObjectId::NonExclusiveRateOfChangeAlarmType:
		return "NonExclusiveRateOfChangeAlarmType";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_EventId:
		return "NonExclusiveRateOfChangeAlarmType_EventId";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_EventType:
		return "NonExclusiveRateOfChangeAlarmType_EventType";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SourceNode:
		return "NonExclusiveRateOfChangeAlarmType_SourceNode";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SourceName:
		return "NonExclusiveRateOfChangeAlarmType_SourceName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Time:
		return "NonExclusiveRateOfChangeAlarmType_Time";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ReceiveTime:
		return "NonExclusiveRateOfChangeAlarmType_ReceiveTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LocalTime:
		return "NonExclusiveRateOfChangeAlarmType_LocalTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Message:
		return "NonExclusiveRateOfChangeAlarmType_Message";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Severity:
		return "NonExclusiveRateOfChangeAlarmType_Severity";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConditionName:
		return "NonExclusiveRateOfChangeAlarmType_ConditionName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_BranchId:
		return "NonExclusiveRateOfChangeAlarmType_BranchId";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Retain:
		return "NonExclusiveRateOfChangeAlarmType_Retain";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_EnabledState:
		return "NonExclusiveRateOfChangeAlarmType_EnabledState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_EnabledState_Id:
		return "NonExclusiveRateOfChangeAlarmType_EnabledState_Id";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_EnabledState_Name:
		return "NonExclusiveRateOfChangeAlarmType_EnabledState_Name";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_EnabledState_Number:
		return "NonExclusiveRateOfChangeAlarmType_EnabledState_Number";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_EnabledState_EffectiveDisplayName:
		return "NonExclusiveRateOfChangeAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_EnabledState_TransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_EnabledState_TransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_EnabledState_EffectiveTransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_EnabledState_TrueState:
		return "NonExclusiveRateOfChangeAlarmType_EnabledState_TrueState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_EnabledState_FalseState:
		return "NonExclusiveRateOfChangeAlarmType_EnabledState_FalseState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Quality:
		return "NonExclusiveRateOfChangeAlarmType_Quality";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Quality_SourceTimestamp:
		return "NonExclusiveRateOfChangeAlarmType_Quality_SourceTimestamp";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LastSeverity:
		return "NonExclusiveRateOfChangeAlarmType_LastSeverity";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LastSeverity_SourceTimestamp:
		return "NonExclusiveRateOfChangeAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Comment:
		return "NonExclusiveRateOfChangeAlarmType_Comment";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Comment_SourceTimestamp:
		return "NonExclusiveRateOfChangeAlarmType_Comment_SourceTimestamp";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ClientUserId:
		return "NonExclusiveRateOfChangeAlarmType_ClientUserId";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Enable:
		return "NonExclusiveRateOfChangeAlarmType_Enable";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Disable:
		return "NonExclusiveRateOfChangeAlarmType_Disable";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_AddComment:
		return "NonExclusiveRateOfChangeAlarmType_AddComment";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_AddComment_InputArguments:
		return "NonExclusiveRateOfChangeAlarmType_AddComment_InputArguments";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConditionRefresh:
		return "NonExclusiveRateOfChangeAlarmType_ConditionRefresh";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConditionRefresh_InputArguments:
		return "NonExclusiveRateOfChangeAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_AckedState:
		return "NonExclusiveRateOfChangeAlarmType_AckedState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_AckedState_Id:
		return "NonExclusiveRateOfChangeAlarmType_AckedState_Id";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_AckedState_Name:
		return "NonExclusiveRateOfChangeAlarmType_AckedState_Name";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_AckedState_Number:
		return "NonExclusiveRateOfChangeAlarmType_AckedState_Number";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_AckedState_EffectiveDisplayName:
		return "NonExclusiveRateOfChangeAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_AckedState_TransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_AckedState_TransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_AckedState_EffectiveTransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_AckedState_TrueState:
		return "NonExclusiveRateOfChangeAlarmType_AckedState_TrueState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_AckedState_FalseState:
		return "NonExclusiveRateOfChangeAlarmType_AckedState_FalseState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConfirmedState:
		return "NonExclusiveRateOfChangeAlarmType_ConfirmedState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConfirmedState_Id:
		return "NonExclusiveRateOfChangeAlarmType_ConfirmedState_Id";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConfirmedState_Name:
		return "NonExclusiveRateOfChangeAlarmType_ConfirmedState_Name";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConfirmedState_Number:
		return "NonExclusiveRateOfChangeAlarmType_ConfirmedState_Number";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveDisplayName:
		return "NonExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConfirmedState_TransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConfirmedState_TrueState:
		return "NonExclusiveRateOfChangeAlarmType_ConfirmedState_TrueState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConfirmedState_FalseState:
		return "NonExclusiveRateOfChangeAlarmType_ConfirmedState_FalseState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Acknowledge:
		return "NonExclusiveRateOfChangeAlarmType_Acknowledge";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Acknowledge_InputArguments:
		return "NonExclusiveRateOfChangeAlarmType_Acknowledge_InputArguments";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Confirm:
		return "NonExclusiveRateOfChangeAlarmType_Confirm";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_Confirm_InputArguments:
		return "NonExclusiveRateOfChangeAlarmType_Confirm_InputArguments";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ActiveState:
		return "NonExclusiveRateOfChangeAlarmType_ActiveState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ActiveState_Id:
		return "NonExclusiveRateOfChangeAlarmType_ActiveState_Id";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ActiveState_Name:
		return "NonExclusiveRateOfChangeAlarmType_ActiveState_Name";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ActiveState_Number:
		return "NonExclusiveRateOfChangeAlarmType_ActiveState_Number";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ActiveState_EffectiveDisplayName:
		return "NonExclusiveRateOfChangeAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ActiveState_TransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_ActiveState_TransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ActiveState_EffectiveTransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ActiveState_TrueState:
		return "NonExclusiveRateOfChangeAlarmType_ActiveState_TrueState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ActiveState_FalseState:
		return "NonExclusiveRateOfChangeAlarmType_ActiveState_FalseState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SuppressedState:
		return "NonExclusiveRateOfChangeAlarmType_SuppressedState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SuppressedState_Id:
		return "NonExclusiveRateOfChangeAlarmType_SuppressedState_Id";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SuppressedState_Name:
		return "NonExclusiveRateOfChangeAlarmType_SuppressedState_Name";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SuppressedState_Number:
		return "NonExclusiveRateOfChangeAlarmType_SuppressedState_Number";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveDisplayName:
		return "NonExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SuppressedState_TransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_SuppressedState_TransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveTransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SuppressedState_TrueState:
		return "NonExclusiveRateOfChangeAlarmType_SuppressedState_TrueState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SuppressedState_FalseState:
		return "NonExclusiveRateOfChangeAlarmType_SuppressedState_FalseState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Id:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Name:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Number:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Id:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Name:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Number:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_UnshelveTime:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_Unshelve:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_Unshelve";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_OneShotShelve:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_SuppressedOrShelved:
		return "NonExclusiveRateOfChangeAlarmType_SuppressedOrShelved";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_MaxTimeShelved:
		return "NonExclusiveRateOfChangeAlarmType_MaxTimeShelved";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighHighState:
		return "NonExclusiveRateOfChangeAlarmType_HighHighState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighHighState_Id:
		return "NonExclusiveRateOfChangeAlarmType_HighHighState_Id";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighHighState_Name:
		return "NonExclusiveRateOfChangeAlarmType_HighHighState_Name";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighHighState_Number:
		return "NonExclusiveRateOfChangeAlarmType_HighHighState_Number";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighHighState_EffectiveDisplayName:
		return "NonExclusiveRateOfChangeAlarmType_HighHighState_EffectiveDisplayName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighHighState_TransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_HighHighState_TransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighHighState_EffectiveTransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_HighHighState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighHighState_TrueState:
		return "NonExclusiveRateOfChangeAlarmType_HighHighState_TrueState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighHighState_FalseState:
		return "NonExclusiveRateOfChangeAlarmType_HighHighState_FalseState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighState:
		return "NonExclusiveRateOfChangeAlarmType_HighState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighState_Id:
		return "NonExclusiveRateOfChangeAlarmType_HighState_Id";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighState_Name:
		return "NonExclusiveRateOfChangeAlarmType_HighState_Name";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighState_Number:
		return "NonExclusiveRateOfChangeAlarmType_HighState_Number";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighState_EffectiveDisplayName:
		return "NonExclusiveRateOfChangeAlarmType_HighState_EffectiveDisplayName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighState_TransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_HighState_TransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighState_EffectiveTransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_HighState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighState_TrueState:
		return "NonExclusiveRateOfChangeAlarmType_HighState_TrueState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighState_FalseState:
		return "NonExclusiveRateOfChangeAlarmType_HighState_FalseState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowState:
		return "NonExclusiveRateOfChangeAlarmType_LowState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowState_Id:
		return "NonExclusiveRateOfChangeAlarmType_LowState_Id";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowState_Name:
		return "NonExclusiveRateOfChangeAlarmType_LowState_Name";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowState_Number:
		return "NonExclusiveRateOfChangeAlarmType_LowState_Number";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowState_EffectiveDisplayName:
		return "NonExclusiveRateOfChangeAlarmType_LowState_EffectiveDisplayName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowState_TransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_LowState_TransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowState_EffectiveTransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_LowState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowState_TrueState:
		return "NonExclusiveRateOfChangeAlarmType_LowState_TrueState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowState_FalseState:
		return "NonExclusiveRateOfChangeAlarmType_LowState_FalseState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowLowState:
		return "NonExclusiveRateOfChangeAlarmType_LowLowState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowLowState_Id:
		return "NonExclusiveRateOfChangeAlarmType_LowLowState_Id";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowLowState_Name:
		return "NonExclusiveRateOfChangeAlarmType_LowLowState_Name";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowLowState_Number:
		return "NonExclusiveRateOfChangeAlarmType_LowLowState_Number";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowLowState_EffectiveDisplayName:
		return "NonExclusiveRateOfChangeAlarmType_LowLowState_EffectiveDisplayName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowLowState_TransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_LowLowState_TransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowLowState_EffectiveTransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_LowLowState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowLowState_TrueState:
		return "NonExclusiveRateOfChangeAlarmType_LowLowState_TrueState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowLowState_FalseState:
		return "NonExclusiveRateOfChangeAlarmType_LowLowState_FalseState";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighHighLimit:
		return "NonExclusiveRateOfChangeAlarmType_HighHighLimit";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_HighLimit:
		return "NonExclusiveRateOfChangeAlarmType_HighLimit";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowLimit:
		return "NonExclusiveRateOfChangeAlarmType_LowLimit";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_LowLowLimit:
		return "NonExclusiveRateOfChangeAlarmType_LowLowLimit";
	case ObjectId::NonExclusiveDeviationAlarmType:
		return "NonExclusiveDeviationAlarmType";
	case ObjectId::NonExclusiveDeviationAlarmType_EventId:
		return "NonExclusiveDeviationAlarmType_EventId";
	case ObjectId::NonExclusiveDeviationAlarmType_EventType:
		return "NonExclusiveDeviationAlarmType_EventType";
	case ObjectId::NonExclusiveDeviationAlarmType_SourceNode:
		return "NonExclusiveDeviationAlarmType_SourceNode";
	case ObjectId::NonExclusiveDeviationAlarmType_SourceName:
		return "NonExclusiveDeviationAlarmType_SourceName";
	case ObjectId::NonExclusiveDeviationAlarmType_Time:
		return "NonExclusiveDeviationAlarmType_Time";
	case ObjectId::NonExclusiveDeviationAlarmType_ReceiveTime:
		return "NonExclusiveDeviationAlarmType_ReceiveTime";
	case ObjectId::NonExclusiveDeviationAlarmType_LocalTime:
		return "NonExclusiveDeviationAlarmType_LocalTime";
	case ObjectId::NonExclusiveDeviationAlarmType_Message:
		return "NonExclusiveDeviationAlarmType_Message";
	case ObjectId::NonExclusiveDeviationAlarmType_Severity:
		return "NonExclusiveDeviationAlarmType_Severity";
	case ObjectId::NonExclusiveDeviationAlarmType_ConditionName:
		return "NonExclusiveDeviationAlarmType_ConditionName";
	case ObjectId::NonExclusiveDeviationAlarmType_BranchId:
		return "NonExclusiveDeviationAlarmType_BranchId";
	case ObjectId::NonExclusiveDeviationAlarmType_Retain:
		return "NonExclusiveDeviationAlarmType_Retain";
	case ObjectId::NonExclusiveDeviationAlarmType_EnabledState:
		return "NonExclusiveDeviationAlarmType_EnabledState";
	case ObjectId::NonExclusiveDeviationAlarmType_EnabledState_Id:
		return "NonExclusiveDeviationAlarmType_EnabledState_Id";
	case ObjectId::NonExclusiveDeviationAlarmType_EnabledState_Name:
		return "NonExclusiveDeviationAlarmType_EnabledState_Name";
	case ObjectId::NonExclusiveDeviationAlarmType_EnabledState_Number:
		return "NonExclusiveDeviationAlarmType_EnabledState_Number";
	case ObjectId::NonExclusiveDeviationAlarmType_EnabledState_EffectiveDisplayName:
		return "NonExclusiveDeviationAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::NonExclusiveDeviationAlarmType_EnabledState_TransitionTime:
		return "NonExclusiveDeviationAlarmType_EnabledState_TransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_EnabledState_EffectiveTransitionTime:
		return "NonExclusiveDeviationAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_EnabledState_TrueState:
		return "NonExclusiveDeviationAlarmType_EnabledState_TrueState";
	case ObjectId::NonExclusiveDeviationAlarmType_EnabledState_FalseState:
		return "NonExclusiveDeviationAlarmType_EnabledState_FalseState";
	case ObjectId::NonExclusiveDeviationAlarmType_Quality:
		return "NonExclusiveDeviationAlarmType_Quality";
	case ObjectId::NonExclusiveDeviationAlarmType_Quality_SourceTimestamp:
		return "NonExclusiveDeviationAlarmType_Quality_SourceTimestamp";
	case ObjectId::NonExclusiveDeviationAlarmType_LastSeverity:
		return "NonExclusiveDeviationAlarmType_LastSeverity";
	case ObjectId::NonExclusiveDeviationAlarmType_LastSeverity_SourceTimestamp:
		return "NonExclusiveDeviationAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::NonExclusiveDeviationAlarmType_Comment:
		return "NonExclusiveDeviationAlarmType_Comment";
	case ObjectId::NonExclusiveDeviationAlarmType_Comment_SourceTimestamp:
		return "NonExclusiveDeviationAlarmType_Comment_SourceTimestamp";
	case ObjectId::NonExclusiveDeviationAlarmType_ClientUserId:
		return "NonExclusiveDeviationAlarmType_ClientUserId";
	case ObjectId::NonExclusiveDeviationAlarmType_Enable:
		return "NonExclusiveDeviationAlarmType_Enable";
	case ObjectId::NonExclusiveDeviationAlarmType_Disable:
		return "NonExclusiveDeviationAlarmType_Disable";
	case ObjectId::NonExclusiveDeviationAlarmType_AddComment:
		return "NonExclusiveDeviationAlarmType_AddComment";
	case ObjectId::NonExclusiveDeviationAlarmType_AddComment_InputArguments:
		return "NonExclusiveDeviationAlarmType_AddComment_InputArguments";
	case ObjectId::NonExclusiveDeviationAlarmType_ConditionRefresh:
		return "NonExclusiveDeviationAlarmType_ConditionRefresh";
	case ObjectId::NonExclusiveDeviationAlarmType_ConditionRefresh_InputArguments:
		return "NonExclusiveDeviationAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::NonExclusiveDeviationAlarmType_AckedState:
		return "NonExclusiveDeviationAlarmType_AckedState";
	case ObjectId::NonExclusiveDeviationAlarmType_AckedState_Id:
		return "NonExclusiveDeviationAlarmType_AckedState_Id";
	case ObjectId::NonExclusiveDeviationAlarmType_AckedState_Name:
		return "NonExclusiveDeviationAlarmType_AckedState_Name";
	case ObjectId::NonExclusiveDeviationAlarmType_AckedState_Number:
		return "NonExclusiveDeviationAlarmType_AckedState_Number";
	case ObjectId::NonExclusiveDeviationAlarmType_AckedState_EffectiveDisplayName:
		return "NonExclusiveDeviationAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveDeviationAlarmType_AckedState_TransitionTime:
		return "NonExclusiveDeviationAlarmType_AckedState_TransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_AckedState_EffectiveTransitionTime:
		return "NonExclusiveDeviationAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_AckedState_TrueState:
		return "NonExclusiveDeviationAlarmType_AckedState_TrueState";
	case ObjectId::NonExclusiveDeviationAlarmType_AckedState_FalseState:
		return "NonExclusiveDeviationAlarmType_AckedState_FalseState";
	case ObjectId::NonExclusiveDeviationAlarmType_ConfirmedState:
		return "NonExclusiveDeviationAlarmType_ConfirmedState";
	case ObjectId::NonExclusiveDeviationAlarmType_ConfirmedState_Id:
		return "NonExclusiveDeviationAlarmType_ConfirmedState_Id";
	case ObjectId::NonExclusiveDeviationAlarmType_ConfirmedState_Name:
		return "NonExclusiveDeviationAlarmType_ConfirmedState_Name";
	case ObjectId::NonExclusiveDeviationAlarmType_ConfirmedState_Number:
		return "NonExclusiveDeviationAlarmType_ConfirmedState_Number";
	case ObjectId::NonExclusiveDeviationAlarmType_ConfirmedState_EffectiveDisplayName:
		return "NonExclusiveDeviationAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveDeviationAlarmType_ConfirmedState_TransitionTime:
		return "NonExclusiveDeviationAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "NonExclusiveDeviationAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_ConfirmedState_TrueState:
		return "NonExclusiveDeviationAlarmType_ConfirmedState_TrueState";
	case ObjectId::NonExclusiveDeviationAlarmType_ConfirmedState_FalseState:
		return "NonExclusiveDeviationAlarmType_ConfirmedState_FalseState";
	case ObjectId::NonExclusiveDeviationAlarmType_Acknowledge:
		return "NonExclusiveDeviationAlarmType_Acknowledge";
	case ObjectId::NonExclusiveDeviationAlarmType_Acknowledge_InputArguments:
		return "NonExclusiveDeviationAlarmType_Acknowledge_InputArguments";
	case ObjectId::NonExclusiveDeviationAlarmType_Confirm:
		return "NonExclusiveDeviationAlarmType_Confirm";
	case ObjectId::NonExclusiveDeviationAlarmType_Confirm_InputArguments:
		return "NonExclusiveDeviationAlarmType_Confirm_InputArguments";
	case ObjectId::NonExclusiveDeviationAlarmType_ActiveState:
		return "NonExclusiveDeviationAlarmType_ActiveState";
	case ObjectId::NonExclusiveDeviationAlarmType_ActiveState_Id:
		return "NonExclusiveDeviationAlarmType_ActiveState_Id";
	case ObjectId::NonExclusiveDeviationAlarmType_ActiveState_Name:
		return "NonExclusiveDeviationAlarmType_ActiveState_Name";
	case ObjectId::NonExclusiveDeviationAlarmType_ActiveState_Number:
		return "NonExclusiveDeviationAlarmType_ActiveState_Number";
	case ObjectId::NonExclusiveDeviationAlarmType_ActiveState_EffectiveDisplayName:
		return "NonExclusiveDeviationAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::NonExclusiveDeviationAlarmType_ActiveState_TransitionTime:
		return "NonExclusiveDeviationAlarmType_ActiveState_TransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_ActiveState_EffectiveTransitionTime:
		return "NonExclusiveDeviationAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_ActiveState_TrueState:
		return "NonExclusiveDeviationAlarmType_ActiveState_TrueState";
	case ObjectId::NonExclusiveDeviationAlarmType_ActiveState_FalseState:
		return "NonExclusiveDeviationAlarmType_ActiveState_FalseState";
	case ObjectId::NonExclusiveDeviationAlarmType_SuppressedState:
		return "NonExclusiveDeviationAlarmType_SuppressedState";
	case ObjectId::NonExclusiveDeviationAlarmType_SuppressedState_Id:
		return "NonExclusiveDeviationAlarmType_SuppressedState_Id";
	case ObjectId::NonExclusiveDeviationAlarmType_SuppressedState_Name:
		return "NonExclusiveDeviationAlarmType_SuppressedState_Name";
	case ObjectId::NonExclusiveDeviationAlarmType_SuppressedState_Number:
		return "NonExclusiveDeviationAlarmType_SuppressedState_Number";
	case ObjectId::NonExclusiveDeviationAlarmType_SuppressedState_EffectiveDisplayName:
		return "NonExclusiveDeviationAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::NonExclusiveDeviationAlarmType_SuppressedState_TransitionTime:
		return "NonExclusiveDeviationAlarmType_SuppressedState_TransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_SuppressedState_EffectiveTransitionTime:
		return "NonExclusiveDeviationAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_SuppressedState_TrueState:
		return "NonExclusiveDeviationAlarmType_SuppressedState_TrueState";
	case ObjectId::NonExclusiveDeviationAlarmType_SuppressedState_FalseState:
		return "NonExclusiveDeviationAlarmType_SuppressedState_FalseState";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState:
		return "NonExclusiveDeviationAlarmType_ShelvingState";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_CurrentState:
		return "NonExclusiveDeviationAlarmType_ShelvingState_CurrentState";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_Id:
		return "NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_Name:
		return "NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_Number:
		return "NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "NonExclusiveDeviationAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_LastTransition:
		return "NonExclusiveDeviationAlarmType_ShelvingState_LastTransition";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_Id:
		return "NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_Name:
		return "NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_Number:
		return "NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_UnshelveTime:
		return "NonExclusiveDeviationAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_Unshelve:
		return "NonExclusiveDeviationAlarmType_ShelvingState_Unshelve";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_OneShotShelve:
		return "NonExclusiveDeviationAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_TimedShelve:
		return "NonExclusiveDeviationAlarmType_ShelvingState_TimedShelve";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "NonExclusiveDeviationAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::NonExclusiveDeviationAlarmType_SuppressedOrShelved:
		return "NonExclusiveDeviationAlarmType_SuppressedOrShelved";
	case ObjectId::NonExclusiveDeviationAlarmType_MaxTimeShelved:
		return "NonExclusiveDeviationAlarmType_MaxTimeShelved";
	case ObjectId::NonExclusiveDeviationAlarmType_HighHighState:
		return "NonExclusiveDeviationAlarmType_HighHighState";
	case ObjectId::NonExclusiveDeviationAlarmType_HighHighState_Id:
		return "NonExclusiveDeviationAlarmType_HighHighState_Id";
	case ObjectId::NonExclusiveDeviationAlarmType_HighHighState_Name:
		return "NonExclusiveDeviationAlarmType_HighHighState_Name";
	case ObjectId::NonExclusiveDeviationAlarmType_HighHighState_Number:
		return "NonExclusiveDeviationAlarmType_HighHighState_Number";
	case ObjectId::NonExclusiveDeviationAlarmType_HighHighState_EffectiveDisplayName:
		return "NonExclusiveDeviationAlarmType_HighHighState_EffectiveDisplayName";
	case ObjectId::NonExclusiveDeviationAlarmType_HighHighState_TransitionTime:
		return "NonExclusiveDeviationAlarmType_HighHighState_TransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_HighHighState_EffectiveTransitionTime:
		return "NonExclusiveDeviationAlarmType_HighHighState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_HighHighState_TrueState:
		return "NonExclusiveDeviationAlarmType_HighHighState_TrueState";
	case ObjectId::NonExclusiveDeviationAlarmType_HighHighState_FalseState:
		return "NonExclusiveDeviationAlarmType_HighHighState_FalseState";
	case ObjectId::NonExclusiveDeviationAlarmType_HighState:
		return "NonExclusiveDeviationAlarmType_HighState";
	case ObjectId::NonExclusiveDeviationAlarmType_HighState_Id:
		return "NonExclusiveDeviationAlarmType_HighState_Id";
	case ObjectId::NonExclusiveDeviationAlarmType_HighState_Name:
		return "NonExclusiveDeviationAlarmType_HighState_Name";
	case ObjectId::NonExclusiveDeviationAlarmType_HighState_Number:
		return "NonExclusiveDeviationAlarmType_HighState_Number";
	case ObjectId::NonExclusiveDeviationAlarmType_HighState_EffectiveDisplayName:
		return "NonExclusiveDeviationAlarmType_HighState_EffectiveDisplayName";
	case ObjectId::NonExclusiveDeviationAlarmType_HighState_TransitionTime:
		return "NonExclusiveDeviationAlarmType_HighState_TransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_HighState_EffectiveTransitionTime:
		return "NonExclusiveDeviationAlarmType_HighState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_HighState_TrueState:
		return "NonExclusiveDeviationAlarmType_HighState_TrueState";
	case ObjectId::NonExclusiveDeviationAlarmType_HighState_FalseState:
		return "NonExclusiveDeviationAlarmType_HighState_FalseState";
	case ObjectId::NonExclusiveDeviationAlarmType_LowState:
		return "NonExclusiveDeviationAlarmType_LowState";
	case ObjectId::NonExclusiveDeviationAlarmType_LowState_Id:
		return "NonExclusiveDeviationAlarmType_LowState_Id";
	case ObjectId::NonExclusiveDeviationAlarmType_LowState_Name:
		return "NonExclusiveDeviationAlarmType_LowState_Name";
	case ObjectId::NonExclusiveDeviationAlarmType_LowState_Number:
		return "NonExclusiveDeviationAlarmType_LowState_Number";
	case ObjectId::NonExclusiveDeviationAlarmType_LowState_EffectiveDisplayName:
		return "NonExclusiveDeviationAlarmType_LowState_EffectiveDisplayName";
	case ObjectId::NonExclusiveDeviationAlarmType_LowState_TransitionTime:
		return "NonExclusiveDeviationAlarmType_LowState_TransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_LowState_EffectiveTransitionTime:
		return "NonExclusiveDeviationAlarmType_LowState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_LowState_TrueState:
		return "NonExclusiveDeviationAlarmType_LowState_TrueState";
	case ObjectId::NonExclusiveDeviationAlarmType_LowState_FalseState:
		return "NonExclusiveDeviationAlarmType_LowState_FalseState";
	case ObjectId::NonExclusiveDeviationAlarmType_LowLowState:
		return "NonExclusiveDeviationAlarmType_LowLowState";
	case ObjectId::NonExclusiveDeviationAlarmType_LowLowState_Id:
		return "NonExclusiveDeviationAlarmType_LowLowState_Id";
	case ObjectId::NonExclusiveDeviationAlarmType_LowLowState_Name:
		return "NonExclusiveDeviationAlarmType_LowLowState_Name";
	case ObjectId::NonExclusiveDeviationAlarmType_LowLowState_Number:
		return "NonExclusiveDeviationAlarmType_LowLowState_Number";
	case ObjectId::NonExclusiveDeviationAlarmType_LowLowState_EffectiveDisplayName:
		return "NonExclusiveDeviationAlarmType_LowLowState_EffectiveDisplayName";
	case ObjectId::NonExclusiveDeviationAlarmType_LowLowState_TransitionTime:
		return "NonExclusiveDeviationAlarmType_LowLowState_TransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_LowLowState_EffectiveTransitionTime:
		return "NonExclusiveDeviationAlarmType_LowLowState_EffectiveTransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_LowLowState_TrueState:
		return "NonExclusiveDeviationAlarmType_LowLowState_TrueState";
	case ObjectId::NonExclusiveDeviationAlarmType_LowLowState_FalseState:
		return "NonExclusiveDeviationAlarmType_LowLowState_FalseState";
	case ObjectId::NonExclusiveDeviationAlarmType_HighHighLimit:
		return "NonExclusiveDeviationAlarmType_HighHighLimit";
	case ObjectId::NonExclusiveDeviationAlarmType_HighLimit:
		return "NonExclusiveDeviationAlarmType_HighLimit";
	case ObjectId::NonExclusiveDeviationAlarmType_LowLimit:
		return "NonExclusiveDeviationAlarmType_LowLimit";
	case ObjectId::NonExclusiveDeviationAlarmType_LowLowLimit:
		return "NonExclusiveDeviationAlarmType_LowLowLimit";
	case ObjectId::NonExclusiveDeviationAlarmType_SetpointNode:
		return "NonExclusiveDeviationAlarmType_SetpointNode";
	case ObjectId::DiscreteAlarmType:
		return "DiscreteAlarmType";
	case ObjectId::DiscreteAlarmType_EventId:
		return "DiscreteAlarmType_EventId";
	case ObjectId::DiscreteAlarmType_EventType:
		return "DiscreteAlarmType_EventType";
	case ObjectId::DiscreteAlarmType_SourceNode:
		return "DiscreteAlarmType_SourceNode";
	case ObjectId::DiscreteAlarmType_SourceName:
		return "DiscreteAlarmType_SourceName";
	case ObjectId::DiscreteAlarmType_Time:
		return "DiscreteAlarmType_Time";
	case ObjectId::DiscreteAlarmType_ReceiveTime:
		return "DiscreteAlarmType_ReceiveTime";
	case ObjectId::DiscreteAlarmType_LocalTime:
		return "DiscreteAlarmType_LocalTime";
	case ObjectId::DiscreteAlarmType_Message:
		return "DiscreteAlarmType_Message";
	case ObjectId::DiscreteAlarmType_Severity:
		return "DiscreteAlarmType_Severity";
	case ObjectId::DiscreteAlarmType_ConditionName:
		return "DiscreteAlarmType_ConditionName";
	case ObjectId::DiscreteAlarmType_BranchId:
		return "DiscreteAlarmType_BranchId";
	case ObjectId::DiscreteAlarmType_Retain:
		return "DiscreteAlarmType_Retain";
	case ObjectId::DiscreteAlarmType_EnabledState:
		return "DiscreteAlarmType_EnabledState";
	case ObjectId::DiscreteAlarmType_EnabledState_Id:
		return "DiscreteAlarmType_EnabledState_Id";
	case ObjectId::DiscreteAlarmType_EnabledState_Name:
		return "DiscreteAlarmType_EnabledState_Name";
	case ObjectId::DiscreteAlarmType_EnabledState_Number:
		return "DiscreteAlarmType_EnabledState_Number";
	case ObjectId::DiscreteAlarmType_EnabledState_EffectiveDisplayName:
		return "DiscreteAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::DiscreteAlarmType_EnabledState_TransitionTime:
		return "DiscreteAlarmType_EnabledState_TransitionTime";
	case ObjectId::DiscreteAlarmType_EnabledState_EffectiveTransitionTime:
		return "DiscreteAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::DiscreteAlarmType_EnabledState_TrueState:
		return "DiscreteAlarmType_EnabledState_TrueState";
	case ObjectId::DiscreteAlarmType_EnabledState_FalseState:
		return "DiscreteAlarmType_EnabledState_FalseState";
	case ObjectId::DiscreteAlarmType_Quality:
		return "DiscreteAlarmType_Quality";
	case ObjectId::DiscreteAlarmType_Quality_SourceTimestamp:
		return "DiscreteAlarmType_Quality_SourceTimestamp";
	case ObjectId::DiscreteAlarmType_LastSeverity:
		return "DiscreteAlarmType_LastSeverity";
	case ObjectId::DiscreteAlarmType_LastSeverity_SourceTimestamp:
		return "DiscreteAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::DiscreteAlarmType_Comment:
		return "DiscreteAlarmType_Comment";
	case ObjectId::DiscreteAlarmType_Comment_SourceTimestamp:
		return "DiscreteAlarmType_Comment_SourceTimestamp";
	case ObjectId::DiscreteAlarmType_ClientUserId:
		return "DiscreteAlarmType_ClientUserId";
	case ObjectId::DiscreteAlarmType_Enable:
		return "DiscreteAlarmType_Enable";
	case ObjectId::DiscreteAlarmType_Disable:
		return "DiscreteAlarmType_Disable";
	case ObjectId::DiscreteAlarmType_AddComment:
		return "DiscreteAlarmType_AddComment";
	case ObjectId::DiscreteAlarmType_AddComment_InputArguments:
		return "DiscreteAlarmType_AddComment_InputArguments";
	case ObjectId::DiscreteAlarmType_ConditionRefresh:
		return "DiscreteAlarmType_ConditionRefresh";
	case ObjectId::DiscreteAlarmType_ConditionRefresh_InputArguments:
		return "DiscreteAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::DiscreteAlarmType_AckedState:
		return "DiscreteAlarmType_AckedState";
	case ObjectId::DiscreteAlarmType_AckedState_Id:
		return "DiscreteAlarmType_AckedState_Id";
	case ObjectId::DiscreteAlarmType_AckedState_Name:
		return "DiscreteAlarmType_AckedState_Name";
	case ObjectId::DiscreteAlarmType_AckedState_Number:
		return "DiscreteAlarmType_AckedState_Number";
	case ObjectId::DiscreteAlarmType_AckedState_EffectiveDisplayName:
		return "DiscreteAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::DiscreteAlarmType_AckedState_TransitionTime:
		return "DiscreteAlarmType_AckedState_TransitionTime";
	case ObjectId::DiscreteAlarmType_AckedState_EffectiveTransitionTime:
		return "DiscreteAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::DiscreteAlarmType_AckedState_TrueState:
		return "DiscreteAlarmType_AckedState_TrueState";
	case ObjectId::DiscreteAlarmType_AckedState_FalseState:
		return "DiscreteAlarmType_AckedState_FalseState";
	case ObjectId::DiscreteAlarmType_ConfirmedState:
		return "DiscreteAlarmType_ConfirmedState";
	case ObjectId::DiscreteAlarmType_ConfirmedState_Id:
		return "DiscreteAlarmType_ConfirmedState_Id";
	case ObjectId::DiscreteAlarmType_ConfirmedState_Name:
		return "DiscreteAlarmType_ConfirmedState_Name";
	case ObjectId::DiscreteAlarmType_ConfirmedState_Number:
		return "DiscreteAlarmType_ConfirmedState_Number";
	case ObjectId::DiscreteAlarmType_ConfirmedState_EffectiveDisplayName:
		return "DiscreteAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::DiscreteAlarmType_ConfirmedState_TransitionTime:
		return "DiscreteAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::DiscreteAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "DiscreteAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::DiscreteAlarmType_ConfirmedState_TrueState:
		return "DiscreteAlarmType_ConfirmedState_TrueState";
	case ObjectId::DiscreteAlarmType_ConfirmedState_FalseState:
		return "DiscreteAlarmType_ConfirmedState_FalseState";
	case ObjectId::DiscreteAlarmType_Acknowledge:
		return "DiscreteAlarmType_Acknowledge";
	case ObjectId::DiscreteAlarmType_Acknowledge_InputArguments:
		return "DiscreteAlarmType_Acknowledge_InputArguments";
	case ObjectId::DiscreteAlarmType_Confirm:
		return "DiscreteAlarmType_Confirm";
	case ObjectId::DiscreteAlarmType_Confirm_InputArguments:
		return "DiscreteAlarmType_Confirm_InputArguments";
	case ObjectId::DiscreteAlarmType_ActiveState:
		return "DiscreteAlarmType_ActiveState";
	case ObjectId::DiscreteAlarmType_ActiveState_Id:
		return "DiscreteAlarmType_ActiveState_Id";
	case ObjectId::DiscreteAlarmType_ActiveState_Name:
		return "DiscreteAlarmType_ActiveState_Name";
	case ObjectId::DiscreteAlarmType_ActiveState_Number:
		return "DiscreteAlarmType_ActiveState_Number";
	case ObjectId::DiscreteAlarmType_ActiveState_EffectiveDisplayName:
		return "DiscreteAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::DiscreteAlarmType_ActiveState_TransitionTime:
		return "DiscreteAlarmType_ActiveState_TransitionTime";
	case ObjectId::DiscreteAlarmType_ActiveState_EffectiveTransitionTime:
		return "DiscreteAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::DiscreteAlarmType_ActiveState_TrueState:
		return "DiscreteAlarmType_ActiveState_TrueState";
	case ObjectId::DiscreteAlarmType_ActiveState_FalseState:
		return "DiscreteAlarmType_ActiveState_FalseState";
	case ObjectId::DiscreteAlarmType_SuppressedState:
		return "DiscreteAlarmType_SuppressedState";
	case ObjectId::DiscreteAlarmType_SuppressedState_Id:
		return "DiscreteAlarmType_SuppressedState_Id";
	case ObjectId::DiscreteAlarmType_SuppressedState_Name:
		return "DiscreteAlarmType_SuppressedState_Name";
	case ObjectId::DiscreteAlarmType_SuppressedState_Number:
		return "DiscreteAlarmType_SuppressedState_Number";
	case ObjectId::DiscreteAlarmType_SuppressedState_EffectiveDisplayName:
		return "DiscreteAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::DiscreteAlarmType_SuppressedState_TransitionTime:
		return "DiscreteAlarmType_SuppressedState_TransitionTime";
	case ObjectId::DiscreteAlarmType_SuppressedState_EffectiveTransitionTime:
		return "DiscreteAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::DiscreteAlarmType_SuppressedState_TrueState:
		return "DiscreteAlarmType_SuppressedState_TrueState";
	case ObjectId::DiscreteAlarmType_SuppressedState_FalseState:
		return "DiscreteAlarmType_SuppressedState_FalseState";
	case ObjectId::DiscreteAlarmType_ShelvingState:
		return "DiscreteAlarmType_ShelvingState";
	case ObjectId::DiscreteAlarmType_ShelvingState_CurrentState:
		return "DiscreteAlarmType_ShelvingState_CurrentState";
	case ObjectId::DiscreteAlarmType_ShelvingState_CurrentState_Id:
		return "DiscreteAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::DiscreteAlarmType_ShelvingState_CurrentState_Name:
		return "DiscreteAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::DiscreteAlarmType_ShelvingState_CurrentState_Number:
		return "DiscreteAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::DiscreteAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "DiscreteAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::DiscreteAlarmType_ShelvingState_LastTransition:
		return "DiscreteAlarmType_ShelvingState_LastTransition";
	case ObjectId::DiscreteAlarmType_ShelvingState_LastTransition_Id:
		return "DiscreteAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::DiscreteAlarmType_ShelvingState_LastTransition_Name:
		return "DiscreteAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::DiscreteAlarmType_ShelvingState_LastTransition_Number:
		return "DiscreteAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::DiscreteAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "DiscreteAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::DiscreteAlarmType_ShelvingState_UnshelveTime:
		return "DiscreteAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::DiscreteAlarmType_ShelvingState_Unshelve:
		return "DiscreteAlarmType_ShelvingState_Unshelve";
	case ObjectId::DiscreteAlarmType_ShelvingState_OneShotShelve:
		return "DiscreteAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::DiscreteAlarmType_ShelvingState_TimedShelve:
		return "DiscreteAlarmType_ShelvingState_TimedShelve";
	case ObjectId::DiscreteAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "DiscreteAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::DiscreteAlarmType_SuppressedOrShelved:
		return "DiscreteAlarmType_SuppressedOrShelved";
	case ObjectId::DiscreteAlarmType_MaxTimeShelved:
		return "DiscreteAlarmType_MaxTimeShelved";
	case ObjectId::OffNormalAlarmType:
		return "OffNormalAlarmType";
	case ObjectId::OffNormalAlarmType_EventId:
		return "OffNormalAlarmType_EventId";
	case ObjectId::OffNormalAlarmType_EventType:
		return "OffNormalAlarmType_EventType";
	case ObjectId::OffNormalAlarmType_SourceNode:
		return "OffNormalAlarmType_SourceNode";
	case ObjectId::OffNormalAlarmType_SourceName:
		return "OffNormalAlarmType_SourceName";
	case ObjectId::OffNormalAlarmType_Time:
		return "OffNormalAlarmType_Time";
	case ObjectId::OffNormalAlarmType_ReceiveTime:
		return "OffNormalAlarmType_ReceiveTime";
	case ObjectId::OffNormalAlarmType_LocalTime:
		return "OffNormalAlarmType_LocalTime";
	case ObjectId::OffNormalAlarmType_Message:
		return "OffNormalAlarmType_Message";
	case ObjectId::OffNormalAlarmType_Severity:
		return "OffNormalAlarmType_Severity";
	case ObjectId::OffNormalAlarmType_ConditionName:
		return "OffNormalAlarmType_ConditionName";
	case ObjectId::OffNormalAlarmType_BranchId:
		return "OffNormalAlarmType_BranchId";
	case ObjectId::OffNormalAlarmType_Retain:
		return "OffNormalAlarmType_Retain";
	case ObjectId::OffNormalAlarmType_EnabledState:
		return "OffNormalAlarmType_EnabledState";
	case ObjectId::OffNormalAlarmType_EnabledState_Id:
		return "OffNormalAlarmType_EnabledState_Id";
	case ObjectId::OffNormalAlarmType_EnabledState_Name:
		return "OffNormalAlarmType_EnabledState_Name";
	case ObjectId::OffNormalAlarmType_EnabledState_Number:
		return "OffNormalAlarmType_EnabledState_Number";
	case ObjectId::OffNormalAlarmType_EnabledState_EffectiveDisplayName:
		return "OffNormalAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::OffNormalAlarmType_EnabledState_TransitionTime:
		return "OffNormalAlarmType_EnabledState_TransitionTime";
	case ObjectId::OffNormalAlarmType_EnabledState_EffectiveTransitionTime:
		return "OffNormalAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::OffNormalAlarmType_EnabledState_TrueState:
		return "OffNormalAlarmType_EnabledState_TrueState";
	case ObjectId::OffNormalAlarmType_EnabledState_FalseState:
		return "OffNormalAlarmType_EnabledState_FalseState";
	case ObjectId::OffNormalAlarmType_Quality:
		return "OffNormalAlarmType_Quality";
	case ObjectId::OffNormalAlarmType_Quality_SourceTimestamp:
		return "OffNormalAlarmType_Quality_SourceTimestamp";
	case ObjectId::OffNormalAlarmType_LastSeverity:
		return "OffNormalAlarmType_LastSeverity";
	case ObjectId::OffNormalAlarmType_LastSeverity_SourceTimestamp:
		return "OffNormalAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::OffNormalAlarmType_Comment:
		return "OffNormalAlarmType_Comment";
	case ObjectId::OffNormalAlarmType_Comment_SourceTimestamp:
		return "OffNormalAlarmType_Comment_SourceTimestamp";
	case ObjectId::OffNormalAlarmType_ClientUserId:
		return "OffNormalAlarmType_ClientUserId";
	case ObjectId::OffNormalAlarmType_Enable:
		return "OffNormalAlarmType_Enable";
	case ObjectId::OffNormalAlarmType_Disable:
		return "OffNormalAlarmType_Disable";
	case ObjectId::OffNormalAlarmType_AddComment:
		return "OffNormalAlarmType_AddComment";
	case ObjectId::OffNormalAlarmType_AddComment_InputArguments:
		return "OffNormalAlarmType_AddComment_InputArguments";
	case ObjectId::OffNormalAlarmType_ConditionRefresh:
		return "OffNormalAlarmType_ConditionRefresh";
	case ObjectId::OffNormalAlarmType_ConditionRefresh_InputArguments:
		return "OffNormalAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::OffNormalAlarmType_AckedState:
		return "OffNormalAlarmType_AckedState";
	case ObjectId::OffNormalAlarmType_AckedState_Id:
		return "OffNormalAlarmType_AckedState_Id";
	case ObjectId::OffNormalAlarmType_AckedState_Name:
		return "OffNormalAlarmType_AckedState_Name";
	case ObjectId::OffNormalAlarmType_AckedState_Number:
		return "OffNormalAlarmType_AckedState_Number";
	case ObjectId::OffNormalAlarmType_AckedState_EffectiveDisplayName:
		return "OffNormalAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::OffNormalAlarmType_AckedState_TransitionTime:
		return "OffNormalAlarmType_AckedState_TransitionTime";
	case ObjectId::OffNormalAlarmType_AckedState_EffectiveTransitionTime:
		return "OffNormalAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::OffNormalAlarmType_AckedState_TrueState:
		return "OffNormalAlarmType_AckedState_TrueState";
	case ObjectId::OffNormalAlarmType_AckedState_FalseState:
		return "OffNormalAlarmType_AckedState_FalseState";
	case ObjectId::OffNormalAlarmType_ConfirmedState:
		return "OffNormalAlarmType_ConfirmedState";
	case ObjectId::OffNormalAlarmType_ConfirmedState_Id:
		return "OffNormalAlarmType_ConfirmedState_Id";
	case ObjectId::OffNormalAlarmType_ConfirmedState_Name:
		return "OffNormalAlarmType_ConfirmedState_Name";
	case ObjectId::OffNormalAlarmType_ConfirmedState_Number:
		return "OffNormalAlarmType_ConfirmedState_Number";
	case ObjectId::OffNormalAlarmType_ConfirmedState_EffectiveDisplayName:
		return "OffNormalAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::OffNormalAlarmType_ConfirmedState_TransitionTime:
		return "OffNormalAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::OffNormalAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "OffNormalAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::OffNormalAlarmType_ConfirmedState_TrueState:
		return "OffNormalAlarmType_ConfirmedState_TrueState";
	case ObjectId::OffNormalAlarmType_ConfirmedState_FalseState:
		return "OffNormalAlarmType_ConfirmedState_FalseState";
	case ObjectId::OffNormalAlarmType_Acknowledge:
		return "OffNormalAlarmType_Acknowledge";
	case ObjectId::OffNormalAlarmType_Acknowledge_InputArguments:
		return "OffNormalAlarmType_Acknowledge_InputArguments";
	case ObjectId::OffNormalAlarmType_Confirm:
		return "OffNormalAlarmType_Confirm";
	case ObjectId::OffNormalAlarmType_Confirm_InputArguments:
		return "OffNormalAlarmType_Confirm_InputArguments";
	case ObjectId::OffNormalAlarmType_ActiveState:
		return "OffNormalAlarmType_ActiveState";
	case ObjectId::OffNormalAlarmType_ActiveState_Id:
		return "OffNormalAlarmType_ActiveState_Id";
	case ObjectId::OffNormalAlarmType_ActiveState_Name:
		return "OffNormalAlarmType_ActiveState_Name";
	case ObjectId::OffNormalAlarmType_ActiveState_Number:
		return "OffNormalAlarmType_ActiveState_Number";
	case ObjectId::OffNormalAlarmType_ActiveState_EffectiveDisplayName:
		return "OffNormalAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::OffNormalAlarmType_ActiveState_TransitionTime:
		return "OffNormalAlarmType_ActiveState_TransitionTime";
	case ObjectId::OffNormalAlarmType_ActiveState_EffectiveTransitionTime:
		return "OffNormalAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::OffNormalAlarmType_ActiveState_TrueState:
		return "OffNormalAlarmType_ActiveState_TrueState";
	case ObjectId::OffNormalAlarmType_ActiveState_FalseState:
		return "OffNormalAlarmType_ActiveState_FalseState";
	case ObjectId::OffNormalAlarmType_SuppressedState:
		return "OffNormalAlarmType_SuppressedState";
	case ObjectId::OffNormalAlarmType_SuppressedState_Id:
		return "OffNormalAlarmType_SuppressedState_Id";
	case ObjectId::OffNormalAlarmType_SuppressedState_Name:
		return "OffNormalAlarmType_SuppressedState_Name";
	case ObjectId::OffNormalAlarmType_SuppressedState_Number:
		return "OffNormalAlarmType_SuppressedState_Number";
	case ObjectId::OffNormalAlarmType_SuppressedState_EffectiveDisplayName:
		return "OffNormalAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::OffNormalAlarmType_SuppressedState_TransitionTime:
		return "OffNormalAlarmType_SuppressedState_TransitionTime";
	case ObjectId::OffNormalAlarmType_SuppressedState_EffectiveTransitionTime:
		return "OffNormalAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::OffNormalAlarmType_SuppressedState_TrueState:
		return "OffNormalAlarmType_SuppressedState_TrueState";
	case ObjectId::OffNormalAlarmType_SuppressedState_FalseState:
		return "OffNormalAlarmType_SuppressedState_FalseState";
	case ObjectId::OffNormalAlarmType_ShelvingState:
		return "OffNormalAlarmType_ShelvingState";
	case ObjectId::OffNormalAlarmType_ShelvingState_CurrentState:
		return "OffNormalAlarmType_ShelvingState_CurrentState";
	case ObjectId::OffNormalAlarmType_ShelvingState_CurrentState_Id:
		return "OffNormalAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::OffNormalAlarmType_ShelvingState_CurrentState_Name:
		return "OffNormalAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::OffNormalAlarmType_ShelvingState_CurrentState_Number:
		return "OffNormalAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::OffNormalAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "OffNormalAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::OffNormalAlarmType_ShelvingState_LastTransition:
		return "OffNormalAlarmType_ShelvingState_LastTransition";
	case ObjectId::OffNormalAlarmType_ShelvingState_LastTransition_Id:
		return "OffNormalAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::OffNormalAlarmType_ShelvingState_LastTransition_Name:
		return "OffNormalAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::OffNormalAlarmType_ShelvingState_LastTransition_Number:
		return "OffNormalAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::OffNormalAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "OffNormalAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::OffNormalAlarmType_ShelvingState_UnshelveTime:
		return "OffNormalAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::OffNormalAlarmType_ShelvingState_Unshelve:
		return "OffNormalAlarmType_ShelvingState_Unshelve";
	case ObjectId::OffNormalAlarmType_ShelvingState_OneShotShelve:
		return "OffNormalAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::OffNormalAlarmType_ShelvingState_TimedShelve:
		return "OffNormalAlarmType_ShelvingState_TimedShelve";
	case ObjectId::OffNormalAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "OffNormalAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::OffNormalAlarmType_SuppressedOrShelved:
		return "OffNormalAlarmType_SuppressedOrShelved";
	case ObjectId::OffNormalAlarmType_MaxTimeShelved:
		return "OffNormalAlarmType_MaxTimeShelved";
	case ObjectId::TripAlarmType:
		return "TripAlarmType";
	case ObjectId::TripAlarmType_EventId:
		return "TripAlarmType_EventId";
	case ObjectId::TripAlarmType_EventType:
		return "TripAlarmType_EventType";
	case ObjectId::TripAlarmType_SourceNode:
		return "TripAlarmType_SourceNode";
	case ObjectId::TripAlarmType_SourceName:
		return "TripAlarmType_SourceName";
	case ObjectId::TripAlarmType_Time:
		return "TripAlarmType_Time";
	case ObjectId::TripAlarmType_ReceiveTime:
		return "TripAlarmType_ReceiveTime";
	case ObjectId::TripAlarmType_LocalTime:
		return "TripAlarmType_LocalTime";
	case ObjectId::TripAlarmType_Message:
		return "TripAlarmType_Message";
	case ObjectId::TripAlarmType_Severity:
		return "TripAlarmType_Severity";
	case ObjectId::TripAlarmType_ConditionName:
		return "TripAlarmType_ConditionName";
	case ObjectId::TripAlarmType_BranchId:
		return "TripAlarmType_BranchId";
	case ObjectId::TripAlarmType_Retain:
		return "TripAlarmType_Retain";
	case ObjectId::TripAlarmType_EnabledState:
		return "TripAlarmType_EnabledState";
	case ObjectId::TripAlarmType_EnabledState_Id:
		return "TripAlarmType_EnabledState_Id";
	case ObjectId::TripAlarmType_EnabledState_Name:
		return "TripAlarmType_EnabledState_Name";
	case ObjectId::TripAlarmType_EnabledState_Number:
		return "TripAlarmType_EnabledState_Number";
	case ObjectId::TripAlarmType_EnabledState_EffectiveDisplayName:
		return "TripAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::TripAlarmType_EnabledState_TransitionTime:
		return "TripAlarmType_EnabledState_TransitionTime";
	case ObjectId::TripAlarmType_EnabledState_EffectiveTransitionTime:
		return "TripAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::TripAlarmType_EnabledState_TrueState:
		return "TripAlarmType_EnabledState_TrueState";
	case ObjectId::TripAlarmType_EnabledState_FalseState:
		return "TripAlarmType_EnabledState_FalseState";
	case ObjectId::TripAlarmType_Quality:
		return "TripAlarmType_Quality";
	case ObjectId::TripAlarmType_Quality_SourceTimestamp:
		return "TripAlarmType_Quality_SourceTimestamp";
	case ObjectId::TripAlarmType_LastSeverity:
		return "TripAlarmType_LastSeverity";
	case ObjectId::TripAlarmType_LastSeverity_SourceTimestamp:
		return "TripAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::TripAlarmType_Comment:
		return "TripAlarmType_Comment";
	case ObjectId::TripAlarmType_Comment_SourceTimestamp:
		return "TripAlarmType_Comment_SourceTimestamp";
	case ObjectId::TripAlarmType_ClientUserId:
		return "TripAlarmType_ClientUserId";
	case ObjectId::TripAlarmType_Enable:
		return "TripAlarmType_Enable";
	case ObjectId::TripAlarmType_Disable:
		return "TripAlarmType_Disable";
	case ObjectId::TripAlarmType_AddComment:
		return "TripAlarmType_AddComment";
	case ObjectId::TripAlarmType_AddComment_InputArguments:
		return "TripAlarmType_AddComment_InputArguments";
	case ObjectId::TripAlarmType_ConditionRefresh:
		return "TripAlarmType_ConditionRefresh";
	case ObjectId::TripAlarmType_ConditionRefresh_InputArguments:
		return "TripAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::TripAlarmType_AckedState:
		return "TripAlarmType_AckedState";
	case ObjectId::TripAlarmType_AckedState_Id:
		return "TripAlarmType_AckedState_Id";
	case ObjectId::TripAlarmType_AckedState_Name:
		return "TripAlarmType_AckedState_Name";
	case ObjectId::TripAlarmType_AckedState_Number:
		return "TripAlarmType_AckedState_Number";
	case ObjectId::TripAlarmType_AckedState_EffectiveDisplayName:
		return "TripAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::TripAlarmType_AckedState_TransitionTime:
		return "TripAlarmType_AckedState_TransitionTime";
	case ObjectId::TripAlarmType_AckedState_EffectiveTransitionTime:
		return "TripAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::TripAlarmType_AckedState_TrueState:
		return "TripAlarmType_AckedState_TrueState";
	case ObjectId::TripAlarmType_AckedState_FalseState:
		return "TripAlarmType_AckedState_FalseState";
	case ObjectId::TripAlarmType_ConfirmedState:
		return "TripAlarmType_ConfirmedState";
	case ObjectId::TripAlarmType_ConfirmedState_Id:
		return "TripAlarmType_ConfirmedState_Id";
	case ObjectId::TripAlarmType_ConfirmedState_Name:
		return "TripAlarmType_ConfirmedState_Name";
	case ObjectId::TripAlarmType_ConfirmedState_Number:
		return "TripAlarmType_ConfirmedState_Number";
	case ObjectId::TripAlarmType_ConfirmedState_EffectiveDisplayName:
		return "TripAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::TripAlarmType_ConfirmedState_TransitionTime:
		return "TripAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::TripAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "TripAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::TripAlarmType_ConfirmedState_TrueState:
		return "TripAlarmType_ConfirmedState_TrueState";
	case ObjectId::TripAlarmType_ConfirmedState_FalseState:
		return "TripAlarmType_ConfirmedState_FalseState";
	case ObjectId::TripAlarmType_Acknowledge:
		return "TripAlarmType_Acknowledge";
	case ObjectId::TripAlarmType_Acknowledge_InputArguments:
		return "TripAlarmType_Acknowledge_InputArguments";
	case ObjectId::TripAlarmType_Confirm:
		return "TripAlarmType_Confirm";
	case ObjectId::TripAlarmType_Confirm_InputArguments:
		return "TripAlarmType_Confirm_InputArguments";
	case ObjectId::TripAlarmType_ActiveState:
		return "TripAlarmType_ActiveState";
	case ObjectId::TripAlarmType_ActiveState_Id:
		return "TripAlarmType_ActiveState_Id";
	case ObjectId::TripAlarmType_ActiveState_Name:
		return "TripAlarmType_ActiveState_Name";
	case ObjectId::TripAlarmType_ActiveState_Number:
		return "TripAlarmType_ActiveState_Number";
	case ObjectId::TripAlarmType_ActiveState_EffectiveDisplayName:
		return "TripAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::TripAlarmType_ActiveState_TransitionTime:
		return "TripAlarmType_ActiveState_TransitionTime";
	case ObjectId::TripAlarmType_ActiveState_EffectiveTransitionTime:
		return "TripAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::TripAlarmType_ActiveState_TrueState:
		return "TripAlarmType_ActiveState_TrueState";
	case ObjectId::TripAlarmType_ActiveState_FalseState:
		return "TripAlarmType_ActiveState_FalseState";
	case ObjectId::TripAlarmType_SuppressedState:
		return "TripAlarmType_SuppressedState";
	case ObjectId::TripAlarmType_SuppressedState_Id:
		return "TripAlarmType_SuppressedState_Id";
	case ObjectId::TripAlarmType_SuppressedState_Name:
		return "TripAlarmType_SuppressedState_Name";
	case ObjectId::TripAlarmType_SuppressedState_Number:
		return "TripAlarmType_SuppressedState_Number";
	case ObjectId::TripAlarmType_SuppressedState_EffectiveDisplayName:
		return "TripAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::TripAlarmType_SuppressedState_TransitionTime:
		return "TripAlarmType_SuppressedState_TransitionTime";
	case ObjectId::TripAlarmType_SuppressedState_EffectiveTransitionTime:
		return "TripAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::TripAlarmType_SuppressedState_TrueState:
		return "TripAlarmType_SuppressedState_TrueState";
	case ObjectId::TripAlarmType_SuppressedState_FalseState:
		return "TripAlarmType_SuppressedState_FalseState";
	case ObjectId::TripAlarmType_ShelvingState:
		return "TripAlarmType_ShelvingState";
	case ObjectId::TripAlarmType_ShelvingState_CurrentState:
		return "TripAlarmType_ShelvingState_CurrentState";
	case ObjectId::TripAlarmType_ShelvingState_CurrentState_Id:
		return "TripAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::TripAlarmType_ShelvingState_CurrentState_Name:
		return "TripAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::TripAlarmType_ShelvingState_CurrentState_Number:
		return "TripAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::TripAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "TripAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::TripAlarmType_ShelvingState_LastTransition:
		return "TripAlarmType_ShelvingState_LastTransition";
	case ObjectId::TripAlarmType_ShelvingState_LastTransition_Id:
		return "TripAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::TripAlarmType_ShelvingState_LastTransition_Name:
		return "TripAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::TripAlarmType_ShelvingState_LastTransition_Number:
		return "TripAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::TripAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "TripAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::TripAlarmType_ShelvingState_UnshelveTime:
		return "TripAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::TripAlarmType_ShelvingState_Unshelve:
		return "TripAlarmType_ShelvingState_Unshelve";
	case ObjectId::TripAlarmType_ShelvingState_OneShotShelve:
		return "TripAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::TripAlarmType_ShelvingState_TimedShelve:
		return "TripAlarmType_ShelvingState_TimedShelve";
	case ObjectId::TripAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "TripAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::TripAlarmType_SuppressedOrShelved:
		return "TripAlarmType_SuppressedOrShelved";
	case ObjectId::TripAlarmType_MaxTimeShelved:
		return "TripAlarmType_MaxTimeShelved";
	case ObjectId::AuditConditionShelvingEventType:
		return "AuditConditionShelvingEventType";
	case ObjectId::AuditConditionShelvingEventType_EventId:
		return "AuditConditionShelvingEventType_EventId";
	case ObjectId::AuditConditionShelvingEventType_EventType:
		return "AuditConditionShelvingEventType_EventType";
	case ObjectId::AuditConditionShelvingEventType_SourceNode:
		return "AuditConditionShelvingEventType_SourceNode";
	case ObjectId::AuditConditionShelvingEventType_SourceName:
		return "AuditConditionShelvingEventType_SourceName";
	case ObjectId::AuditConditionShelvingEventType_Time:
		return "AuditConditionShelvingEventType_Time";
	case ObjectId::AuditConditionShelvingEventType_ReceiveTime:
		return "AuditConditionShelvingEventType_ReceiveTime";
	case ObjectId::AuditConditionShelvingEventType_LocalTime:
		return "AuditConditionShelvingEventType_LocalTime";
	case ObjectId::AuditConditionShelvingEventType_Message:
		return "AuditConditionShelvingEventType_Message";
	case ObjectId::AuditConditionShelvingEventType_Severity:
		return "AuditConditionShelvingEventType_Severity";
	case ObjectId::AuditConditionShelvingEventType_ActionTimeStamp:
		return "AuditConditionShelvingEventType_ActionTimeStamp";
	case ObjectId::AuditConditionShelvingEventType_Status:
		return "AuditConditionShelvingEventType_Status";
	case ObjectId::AuditConditionShelvingEventType_ServerId:
		return "AuditConditionShelvingEventType_ServerId";
	case ObjectId::AuditConditionShelvingEventType_ClientAuditEntryId:
		return "AuditConditionShelvingEventType_ClientAuditEntryId";
	case ObjectId::AuditConditionShelvingEventType_ClientUserId:
		return "AuditConditionShelvingEventType_ClientUserId";
	case ObjectId::AuditConditionShelvingEventType_MethodId:
		return "AuditConditionShelvingEventType_MethodId";
	case ObjectId::AuditConditionShelvingEventType_InputArguments:
		return "AuditConditionShelvingEventType_InputArguments";
	case ObjectId::TwoStateVariableType_TrueState:
		return "TwoStateVariableType_TrueState";
	case ObjectId::TwoStateVariableType_FalseState:
		return "TwoStateVariableType_FalseState";
	case ObjectId::ConditionType_ConditionClassId:
		return "ConditionType_ConditionClassId";
	case ObjectId::ConditionType_ConditionClassName:
		return "ConditionType_ConditionClassName";
	case ObjectId::DialogConditionType_ConditionClassId:
		return "DialogConditionType_ConditionClassId";
	case ObjectId::DialogConditionType_ConditionClassName:
		return "DialogConditionType_ConditionClassName";
	case ObjectId::AcknowledgeableConditionType_ConditionClassId:
		return "AcknowledgeableConditionType_ConditionClassId";
	case ObjectId::AcknowledgeableConditionType_ConditionClassName:
		return "AcknowledgeableConditionType_ConditionClassName";
	case ObjectId::AlarmConditionType_ConditionClassId:
		return "AlarmConditionType_ConditionClassId";
	case ObjectId::AlarmConditionType_ConditionClassName:
		return "AlarmConditionType_ConditionClassName";
	case ObjectId::AlarmConditionType_InputNode:
		return "AlarmConditionType_InputNode";
	case ObjectId::LimitAlarmType_ConditionClassId:
		return "LimitAlarmType_ConditionClassId";
	case ObjectId::LimitAlarmType_ConditionClassName:
		return "LimitAlarmType_ConditionClassName";
	case ObjectId::LimitAlarmType_InputNode:
		return "LimitAlarmType_InputNode";
	case ObjectId::LimitAlarmType_HighHighLimit:
		return "LimitAlarmType_HighHighLimit";
	case ObjectId::LimitAlarmType_HighLimit:
		return "LimitAlarmType_HighLimit";
	case ObjectId::LimitAlarmType_LowLimit:
		return "LimitAlarmType_LowLimit";
	case ObjectId::LimitAlarmType_LowLowLimit:
		return "LimitAlarmType_LowLowLimit";
	case ObjectId::ExclusiveLimitAlarmType_ConditionClassId:
		return "ExclusiveLimitAlarmType_ConditionClassId";
	case ObjectId::ExclusiveLimitAlarmType_ConditionClassName:
		return "ExclusiveLimitAlarmType_ConditionClassName";
	case ObjectId::ExclusiveLimitAlarmType_InputNode:
		return "ExclusiveLimitAlarmType_InputNode";
	case ObjectId::ExclusiveLevelAlarmType_ConditionClassId:
		return "ExclusiveLevelAlarmType_ConditionClassId";
	case ObjectId::ExclusiveLevelAlarmType_ConditionClassName:
		return "ExclusiveLevelAlarmType_ConditionClassName";
	case ObjectId::ExclusiveLevelAlarmType_InputNode:
		return "ExclusiveLevelAlarmType_InputNode";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConditionClassId:
		return "ExclusiveRateOfChangeAlarmType_ConditionClassId";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ConditionClassName:
		return "ExclusiveRateOfChangeAlarmType_ConditionClassName";
	case ObjectId::ExclusiveRateOfChangeAlarmType_InputNode:
		return "ExclusiveRateOfChangeAlarmType_InputNode";
	case ObjectId::ExclusiveDeviationAlarmType_ConditionClassId:
		return "ExclusiveDeviationAlarmType_ConditionClassId";
	case ObjectId::ExclusiveDeviationAlarmType_ConditionClassName:
		return "ExclusiveDeviationAlarmType_ConditionClassName";
	case ObjectId::ExclusiveDeviationAlarmType_InputNode:
		return "ExclusiveDeviationAlarmType_InputNode";
	case ObjectId::NonExclusiveLimitAlarmType_ConditionClassId:
		return "NonExclusiveLimitAlarmType_ConditionClassId";
	case ObjectId::NonExclusiveLimitAlarmType_ConditionClassName:
		return "NonExclusiveLimitAlarmType_ConditionClassName";
	case ObjectId::NonExclusiveLimitAlarmType_InputNode:
		return "NonExclusiveLimitAlarmType_InputNode";
	case ObjectId::NonExclusiveLevelAlarmType_ConditionClassId:
		return "NonExclusiveLevelAlarmType_ConditionClassId";
	case ObjectId::NonExclusiveLevelAlarmType_ConditionClassName:
		return "NonExclusiveLevelAlarmType_ConditionClassName";
	case ObjectId::NonExclusiveLevelAlarmType_InputNode:
		return "NonExclusiveLevelAlarmType_InputNode";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConditionClassId:
		return "NonExclusiveRateOfChangeAlarmType_ConditionClassId";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ConditionClassName:
		return "NonExclusiveRateOfChangeAlarmType_ConditionClassName";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_InputNode:
		return "NonExclusiveRateOfChangeAlarmType_InputNode";
	case ObjectId::NonExclusiveDeviationAlarmType_ConditionClassId:
		return "NonExclusiveDeviationAlarmType_ConditionClassId";
	case ObjectId::NonExclusiveDeviationAlarmType_ConditionClassName:
		return "NonExclusiveDeviationAlarmType_ConditionClassName";
	case ObjectId::NonExclusiveDeviationAlarmType_InputNode:
		return "NonExclusiveDeviationAlarmType_InputNode";
	case ObjectId::DiscreteAlarmType_ConditionClassId:
		return "DiscreteAlarmType_ConditionClassId";
	case ObjectId::DiscreteAlarmType_ConditionClassName:
		return "DiscreteAlarmType_ConditionClassName";
	case ObjectId::DiscreteAlarmType_InputNode:
		return "DiscreteAlarmType_InputNode";
	case ObjectId::OffNormalAlarmType_ConditionClassId:
		return "OffNormalAlarmType_ConditionClassId";
	case ObjectId::OffNormalAlarmType_ConditionClassName:
		return "OffNormalAlarmType_ConditionClassName";
	case ObjectId::OffNormalAlarmType_InputNode:
		return "OffNormalAlarmType_InputNode";
	case ObjectId::OffNormalAlarmType_NormalState:
		return "OffNormalAlarmType_NormalState";
	case ObjectId::TripAlarmType_ConditionClassId:
		return "TripAlarmType_ConditionClassId";
	case ObjectId::TripAlarmType_ConditionClassName:
		return "TripAlarmType_ConditionClassName";
	case ObjectId::TripAlarmType_InputNode:
		return "TripAlarmType_InputNode";
	case ObjectId::TripAlarmType_NormalState:
		return "TripAlarmType_NormalState";
	case ObjectId::BaseConditionClassType:
		return "BaseConditionClassType";
	case ObjectId::ProcessConditionClassType:
		return "ProcessConditionClassType";
	case ObjectId::MaintenanceConditionClassType:
		return "MaintenanceConditionClassType";
	case ObjectId::SystemConditionClassType:
		return "SystemConditionClassType";
	case ObjectId::HistoricalDataConfigurationType_AggregateConfiguration_TreatUncertainAsBad:
		return "HistoricalDataConfigurationType_AggregateConfiguration_TreatUncertainAsBad";
	case ObjectId::HistoricalDataConfigurationType_AggregateConfiguration_PercentDataBad:
		return "HistoricalDataConfigurationType_AggregateConfiguration_PercentDataBad";
	case ObjectId::HistoricalDataConfigurationType_AggregateConfiguration_PercentDataGood:
		return "HistoricalDataConfigurationType_AggregateConfiguration_PercentDataGood";
	case ObjectId::HistoricalDataConfigurationType_AggregateConfiguration_UseSlopedExtrapolation:
		return "HistoricalDataConfigurationType_AggregateConfiguration_UseSlopedExtrapolation";
	case ObjectId::HistoryServerCapabilitiesType_AggregateFunctions:
		return "HistoryServerCapabilitiesType_AggregateFunctions";
	case ObjectId::AggregateConfigurationType:
		return "AggregateConfigurationType";
	case ObjectId::AggregateConfigurationType_TreatUncertainAsBad:
		return "AggregateConfigurationType_TreatUncertainAsBad";
	case ObjectId::AggregateConfigurationType_PercentDataBad:
		return "AggregateConfigurationType_PercentDataBad";
	case ObjectId::AggregateConfigurationType_PercentDataGood:
		return "AggregateConfigurationType_PercentDataGood";
	case ObjectId::AggregateConfigurationType_UseSlopedExtrapolation:
		return "AggregateConfigurationType_UseSlopedExtrapolation";
	case ObjectId::HistoryServerCapabilities:
		return "HistoryServerCapabilities";
	case ObjectId::HistoryServerCapabilities_AccessHistoryDataCapability:
		return "HistoryServerCapabilities_AccessHistoryDataCapability";
	case ObjectId::HistoryServerCapabilities_InsertDataCapability:
		return "HistoryServerCapabilities_InsertDataCapability";
	case ObjectId::HistoryServerCapabilities_ReplaceDataCapability:
		return "HistoryServerCapabilities_ReplaceDataCapability";
	case ObjectId::HistoryServerCapabilities_UpdateDataCapability:
		return "HistoryServerCapabilities_UpdateDataCapability";
	case ObjectId::HistoryServerCapabilities_DeleteRawCapability:
		return "HistoryServerCapabilities_DeleteRawCapability";
	case ObjectId::HistoryServerCapabilities_DeleteAtTimeCapability:
		return "HistoryServerCapabilities_DeleteAtTimeCapability";
	case ObjectId::HistoryServerCapabilities_AggregateFunctions:
		return "HistoryServerCapabilities_AggregateFunctions";
	case ObjectId::HAConfiguration:
		return "HAConfiguration";
	case ObjectId::HAConfiguration_AggregateConfiguration:
		return "HAConfiguration_AggregateConfiguration";
	case ObjectId::HAConfiguration_AggregateConfiguration_TreatUncertainAsBad:
		return "HAConfiguration_AggregateConfiguration_TreatUncertainAsBad";
	case ObjectId::HAConfiguration_AggregateConfiguration_PercentDataBad:
		return "HAConfiguration_AggregateConfiguration_PercentDataBad";
	case ObjectId::HAConfiguration_AggregateConfiguration_PercentDataGood:
		return "HAConfiguration_AggregateConfiguration_PercentDataGood";
	case ObjectId::HAConfiguration_AggregateConfiguration_UseSlopedExtrapolation:
		return "HAConfiguration_AggregateConfiguration_UseSlopedExtrapolation";
	case ObjectId::HAConfiguration_Stepped:
		return "HAConfiguration_Stepped";
	case ObjectId::HAConfiguration_Definition:
		return "HAConfiguration_Definition";
	case ObjectId::HAConfiguration_MaxTimeInterval:
		return "HAConfiguration_MaxTimeInterval";
	case ObjectId::HAConfiguration_MinTimeInterval:
		return "HAConfiguration_MinTimeInterval";
	case ObjectId::HAConfiguration_ExceptionDeviation:
		return "HAConfiguration_ExceptionDeviation";
	case ObjectId::HAConfiguration_ExceptionDeviationFormat:
		return "HAConfiguration_ExceptionDeviationFormat";
	case ObjectId::Annotations:
		return "Annotations";
	case ObjectId::HistoricalEventFilter:
		return "HistoricalEventFilter";
	case ObjectId::ModificationInfo:
		return "ModificationInfo";
	case ObjectId::HistoryModifiedData:
		return "HistoryModifiedData";
	case ObjectId::ModificationInfo_Encoding_DefaultXml:
		return "ModificationInfo_Encoding_DefaultXml";
	case ObjectId::HistoryModifiedData_Encoding_DefaultXml:
		return "HistoryModifiedData_Encoding_DefaultXml";
	case ObjectId::ModificationInfo_Encoding_DefaultBinary:
		return "ModificationInfo_Encoding_DefaultBinary";
	case ObjectId::HistoryModifiedData_Encoding_DefaultBinary:
		return "HistoryModifiedData_Encoding_DefaultBinary";
	case ObjectId::HistoryUpdateType:
		return "HistoryUpdateType";
	case ObjectId::MultiStateValueDiscreteType:
		return "MultiStateValueDiscreteType";
	case ObjectId::MultiStateValueDiscreteType_Definition:
		return "MultiStateValueDiscreteType_Definition";
	case ObjectId::MultiStateValueDiscreteType_ValuePrecision:
		return "MultiStateValueDiscreteType_ValuePrecision";
	case ObjectId::MultiStateValueDiscreteType_EnumValues:
		return "MultiStateValueDiscreteType_EnumValues";
	case ObjectId::HistoryServerCapabilities_AccessHistoryEventsCapability:
		return "HistoryServerCapabilities_AccessHistoryEventsCapability";
	case ObjectId::HistoryServerCapabilitiesType_MaxReturnDataValues:
		return "HistoryServerCapabilitiesType_MaxReturnDataValues";
	case ObjectId::HistoryServerCapabilitiesType_MaxReturnEventValues:
		return "HistoryServerCapabilitiesType_MaxReturnEventValues";
	case ObjectId::HistoryServerCapabilitiesType_InsertAnnotationCapability:
		return "HistoryServerCapabilitiesType_InsertAnnotationCapability";
	case ObjectId::HistoryServerCapabilities_MaxReturnDataValues:
		return "HistoryServerCapabilities_MaxReturnDataValues";
	case ObjectId::HistoryServerCapabilities_MaxReturnEventValues:
		return "HistoryServerCapabilities_MaxReturnEventValues";
	case ObjectId::HistoryServerCapabilities_InsertAnnotationCapability:
		return "HistoryServerCapabilities_InsertAnnotationCapability";
	case ObjectId::HistoryServerCapabilitiesType_InsertEventCapability:
		return "HistoryServerCapabilitiesType_InsertEventCapability";
	case ObjectId::HistoryServerCapabilitiesType_ReplaceEventCapability:
		return "HistoryServerCapabilitiesType_ReplaceEventCapability";
	case ObjectId::HistoryServerCapabilitiesType_UpdateEventCapability:
		return "HistoryServerCapabilitiesType_UpdateEventCapability";
	case ObjectId::HistoryServerCapabilities_InsertEventCapability:
		return "HistoryServerCapabilities_InsertEventCapability";
	case ObjectId::HistoryServerCapabilities_ReplaceEventCapability:
		return "HistoryServerCapabilities_ReplaceEventCapability";
	case ObjectId::HistoryServerCapabilities_UpdateEventCapability:
		return "HistoryServerCapabilities_UpdateEventCapability";
	case ObjectId::AggregateFunction_TimeAverage2:
		return "AggregateFunction_TimeAverage2";
	case ObjectId::AggregateFunction_Minimum2:
		return "AggregateFunction_Minimum2";
	case ObjectId::AggregateFunction_Maximum2:
		return "AggregateFunction_Maximum2";
	case ObjectId::AggregateFunction_Range2:
		return "AggregateFunction_Range2";
	case ObjectId::AggregateFunction_WorstQuality2:
		return "AggregateFunction_WorstQuality2";
	case ObjectId::PerformUpdateType:
		return "PerformUpdateType";
	case ObjectId::UpdateStructureDataDetails:
		return "UpdateStructureDataDetails";
	case ObjectId::UpdateStructureDataDetails_Encoding_DefaultXml:
		return "UpdateStructureDataDetails_Encoding_DefaultXml";
	case ObjectId::UpdateStructureDataDetails_Encoding_DefaultBinary:
		return "UpdateStructureDataDetails_Encoding_DefaultBinary";
	case ObjectId::AggregateFunction_Total2:
		return "AggregateFunction_Total2";
	case ObjectId::AggregateFunction_MinimumActualTime2:
		return "AggregateFunction_MinimumActualTime2";
	case ObjectId::AggregateFunction_MaximumActualTime2:
		return "AggregateFunction_MaximumActualTime2";
	case ObjectId::AggregateFunction_DurationInStateZero:
		return "AggregateFunction_DurationInStateZero";
	case ObjectId::AggregateFunction_DurationInStateNonZero:
		return "AggregateFunction_DurationInStateNonZero";
	case ObjectId::Server_ServerRedundancy_CurrentServerId:
		return "Server_ServerRedundancy_CurrentServerId";
	case ObjectId::Server_ServerRedundancy_RedundantServerArray:
		return "Server_ServerRedundancy_RedundantServerArray";
	case ObjectId::Server_ServerRedundancy_ServerUriArray:
		return "Server_ServerRedundancy_ServerUriArray";
	case ObjectId::ShelvedStateMachineType_UnshelvedToTimedShelved_TransitionNumber:
		return "ShelvedStateMachineType_UnshelvedToTimedShelved_TransitionNumber";
	case ObjectId::ShelvedStateMachineType_UnshelvedToOneShotShelved_TransitionNumber:
		return "ShelvedStateMachineType_UnshelvedToOneShotShelved_TransitionNumber";
	case ObjectId::ShelvedStateMachineType_TimedShelvedToUnshelved_TransitionNumber:
		return "ShelvedStateMachineType_TimedShelvedToUnshelved_TransitionNumber";
	case ObjectId::ShelvedStateMachineType_TimedShelvedToOneShotShelved_TransitionNumber:
		return "ShelvedStateMachineType_TimedShelvedToOneShotShelved_TransitionNumber";
	case ObjectId::ShelvedStateMachineType_OneShotShelvedToUnshelved_TransitionNumber:
		return "ShelvedStateMachineType_OneShotShelvedToUnshelved_TransitionNumber";
	case ObjectId::ShelvedStateMachineType_OneShotShelvedToTimedShelved_TransitionNumber:
		return "ShelvedStateMachineType_OneShotShelvedToTimedShelved_TransitionNumber";
	case ObjectId::ExclusiveLimitStateMachineType_LowLowToLow_TransitionNumber:
		return "ExclusiveLimitStateMachineType_LowLowToLow_TransitionNumber";
	case ObjectId::ExclusiveLimitStateMachineType_LowToLowLow_TransitionNumber:
		return "ExclusiveLimitStateMachineType_LowToLowLow_TransitionNumber";
	case ObjectId::ExclusiveLimitStateMachineType_HighHighToHigh_TransitionNumber:
		return "ExclusiveLimitStateMachineType_HighHighToHigh_TransitionNumber";
	case ObjectId::ExclusiveLimitStateMachineType_HighToHighHigh_TransitionNumber:
		return "ExclusiveLimitStateMachineType_HighToHighHigh_TransitionNumber";
	case ObjectId::AggregateFunction_StandardDeviationSample:
		return "AggregateFunction_StandardDeviationSample";
	case ObjectId::AggregateFunction_StandardDeviationPopulation:
		return "AggregateFunction_StandardDeviationPopulation";
	case ObjectId::AggregateFunction_VarianceSample:
		return "AggregateFunction_VarianceSample";
	case ObjectId::AggregateFunction_VariancePopulation:
		return "AggregateFunction_VariancePopulation";
	case ObjectId::EnumStrings:
		return "EnumStrings";
	case ObjectId::ValueAsText:
		return "ValueAsText";
	case ObjectId::ProgressEventType:
		return "ProgressEventType";
	case ObjectId::ProgressEventType_EventId:
		return "ProgressEventType_EventId";
	case ObjectId::ProgressEventType_EventType:
		return "ProgressEventType_EventType";
	case ObjectId::ProgressEventType_SourceNode:
		return "ProgressEventType_SourceNode";
	case ObjectId::ProgressEventType_SourceName:
		return "ProgressEventType_SourceName";
	case ObjectId::ProgressEventType_Time:
		return "ProgressEventType_Time";
	case ObjectId::ProgressEventType_ReceiveTime:
		return "ProgressEventType_ReceiveTime";
	case ObjectId::ProgressEventType_LocalTime:
		return "ProgressEventType_LocalTime";
	case ObjectId::ProgressEventType_Message:
		return "ProgressEventType_Message";
	case ObjectId::ProgressEventType_Severity:
		return "ProgressEventType_Severity";
	case ObjectId::SystemStatusChangeEventType:
		return "SystemStatusChangeEventType";
	case ObjectId::SystemStatusChangeEventType_EventId:
		return "SystemStatusChangeEventType_EventId";
	case ObjectId::SystemStatusChangeEventType_EventType:
		return "SystemStatusChangeEventType_EventType";
	case ObjectId::SystemStatusChangeEventType_SourceNode:
		return "SystemStatusChangeEventType_SourceNode";
	case ObjectId::SystemStatusChangeEventType_SourceName:
		return "SystemStatusChangeEventType_SourceName";
	case ObjectId::SystemStatusChangeEventType_Time:
		return "SystemStatusChangeEventType_Time";
	case ObjectId::SystemStatusChangeEventType_ReceiveTime:
		return "SystemStatusChangeEventType_ReceiveTime";
	case ObjectId::SystemStatusChangeEventType_LocalTime:
		return "SystemStatusChangeEventType_LocalTime";
	case ObjectId::SystemStatusChangeEventType_Message:
		return "SystemStatusChangeEventType_Message";
	case ObjectId::SystemStatusChangeEventType_Severity:
		return "SystemStatusChangeEventType_Severity";
	case ObjectId::TransitionVariableType_EffectiveTransitionTime:
		return "TransitionVariableType_EffectiveTransitionTime";
	case ObjectId::FiniteTransitionVariableType_EffectiveTransitionTime:
		return "FiniteTransitionVariableType_EffectiveTransitionTime";
	case ObjectId::StateMachineType_LastTransition_EffectiveTransitionTime:
		return "StateMachineType_LastTransition_EffectiveTransitionTime";
	case ObjectId::FiniteStateMachineType_LastTransition_EffectiveTransitionTime:
		return "FiniteStateMachineType_LastTransition_EffectiveTransitionTime";
	case ObjectId::TransitionEventType_Transition_EffectiveTransitionTime:
		return "TransitionEventType_Transition_EffectiveTransitionTime";
	case ObjectId::MultiStateValueDiscreteType_ValueAsText:
		return "MultiStateValueDiscreteType_ValueAsText";
	case ObjectId::ProgramTransitionEventType_Transition_EffectiveTransitionTime:
		return "ProgramTransitionEventType_Transition_EffectiveTransitionTime";
	case ObjectId::ProgramTransitionAuditEventType_Transition_EffectiveTransitionTime:
		return "ProgramTransitionAuditEventType_Transition_EffectiveTransitionTime";
	case ObjectId::ProgramStateMachineType_LastTransition_EffectiveTransitionTime:
		return "ProgramStateMachineType_LastTransition_EffectiveTransitionTime";
	case ObjectId::ShelvedStateMachineType_LastTransition_EffectiveTransitionTime:
		return "ShelvedStateMachineType_LastTransition_EffectiveTransitionTime";
	case ObjectId::AlarmConditionType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "AlarmConditionType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::LimitAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "LimitAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::ExclusiveLimitStateMachineType_LastTransition_EffectiveTransitionTime:
		return "ExclusiveLimitStateMachineType_LastTransition_EffectiveTransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "ExclusiveLimitAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::ExclusiveLimitAlarmType_LimitState_LastTransition_EffectiveTransitionTime:
		return "ExclusiveLimitAlarmType_LimitState_LastTransition_EffectiveTransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "ExclusiveLevelAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::ExclusiveLevelAlarmType_LimitState_LastTransition_EffectiveTransitionTime:
		return "ExclusiveLevelAlarmType_LimitState_LastTransition_EffectiveTransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "ExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_EffectiveTransitionTime:
		return "ExclusiveRateOfChangeAlarmType_LimitState_LastTransition_EffectiveTransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "ExclusiveDeviationAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::ExclusiveDeviationAlarmType_LimitState_LastTransition_EffectiveTransitionTime:
		return "ExclusiveDeviationAlarmType_LimitState_LastTransition_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLimitAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "NonExclusiveLimitAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::NonExclusiveLevelAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "NonExclusiveLevelAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "NonExclusiveRateOfChangeAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "NonExclusiveDeviationAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::DiscreteAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "DiscreteAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::OffNormalAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "OffNormalAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::TripAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "TripAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::AuditActivateSessionEventType_SecureChannelId:
		return "AuditActivateSessionEventType_SecureChannelId";
	case ObjectId::OptionSetType:
		return "OptionSetType";
	case ObjectId::OptionSetType_OptionSetValues:
		return "OptionSetType_OptionSetValues";
	case ObjectId::ServerType_GetMonitoredItems:
		return "ServerType_GetMonitoredItems";
	case ObjectId::ServerType_GetMonitoredItems_InputArguments:
		return "ServerType_GetMonitoredItems_InputArguments";
	case ObjectId::ServerType_GetMonitoredItems_OutputArguments:
		return "ServerType_GetMonitoredItems_OutputArguments";
	case ObjectId::Server_GetMonitoredItems:
		return "Server_GetMonitoredItems";
	case ObjectId::Server_GetMonitoredItems_InputArguments:
		return "Server_GetMonitoredItems_InputArguments";
	case ObjectId::Server_GetMonitoredItems_OutputArguments:
		return "Server_GetMonitoredItems_OutputArguments";
	case ObjectId::GetMonitoredItemsMethodType:
		return "GetMonitoredItemsMethodType";
	case ObjectId::GetMonitoredItemsMethodType_InputArguments:
		return "GetMonitoredItemsMethodType_InputArguments";
	case ObjectId::GetMonitoredItemsMethodType_OutputArguments:
		return "GetMonitoredItemsMethodType_OutputArguments";
	case ObjectId::MaxStringLength:
		return "MaxStringLength";
	case ObjectId::HistoricalDataConfigurationType_StartOfArchive:
		return "HistoricalDataConfigurationType_StartOfArchive";
	case ObjectId::HistoricalDataConfigurationType_StartOfOnlineArchive:
		return "HistoricalDataConfigurationType_StartOfOnlineArchive";
	case ObjectId::HistoryServerCapabilitiesType_DeleteEventCapability:
		return "HistoryServerCapabilitiesType_DeleteEventCapability";
	case ObjectId::HistoryServerCapabilities_DeleteEventCapability:
		return "HistoryServerCapabilities_DeleteEventCapability";
	case ObjectId::HAConfiguration_StartOfArchive:
		return "HAConfiguration_StartOfArchive";
	case ObjectId::HAConfiguration_StartOfOnlineArchive:
		return "HAConfiguration_StartOfOnlineArchive";
	case ObjectId::AggregateFunction_StartBound:
		return "AggregateFunction_StartBound";
	case ObjectId::AggregateFunction_EndBound:
		return "AggregateFunction_EndBound";
	case ObjectId::AggregateFunction_DeltaBounds:
		return "AggregateFunction_DeltaBounds";
	case ObjectId::ModellingRule_OptionalPlaceholder:
		return "ModellingRule_OptionalPlaceholder";
	case ObjectId::ModellingRule_OptionalPlaceholder_NamingRule:
		return "ModellingRule_OptionalPlaceholder_NamingRule";
	case ObjectId::ModellingRule_MandatoryPlaceholder:
		return "ModellingRule_MandatoryPlaceholder";
	case ObjectId::ModellingRule_MandatoryPlaceholder_NamingRule:
		return "ModellingRule_MandatoryPlaceholder_NamingRule";
	case ObjectId::MaxArrayLength:
		return "MaxArrayLength";
	case ObjectId::EngineeringUnits:
		return "EngineeringUnits";
	case ObjectId::ServerType_ServerCapabilities_MaxArrayLength:
		return "ServerType_ServerCapabilities_MaxArrayLength";
	case ObjectId::ServerType_ServerCapabilities_MaxStringLength:
		return "ServerType_ServerCapabilities_MaxStringLength";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits:
		return "ServerType_ServerCapabilities_OperationLimits";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxNodesPerRead:
		return "ServerType_ServerCapabilities_OperationLimits_MaxNodesPerRead";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxNodesPerWrite:
		return "ServerType_ServerCapabilities_OperationLimits_MaxNodesPerWrite";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxNodesPerMethodCall:
		return "ServerType_ServerCapabilities_OperationLimits_MaxNodesPerMethodCall";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxNodesPerBrowse:
		return "ServerType_ServerCapabilities_OperationLimits_MaxNodesPerBrowse";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxNodesPerRegisterNodes:
		return "ServerType_ServerCapabilities_OperationLimits_MaxNodesPerRegisterNodes";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxNodesPerTranslateBrowsePathsToNodeIds:
		return "ServerType_ServerCapabilities_OperationLimits_MaxNodesPerTranslateBrowsePathsToNodeIds";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxNodesPerNodeManagement:
		return "ServerType_ServerCapabilities_OperationLimits_MaxNodesPerNodeManagement";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxMonitoredItemsPerCall:
		return "ServerType_ServerCapabilities_OperationLimits_MaxMonitoredItemsPerCall";
	case ObjectId::ServerType_Namespaces:
		return "ServerType_Namespaces";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile:
		return "ServerType_Namespaces_AddressSpaceFile";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Size:
		return "ServerType_Namespaces_AddressSpaceFile_Size";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Writeable:
		return "ServerType_Namespaces_AddressSpaceFile_Writeable";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_UserWriteable:
		return "ServerType_Namespaces_AddressSpaceFile_UserWriteable";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_OpenCount:
		return "ServerType_Namespaces_AddressSpaceFile_OpenCount";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Open:
		return "ServerType_Namespaces_AddressSpaceFile_Open";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Open_InputArguments:
		return "ServerType_Namespaces_AddressSpaceFile_Open_InputArguments";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Open_OutputArguments:
		return "ServerType_Namespaces_AddressSpaceFile_Open_OutputArguments";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Close:
		return "ServerType_Namespaces_AddressSpaceFile_Close";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Close_InputArguments:
		return "ServerType_Namespaces_AddressSpaceFile_Close_InputArguments";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Read:
		return "ServerType_Namespaces_AddressSpaceFile_Read";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Read_InputArguments:
		return "ServerType_Namespaces_AddressSpaceFile_Read_InputArguments";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Read_OutputArguments:
		return "ServerType_Namespaces_AddressSpaceFile_Read_OutputArguments";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Write:
		return "ServerType_Namespaces_AddressSpaceFile_Write";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_Write_InputArguments:
		return "ServerType_Namespaces_AddressSpaceFile_Write_InputArguments";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_GetPosition:
		return "ServerType_Namespaces_AddressSpaceFile_GetPosition";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_GetPosition_InputArguments:
		return "ServerType_Namespaces_AddressSpaceFile_GetPosition_InputArguments";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_GetPosition_OutputArguments:
		return "ServerType_Namespaces_AddressSpaceFile_GetPosition_OutputArguments";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_SetPosition:
		return "ServerType_Namespaces_AddressSpaceFile_SetPosition";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_SetPosition_InputArguments:
		return "ServerType_Namespaces_AddressSpaceFile_SetPosition_InputArguments";
	case ObjectId::ServerType_Namespaces_AddressSpaceFile_ExportNamespace:
		return "ServerType_Namespaces_AddressSpaceFile_ExportNamespace";
	case ObjectId::ServerCapabilitiesType_MaxArrayLength:
		return "ServerCapabilitiesType_MaxArrayLength";
	case ObjectId::ServerCapabilitiesType_MaxStringLength:
		return "ServerCapabilitiesType_MaxStringLength";
	case ObjectId::ServerCapabilitiesType_OperationLimits:
		return "ServerCapabilitiesType_OperationLimits";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxNodesPerRead:
		return "ServerCapabilitiesType_OperationLimits_MaxNodesPerRead";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxNodesPerWrite:
		return "ServerCapabilitiesType_OperationLimits_MaxNodesPerWrite";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxNodesPerMethodCall:
		return "ServerCapabilitiesType_OperationLimits_MaxNodesPerMethodCall";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxNodesPerBrowse:
		return "ServerCapabilitiesType_OperationLimits_MaxNodesPerBrowse";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxNodesPerRegisterNodes:
		return "ServerCapabilitiesType_OperationLimits_MaxNodesPerRegisterNodes";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxNodesPerTranslateBrowsePathsToNodeIds:
		return "ServerCapabilitiesType_OperationLimits_MaxNodesPerTranslateBrowsePathsToNodeIds";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxNodesPerNodeManagement:
		return "ServerCapabilitiesType_OperationLimits_MaxNodesPerNodeManagement";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxMonitoredItemsPerCall:
		return "ServerCapabilitiesType_OperationLimits_MaxMonitoredItemsPerCall";
	case ObjectId::ServerCapabilitiesType_VendorCapability:
		return "ServerCapabilitiesType_VendorCapability";
	case ObjectId::OperationLimitsType:
		return "OperationLimitsType";
	case ObjectId::OperationLimitsType_MaxNodesPerRead:
		return "OperationLimitsType_MaxNodesPerRead";
	case ObjectId::OperationLimitsType_MaxNodesPerWrite:
		return "OperationLimitsType_MaxNodesPerWrite";
	case ObjectId::OperationLimitsType_MaxNodesPerMethodCall:
		return "OperationLimitsType_MaxNodesPerMethodCall";
	case ObjectId::OperationLimitsType_MaxNodesPerBrowse:
		return "OperationLimitsType_MaxNodesPerBrowse";
	case ObjectId::OperationLimitsType_MaxNodesPerRegisterNodes:
		return "OperationLimitsType_MaxNodesPerRegisterNodes";
	case ObjectId::OperationLimitsType_MaxNodesPerTranslateBrowsePathsToNodeIds:
		return "OperationLimitsType_MaxNodesPerTranslateBrowsePathsToNodeIds";
	case ObjectId::OperationLimitsType_MaxNodesPerNodeManagement:
		return "OperationLimitsType_MaxNodesPerNodeManagement";
	case ObjectId::OperationLimitsType_MaxMonitoredItemsPerCall:
		return "OperationLimitsType_MaxMonitoredItemsPerCall";
	case ObjectId::FileType:
		return "FileType";
	case ObjectId::FileType_Size:
		return "FileType_Size";
	case ObjectId::FileType_Writeable:
		return "FileType_Writeable";
	case ObjectId::FileType_UserWriteable:
		return "FileType_UserWriteable";
	case ObjectId::FileType_OpenCount:
		return "FileType_OpenCount";
	case ObjectId::FileType_Open:
		return "FileType_Open";
	case ObjectId::FileType_Open_InputArguments:
		return "FileType_Open_InputArguments";
	case ObjectId::FileType_Open_OutputArguments:
		return "FileType_Open_OutputArguments";
	case ObjectId::FileType_Close:
		return "FileType_Close";
	case ObjectId::FileType_Close_InputArguments:
		return "FileType_Close_InputArguments";
	case ObjectId::FileType_Read:
		return "FileType_Read";
	case ObjectId::FileType_Read_InputArguments:
		return "FileType_Read_InputArguments";
	case ObjectId::FileType_Read_OutputArguments:
		return "FileType_Read_OutputArguments";
	case ObjectId::FileType_Write:
		return "FileType_Write";
	case ObjectId::FileType_Write_InputArguments:
		return "FileType_Write_InputArguments";
	case ObjectId::FileType_GetPosition:
		return "FileType_GetPosition";
	case ObjectId::FileType_GetPosition_InputArguments:
		return "FileType_GetPosition_InputArguments";
	case ObjectId::FileType_GetPosition_OutputArguments:
		return "FileType_GetPosition_OutputArguments";
	case ObjectId::FileType_SetPosition:
		return "FileType_SetPosition";
	case ObjectId::FileType_SetPosition_InputArguments:
		return "FileType_SetPosition_InputArguments";
	case ObjectId::AddressSpaceFileType:
		return "AddressSpaceFileType";
	case ObjectId::AddressSpaceFileType_Size:
		return "AddressSpaceFileType_Size";
	case ObjectId::AddressSpaceFileType_Writeable:
		return "AddressSpaceFileType_Writeable";
	case ObjectId::AddressSpaceFileType_UserWriteable:
		return "AddressSpaceFileType_UserWriteable";
	case ObjectId::AddressSpaceFileType_OpenCount:
		return "AddressSpaceFileType_OpenCount";
	case ObjectId::AddressSpaceFileType_Open:
		return "AddressSpaceFileType_Open";
	case ObjectId::AddressSpaceFileType_Open_InputArguments:
		return "AddressSpaceFileType_Open_InputArguments";
	case ObjectId::AddressSpaceFileType_Open_OutputArguments:
		return "AddressSpaceFileType_Open_OutputArguments";
	case ObjectId::AddressSpaceFileType_Close:
		return "AddressSpaceFileType_Close";
	case ObjectId::AddressSpaceFileType_Close_InputArguments:
		return "AddressSpaceFileType_Close_InputArguments";
	case ObjectId::AddressSpaceFileType_Read:
		return "AddressSpaceFileType_Read";
	case ObjectId::AddressSpaceFileType_Read_InputArguments:
		return "AddressSpaceFileType_Read_InputArguments";
	case ObjectId::AddressSpaceFileType_Read_OutputArguments:
		return "AddressSpaceFileType_Read_OutputArguments";
	case ObjectId::AddressSpaceFileType_Write:
		return "AddressSpaceFileType_Write";
	case ObjectId::AddressSpaceFileType_Write_InputArguments:
		return "AddressSpaceFileType_Write_InputArguments";
	case ObjectId::AddressSpaceFileType_GetPosition:
		return "AddressSpaceFileType_GetPosition";
	case ObjectId::AddressSpaceFileType_GetPosition_InputArguments:
		return "AddressSpaceFileType_GetPosition_InputArguments";
	case ObjectId::AddressSpaceFileType_GetPosition_OutputArguments:
		return "AddressSpaceFileType_GetPosition_OutputArguments";
	case ObjectId::AddressSpaceFileType_SetPosition:
		return "AddressSpaceFileType_SetPosition";
	case ObjectId::AddressSpaceFileType_SetPosition_InputArguments:
		return "AddressSpaceFileType_SetPosition_InputArguments";
	case ObjectId::AddressSpaceFileType_ExportNamespace:
		return "AddressSpaceFileType_ExportNamespace";
	case ObjectId::NamespaceMetadataType:
		return "NamespaceMetadataType";
	case ObjectId::NamespaceMetadataType_NamespaceUri:
		return "NamespaceMetadataType_NamespaceUri";
	case ObjectId::NamespaceMetadataType_NamespaceVersion:
		return "NamespaceMetadataType_NamespaceVersion";
	case ObjectId::NamespaceMetadataType_NamespacePublicationDate:
		return "NamespaceMetadataType_NamespacePublicationDate";
	case ObjectId::NamespaceMetadataType_IsNamespaceSubset:
		return "NamespaceMetadataType_IsNamespaceSubset";
	case ObjectId::NamespaceMetadataType_StaticNodeIdIdentifierTypes:
		return "NamespaceMetadataType_StaticNodeIdIdentifierTypes";
	case ObjectId::NamespaceMetadataType_StaticNumericNodeIdRange:
		return "NamespaceMetadataType_StaticNumericNodeIdRange";
	case ObjectId::NamespaceMetadataType_StaticStringNodeIdPattern:
		return "NamespaceMetadataType_StaticStringNodeIdPattern";
	case ObjectId::NamespaceMetadataType_NamespaceFile:
		return "NamespaceMetadataType_NamespaceFile";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Size:
		return "NamespaceMetadataType_NamespaceFile_Size";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Writeable:
		return "NamespaceMetadataType_NamespaceFile_Writeable";
	case ObjectId::NamespaceMetadataType_NamespaceFile_UserWriteable:
		return "NamespaceMetadataType_NamespaceFile_UserWriteable";
	case ObjectId::NamespaceMetadataType_NamespaceFile_OpenCount:
		return "NamespaceMetadataType_NamespaceFile_OpenCount";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Open:
		return "NamespaceMetadataType_NamespaceFile_Open";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Open_InputArguments:
		return "NamespaceMetadataType_NamespaceFile_Open_InputArguments";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Open_OutputArguments:
		return "NamespaceMetadataType_NamespaceFile_Open_OutputArguments";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Close:
		return "NamespaceMetadataType_NamespaceFile_Close";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Close_InputArguments:
		return "NamespaceMetadataType_NamespaceFile_Close_InputArguments";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Read:
		return "NamespaceMetadataType_NamespaceFile_Read";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Read_InputArguments:
		return "NamespaceMetadataType_NamespaceFile_Read_InputArguments";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Read_OutputArguments:
		return "NamespaceMetadataType_NamespaceFile_Read_OutputArguments";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Write:
		return "NamespaceMetadataType_NamespaceFile_Write";
	case ObjectId::NamespaceMetadataType_NamespaceFile_Write_InputArguments:
		return "NamespaceMetadataType_NamespaceFile_Write_InputArguments";
	case ObjectId::NamespaceMetadataType_NamespaceFile_GetPosition:
		return "NamespaceMetadataType_NamespaceFile_GetPosition";
	case ObjectId::NamespaceMetadataType_NamespaceFile_GetPosition_InputArguments:
		return "NamespaceMetadataType_NamespaceFile_GetPosition_InputArguments";
	case ObjectId::NamespaceMetadataType_NamespaceFile_GetPosition_OutputArguments:
		return "NamespaceMetadataType_NamespaceFile_GetPosition_OutputArguments";
	case ObjectId::NamespaceMetadataType_NamespaceFile_SetPosition:
		return "NamespaceMetadataType_NamespaceFile_SetPosition";
	case ObjectId::NamespaceMetadataType_NamespaceFile_SetPosition_InputArguments:
		return "NamespaceMetadataType_NamespaceFile_SetPosition_InputArguments";
	case ObjectId::NamespaceMetadataType_NamespaceFile_ExportNamespace:
		return "NamespaceMetadataType_NamespaceFile_ExportNamespace";
	case ObjectId::NamespacesType:
		return "NamespacesType";
	case ObjectId::NamespacesType_NamespaceIdentifier:
		return "NamespacesType_NamespaceIdentifier";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceUri:
		return "NamespacesType_NamespaceIdentifier_NamespaceUri";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceVersion:
		return "NamespacesType_NamespaceIdentifier_NamespaceVersion";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespacePublicationDate:
		return "NamespacesType_NamespaceIdentifier_NamespacePublicationDate";
	case ObjectId::NamespacesType_NamespaceIdentifier_IsNamespaceSubset:
		return "NamespacesType_NamespaceIdentifier_IsNamespaceSubset";
	case ObjectId::NamespacesType_NamespaceIdentifier_StaticNodeIdIdentifierTypes:
		return "NamespacesType_NamespaceIdentifier_StaticNodeIdIdentifierTypes";
	case ObjectId::NamespacesType_NamespaceIdentifier_StaticNumericNodeIdRange:
		return "NamespacesType_NamespaceIdentifier_StaticNumericNodeIdRange";
	case ObjectId::NamespacesType_NamespaceIdentifier_StaticStringNodeIdPattern:
		return "NamespacesType_NamespaceIdentifier_StaticStringNodeIdPattern";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Size:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Size";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Writeable:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Writeable";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_UserWriteable:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_UserWriteable";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_OpenCount:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_OpenCount";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Open:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Open";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Open_InputArguments:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Open_InputArguments";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Open_OutputArguments:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Open_OutputArguments";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Close:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Close";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Close_InputArguments:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Close_InputArguments";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Read:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Read";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Read_InputArguments:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Read_InputArguments";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Read_OutputArguments:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Read_OutputArguments";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Write:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Write";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_Write_InputArguments:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_Write_InputArguments";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_GetPosition:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_GetPosition";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_GetPosition_InputArguments:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_GetPosition_InputArguments";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_GetPosition_OutputArguments:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_GetPosition_OutputArguments";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_SetPosition:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_SetPosition";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_SetPosition_InputArguments:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_SetPosition_InputArguments";
	case ObjectId::NamespacesType_NamespaceIdentifier_NamespaceFile_ExportNamespace:
		return "NamespacesType_NamespaceIdentifier_NamespaceFile_ExportNamespace";
	case ObjectId::NamespacesType_AddressSpaceFile:
		return "NamespacesType_AddressSpaceFile";
	case ObjectId::NamespacesType_AddressSpaceFile_Size:
		return "NamespacesType_AddressSpaceFile_Size";
	case ObjectId::NamespacesType_AddressSpaceFile_Writeable:
		return "NamespacesType_AddressSpaceFile_Writeable";
	case ObjectId::NamespacesType_AddressSpaceFile_UserWriteable:
		return "NamespacesType_AddressSpaceFile_UserWriteable";
	case ObjectId::NamespacesType_AddressSpaceFile_OpenCount:
		return "NamespacesType_AddressSpaceFile_OpenCount";
	case ObjectId::NamespacesType_AddressSpaceFile_Open:
		return "NamespacesType_AddressSpaceFile_Open";
	case ObjectId::NamespacesType_AddressSpaceFile_Open_InputArguments:
		return "NamespacesType_AddressSpaceFile_Open_InputArguments";
	case ObjectId::NamespacesType_AddressSpaceFile_Open_OutputArguments:
		return "NamespacesType_AddressSpaceFile_Open_OutputArguments";
	case ObjectId::NamespacesType_AddressSpaceFile_Close:
		return "NamespacesType_AddressSpaceFile_Close";
	case ObjectId::NamespacesType_AddressSpaceFile_Close_InputArguments:
		return "NamespacesType_AddressSpaceFile_Close_InputArguments";
	case ObjectId::NamespacesType_AddressSpaceFile_Read:
		return "NamespacesType_AddressSpaceFile_Read";
	case ObjectId::NamespacesType_AddressSpaceFile_Read_InputArguments:
		return "NamespacesType_AddressSpaceFile_Read_InputArguments";
	case ObjectId::NamespacesType_AddressSpaceFile_Read_OutputArguments:
		return "NamespacesType_AddressSpaceFile_Read_OutputArguments";
	case ObjectId::NamespacesType_AddressSpaceFile_Write:
		return "NamespacesType_AddressSpaceFile_Write";
	case ObjectId::NamespacesType_AddressSpaceFile_Write_InputArguments:
		return "NamespacesType_AddressSpaceFile_Write_InputArguments";
	case ObjectId::NamespacesType_AddressSpaceFile_GetPosition:
		return "NamespacesType_AddressSpaceFile_GetPosition";
	case ObjectId::NamespacesType_AddressSpaceFile_GetPosition_InputArguments:
		return "NamespacesType_AddressSpaceFile_GetPosition_InputArguments";
	case ObjectId::NamespacesType_AddressSpaceFile_GetPosition_OutputArguments:
		return "NamespacesType_AddressSpaceFile_GetPosition_OutputArguments";
	case ObjectId::NamespacesType_AddressSpaceFile_SetPosition:
		return "NamespacesType_AddressSpaceFile_SetPosition";
	case ObjectId::NamespacesType_AddressSpaceFile_SetPosition_InputArguments:
		return "NamespacesType_AddressSpaceFile_SetPosition_InputArguments";
	case ObjectId::NamespacesType_AddressSpaceFile_ExportNamespace:
		return "NamespacesType_AddressSpaceFile_ExportNamespace";
	case ObjectId::SystemStatusChangeEventType_SystemState:
		return "SystemStatusChangeEventType_SystemState";
	case ObjectId::SamplingIntervalDiagnosticsType_SampledMonitoredItemsCount:
		return "SamplingIntervalDiagnosticsType_SampledMonitoredItemsCount";
	case ObjectId::SamplingIntervalDiagnosticsType_MaxSampledMonitoredItemsCount:
		return "SamplingIntervalDiagnosticsType_MaxSampledMonitoredItemsCount";
	case ObjectId::SamplingIntervalDiagnosticsType_DisabledMonitoredItemsSamplingCount:
		return "SamplingIntervalDiagnosticsType_DisabledMonitoredItemsSamplingCount";
	case ObjectId::OptionSetType_BitMask:
		return "OptionSetType_BitMask";
	case ObjectId::Server_ServerCapabilities_MaxArrayLength:
		return "Server_ServerCapabilities_MaxArrayLength";
	case ObjectId::Server_ServerCapabilities_MaxStringLength:
		return "Server_ServerCapabilities_MaxStringLength";
	case ObjectId::Server_ServerCapabilities_OperationLimits:
		return "Server_ServerCapabilities_OperationLimits";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxNodesPerRead:
		return "Server_ServerCapabilities_OperationLimits_MaxNodesPerRead";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxNodesPerWrite:
		return "Server_ServerCapabilities_OperationLimits_MaxNodesPerWrite";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxNodesPerMethodCall:
		return "Server_ServerCapabilities_OperationLimits_MaxNodesPerMethodCall";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxNodesPerBrowse:
		return "Server_ServerCapabilities_OperationLimits_MaxNodesPerBrowse";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxNodesPerRegisterNodes:
		return "Server_ServerCapabilities_OperationLimits_MaxNodesPerRegisterNodes";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxNodesPerTranslateBrowsePathsToNodeIds:
		return "Server_ServerCapabilities_OperationLimits_MaxNodesPerTranslateBrowsePathsToNodeIds";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxNodesPerNodeManagement:
		return "Server_ServerCapabilities_OperationLimits_MaxNodesPerNodeManagement";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxMonitoredItemsPerCall:
		return "Server_ServerCapabilities_OperationLimits_MaxMonitoredItemsPerCall";
	case ObjectId::Server_Namespaces:
		return "Server_Namespaces";
	case ObjectId::Server_Namespaces_AddressSpaceFile:
		return "Server_Namespaces_AddressSpaceFile";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Size:
		return "Server_Namespaces_AddressSpaceFile_Size";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Writeable:
		return "Server_Namespaces_AddressSpaceFile_Writeable";
	case ObjectId::Server_Namespaces_AddressSpaceFile_UserWriteable:
		return "Server_Namespaces_AddressSpaceFile_UserWriteable";
	case ObjectId::Server_Namespaces_AddressSpaceFile_OpenCount:
		return "Server_Namespaces_AddressSpaceFile_OpenCount";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Open:
		return "Server_Namespaces_AddressSpaceFile_Open";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Open_InputArguments:
		return "Server_Namespaces_AddressSpaceFile_Open_InputArguments";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Open_OutputArguments:
		return "Server_Namespaces_AddressSpaceFile_Open_OutputArguments";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Close:
		return "Server_Namespaces_AddressSpaceFile_Close";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Close_InputArguments:
		return "Server_Namespaces_AddressSpaceFile_Close_InputArguments";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Read:
		return "Server_Namespaces_AddressSpaceFile_Read";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Read_InputArguments:
		return "Server_Namespaces_AddressSpaceFile_Read_InputArguments";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Read_OutputArguments:
		return "Server_Namespaces_AddressSpaceFile_Read_OutputArguments";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Write:
		return "Server_Namespaces_AddressSpaceFile_Write";
	case ObjectId::Server_Namespaces_AddressSpaceFile_Write_InputArguments:
		return "Server_Namespaces_AddressSpaceFile_Write_InputArguments";
	case ObjectId::Server_Namespaces_AddressSpaceFile_GetPosition:
		return "Server_Namespaces_AddressSpaceFile_GetPosition";
	case ObjectId::Server_Namespaces_AddressSpaceFile_GetPosition_InputArguments:
		return "Server_Namespaces_AddressSpaceFile_GetPosition_InputArguments";
	case ObjectId::Server_Namespaces_AddressSpaceFile_GetPosition_OutputArguments:
		return "Server_Namespaces_AddressSpaceFile_GetPosition_OutputArguments";
	case ObjectId::Server_Namespaces_AddressSpaceFile_SetPosition:
		return "Server_Namespaces_AddressSpaceFile_SetPosition";
	case ObjectId::Server_Namespaces_AddressSpaceFile_SetPosition_InputArguments:
		return "Server_Namespaces_AddressSpaceFile_SetPosition_InputArguments";
	case ObjectId::Server_Namespaces_AddressSpaceFile_ExportNamespace:
		return "Server_Namespaces_AddressSpaceFile_ExportNamespace";
	case ObjectId::BitFieldMaskDataType:
		return "BitFieldMaskDataType";
	case ObjectId::OpenMethodType:
		return "OpenMethodType";
	case ObjectId::OpenMethodType_InputArguments:
		return "OpenMethodType_InputArguments";
	case ObjectId::OpenMethodType_OutputArguments:
		return "OpenMethodType_OutputArguments";
	case ObjectId::CloseMethodType:
		return "CloseMethodType";
	case ObjectId::CloseMethodType_InputArguments:
		return "CloseMethodType_InputArguments";
	case ObjectId::ReadMethodType:
		return "ReadMethodType";
	case ObjectId::ReadMethodType_InputArguments:
		return "ReadMethodType_InputArguments";
	case ObjectId::ReadMethodType_OutputArguments:
		return "ReadMethodType_OutputArguments";
	case ObjectId::WriteMethodType:
		return "WriteMethodType";
	case ObjectId::WriteMethodType_InputArguments:
		return "WriteMethodType_InputArguments";
	case ObjectId::GetPositionMethodType:
		return "GetPositionMethodType";
	case ObjectId::GetPositionMethodType_InputArguments:
		return "GetPositionMethodType_InputArguments";
	case ObjectId::GetPositionMethodType_OutputArguments:
		return "GetPositionMethodType_OutputArguments";
	case ObjectId::SetPositionMethodType:
		return "SetPositionMethodType";
	case ObjectId::SetPositionMethodType_InputArguments:
		return "SetPositionMethodType_InputArguments";
	case ObjectId::SystemOffNormalAlarmType:
		return "SystemOffNormalAlarmType";
	case ObjectId::SystemOffNormalAlarmType_EventId:
		return "SystemOffNormalAlarmType_EventId";
	case ObjectId::SystemOffNormalAlarmType_EventType:
		return "SystemOffNormalAlarmType_EventType";
	case ObjectId::SystemOffNormalAlarmType_SourceNode:
		return "SystemOffNormalAlarmType_SourceNode";
	case ObjectId::SystemOffNormalAlarmType_SourceName:
		return "SystemOffNormalAlarmType_SourceName";
	case ObjectId::SystemOffNormalAlarmType_Time:
		return "SystemOffNormalAlarmType_Time";
	case ObjectId::SystemOffNormalAlarmType_ReceiveTime:
		return "SystemOffNormalAlarmType_ReceiveTime";
	case ObjectId::SystemOffNormalAlarmType_LocalTime:
		return "SystemOffNormalAlarmType_LocalTime";
	case ObjectId::SystemOffNormalAlarmType_Message:
		return "SystemOffNormalAlarmType_Message";
	case ObjectId::SystemOffNormalAlarmType_Severity:
		return "SystemOffNormalAlarmType_Severity";
	case ObjectId::SystemOffNormalAlarmType_ConditionClassId:
		return "SystemOffNormalAlarmType_ConditionClassId";
	case ObjectId::SystemOffNormalAlarmType_ConditionClassName:
		return "SystemOffNormalAlarmType_ConditionClassName";
	case ObjectId::SystemOffNormalAlarmType_ConditionName:
		return "SystemOffNormalAlarmType_ConditionName";
	case ObjectId::SystemOffNormalAlarmType_BranchId:
		return "SystemOffNormalAlarmType_BranchId";
	case ObjectId::SystemOffNormalAlarmType_Retain:
		return "SystemOffNormalAlarmType_Retain";
	case ObjectId::SystemOffNormalAlarmType_EnabledState:
		return "SystemOffNormalAlarmType_EnabledState";
	case ObjectId::SystemOffNormalAlarmType_EnabledState_Id:
		return "SystemOffNormalAlarmType_EnabledState_Id";
	case ObjectId::SystemOffNormalAlarmType_EnabledState_Name:
		return "SystemOffNormalAlarmType_EnabledState_Name";
	case ObjectId::SystemOffNormalAlarmType_EnabledState_Number:
		return "SystemOffNormalAlarmType_EnabledState_Number";
	case ObjectId::SystemOffNormalAlarmType_EnabledState_EffectiveDisplayName:
		return "SystemOffNormalAlarmType_EnabledState_EffectiveDisplayName";
	case ObjectId::SystemOffNormalAlarmType_EnabledState_TransitionTime:
		return "SystemOffNormalAlarmType_EnabledState_TransitionTime";
	case ObjectId::SystemOffNormalAlarmType_EnabledState_EffectiveTransitionTime:
		return "SystemOffNormalAlarmType_EnabledState_EffectiveTransitionTime";
	case ObjectId::SystemOffNormalAlarmType_EnabledState_TrueState:
		return "SystemOffNormalAlarmType_EnabledState_TrueState";
	case ObjectId::SystemOffNormalAlarmType_EnabledState_FalseState:
		return "SystemOffNormalAlarmType_EnabledState_FalseState";
	case ObjectId::SystemOffNormalAlarmType_Quality:
		return "SystemOffNormalAlarmType_Quality";
	case ObjectId::SystemOffNormalAlarmType_Quality_SourceTimestamp:
		return "SystemOffNormalAlarmType_Quality_SourceTimestamp";
	case ObjectId::SystemOffNormalAlarmType_LastSeverity:
		return "SystemOffNormalAlarmType_LastSeverity";
	case ObjectId::SystemOffNormalAlarmType_LastSeverity_SourceTimestamp:
		return "SystemOffNormalAlarmType_LastSeverity_SourceTimestamp";
	case ObjectId::SystemOffNormalAlarmType_Comment:
		return "SystemOffNormalAlarmType_Comment";
	case ObjectId::SystemOffNormalAlarmType_Comment_SourceTimestamp:
		return "SystemOffNormalAlarmType_Comment_SourceTimestamp";
	case ObjectId::SystemOffNormalAlarmType_ClientUserId:
		return "SystemOffNormalAlarmType_ClientUserId";
	case ObjectId::SystemOffNormalAlarmType_Disable:
		return "SystemOffNormalAlarmType_Disable";
	case ObjectId::SystemOffNormalAlarmType_Enable:
		return "SystemOffNormalAlarmType_Enable";
	case ObjectId::SystemOffNormalAlarmType_AddComment:
		return "SystemOffNormalAlarmType_AddComment";
	case ObjectId::SystemOffNormalAlarmType_AddComment_InputArguments:
		return "SystemOffNormalAlarmType_AddComment_InputArguments";
	case ObjectId::SystemOffNormalAlarmType_ConditionRefresh:
		return "SystemOffNormalAlarmType_ConditionRefresh";
	case ObjectId::SystemOffNormalAlarmType_ConditionRefresh_InputArguments:
		return "SystemOffNormalAlarmType_ConditionRefresh_InputArguments";
	case ObjectId::SystemOffNormalAlarmType_AckedState:
		return "SystemOffNormalAlarmType_AckedState";
	case ObjectId::SystemOffNormalAlarmType_AckedState_Id:
		return "SystemOffNormalAlarmType_AckedState_Id";
	case ObjectId::SystemOffNormalAlarmType_AckedState_Name:
		return "SystemOffNormalAlarmType_AckedState_Name";
	case ObjectId::SystemOffNormalAlarmType_AckedState_Number:
		return "SystemOffNormalAlarmType_AckedState_Number";
	case ObjectId::SystemOffNormalAlarmType_AckedState_EffectiveDisplayName:
		return "SystemOffNormalAlarmType_AckedState_EffectiveDisplayName";
	case ObjectId::SystemOffNormalAlarmType_AckedState_TransitionTime:
		return "SystemOffNormalAlarmType_AckedState_TransitionTime";
	case ObjectId::SystemOffNormalAlarmType_AckedState_EffectiveTransitionTime:
		return "SystemOffNormalAlarmType_AckedState_EffectiveTransitionTime";
	case ObjectId::SystemOffNormalAlarmType_AckedState_TrueState:
		return "SystemOffNormalAlarmType_AckedState_TrueState";
	case ObjectId::SystemOffNormalAlarmType_AckedState_FalseState:
		return "SystemOffNormalAlarmType_AckedState_FalseState";
	case ObjectId::SystemOffNormalAlarmType_ConfirmedState:
		return "SystemOffNormalAlarmType_ConfirmedState";
	case ObjectId::SystemOffNormalAlarmType_ConfirmedState_Id:
		return "SystemOffNormalAlarmType_ConfirmedState_Id";
	case ObjectId::SystemOffNormalAlarmType_ConfirmedState_Name:
		return "SystemOffNormalAlarmType_ConfirmedState_Name";
	case ObjectId::SystemOffNormalAlarmType_ConfirmedState_Number:
		return "SystemOffNormalAlarmType_ConfirmedState_Number";
	case ObjectId::SystemOffNormalAlarmType_ConfirmedState_EffectiveDisplayName:
		return "SystemOffNormalAlarmType_ConfirmedState_EffectiveDisplayName";
	case ObjectId::SystemOffNormalAlarmType_ConfirmedState_TransitionTime:
		return "SystemOffNormalAlarmType_ConfirmedState_TransitionTime";
	case ObjectId::SystemOffNormalAlarmType_ConfirmedState_EffectiveTransitionTime:
		return "SystemOffNormalAlarmType_ConfirmedState_EffectiveTransitionTime";
	case ObjectId::SystemOffNormalAlarmType_ConfirmedState_TrueState:
		return "SystemOffNormalAlarmType_ConfirmedState_TrueState";
	case ObjectId::SystemOffNormalAlarmType_ConfirmedState_FalseState:
		return "SystemOffNormalAlarmType_ConfirmedState_FalseState";
	case ObjectId::SystemOffNormalAlarmType_Acknowledge:
		return "SystemOffNormalAlarmType_Acknowledge";
	case ObjectId::SystemOffNormalAlarmType_Acknowledge_InputArguments:
		return "SystemOffNormalAlarmType_Acknowledge_InputArguments";
	case ObjectId::SystemOffNormalAlarmType_Confirm:
		return "SystemOffNormalAlarmType_Confirm";
	case ObjectId::SystemOffNormalAlarmType_Confirm_InputArguments:
		return "SystemOffNormalAlarmType_Confirm_InputArguments";
	case ObjectId::SystemOffNormalAlarmType_ActiveState:
		return "SystemOffNormalAlarmType_ActiveState";
	case ObjectId::SystemOffNormalAlarmType_ActiveState_Id:
		return "SystemOffNormalAlarmType_ActiveState_Id";
	case ObjectId::SystemOffNormalAlarmType_ActiveState_Name:
		return "SystemOffNormalAlarmType_ActiveState_Name";
	case ObjectId::SystemOffNormalAlarmType_ActiveState_Number:
		return "SystemOffNormalAlarmType_ActiveState_Number";
	case ObjectId::SystemOffNormalAlarmType_ActiveState_EffectiveDisplayName:
		return "SystemOffNormalAlarmType_ActiveState_EffectiveDisplayName";
	case ObjectId::SystemOffNormalAlarmType_ActiveState_TransitionTime:
		return "SystemOffNormalAlarmType_ActiveState_TransitionTime";
	case ObjectId::SystemOffNormalAlarmType_ActiveState_EffectiveTransitionTime:
		return "SystemOffNormalAlarmType_ActiveState_EffectiveTransitionTime";
	case ObjectId::SystemOffNormalAlarmType_ActiveState_TrueState:
		return "SystemOffNormalAlarmType_ActiveState_TrueState";
	case ObjectId::SystemOffNormalAlarmType_ActiveState_FalseState:
		return "SystemOffNormalAlarmType_ActiveState_FalseState";
	case ObjectId::SystemOffNormalAlarmType_InputNode:
		return "SystemOffNormalAlarmType_InputNode";
	case ObjectId::SystemOffNormalAlarmType_SuppressedState:
		return "SystemOffNormalAlarmType_SuppressedState";
	case ObjectId::SystemOffNormalAlarmType_SuppressedState_Id:
		return "SystemOffNormalAlarmType_SuppressedState_Id";
	case ObjectId::SystemOffNormalAlarmType_SuppressedState_Name:
		return "SystemOffNormalAlarmType_SuppressedState_Name";
	case ObjectId::SystemOffNormalAlarmType_SuppressedState_Number:
		return "SystemOffNormalAlarmType_SuppressedState_Number";
	case ObjectId::SystemOffNormalAlarmType_SuppressedState_EffectiveDisplayName:
		return "SystemOffNormalAlarmType_SuppressedState_EffectiveDisplayName";
	case ObjectId::SystemOffNormalAlarmType_SuppressedState_TransitionTime:
		return "SystemOffNormalAlarmType_SuppressedState_TransitionTime";
	case ObjectId::SystemOffNormalAlarmType_SuppressedState_EffectiveTransitionTime:
		return "SystemOffNormalAlarmType_SuppressedState_EffectiveTransitionTime";
	case ObjectId::SystemOffNormalAlarmType_SuppressedState_TrueState:
		return "SystemOffNormalAlarmType_SuppressedState_TrueState";
	case ObjectId::SystemOffNormalAlarmType_SuppressedState_FalseState:
		return "SystemOffNormalAlarmType_SuppressedState_FalseState";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState:
		return "SystemOffNormalAlarmType_ShelvingState";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_CurrentState:
		return "SystemOffNormalAlarmType_ShelvingState_CurrentState";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_CurrentState_Id:
		return "SystemOffNormalAlarmType_ShelvingState_CurrentState_Id";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_CurrentState_Name:
		return "SystemOffNormalAlarmType_ShelvingState_CurrentState_Name";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_CurrentState_Number:
		return "SystemOffNormalAlarmType_ShelvingState_CurrentState_Number";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_CurrentState_EffectiveDisplayName:
		return "SystemOffNormalAlarmType_ShelvingState_CurrentState_EffectiveDisplayName";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_LastTransition:
		return "SystemOffNormalAlarmType_ShelvingState_LastTransition";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_LastTransition_Id:
		return "SystemOffNormalAlarmType_ShelvingState_LastTransition_Id";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_LastTransition_Name:
		return "SystemOffNormalAlarmType_ShelvingState_LastTransition_Name";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_LastTransition_Number:
		return "SystemOffNormalAlarmType_ShelvingState_LastTransition_Number";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_LastTransition_TransitionTime:
		return "SystemOffNormalAlarmType_ShelvingState_LastTransition_TransitionTime";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime:
		return "SystemOffNormalAlarmType_ShelvingState_LastTransition_EffectiveTransitionTime";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_UnshelveTime:
		return "SystemOffNormalAlarmType_ShelvingState_UnshelveTime";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_Unshelve:
		return "SystemOffNormalAlarmType_ShelvingState_Unshelve";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_OneShotShelve:
		return "SystemOffNormalAlarmType_ShelvingState_OneShotShelve";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_TimedShelve:
		return "SystemOffNormalAlarmType_ShelvingState_TimedShelve";
	case ObjectId::SystemOffNormalAlarmType_ShelvingState_TimedShelve_InputArguments:
		return "SystemOffNormalAlarmType_ShelvingState_TimedShelve_InputArguments";
	case ObjectId::SystemOffNormalAlarmType_SuppressedOrShelved:
		return "SystemOffNormalAlarmType_SuppressedOrShelved";
	case ObjectId::SystemOffNormalAlarmType_MaxTimeShelved:
		return "SystemOffNormalAlarmType_MaxTimeShelved";
	case ObjectId::SystemOffNormalAlarmType_NormalState:
		return "SystemOffNormalAlarmType_NormalState";
	case ObjectId::AuditConditionCommentEventType_Comment:
		return "AuditConditionCommentEventType_Comment";
	case ObjectId::AuditConditionRespondEventType_SelectedResponse:
		return "AuditConditionRespondEventType_SelectedResponse";
	case ObjectId::AuditConditionAcknowledgeEventType_Comment:
		return "AuditConditionAcknowledgeEventType_Comment";
	case ObjectId::AuditConditionConfirmEventType_Comment:
		return "AuditConditionConfirmEventType_Comment";
	case ObjectId::AuditConditionShelvingEventType_ShelvingTime:
		return "AuditConditionShelvingEventType_ShelvingTime";
	case ObjectId::AuditProgramTransitionEventType:
		return "AuditProgramTransitionEventType";
	case ObjectId::AuditProgramTransitionEventType_EventId:
		return "AuditProgramTransitionEventType_EventId";
	case ObjectId::AuditProgramTransitionEventType_EventType:
		return "AuditProgramTransitionEventType_EventType";
	case ObjectId::AuditProgramTransitionEventType_SourceNode:
		return "AuditProgramTransitionEventType_SourceNode";
	case ObjectId::AuditProgramTransitionEventType_SourceName:
		return "AuditProgramTransitionEventType_SourceName";
	case ObjectId::AuditProgramTransitionEventType_Time:
		return "AuditProgramTransitionEventType_Time";
	case ObjectId::AuditProgramTransitionEventType_ReceiveTime:
		return "AuditProgramTransitionEventType_ReceiveTime";
	case ObjectId::AuditProgramTransitionEventType_LocalTime:
		return "AuditProgramTransitionEventType_LocalTime";
	case ObjectId::AuditProgramTransitionEventType_Message:
		return "AuditProgramTransitionEventType_Message";
	case ObjectId::AuditProgramTransitionEventType_Severity:
		return "AuditProgramTransitionEventType_Severity";
	case ObjectId::AuditProgramTransitionEventType_ActionTimeStamp:
		return "AuditProgramTransitionEventType_ActionTimeStamp";
	case ObjectId::AuditProgramTransitionEventType_Status:
		return "AuditProgramTransitionEventType_Status";
	case ObjectId::AuditProgramTransitionEventType_ServerId:
		return "AuditProgramTransitionEventType_ServerId";
	case ObjectId::AuditProgramTransitionEventType_ClientAuditEntryId:
		return "AuditProgramTransitionEventType_ClientAuditEntryId";
	case ObjectId::AuditProgramTransitionEventType_ClientUserId:
		return "AuditProgramTransitionEventType_ClientUserId";
	case ObjectId::AuditProgramTransitionEventType_MethodId:
		return "AuditProgramTransitionEventType_MethodId";
	case ObjectId::AuditProgramTransitionEventType_InputArguments:
		return "AuditProgramTransitionEventType_InputArguments";
	case ObjectId::AuditProgramTransitionEventType_OldStateId:
		return "AuditProgramTransitionEventType_OldStateId";
	case ObjectId::AuditProgramTransitionEventType_NewStateId:
		return "AuditProgramTransitionEventType_NewStateId";
	case ObjectId::AuditProgramTransitionEventType_TransitionNumber:
		return "AuditProgramTransitionEventType_TransitionNumber";
	case ObjectId::HistoricalDataConfigurationType_AggregateFunctions:
		return "HistoricalDataConfigurationType_AggregateFunctions";
	case ObjectId::HAConfiguration_AggregateFunctions:
		return "HAConfiguration_AggregateFunctions";
	case ObjectId::NodeClass_EnumValues:
		return "NodeClass_EnumValues";
	case ObjectId::InstanceNode:
		return "InstanceNode";
	case ObjectId::TypeNode:
		return "TypeNode";
	case ObjectId::NodeAttributesMask_EnumValues:
		return "NodeAttributesMask_EnumValues";
	case ObjectId::AttributeWriteMask_EnumValues:
		return "AttributeWriteMask_EnumValues";
	case ObjectId::BrowseResultMask_EnumValues:
		return "BrowseResultMask_EnumValues";
	case ObjectId::HistoryUpdateType_EnumValues:
		return "HistoryUpdateType_EnumValues";
	case ObjectId::PerformUpdateType_EnumValues:
		return "PerformUpdateType_EnumValues";
	case ObjectId::EnumeratedTestType_EnumValues:
		return "EnumeratedTestType_EnumValues";
	case ObjectId::InstanceNode_Encoding_DefaultXml:
		return "InstanceNode_Encoding_DefaultXml";
	case ObjectId::TypeNode_Encoding_DefaultXml:
		return "TypeNode_Encoding_DefaultXml";
	case ObjectId::InstanceNode_Encoding_DefaultBinary:
		return "InstanceNode_Encoding_DefaultBinary";
	case ObjectId::TypeNode_Encoding_DefaultBinary:
		return "TypeNode_Encoding_DefaultBinary";
	case ObjectId::SessionDiagnosticsObjectType_SessionDiagnostics_UnauthorizedRequestCount:
		return "SessionDiagnosticsObjectType_SessionDiagnostics_UnauthorizedRequestCount";
	case ObjectId::SessionDiagnosticsVariableType_UnauthorizedRequestCount:
		return "SessionDiagnosticsVariableType_UnauthorizedRequestCount";
	case ObjectId::OpenFileMode:
		return "OpenFileMode";
	case ObjectId::OpenFileMode_EnumValues:
		return "OpenFileMode_EnumValues";
	case ObjectId::ModelChangeStructureVerbMask:
		return "ModelChangeStructureVerbMask";
	case ObjectId::ModelChangeStructureVerbMask_EnumValues:
		return "ModelChangeStructureVerbMask_EnumValues";
	case ObjectId::EndpointUrlListDataType:
		return "EndpointUrlListDataType";
	case ObjectId::NetworkGroupDataType:
		return "NetworkGroupDataType";
	case ObjectId::NonTransparentNetworkRedundancyType:
		return "NonTransparentNetworkRedundancyType";
	case ObjectId::NonTransparentNetworkRedundancyType_RedundancySupport:
		return "NonTransparentNetworkRedundancyType_RedundancySupport";
	case ObjectId::NonTransparentNetworkRedundancyType_ServerUriArray:
		return "NonTransparentNetworkRedundancyType_ServerUriArray";
	case ObjectId::NonTransparentNetworkRedundancyType_ServerNetworkGroups:
		return "NonTransparentNetworkRedundancyType_ServerNetworkGroups";
	case ObjectId::EndpointUrlListDataType_Encoding_DefaultXml:
		return "EndpointUrlListDataType_Encoding_DefaultXml";
	case ObjectId::NetworkGroupDataType_Encoding_DefaultXml:
		return "NetworkGroupDataType_Encoding_DefaultXml";
	case ObjectId::OpcUa_XmlSchema_EndpointUrlListDataType:
		return "OpcUa_XmlSchema_EndpointUrlListDataType";
	case ObjectId::OpcUa_XmlSchema_EndpointUrlListDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_EndpointUrlListDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_EndpointUrlListDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_EndpointUrlListDataType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_NetworkGroupDataType:
		return "OpcUa_XmlSchema_NetworkGroupDataType";
	case ObjectId::OpcUa_XmlSchema_NetworkGroupDataType_DataTypeVersion:
		return "OpcUa_XmlSchema_NetworkGroupDataType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_NetworkGroupDataType_DictionaryFragment:
		return "OpcUa_XmlSchema_NetworkGroupDataType_DictionaryFragment";
	case ObjectId::EndpointUrlListDataType_Encoding_DefaultBinary:
		return "EndpointUrlListDataType_Encoding_DefaultBinary";
	case ObjectId::NetworkGroupDataType_Encoding_DefaultBinary:
		return "NetworkGroupDataType_Encoding_DefaultBinary";
	case ObjectId::OpcUa_BinarySchema_EndpointUrlListDataType:
		return "OpcUa_BinarySchema_EndpointUrlListDataType";
	case ObjectId::OpcUa_BinarySchema_EndpointUrlListDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_EndpointUrlListDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_EndpointUrlListDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_EndpointUrlListDataType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_NetworkGroupDataType:
		return "OpcUa_BinarySchema_NetworkGroupDataType";
	case ObjectId::OpcUa_BinarySchema_NetworkGroupDataType_DataTypeVersion:
		return "OpcUa_BinarySchema_NetworkGroupDataType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_NetworkGroupDataType_DictionaryFragment:
		return "OpcUa_BinarySchema_NetworkGroupDataType_DictionaryFragment";
	case ObjectId::ArrayItemType:
		return "ArrayItemType";
	case ObjectId::ArrayItemType_Definition:
		return "ArrayItemType_Definition";
	case ObjectId::ArrayItemType_ValuePrecision:
		return "ArrayItemType_ValuePrecision";
	case ObjectId::ArrayItemType_InstrumentRange:
		return "ArrayItemType_InstrumentRange";
	case ObjectId::ArrayItemType_EURange:
		return "ArrayItemType_EURange";
	case ObjectId::ArrayItemType_EngineeringUnits:
		return "ArrayItemType_EngineeringUnits";
	case ObjectId::ArrayItemType_Title:
		return "ArrayItemType_Title";
	case ObjectId::ArrayItemType_AxisScaleType:
		return "ArrayItemType_AxisScaleType";
	case ObjectId::YArrayItemType:
		return "YArrayItemType";
	case ObjectId::YArrayItemType_Definition:
		return "YArrayItemType_Definition";
	case ObjectId::YArrayItemType_ValuePrecision:
		return "YArrayItemType_ValuePrecision";
	case ObjectId::YArrayItemType_InstrumentRange:
		return "YArrayItemType_InstrumentRange";
	case ObjectId::YArrayItemType_EURange:
		return "YArrayItemType_EURange";
	case ObjectId::YArrayItemType_EngineeringUnits:
		return "YArrayItemType_EngineeringUnits";
	case ObjectId::YArrayItemType_Title:
		return "YArrayItemType_Title";
	case ObjectId::YArrayItemType_AxisScaleType:
		return "YArrayItemType_AxisScaleType";
	case ObjectId::YArrayItemType_XAxisDefinition:
		return "YArrayItemType_XAxisDefinition";
	case ObjectId::XYArrayItemType:
		return "XYArrayItemType";
	case ObjectId::XYArrayItemType_Definition:
		return "XYArrayItemType_Definition";
	case ObjectId::XYArrayItemType_ValuePrecision:
		return "XYArrayItemType_ValuePrecision";
	case ObjectId::XYArrayItemType_InstrumentRange:
		return "XYArrayItemType_InstrumentRange";
	case ObjectId::XYArrayItemType_EURange:
		return "XYArrayItemType_EURange";
	case ObjectId::XYArrayItemType_EngineeringUnits:
		return "XYArrayItemType_EngineeringUnits";
	case ObjectId::XYArrayItemType_Title:
		return "XYArrayItemType_Title";
	case ObjectId::XYArrayItemType_AxisScaleType:
		return "XYArrayItemType_AxisScaleType";
	case ObjectId::XYArrayItemType_XAxisDefinition:
		return "XYArrayItemType_XAxisDefinition";
	case ObjectId::ImageItemType:
		return "ImageItemType";
	case ObjectId::ImageItemType_Definition:
		return "ImageItemType_Definition";
	case ObjectId::ImageItemType_ValuePrecision:
		return "ImageItemType_ValuePrecision";
	case ObjectId::ImageItemType_InstrumentRange:
		return "ImageItemType_InstrumentRange";
	case ObjectId::ImageItemType_EURange:
		return "ImageItemType_EURange";
	case ObjectId::ImageItemType_EngineeringUnits:
		return "ImageItemType_EngineeringUnits";
	case ObjectId::ImageItemType_Title:
		return "ImageItemType_Title";
	case ObjectId::ImageItemType_AxisScaleType:
		return "ImageItemType_AxisScaleType";
	case ObjectId::ImageItemType_XAxisDefinition:
		return "ImageItemType_XAxisDefinition";
	case ObjectId::ImageItemType_YAxisDefinition:
		return "ImageItemType_YAxisDefinition";
	case ObjectId::CubeItemType:
		return "CubeItemType";
	case ObjectId::CubeItemType_Definition:
		return "CubeItemType_Definition";
	case ObjectId::CubeItemType_ValuePrecision:
		return "CubeItemType_ValuePrecision";
	case ObjectId::CubeItemType_InstrumentRange:
		return "CubeItemType_InstrumentRange";
	case ObjectId::CubeItemType_EURange:
		return "CubeItemType_EURange";
	case ObjectId::CubeItemType_EngineeringUnits:
		return "CubeItemType_EngineeringUnits";
	case ObjectId::CubeItemType_Title:
		return "CubeItemType_Title";
	case ObjectId::CubeItemType_AxisScaleType:
		return "CubeItemType_AxisScaleType";
	case ObjectId::CubeItemType_XAxisDefinition:
		return "CubeItemType_XAxisDefinition";
	case ObjectId::CubeItemType_YAxisDefinition:
		return "CubeItemType_YAxisDefinition";
	case ObjectId::CubeItemType_ZAxisDefinition:
		return "CubeItemType_ZAxisDefinition";
	case ObjectId::NDimensionArrayItemType:
		return "NDimensionArrayItemType";
	case ObjectId::NDimensionArrayItemType_Definition:
		return "NDimensionArrayItemType_Definition";
	case ObjectId::NDimensionArrayItemType_ValuePrecision:
		return "NDimensionArrayItemType_ValuePrecision";
	case ObjectId::NDimensionArrayItemType_InstrumentRange:
		return "NDimensionArrayItemType_InstrumentRange";
	case ObjectId::NDimensionArrayItemType_EURange:
		return "NDimensionArrayItemType_EURange";
	case ObjectId::NDimensionArrayItemType_EngineeringUnits:
		return "NDimensionArrayItemType_EngineeringUnits";
	case ObjectId::NDimensionArrayItemType_Title:
		return "NDimensionArrayItemType_Title";
	case ObjectId::NDimensionArrayItemType_AxisScaleType:
		return "NDimensionArrayItemType_AxisScaleType";
	case ObjectId::NDimensionArrayItemType_AxisDefinition:
		return "NDimensionArrayItemType_AxisDefinition";
	case ObjectId::AxisScaleEnumeration:
		return "AxisScaleEnumeration";
	case ObjectId::AxisScaleEnumeration_EnumStrings:
		return "AxisScaleEnumeration_EnumStrings";
	case ObjectId::AxisInformation:
		return "AxisInformation";
	case ObjectId::XVType:
		return "XVType";
	case ObjectId::AxisInformation_Encoding_DefaultXml:
		return "AxisInformation_Encoding_DefaultXml";
	case ObjectId::XVType_Encoding_DefaultXml:
		return "XVType_Encoding_DefaultXml";
	case ObjectId::OpcUa_XmlSchema_AxisInformation:
		return "OpcUa_XmlSchema_AxisInformation";
	case ObjectId::OpcUa_XmlSchema_AxisInformation_DataTypeVersion:
		return "OpcUa_XmlSchema_AxisInformation_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_AxisInformation_DictionaryFragment:
		return "OpcUa_XmlSchema_AxisInformation_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_XVType:
		return "OpcUa_XmlSchema_XVType";
	case ObjectId::OpcUa_XmlSchema_XVType_DataTypeVersion:
		return "OpcUa_XmlSchema_XVType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_XVType_DictionaryFragment:
		return "OpcUa_XmlSchema_XVType_DictionaryFragment";
	case ObjectId::AxisInformation_Encoding_DefaultBinary:
		return "AxisInformation_Encoding_DefaultBinary";
	case ObjectId::XVType_Encoding_DefaultBinary:
		return "XVType_Encoding_DefaultBinary";
	case ObjectId::OpcUa_BinarySchema_AxisInformation:
		return "OpcUa_BinarySchema_AxisInformation";
	case ObjectId::OpcUa_BinarySchema_AxisInformation_DataTypeVersion:
		return "OpcUa_BinarySchema_AxisInformation_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_AxisInformation_DictionaryFragment:
		return "OpcUa_BinarySchema_AxisInformation_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_XVType:
		return "OpcUa_BinarySchema_XVType";
	case ObjectId::OpcUa_BinarySchema_XVType_DataTypeVersion:
		return "OpcUa_BinarySchema_XVType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_XVType_DictionaryFragment:
		return "OpcUa_BinarySchema_XVType_DictionaryFragment";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SessionId:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SessionId";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SessionName:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SessionName";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ClientDescription:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ClientDescription";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ServerUri:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ServerUri";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_EndpointUrl:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_EndpointUrl";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_LocaleIds:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_LocaleIds";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ActualSessionTimeout:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ActualSessionTimeout";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_MaxResponseMessageSize:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_MaxResponseMessageSize";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ClientConnectionTime:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ClientConnectionTime";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ClientLastContactTime:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ClientLastContactTime";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CurrentSubscriptionsCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CurrentSubscriptionsCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CurrentMonitoredItemsCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CurrentMonitoredItemsCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CurrentPublishRequestsInQueue:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CurrentPublishRequestsInQueue";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_TotalRequestCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_TotalRequestCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_UnauthorizedRequestCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_UnauthorizedRequestCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ReadCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ReadCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_HistoryReadCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_HistoryReadCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_WriteCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_WriteCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_HistoryUpdateCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_HistoryUpdateCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CallCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CallCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CreateMonitoredItemsCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CreateMonitoredItemsCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ModifyMonitoredItemsCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ModifyMonitoredItemsCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SetMonitoringModeCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SetMonitoringModeCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SetTriggeringCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SetTriggeringCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteMonitoredItemsCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteMonitoredItemsCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CreateSubscriptionCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_CreateSubscriptionCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ModifySubscriptionCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_ModifySubscriptionCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SetPublishingModeCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_SetPublishingModeCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_PublishCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_PublishCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_RepublishCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_RepublishCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_TransferSubscriptionsCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_TransferSubscriptionsCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteSubscriptionsCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteSubscriptionsCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_AddNodesCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_AddNodesCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_AddReferencesCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_AddReferencesCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteNodesCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteNodesCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteReferencesCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_DeleteReferencesCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_BrowseCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_BrowseCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_BrowseNextCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_BrowseNextCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_TranslateBrowsePathsToNodeIdsCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_TranslateBrowsePathsToNodeIdsCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_QueryFirstCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_QueryFirstCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_QueryNextCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_QueryNextCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_RegisterNodesCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_RegisterNodesCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_UnregisterNodesCount:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionDiagnostics_UnregisterNodesCount";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_SessionId:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_SessionId";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_ClientUserIdOfSession:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_ClientUserIdOfSession";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_ClientUserIdHistory:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_ClientUserIdHistory";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_AuthenticationMechanism:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_AuthenticationMechanism";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_Encoding:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_Encoding";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_TransportProtocol:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_TransportProtocol";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_SecurityMode:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_SecurityMode";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_SecurityPolicyUri:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_SecurityPolicyUri";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_ClientCertificate:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SessionSecurityDiagnostics_ClientCertificate";
	case ObjectId::SessionsDiagnosticsSummaryType_SessionPlaceholder_SubscriptionDiagnosticsArray:
		return "SessionsDiagnosticsSummaryType_SessionPlaceholder_SubscriptionDiagnosticsArray";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadData:
		return "ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadData";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadEvents:
		return "ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadEvents";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateData:
		return "ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateData";
	case ObjectId::ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateEvents:
		return "ServerType_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateEvents";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryReadData:
		return "ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryReadData";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryReadEvents:
		return "ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryReadEvents";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryUpdateData:
		return "ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryUpdateData";
	case ObjectId::ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryUpdateEvents:
		return "ServerCapabilitiesType_OperationLimits_MaxNodesPerHistoryUpdateEvents";
	case ObjectId::OperationLimitsType_MaxNodesPerHistoryReadData:
		return "OperationLimitsType_MaxNodesPerHistoryReadData";
	case ObjectId::OperationLimitsType_MaxNodesPerHistoryReadEvents:
		return "OperationLimitsType_MaxNodesPerHistoryReadEvents";
	case ObjectId::OperationLimitsType_MaxNodesPerHistoryUpdateData:
		return "OperationLimitsType_MaxNodesPerHistoryUpdateData";
	case ObjectId::OperationLimitsType_MaxNodesPerHistoryUpdateEvents:
		return "OperationLimitsType_MaxNodesPerHistoryUpdateEvents";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadData:
		return "Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadData";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadEvents:
		return "Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryReadEvents";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateData:
		return "Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateData";
	case ObjectId::Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateEvents:
		return "Server_ServerCapabilities_OperationLimits_MaxNodesPerHistoryUpdateEvents";
	case ObjectId::NamingRuleType_EnumValues:
		return "NamingRuleType_EnumValues";
	case ObjectId::ViewVersion:
		return "ViewVersion";
	case ObjectId::ComplexNumberType:
		return "ComplexNumberType";
	case ObjectId::DoubleComplexNumberType:
		return "DoubleComplexNumberType";
	case ObjectId::ComplexNumberType_Encoding_DefaultXml:
		return "ComplexNumberType_Encoding_DefaultXml";
	case ObjectId::DoubleComplexNumberType_Encoding_DefaultXml:
		return "DoubleComplexNumberType_Encoding_DefaultXml";
	case ObjectId::OpcUa_XmlSchema_ComplexNumberType:
		return "OpcUa_XmlSchema_ComplexNumberType";
	case ObjectId::OpcUa_XmlSchema_ComplexNumberType_DataTypeVersion:
		return "OpcUa_XmlSchema_ComplexNumberType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_ComplexNumberType_DictionaryFragment:
		return "OpcUa_XmlSchema_ComplexNumberType_DictionaryFragment";
	case ObjectId::OpcUa_XmlSchema_DoubleComplexNumberType:
		return "OpcUa_XmlSchema_DoubleComplexNumberType";
	case ObjectId::OpcUa_XmlSchema_DoubleComplexNumberType_DataTypeVersion:
		return "OpcUa_XmlSchema_DoubleComplexNumberType_DataTypeVersion";
	case ObjectId::OpcUa_XmlSchema_DoubleComplexNumberType_DictionaryFragment:
		return "OpcUa_XmlSchema_DoubleComplexNumberType_DictionaryFragment";
	case ObjectId::ComplexNumberType_Encoding_DefaultBinary:
		return "ComplexNumberType_Encoding_DefaultBinary";
	case ObjectId::DoubleComplexNumberType_Encoding_DefaultBinary:
		return "DoubleComplexNumberType_Encoding_DefaultBinary";
	case ObjectId::OpcUa_BinarySchema_ComplexNumberType:
		return "OpcUa_BinarySchema_ComplexNumberType";
	case ObjectId::OpcUa_BinarySchema_ComplexNumberType_DataTypeVersion:
		return "OpcUa_BinarySchema_ComplexNumberType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_ComplexNumberType_DictionaryFragment:
		return "OpcUa_BinarySchema_ComplexNumberType_DictionaryFragment";
	case ObjectId::OpcUa_BinarySchema_DoubleComplexNumberType:
		return "OpcUa_BinarySchema_DoubleComplexNumberType";
	case ObjectId::OpcUa_BinarySchema_DoubleComplexNumberType_DataTypeVersion:
		return "OpcUa_BinarySchema_DoubleComplexNumberType_DataTypeVersion";
	case ObjectId::OpcUa_BinarySchema_DoubleComplexNumberType_DictionaryFragment:
		return "OpcUa_BinarySchema_DoubleComplexNumberType_DictionaryFragment";
	default:
	{
		//std::stringstream result;
		//result << "unknown(" << static_cast<int>(value) << ")";
		//return result.str();
		return "";
	}
	}
}
